package com.tvhelper.color

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * 独立下拉状态栏快捷开关：专控“点探索栏快切列表”新功能，与原“TV标记开关”完全隔离
 */
class ExploreJumpTileService : TileService() {

    companion object {
        fun requestTileSync(context: Context) {
            try {
                requestListeningState(
                    context.applicationContext,
                    ComponentName(context.applicationContext, ExploreJumpTileService::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }

    override fun onTileAdded() {
        super.onTileAdded()
        AppStore.init(this)
        updateTileAppearance()
    }

    override fun onStartListening() {
        super.onStartListening()
        AppStore.init(this)
        updateTileAppearance()
    }

    override fun onClick() {
        super.onClick()
        AppStore.init(this)
        val nextEnabled = !AppStore.isExploreJumpEnabled()
        AppStore.setExploreJumpEnabled(this, nextEnabled, source = "状态栏列表快切开关")
        updateTileAppearance()
    }

    private fun updateTileAppearance() {
        val tile = qsTile ?: return
        val enabled = AppStore.isExploreJumpEnabled()
        tile.label = getString(R.string.explore_tile_label)
        tile.subtitle = if (enabled) "已开启" else "已关闭"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_jump)
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
