package com.tvhelper.color

object CatalogDefaultData {
    // 升级内置版本号：覆盖安装后自动载入完整 12 列表 / 509 品种《品种大全》
    const val BUILTIN_VERSION = 3

    val RAW_TEXT: String = """
(●—●)-1商

★外金
GOLD——黄金—TVC
SILVER——白银—TVC
PLATINUM——铂金—TVC
PALLADIUM——钯金—TVC
XCUUSD——高级铜—CAPITALCOM
COPPER——LME伦铜—IG
LEAD——铅—IG
ZINC——锌—IG
ALUMINIUM——铝—IG
★能源
USOIL——WTI原油—TVC
UKOIL——布伦特原油—TVC
RBOBGASOLINE——美国无铅汽油—CMCMARKETS
LONDONGAS——欧洲ICE低硫柴油—IG
HEATINGOIL——取暖油—IG
NATURALGAS——美国亨利港天然气—IG
TFM1! D——欧洲大陆天然气—ICEENDEX
GWM1! D——英国天然气—ICEEUR
CARBONF——碳排放—FX
★软商
USWHEAT 美小麦
OATS 燕麦
ROUGHRICE 大米
CORN 玉米
SOYBEAN 大豆
SOYOIL 豆油
ZM1! 豆粕期货
SOYMEAL 豆粕
LIVECATTLE 活牛
LEANHOGS 瘦肉猪
USSUGAR 纽商糖
UKSUGAR 伦敦糖
COTTON 棉花
USCOCOA 可可
USCOFFEE 阿拉比卡咖啡
ROBCOFFEE 罗布斯塔咖啡
ORANGEJUICE 橙汁
USLUMBER 木材
★加密
CRYPTOB10——数字加密货币指数—IG
BTCUSD
ETHUSD
BNBUSD
SOLUSD
ETHBTC
BCHBTC
★IG上没有品种
BCOMNI——镍
FEEDERCATTLE——饲牛


(●—●)-2指

△中金所
IH1! D——上证50
IF1! D——沪深300
IC1! D——中证500
IM1! D——中证1000
△国港指
CHN50——A50—FX
XINHUA——A50—IG
HANGSENG——恒生指数—IG
HSCEI——恒生国企—HSI
HSTECH——恒生科技—IG
HHI1! D——H股指数—HKEX
CHINAHSHARES——H股指数—IG
△美股
DOW——道指—IG
NASDAQ——纳指—IG
SPTRD——标普—IG
RUSSELL——罗素2000—IG
MAGS——美股七雄指数 Roundhill科技七巨头ETF—CBOE
NYFANG - D——纽交所FANG+指数—ICE
FANG—纽交所FANG+指数—IG
△非欧美各国
NI225——日经平均指数Nikkei225—TVC
TOPIX——东证股价指数—TSE
TOPIX——东京第一板块指数 同上—IG
TAIEX——富时台湾RIC上限指数—THINKMARKETS
SINGAPORE——新加坡蓝筹指数—IG
NIFTY——印度Nifty50指数—NSE
SAF——南非40指数—IG
ASX——澳大利亚S&P/ASX指数—IG
△欧洲斯托克
STXE——欧洲斯托克50指数—IG
SXXP——斯托克欧洲600指数—STOXX
SX7P——斯托克欧洲600银行指数—STOXX
△欧洲各国
FTSE——英国富时100指数—IG
DAX——德国DAX指数—IG
TECDAX——德国科技30指数—IG
FRA40——法国CAC40指数—FX
CAC——法国CAC40指数—IG
SMI——瑞士蓝筹指数—IG
IBEX——西班牙IBEX35指数—IG
AEX——荷兰25指数—IG
OMX——瑞典30指数—IG
OBX——挪威25指数—IG
△其它
MME1!——MSCI新兴市场指数期货—ICEUS
VOLX——标普500波动率指数期货(VIX)—FX
VOLATILITYINDEX——标普500波动率指数期货(VIX)—IG
FVS1!——欧洲斯托克50指数 波动率指数期货—EUREX
EUVOLATILITYINDEX——欧洲斯托克50指数 波动率指数期货—IG

(●—●)-3基

★基商
U.UN▰ 实物铀-伦
REMX▰稀土股-美
PICK▰矿搞剔金银股-美
REET▰全球房地产-美
★基中
GXC▰标普中国BMI指-美
MCHI▰MSCI中国指-美
0AC7▰MSCI中国指-伦
KWEB▰中证海外中国互联网指-美
KWEB▰中证海外中国互联网指-伦
CXSE▰中国非国有企业-美
★基它
EWY▰韩股-美
IKO▰韩股-澳
VNM▰越股-美
KSA▰沙特股-美
IKSA▰沙特股-伦
LEER▰东欧股-德交所-欧元
EPOL▰波兰股-美
XIC▰加拿大全股-多伦多所-加元
XIU▰加拿大60股-多伦多所-加元
EWW▰墨西哥股-美
ILF▰拉丁美洲40股-美
EWZ▰巴西46股-美
ARGT▰美国阿根廷股-美
ECH▰智利股-美


(●—●)-4❶中一

▲美中概
BABA 阿里巴巴
PDD 拼多多
NTES 网易
ONC 百济神州
BIDU 百度
JD 京东
TCOM 携程网
ZTO 中通快递
BEKE 贝壳
FUTU 富途
BILI 哔哩哔哩
▲中一
700 腾讯控股
9988 阿里巴巴
3690 美团
9961 携程集团
9618 京东
9888 百度
9999 网易
1024 快手
9626 哔哩哔哩
2513 智谱
6082 壁仞科技
100 MINIMAX
3888 金山软件
3986 兆易创新
1347 华虹宏力
522 ASMPT
300 美的集团
1810 小米集团
992 联想集团
2382 舜宇光学科技
9660 地平线机器人
1211 比亚迪股份
175 吉利汽车
9973 奇瑞汽车
3750 宁德时代
3606 福耀玻璃
2050 三花智控
1398 工商银行
939 建设银行
1288 农业银行
3988 中国银行
3968 招商银行
5 汇丰控股
2388 中银香港
2888 渣打集团
2318 中国平安
1299 友邦保险
2328 中国财险
388 香港交易所
6030 中信证券
3908 中金公司
267 中信股份

(●—●)-4❶中二

▲中二
857 中国石油
386 中国石化
1088 中国神华
1816 中广核电力
836 华润电力
2899 紫金矿业
3993 洛阳钼业
1378 中国宏桥
9633 农夫山泉
2097 蜜雪集团
3288 海天味业
288 万洲国际
2319 蒙牛乳业
291 华润啤酒
2020 安踏体育
3998 波司登
1768 鸣鸣很忙
9992 泡泡玛特
6160 百济神州
2367 巨子生物
1276 恒瑞医药
1801 信达生物
1093 石药集团
1177 中国生物制药
9926 康方生物
2359 药明康德
2269 药明生物
16 新鸿基地产
1 长和
66 港铁公司
1113 长实集团
2338 潍柴动力
6031 三一重工
1766 中国中车
1072 东方电气
2039 中集集团
669 创科实业
6936 顺丰控股
2057 中通快递
1519 极兔速递


(●—●)-4❷美一

▲美一
AAPL—苹果
GOOGL—谷歌
MSFT—微软
AMZN—亚马逊
META—Meta
NVDA—英伟达
AVGO—博通
AMD—超威半导体
INTC—英特尔
TXN—德州仪器
QCOM—高通
AMAT—应用材料
GLW—康宁
MU—美光科技
WDC—西部数据
CSCO—思科
ORCL—甲骨文
PANW—帕洛阿尔托网络
IBM—IBM
ADBE—Adobe
NFLX—奈飞
UBER—优步
ABNB—爱彼迎
JPM—摩根大通
BAC—美国银行
WFC—富国银行
C—花旗集团
BRK.A—伯克希尔哈撒韦
MS—摩根士丹利
GS—高盛
BLK—贝莱德
BX—黑石集团
SCHW—嘉信理财
IBKR—盈透证券
SPGI—标普全球
CME—芝加哥商品交易所
ICE—洲际交易所
MCO—穆迪
V—Visa
MA—万事达
AXP—美国运通


(●—●)-4❷美二

▲美二
LLY—礼来
JNJ—强生
MRK—默沙东
AMGN—安进
PFE—辉瑞
REGN—再生元制药
UNH—联合健康
BSX—波士顿科学
KO—可口可乐
PG—宝洁
PEP—百事可乐
MNST—怪兽饮料
CL—高露洁
WMT—沃尔玛
COST—好市多
HD—家得宝
LOW—劳氏
MCD—麦当劳
DIS—迪士尼
SBUX—星巴克
MAR—万豪国际
HLT—希尔顿
NKE—耐克
TSLA—特斯拉
GM—通用汽车
F—福特汽车
STLA—斯特兰蒂斯
GE—GE航天航空
RTX—雷神技术
LMT—洛克希德马丁
BA—波音
GD—通用动力
CAT—卡特彼勒
DE—约翰迪尔
MMM—3M公司
EMR—艾默生电气
HON—霍尼韦尔
UNP—联合太平洋
FDX—联邦快递
XOM—埃克森美孚
CVX—雪佛龙
RIO—力拓集团
SO—南方公司
AEP—美国电力公司
ADM—ADM
BG—邦吉
GRMN—佳明


(●—●)-4❸欧概

●美德概
SAP—思爱普
●美英概
〓医药健康
AZN—阿斯利康
GSK—葛兰素史克
〓科技与数据
ARM—安谋
RELX—励讯集团
〓传统能源
SHEL—壳牌
BP—英国石油
〓金融银行
HSBC—汇丰控股
BCS—巴克莱银行
〓日常消费
BTI—英美烟草
UL—联合利华
〓公用事业
NGG—英国国家电网
〓商业服务
RTO—能多洁
〓可选消费与服务
VOD—沃达丰
IHG—洲际酒店集团
●美法概
STM—意法半导体
TTE—道达尔能源
●美瑞士概
NVS—诺华制药
UBS—瑞银集团
ALC—爱尔康
LOGI—罗技
●美意概
RACE—法拉利
●美荷兰概
ASML—阿斯麦
NXPI—恩智浦半导体
PHG—飞利浦
●美丹麦概
NVO—诺和诺德
●美比利时概
BUD—百威英博
●美瑞典概
SPOT—Spotify
ERIC—爱立信
●美芬兰概
NOK—诺基亚
●美加拿大概
RY—加拿大皇家银行
CNQ—加拿大自然资源公司
CNR—加拿大国家铁路
●美澳概
BHP—必和必拓

(●—●)-4❸欧股

■德股
〓【科技】
SAP—思爱普
IFX—英飞凌
〓【汽车】
MBG—梅赛德斯奔驰
P911—保时捷
VOW3—大众
DTG—戴姆勒卡车
BMW—宝马
〓【金融】
ALV—安联保险
MUV2—慕尼黑再保险
DBK—德意志银行
DB1—德国证券交易所
〓【工业与国防】
SIE—西门子
RHM—莱茵金属
〓【能源与公用事业】
ENR—西门子能源
EOAN—意昂集团
RWE—莱茵集团
〓【医药与化工】
BAYN—拜耳
BAS—巴斯夫
SHL—西门子医疗
〓【消费】
ADS—阿迪达斯
HEN3—汉高
■英股
RR.—罗尔斯·罗伊斯
GLEN—嘉能可
BA.—BAE系统
STAN — 渣打银行
LSEG—伦敦证券交易所集团
■法股
〓【奢华与美妆】
MC—LVMH
OR—欧莱雅
RMS—爱马仕
KER—开云集团
〓【航空与防务】
AIR—空客集团
SAF—赛峰集团
AM—达索航空
〓【金融保险】
BNP—法国巴黎银行
CS—安盛集团
GLE—法国兴业银行
〓【汽车零部件】
ML—米其林
〓【电气与工业】
SU—施耐德电气
〓【医药健康】
SAN—赛诺菲
〓【科技与软件】
DSY—达索系统
〓【日常消费】
CA—家乐福
■瑞士股票
RO—罗氏
NESN—雀巢
ABBN—ABB
CFR—历峰集团
ZURN—苏黎世保险
SCHN—迅达集团
■西班牙股票
ITX—印地纺
■荷兰股票
HEIA—喜力
■丹麦股票
MAERSK B—马士基
VWS—维斯塔斯
PNDORA—潘多拉
■瑞典股票
VOLV_B—沃尔沃集团
HM_B—H&M
■挪威股票
EQNR—挪威国家石油
■芬兰股票
NDA_FI—北欧联合银行
FORTUM—富腾
METSO—美卓
■澳大利亚股票
MQG—麦格理集团

(●—●)-4❹亚

●美日概
MUFG—三菱UFJ金融集团
TM—丰田汽车
SONY—索尼集团
TAK—武田制药
HMC—本田汽车
●美台概
TSM—台积电
ASX—日月光投控
UMC—联电
●美韩概
SKHY—SK海力士
●美新加坡概
SE—冬海集团
●美南非概
AU—安格鲁黄金
GFI—金田
●美巴西概
NU—Nu Holdings
VALE—淡水河谷
●美以概
TEVA—梯瓦制药
ESLT—埃尔比特系统
●美印度概
INFY—印孚瑟斯
WIT—Wipro

■日股
〓【半导体与电子】
8035—东京电子
4063—信越化学
6981—村田制作所
6857—爱德万测试
6146—迪斯科
6920—激光科技
〓【汽车与轮胎】
7203—丰田汽车
7267—本田技研
5108—普利司通
〓【工业与重工】
6501—日立制作所
6861—基恩士
7011—三菱重工
6367—大金工业
〓【消费与娱乐】
9983—迅销
6758—索尼
7974—任天堂
2802—味之素
〓【金融与商社】
8306—三菱UFJ金融集团
9984—软银
8316—三井住友金融集团
8058—三菱商事
8031—三井物产
〓【医药与成熟制造】
4502—武田制药
7751—佳能
4568—第一三共
6752—松下控股
■新加坡股票
D05—星展集团
O39—华侨银行


(●—●)-5汇债

▲美元指数
DXY——美元指数
USDOLLAR
▲主汇
EURUSD——欧元/美元
GBPUSD——英镑/美元
USDJPY——美元/日元
AUDUSD——澳元/美元
NZDUSD——纽元/美元
USDCAD——美元/加元
USDCHF——美元/瑞郎
▲近汇
USDCNH——美元/离岸人民币
USDSGD——美元/新加坡元
USDTWD——美元/新台币
USDKRW——美元/韩元
USDHKD——美元/港币
▲远汇
USDTRY——美元/新土耳其里拉
USDZAR——美元/南非兰特
USDINR——美元/印度卢比
USDILS——美元/以色列谢克尔
USDIDR——美元/印度尼西亚卢比
USDBRL——美元/巴西雷亚尔
USDPHP——美元/菲律宾比索
USDTHB
▲欧汇
USDNOK——美元/挪威克朗
USDSEK——美元/瑞典克朗
USDCZK——美元/捷克克朗
USDDKK——美元/丹麦克朗
USDHUF——美元/匈牙利福林
USDPLN——美元/波兰兹罗提
▲美债
TBOND——长期美债
TNOTE10YR——10年期美债
TNOTE5YR——5年期美债
TNOTE2YR——2年期美债
▲德债
EUROBUXL——超长期德债
EUROBUND——长期德债
EUROBOBL——5年期德债
EUROSCHATZ——2年期德债
▲英国长期国债
GILT——英国长期国债
▲日本10年期国债
JBL1!——日10年国债
▲法国10年期国债
FOAT1!——法10年国债
▲意大利
FBTP1!——10年期意债
FBTS1!——2年期意债
▲中国国债
TL1!——30年国债
T1!——10年国债
TF1!——5年国债
TS1!——2年国债


(●—●)-6加密

CRYPTOB10
BTCUSD
ETHUSD
BNBUSD
XRPUSD
SOLUSD
TRXUSD
ZECUSD
DOGEUSD
XMRUSD
LEOUSD
LINKUSD
ADAUSD
XLMUSD
BCHUSD
NEARUSD
UNIUSD
LTCUSD
AVAXUSD
SHIBUSD
TAOBUSD
PEPEUSD
DOTUSD
ICPUSD
POLYGUSD
RENDERUSD
ATOMUSD
CAKEUSD
AXSUSD
▲加密货币 汇率对
ETHBTC
BCHBTC
""".trimIndent()
}
