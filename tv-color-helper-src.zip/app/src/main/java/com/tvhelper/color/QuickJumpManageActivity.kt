package com.tvhelper.color

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * 探索栏快切列表项完整管理页：
 * - 长按拖拽排序 / 一键上移下移
 * - 新增 / 删除 / 改名
 * - 精准配置目标定位：顶部第 N 个颜色列表 OR 《品种大全》某列表 → 某细分类别 → 某品种（或自动首位）
 */
class QuickJumpManageActivity : AppCompatActivity() {

    private lateinit var summaryTv: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: EntryAdapter

    private val entries = ArrayList<QuickJumpEntry>()

    private val storeListener: () -> Unit = {
        runOnUiThread { reloadList() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildLayout())
        reloadList()
    }

    override fun onResume() {
        super.onResume()
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(true)
        AppStore.addListener(storeListener)
        reloadList()
    }

    override fun onPause() {
        super.onPause()
        AppStore.removeListener(storeListener)
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(false)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun buildLayout(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        // 顶部栏
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(10))
            setBackgroundColor(Color.parseColor("#161B22"))
        }
        topBar.addView(TextView(this).apply {
            text = "← 返回"
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(dp(4), dp(4), dp(12), dp(4))
            setOnClickListener { finish() }
        })
        topBar.addView(TextView(this).apply {
            text = "快切列表项管理"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        topBar.addView(TextView(this).apply {
            text = "恢复默认"
            setTextColor(Color.parseColor("#FFA657"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setPadding(dp(8), dp(4), dp(4), dp(4))
            setOnClickListener { confirmResetDefaults() }
        })
        root.addView(topBar)

        // 操作按钮行
        val actionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(6))
        }
        val addBtn = Button(this).apply {
            text = "＋ 新增列表项"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#238636"))
            }
            setOnClickListener { showEditEntryDialog(null) }
        }
        actionBar.addView(addBtn)
        root.addView(actionBar)

        summaryTv = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(14), dp(2), dp(14), dp(8))
        }
        root.addView(summaryTv)

        adapter = EntryAdapter()
        recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@QuickJumpManageActivity)
            adapter = this@QuickJumpManageActivity.adapter
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            setPadding(dp(12), 0, dp(12), dp(24))
            clipToPadding = false
        }
        attachDragAndDrop(recyclerView)
        root.addView(recyclerView)

        return root
    }

    private fun reloadList() {
        val latest = AppStore.getQuickJumpEntries()
        entries.clear()
        entries.addAll(latest)
        summaryTv.text = "共 ${entries.size} 项（3列网格展示）｜长按任意行拖拽排序，点行改名或设置定位目标"
        adapter.notifyDataSetChanged()
    }

    private fun attachDragAndDrop(rv: RecyclerView) {
        val cb = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,
            0
        ) {
            private var dirty = false

            override fun isLongPressDragEnabled(): Boolean = true

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                if (from !in entries.indices || to !in entries.indices) return false
                val item = entries.removeAt(from)
                entries.add(to, item)
                adapter.notifyItemMoved(from, to)
                dirty = true
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                if (dirty) {
                    dirty = false
                    AppStore.saveQuickJumpEntriesOrderQuiet(entries.toList())
                }
            }
        }
        ItemTouchHelper(cb).attachToRecyclerView(rv)
    }

    private inner class EntryVH(val card: LinearLayout) : RecyclerView.ViewHolder(card) {
        val indexTv: TextView = card.findViewWithTag("idx")
        val nameTv: TextView = card.findViewWithTag("name")
        val targetTv: TextView = card.findViewWithTag("target")
        val upBtn: TextView = card.findViewWithTag("up")
        val downBtn: TextView = card.findViewWithTag("down")
        val editBtn: TextView = card.findViewWithTag("edit")
        val delBtn: TextView = card.findViewWithTag("del")
    }

    private inner class EntryAdapter : RecyclerView.Adapter<EntryVH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntryVH {
            val row = LinearLayout(this@QuickJumpManageActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(8), dp(10))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(7) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(9).toFloat()
                    setColor(Color.parseColor("#161B22"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
            }

            val idxTv = TextView(this@QuickJumpManageActivity).apply {
                tag = "idx"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                minWidth = dp(28)
            }
            row.addView(idxTv)

            val infoCol = LinearLayout(this@QuickJumpManageActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            infoCol.addView(TextView(this@QuickJumpManageActivity).apply {
                tag = "name"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                paint.isFakeBoldText = true
            })
            infoCol.addView(TextView(this@QuickJumpManageActivity).apply {
                tag = "target"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setPadding(0, dp(2), 0, 0)
            })
            row.addView(infoCol)

            fun makeIconBtn(t: String, lbl: String, colorHex: String): TextView {
                return TextView(this@QuickJumpManageActivity).apply {
                    tag = t
                    text = lbl
                    setTextColor(Color.parseColor(colorHex))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                    setPadding(dp(7), dp(6), dp(7), dp(6))
                }
            }

            row.addView(makeIconBtn("up", "↑", "#8B949E"))
            row.addView(makeIconBtn("down", "↓", "#8B949E"))
            row.addView(makeIconBtn("edit", "编辑", "#58A6FF"))
            row.addView(makeIconBtn("del", "×", "#F85149"))

            return EntryVH(row)
        }

        override fun getItemCount(): Int = entries.size

        override fun onBindViewHolder(holder: EntryVH, position: Int) {
            val item = entries[position]
            holder.indexTv.text = "☰ ${position + 1}"
            holder.nameTv.text = item.displayName
            holder.targetTv.text = QuickJumpCatalog.describeTarget(item)

            holder.card.setOnClickListener { showEditEntryDialog(item) }
            holder.editBtn.setOnClickListener { showEditEntryDialog(item) }
            holder.upBtn.setOnClickListener {
                val p = holder.bindingAdapterPosition
                if (p > 0) AppStore.moveQuickJumpEntry(p, p - 1)
            }
            holder.downBtn.setOnClickListener {
                val p = holder.bindingAdapterPosition
                if (p in 0 until entries.lastIndex) AppStore.moveQuickJumpEntry(p, p + 1)
            }
            holder.delBtn.setOnClickListener {
                AlertDialog.Builder(this@QuickJumpManageActivity)
                    .setTitle("删除快切项")
                    .setMessage("确认删除「${item.displayName}」？")
                    .setPositiveButton("删除") { _, _ ->
                        AppStore.deleteQuickJumpEntry(item.id)
                    }
                    .setNegativeButton("取消", null)
                    .show()
            }
        }
    }

    private fun confirmResetDefaults() {
        AlertDialog.Builder(this)
            .setTitle("恢复默认 17 项")
            .setMessage("将恢复为默认顺序（第一颜色、第二颜色、外商 ~ 加密），覆盖当前自定义排序与增删，是否继续？")
            .setPositiveButton("恢复默认") { _, _ ->
                AppStore.resetQuickJumpEntriesToDefault()
                Toast.makeText(this, "已恢复默认 17 个快切列表项", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /**
     * 新增 / 编辑对话框：
     * 支持改名 + 切换“顶部颜色列表(1~7)”或“《品种大全》某列表 → 某细分类别 → 某品种（三级联动下拉）”
     */
    private fun showEditEntryDialog(existing: QuickJumpEntry?) {
        val allWls = CatalogRepository.getWatchlists()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(6))
        }

        fun addLabel(txt: String) {
            container.addView(TextView(this).apply {
                text = txt
                setTextColor(Color.parseColor("#C9D1D9"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, dp(8), 0, dp(4))
            })
        }

        // 1) 显示名称
        addLabel("显示名称（弹出页面上展示的名字）")
        val nameEt = EditText(this).apply {
            setText(existing?.displayName ?: "")
            hint = "如：第一颜色 / 美中概 / 欧股-德英"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6E7681"))
            setSingleLine(true)
        }
        container.addView(nameEt)

        // 2) 定位模式
        addLabel("定位类型")
        val modeLabels = arrayOf("《品种大全》列表 / 细类别 / 品种定位", "顶部颜色列表定位（最左侧第 N 个颜色）")
        val modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@QuickJumpManageActivity, android.R.layout.simple_spinner_dropdown_item, modeLabels)
            setSelection(if (existing?.targetType == QuickJumpTargetType.COLOR_SLOT) 1 else 0)
        }
        container.addView(modeSpinner)

        // ----- 分支 A：颜色列表面板 -----
        val colorBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        colorBox.addView(TextView(this).apply {
            text = "选择顶部最左侧第几个颜色列表"
            setTextColor(Color.parseColor("#C9D1D9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })
        val slotLabels = (1..7).map { "最左侧第 $it 个颜色列表（打开首个品种图表）" }.toTypedArray()
        val slotSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@QuickJumpManageActivity, android.R.layout.simple_spinner_dropdown_item, slotLabels)
            setSelection(((existing?.colorSlotIndex ?: 1) - 1).coerceIn(0, 6))
        }
        colorBox.addView(slotSpinner)
        colorBox.addView(TextView(this).apply {
            text = "提示：若当前不存在该颜色列表，点击后将自动返回列表选择页。"
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(6), 0, 0)
        })
        container.addView(colorBox)

        // ----- 分支 B：《品种大全》三级联动面板（列表 -> 细类别 -> 品种） -----
        val catalogBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        fun addCatLabel(txt: String) {
            catalogBox.addView(TextView(this).apply {
                text = txt
                setTextColor(Color.parseColor("#C9D1D9"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, dp(8), 0, dp(4))
            })
        }

        addCatLabel("目标列表（来自《品种大全》）")
        val wlSpinner = Spinner(this)
        catalogBox.addView(wlSpinner)

        addCatLabel("目标细分类别（可选）")
        val catSpinner = Spinner(this)
        catalogBox.addView(catSpinner)

        addCatLabel("目标品种（可选，默认自动取首位品种）")
        val symSpinner = Spinner(this)
        catalogBox.addView(symSpinner)

        container.addView(catalogBox)

        // 三级联动状态数据
        var curCategories: List<Pair<String, String>> = emptyList()
        var curInstruments: List<CatalogNode.Instrument> = emptyList()
        var pendingInitCat: String? = existing?.categoryName?.takeIf { it.isNotBlank() }
        var pendingInitSym: String? = existing?.targetSymbol?.takeIf { it.isNotBlank() }

        fun refreshSymbolSpinner(wlId: String, selectedCatRaw: String?) {
            curInstruments = CatalogRepository.listInstrumentsInWatchlistOrCategory(wlId, selectedCatRaw)
            val firstSymHint = curInstruments.firstOrNull()?.symbol ?: "无"
            val symLabels = ArrayList<String>(curInstruments.size + 1)
            symLabels.add("（自动取首位品种 · 当前为 $firstSymHint）")
            for (inst in curInstruments) {
                val cn = if (inst.cnName.isNotBlank()) " ${inst.cnName}" else ""
                symLabels.add("${inst.symbol}$cn")
            }
            symSpinner.adapter = ArrayAdapter(
                this@QuickJumpManageActivity,
                android.R.layout.simple_spinner_dropdown_item,
                symLabels
            )
            val initSym = pendingInitSym
            if (initSym != null) {
                pendingInitSym = null
                val matchIdx = curInstruments.indexOfFirst { it.symbol.equals(initSym, ignoreCase = true) }
                if (matchIdx >= 0) {
                    symSpinner.setSelection(matchIdx + 1)
                }
            }
        }

        fun refreshCategorySpinner(wlId: String) {
            curCategories = CatalogRepository.listCategoriesInWatchlist(wlId)
            val catLabels = ArrayList<String>(curCategories.size + 1)
            catLabels.add("（不限 · 整个列表）")
            for ((_, displayLbl) in curCategories) {
                catLabels.add(displayLbl)
            }
            catSpinner.adapter = ArrayAdapter(
                this@QuickJumpManageActivity,
                android.R.layout.simple_spinner_dropdown_item,
                catLabels
            )

            var chosenCatIdx = 0
            val initCat = pendingInitCat
            if (initCat != null) {
                pendingInitCat = null
                val cleanInit = initCat.trim().trimStart('★', '△', '▲', '●', '■', '◆', '〓', '▪', '▸', '◇', '○', '【', ' ').trimEnd('】', ' ')
                val exactIdx = curCategories.indexOfFirst { (raw, _) ->
                    raw.trim() == initCat.trim() ||
                        raw.trim().trimStart('★', '△', '▲', '●', '■', '◆', '〓', '▪', '▸', '◇', '○', '【', ' ').trimEnd('】', ' ') == cleanInit
                }
                if (exactIdx >= 0) {
                    chosenCatIdx = exactIdx + 1
                }
            }
            catSpinner.setSelection(chosenCatIdx)
            val selectedCatRaw = if (chosenCatIdx > 0) curCategories[chosenCatIdx - 1].first else null
            refreshSymbolSpinner(wlId, selectedCatRaw)
        }

        val wlLabels = allWls.map { it.name }
        wlSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, wlLabels)

        val initWlIdx = if (existing != null) {
            val foundWl = CatalogRepository.findWatchlistForQuickJump(existing.watchlistId, existing.watchlistName)
            if (foundWl != null) allWls.indexOfFirst { it.id == foundWl.id }.coerceAtLeast(0) else 0
        } else 0
        if (allWls.isNotEmpty()) {
            wlSpinner.setSelection(initWlIdx)
            refreshCategorySpinner(allWls[initWlIdx].id)
        }

        var wlListenerReady = false
        wlSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!wlListenerReady) {
                    wlListenerReady = true
                    return
                }
                val wl = allWls.getOrNull(position) ?: return
                refreshCategorySpinner(wl.id)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        var catListenerReady = false
        catSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!catListenerReady) {
                    catListenerReady = true
                    return
                }
                val wl = allWls.getOrNull(wlSpinner.selectedItemPosition) ?: return
                val selectedCatRaw = if (position > 0 && (position - 1) in curCategories.indices) {
                    curCategories[position - 1].first
                } else null
                refreshSymbolSpinner(wl.id, selectedCatRaw)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        fun syncModeVisibility(pos: Int) {
            val isColor = (pos == 1)
            colorBox.visibility = if (isColor) View.VISIBLE else View.GONE
            catalogBox.visibility = if (isColor) View.GONE else View.VISIBLE
        }
        syncModeVisibility(modeSpinner.selectedItemPosition)
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                syncModeVisibility(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "新增快切列表项" else "编辑「${existing.displayName}」")
            .setView(container)
            .setPositiveButton("保存") { _, _ ->
                val isColorMode = (modeSpinner.selectedItemPosition == 1)
                val rawName = nameEt.text.toString().trim()
                if (isColorMode) {
                    val slotIdx = (slotSpinner.selectedItemPosition + 1).coerceIn(1, 7)
                    val finalName = rawName.ifBlank { "第${slotIdx}颜色" }
                    val updated = QuickJumpEntry(
                        id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                        displayName = finalName,
                        targetType = QuickJumpTargetType.COLOR_SLOT,
                        colorSlotIndex = slotIdx
                    )
                    if (existing == null) AppStore.addQuickJumpEntry(updated) else AppStore.updateQuickJumpEntry(updated)
                } else {
                    val chosenWl = allWls.getOrNull(wlSpinner.selectedItemPosition)
                    if (chosenWl == null) {
                        Toast.makeText(this, "《品种大全》暂无列表可选", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    val catPos = catSpinner.selectedItemPosition
                    val chosenCat = if (catPos > 0 && (catPos - 1) in curCategories.indices) {
                        curCategories[catPos - 1].first
                    } else ""
                    val symPos = symSpinner.selectedItemPosition
                    val chosenSym = if (symPos > 0 && (symPos - 1) in curInstruments.indices) {
                        curInstruments[symPos - 1].symbol
                    } else ""
                    val autoFirst = curInstruments.firstOrNull()?.symbol ?: ""
                    val finalName = rawName.ifBlank { chosenCat.ifBlank { chosenWl.name } }

                    val updated = QuickJumpEntry(
                        id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                        displayName = finalName,
                        targetType = QuickJumpTargetType.CATALOG_TARGET,
                        colorSlotIndex = 1,
                        watchlistId = chosenWl.id,
                        watchlistName = chosenWl.name,
                        categoryName = chosenCat,
                        targetSymbol = chosenSym,
                        fallbackSymbol = chosenSym.ifBlank { autoFirst }
                    )
                    if (existing == null) AppStore.addQuickJumpEntry(updated) else AppStore.updateQuickJumpEntry(updated)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }
}
