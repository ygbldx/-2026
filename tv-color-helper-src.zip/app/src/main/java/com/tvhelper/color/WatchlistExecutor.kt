package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

/**
 * 职责单一的自选表跨列表极速执行引擎：
 * - 优先使用左上角 ≡ 列表抽屉 2 次点击秒切任意列表（自动降级顶部横条）
 * - 支持折叠板块自动展开（防止漏标折叠板块内品种）
 * - 支持跨市场同名品种列表锁（防止 ASX / SAF 串号）
 * - 支持“已有任意颜色跳过”与“仅同色跳过、异色覆盖改色”双策略
 */
class WatchlistExecutor(
    private val service: AccessibilityService,
    private val vision: VisionEngine,
    private val inspector: NodeInspector,
    private val gesture: GestureDriver,
    private val screenSizeProvider: () -> Pair<Int, Int>,
    private val captureScreen: (Int) -> Bitmap?,
    private val shouldAbort: () -> Boolean,
    private val onWatchlistIdentified: (String) -> Unit,
    private val onSendNotification: (String) -> Unit,
    private val onShowDoneBanner: () -> Unit,
    private val onShowCustomBanner: (String) -> Unit
) {
    @Volatile
    private var nativeRowLongClickSupport = 0 // 0=未探测, 1=支持原生秒弹, -1=需物理长按
    @Volatile
    private var lastColorDotTapAtMs = 0L

    fun runBatch() {
        gesture.sleepSafe(5L)
        if (shouldAbort()) return

        val visitedWatchlistIds = HashSet<String>()
        val visitedColorWatchlists = HashSet<MarkColor>()
        val failedSwitchWatchlistIds = HashSet<String>()
        val expandedSectionKeys = HashSet<String>()
        var anyActionSucceeded = false
        var hadAnyMissedOrError = false
        val unaddedNotices = ArrayList<String>()

        var outerLoops = 0
        while (!shouldAbort() && AppStore.hasPendingItems() && outerLoops < 24) {
            if (gesture.yieldForUserIfNeeded(shouldAbort)) {
                continue
            }
            if (shouldAbort()) break
            outerLoops++

            // 0) 首先检测当前是否处在顶部最前面的“颜色列表”（红色列表/蓝色列表/绿色列表等）！
            val activeColorWl = detectCurrentColorWatchlist()
            if (activeColorWl != null && activeColorWl.color !in visitedColorWatchlists) {
                val colorRes = runColorWatchlistPass(
                    colorWl = activeColorWl,
                    onSucceeded = { anyActionSucceeded = true },
                    onFailedMenu = { task, msg ->
                        hadAnyMissedOrError = true
                        unaddedNotices.add(msg)
                        AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                    }
                )
                if (shouldAbort()) break
                if (colorRes == -1) continue // 用户手动操作或切换了列表，重新统筹
                visitedColorWatchlists.add(activeColorWl.color)
                if (!AppStore.hasPendingItems()) break
                // 颜色列表已扫完但池里还有未在此颜色列表中的品种 -> 自动转去它们所属的普通自选表继续处理！
                val nextWlFromColor = planNextOptimalWatchlist(null, visitedWatchlistIds, failedSwitchWatchlistIds)
                if (nextWlFromColor != null) {
                    AppStore.log("颜色列表[${activeColorWl.name}]处理完毕，切往[${nextWlFromColor.name}]处理剩余 ${AppStore.pendingCount()} 个")
                    val swOutcome = switchToWatchlist(null, nextWlFromColor, emptyList())
                    if (shouldAbort()) break
                    if (swOutcome == 0) {
                        failedSwitchWatchlistIds.add(nextWlFromColor.id)
                        hadAnyMissedOrError = true
                    }
                    continue
                }
            }

            // 【极速直击通道】普通非颜色列表：先花 ~8ms 原生直查待办池里的品种是否已经在当前屏上，命中立刻动手！
            val allPoolTasks = AppStore.snapshotTasks()
            val directHitRows = inspector.fastFindPendingRowsByText(allPoolTasks.map { it.symbol }.distinct())
            if (directHitRows.isNotEmpty() && !shouldAbort()) {
                val quickWl = inspector.detectActiveWatchlistFromTopNodes()
                    ?: CatalogRepository.identifyWatchlistByVisibleSymbols(directHitRows.map { it.symbol })
                if (quickWl != null) {
                    onWatchlistIdentified(quickWl.id)
                }
                val eligibleDirect = directHitRows.filter { r ->
                    getPendingTasksForWatchlist(quickWl).any { t ->
                        vision.findMatchingTaskKey(r.symbol, setOf(t.symbol)) != null
                    }
                }
                if (eligibleDirect.isNotEmpty()) {
                    AppStore.log("秒击#$outerLoops｜当前=${quickWl?.name ?: "识别中"}｜屏上直中${eligibleDirect.size}个/池内${allPoolTasks.size}个")
                    val readyDirect = if (AppStore.isSkipFlagCheckTurbo()) {
                        eligibleDirect
                    } else {
                        val bmp = captureScreen(2)
                        if (bmp != null) {
                            try {
                                eligibleDirect.map { r ->
                                    val fc = vision.detectLeftEdgeFlagColor(bmp, r.topY, r.bottomY)
                                    r.copy(hasAnyFlag = (fc != null), existingFlagColor = fc)
                                }
                            } finally {
                                bmp.recycle()
                            }
                        } else eligibleDirect
                    }
                    val intervenedQuick = processVisibleMatches(
                        rows = readyDirect,
                        currentWl = quickWl,
                        activeColorWl = null,
                        onSucceeded = { anyActionSucceeded = true },
                        onFailedMenu = { task, msg ->
                            hadAnyMissedOrError = true
                            unaddedNotices.add(msg)
                            AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                        }
                    )
                    if (shouldAbort()) break
                    if (intervenedQuick || gesture.yieldForUserIfNeeded(shouldAbort)) continue
                    if (!AppStore.hasPendingItems()) break
                }
            }

            val (firstRows, firstFp, firstBmpForFallback) = scanScreenRows(waitForFreshNodes = true)
            if (shouldAbort()) {
                firstBmpForFallback?.recycle()
                break
            }

            val currentWl: CatalogWatchlist? = CatalogRepository.identifyWatchlistByVisibleSymbols(firstRows.map { it.symbol })
                ?: inspector.detectActiveWatchlistFromTopNodes()
                ?: firstBmpForFallback?.let { bmp ->
                    vision.readActiveWatchlistName(bmp)?.let { CatalogRepository.getWatchlistByName(it) }
                }
            firstBmpForFallback?.recycle()

            if (currentWl != null) {
                onWatchlistIdentified(currentWl.id)
            }

            val wlNameLog = currentWl?.name ?: "未识别列表"
            AppStore.log("统筹#$outerLoops｜当前=$wlNameLog｜池内=${AppStore.pendingCount()}个")

            // 第1优先：立刻标掉当前屏可见的命中品种
            val intervenedFirst = processVisibleMatches(
                rows = firstRows,
                currentWl = currentWl,
                activeColorWl = null,
                onSucceeded = { anyActionSucceeded = true },
                onFailedMenu = { task, msg ->
                    hadAnyMissedOrError = true
                    unaddedNotices.add(msg)
                    AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                }
            )
            if (shouldAbort()) break
            if (intervenedFirst || gesture.yieldForUserIfNeeded(shouldAbort)) {
                continue
            }

            // 第2优先：检查当前屏是否有折叠板块藏着当前列表的待办品种 -> 自动点开！
            if (currentWl != null) {
                val pendingHereNow = getPendingTasksForWatchlist(currentWl)
                if (pendingHereNow.isNotEmpty() && tryExpandCollapsedSectionsOnScreen(firstRows, pendingHereNow, currentWl, expandedSectionKeys)) {
                    continue
                }
            }

            // 第3优先：当前列表还有剩余待办 -> 按《品种大全》固定顺序上下统筹快搜
            val pendingInCurrentWl = getPendingTasksForWatchlist(currentWl)
            if (currentWl != null && pendingInCurrentWl.isNotEmpty() && !shouldAbort()) {
                val symbolOrders = CatalogRepository.getSymbolOrdersInWatchlist(currentWl.id)
                val visibleIndices = firstRows.flatMap { symbolOrders[it.symbol].orEmpty() }
                val visMin = visibleIndices.minOrNull()
                val visMax = visibleIndices.maxOrNull()

                val targetIndices = pendingInCurrentWl.flatMap { symbolOrders[it.symbol].orEmpty() }
                val hasBelow = if (visMax == null || targetIndices.isEmpty()) true else targetIndices.any { it > visMax }
                val hasAbove = if (visMin == null || targetIndices.isEmpty()) true else targetIndices.any { it < visMin }
                val fallsInsideSpan = !hasBelow && !hasAbove

                val minDownDist = if (visMax != null) targetIndices.filter { it > visMax }.minOfOrNull { it - visMax } ?: Int.MAX_VALUE else 0
                val minUpDist = if (visMin != null) targetIndices.filter { it < visMin }.minOfOrNull { visMin - it } ?: Int.MAX_VALUE else Int.MAX_VALUE

                val directions = ArrayList<Boolean>()
                when {
                    fallsInsideSpan || (hasBelow && hasAbove) -> {
                        if (minDownDist <= minUpDist) {
                            directions.add(true); directions.add(false)
                        } else {
                            directions.add(false); directions.add(true)
                        }
                    }
                    hasBelow -> {
                        directions.add(true); directions.add(false)
                    }
                    else -> {
                        directions.add(false); directions.add(true)
                    }
                }

                AppStore.log("列表[${currentWl.name}] 剩余${pendingInCurrentWl.size}个｜优先方向=${if (directions[0]) "下" else "上"}")

                var interrupted = false
                var stepsFirstDir = 0

                for ((dirIdx, goDown) in directions.withIndex()) {
                    if (shouldAbort() || getPendingTasksForWatchlist(currentWl).isEmpty()) break
                    if (gesture.yieldForUserIfNeeded(shouldAbort)) {
                        interrupted = true
                        break
                    }

                    if (dirIdx == 1 && stepsFirstDir > 1) {
                        val backSteps = (stepsFirstDir - 1).coerceAtLeast(1)
                        for (b in 0 until backSteps) {
                            if (shouldAbort()) break
                            if (gesture.yieldForUserIfNeeded(shouldAbort)) {
                                interrupted = true
                                break
                            }
                            gesture.performFastScroll(scrollDown = goDown)
                            gesture.sleepSafe(45L)
                        }
                        if (interrupted || shouldAbort()) break
                        gesture.sleepSafe(50L)
                    }

                    // 跳屏快进：如果第一个方向距离最近目标 > 16 行，先极速连续跳过中间空屏再精扫！
                    var jumpedScreens = 0
                    if (dirIdx == 0 && !fallsInsideSpan) {
                        val estDist = if (goDown) minDownDist else minUpDist
                        if (estDist in 16..500) {
                            val jumpCount = ((estDist - 10) / 11).coerceIn(1, 5)
                            AppStore.log("距离最近目标约${estDist}行，跳屏快进 $jumpCount 屏")
                            for (j in 0 until jumpCount) {
                                if (shouldAbort()) break
                                if (gesture.yieldForUserIfNeeded(shouldAbort)) {
                                    interrupted = true
                                    break
                                }
                                gesture.performFastScroll(scrollDown = goDown)
                                gesture.sleepSafe(48L)
                                jumpedScreens++
                            }
                            if (interrupted || shouldAbort()) break
                            gesture.sleepSafe(45L)
                            stepsFirstDir += jumpedScreens
                        }
                    }

                    var prevNames = if (dirIdx == 0 && jumpedScreens == 0) firstRows.map { it.symbol } else emptyList()
                    var prevFp = if (dirIdx == 0 && jumpedScreens == 0) firstFp else null
                    var scrolls = 0
                    var sameCount = 0

                    while (!shouldAbort() && getPendingTasksForWatchlist(currentWl).isNotEmpty() && scrolls < 55) {
                        if (gesture.yieldForUserIfNeeded(shouldAbort)) {
                            interrupted = true
                            break
                        }

                        // 若刚跳屏快进落地，首轮先扫描当前落地屏，不用再多滑一屏！
                        if (jumpedScreens > 0 && scrolls == 0) {
                            jumpedScreens = 0
                        } else {
                            if (!gesture.performControlledScroll(scrollDown = goDown, stronger = (sameCount > 0))) {
                                interrupted = true
                                break
                            }
                            gesture.sleepSafe(26L)
                            if (shouldAbort()) break
                        }

                        // 极速直查：先花 ~3ms 原生直查当前列表剩余待办品种是否已在屏上，命中直接标色免扫整屏！
                        val remHereSyms = getPendingTasksForWatchlist(currentWl).map { it.symbol }
                        val fastHits = inspector.fastFindPendingRowsByText(remHereSyms)
                        if (fastHits.isNotEmpty() && !shouldAbort()) {
                            val skipFlagTurbo = AppStore.isSkipFlagCheckTurbo()
                            val hitRowsWithFlags = if (skipFlagTurbo) {
                                fastHits
                            } else {
                                val flagBmp = captureScreen(2)
                                if (flagBmp != null) {
                                    try {
                                        fastHits.map { r ->
                                            val fc = vision.detectLeftEdgeFlagColor(flagBmp, r.topY, r.bottomY)
                                            r.copy(hasAnyFlag = (fc != null), existingFlagColor = fc)
                                        }
                                    } finally {
                                        flagBmp.recycle()
                                    }
                                } else fastHits
                            }

                            val hitIntervened = processVisibleMatches(
                                rows = hitRowsWithFlags,
                                currentWl = currentWl,
                                activeColorWl = null,
                                onSucceeded = { anyActionSucceeded = true },
                                onFailedMenu = { task, msg ->
                                    hadAnyMissedOrError = true
                                    unaddedNotices.add(msg)
                                    AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                                }
                            )
                            if (hitIntervened) {
                                interrupted = true
                                break
                            }
                            if (getPendingTasksForWatchlist(currentWl).isEmpty()) break
                            // 本屏已精准命中并处理完毕，无需再重扫整屏节点，直接进入下一屏！
                            sameCount = 0
                            scrolls++
                            if (dirIdx == 0) stepsFirstDir++
                            prevNames = emptyList()
                            prevFp = null
                            continue
                        }

                        var (rows, fp, bmpExtra) = scanScreenRows(waitForFreshNodes = false)
                        bmpExtra?.recycle()
                        if (shouldAbort()) break

                        var names = rows.map { it.symbol }
                        if (names.isNotEmpty() && names == prevNames) {
                            gesture.sleepSafe(60L)
                            if (shouldAbort()) break
                            val retry = scanScreenRows(waitForFreshNodes = false)
                            retry.third?.recycle()
                            rows = retry.first
                            fp = retry.second
                            names = rows.map { it.symbol }
                        }

                        val detectedWlNow = CatalogRepository.identifyWatchlistByVisibleSymbols(names)
                        if (detectedWlNow != null && detectedWlNow.id != currentWl.id) {
                            AppStore.log("检测到你切到了[${detectedWlNow.name}]，立刻转战新列表")
                            interrupted = true
                            break
                        }

                        val unchanged = (names.isNotEmpty() && names == prevNames) ||
                            (fp != null && prevFp != null && vision.isSameFrame(prevFp, fp))
                        if (unchanged) {
                            sameCount++
                            if (sameCount >= 2) {
                                AppStore.log("[${currentWl.name}]确认已达${if (goDown) "底部" else "顶部"}（翻 $scrolls 屏）")
                                break
                            }
                            continue
                        }
                        sameCount = 0
                        scrolls++
                        if (dirIdx == 0) stepsFirstDir++
                        prevNames = names
                        prevFp = fp

                        val userIntervened = processVisibleMatches(
                            rows = rows,
                            currentWl = currentWl,
                            activeColorWl = null,
                            onSucceeded = { anyActionSucceeded = true },
                            onFailedMenu = { task, msg ->
                                hadAnyMissedOrError = true
                                unaddedNotices.add(msg)
                                AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                            }
                        )
                        if (userIntervened) {
                            interrupted = true
                            break
                        }

                        val stillLeft = getPendingTasksForWatchlist(currentWl)
                        if (stillLeft.isEmpty()) break

                        // 翻屏后检查新露出的折叠板块，若有则自动展开并立刻处理！
                        if (tryExpandCollapsedSectionsOnScreen(rows, stillLeft, currentWl, expandedSectionKeys)) {
                            val expandedScan = scanScreenRows(waitForFreshNodes = true)
                            expandedScan.third?.recycle()
                            if (!shouldAbort()) {
                                processVisibleMatches(
                                    rows = expandedScan.first,
                                    currentWl = currentWl,
                                    activeColorWl = null,
                                    onSucceeded = { anyActionSucceeded = true },
                                    onFailedMenu = { task, msg ->
                                        hadAnyMissedOrError = true
                                        unaddedNotices.add(msg)
                                        AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                                    }
                                )
                            }
                            if (getPendingTasksForWatchlist(currentWl).isEmpty()) break
                        }
                    }

                    if (interrupted || shouldAbort()) break
                }

                if (shouldAbort()) break
                if (interrupted) continue

                visitedWatchlistIds.add(currentWl.id)
                val stillMissing = getPendingTasksForWatchlist(currentWl)
                for (task in stillMissing) {
                    val allLocs = CatalogRepository.findLocations(task.symbol)
                    val isUnknown = allLocs.isEmpty()
                    val hasOtherUnvisited = when {
                        task.preferredWatchlistId.isNotEmpty() -> task.preferredWatchlistId != currentWl.id &&
                            task.preferredWatchlistId !in visitedWatchlistIds &&
                            task.preferredWatchlistId !in failedSwitchWatchlistIds
                        // 不在《品种大全》的未知品种只在当前列表找，绝不拖着它去翻遍其它无关列表浪费时间！
                        isUnknown -> false
                        else -> allLocs.any { it.watchlistId !in visitedWatchlistIds && it.watchlistId !in failedSwitchWatchlistIds }
                    }
                    if (!hasOtherUnvisited) {
                        val msg = if (isUnknown) {
                            "未添加：${task.symbol}（${task.color.label}色，不在《品种大全》），在 ${currentWl.name} 未找到"
                        } else {
                            "未添加：${task.symbol}（${task.color.label}色），在 ${currentWl.name} 完整搜遍后未找到"
                        }
                        AppStore.log(msg)
                        AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                        unaddedNotices.add(msg)
                        AppStore.removeTaskByKey(task.key)
                        hadAnyMissedOrError = true
                    }
                }
            }

            if (shouldAbort() || !AppStore.hasPendingItems()) break
            if (gesture.yieldForUserIfNeeded(shouldAbort)) continue

            // 第4优先：全局最短路径统筹跨列表切换（首选 ≡ 抽屉 2 次点击秒切！）
            val nextTargetWl = planNextOptimalWatchlist(currentWl, visitedWatchlistIds, failedSwitchWatchlistIds)
            if (nextTargetWl == null) {
                val leftover = AppStore.snapshotTasks()
                for (task in leftover) {
                    val wlName = if (task.preferredWatchlistId.isNotEmpty()) {
                        CatalogRepository.getWatchlistById(task.preferredWatchlistId)?.name.orEmpty()
                    } else {
                        CatalogRepository.findLocations(task.symbol).map { it.watchlistName }.distinct().joinToString("/")
                    }
                    val msg = if (wlName.isNotEmpty()) {
                        "未添加：${task.symbol}（${task.color.label}色，属于 $wlName），未能自动切至该列表"
                    } else {
                        "未添加：${task.symbol}（${task.color.label}色，不在《品种大全》），请切到所属列表后一键重试"
                    }
                    AppStore.log(msg)
                    AppStore.addUnaddedItem(task.symbol, task.color, msg, task.preferredWatchlistId)
                    unaddedNotices.add(msg)
                    AppStore.removeTaskByKey(task.key)
                    hadAnyMissedOrError = true
                }
                break
            }

            AppStore.log("统筹跨列表切换：${currentWl?.name ?: "当前"} -> ${nextTargetWl.name}")
            val prevSymbolsSig = firstRows.map { it.symbol }
            val outcome = switchToWatchlist(currentWl, nextTargetWl, prevSymbolsSig)
            if (shouldAbort()) break
            if (outcome == -1) {
                continue
            } else if (outcome == 0) {
                AppStore.log("切至[${nextTargetWl.name}]失败，记录跳过")
                failedSwitchWatchlistIds.add(nextTargetWl.id)
                hadAnyMissedOrError = true
            }
        }

        if (shouldAbort()) {
            AppStore.log("批处理暂停（剩余待办 ${AppStore.pendingCount()} 个，回到列表页自动继续）")
            return
        }

        if (unaddedNotices.isNotEmpty()) {
            onSendNotification(unaddedNotices.joinToString("\n"))
        }
        if (!AppStore.hasPendingItems()) {
            if (!hadAnyMissedOrError && anyActionSucceeded) {
                AppStore.log("全部完活！")
                onShowDoneBanner()
            } else if (!hadAnyMissedOrError) {
                AppStore.log("待办已全部处理/跳过")
                onShowDoneBanner()
            } else {
                AppStore.log("本轮处理结束（有未添加项，可在APP一键重新加入待添加池）")
            }
        }
    }

    // ==================== 折叠板块自动展开 ====================


    // ==================== 颜色列表专享处理通道（0截屏 · 同色跳过 · 异色重标） ====================

    private fun detectCurrentColorWatchlist(): ActiveColorWatchlist? {
        return inspector.detectActiveColorWatchlistFromTopNodes()
    }

    /**
     * 在当前打开的“颜色列表”内极速扫描（当前屏 -> 向下到底 -> 向上到顶）：
     * - 因为处在颜色列表内，所有可见品种必然带有该列表颜色，无需截屏查旗！
     * - 目标色 == 当前颜色列表色 -> 无视跳过；目标色 != 当前颜色列表色 -> 长按改标新颜色！
     * 返回 1=扫完本颜色列表，-1=被用户手动操作/切列表打断需重新统筹
     */
    private fun runColorWatchlistPass(
        colorWl: ActiveColorWatchlist,
        onSucceeded: () -> Unit,
        onFailedMenu: (PendingTask, String) -> Unit
    ): Int {
        AppStore.log("颜色列表模式[${colorWl.name}]｜待办池=${AppStore.pendingCount()}个（同色跳过/异色改标）")

        fun tagColorOnRows(rawRows: List<WatchlistRow>): List<WatchlistRow> {
            return rawRows.map { it.copy(hasAnyFlag = true, existingFlagColor = colorWl.color) }
        }

        // 1) 优先处理当前屏直接命中的品种（无需截屏！）
        val directSyms = AppStore.snapshotTasks().map { it.symbol }.distinct()
        val directHits = inspector.fastFindPendingRowsByText(directSyms)
        if (directHits.isNotEmpty()) {
            val intervened = processVisibleMatches(
                rows = tagColorOnRows(directHits),
                currentWl = null,
                activeColorWl = colorWl,
                onSucceeded = onSucceeded,
                onFailedMenu = onFailedMenu
            )
            if (shouldAbort()) return 1
            if (intervened || gesture.yieldForUserIfNeeded(shouldAbort)) return -1
            if (!AppStore.hasPendingItems()) return 1
        }

        // 2) 若还有待办，按“先向下到底，再向上到顶”完整扫一遍本颜色列表
        val initRows = inspector.scanWatchlistSymbolsFromNodes()
        if (initRows.isNotEmpty()) {
            val intervened = processVisibleMatches(
                rows = tagColorOnRows(initRows),
                currentWl = null,
                activeColorWl = colorWl,
                onSucceeded = onSucceeded,
                onFailedMenu = onFailedMenu
            )
            if (shouldAbort()) return 1
            if (intervened || gesture.yieldForUserIfNeeded(shouldAbort)) return -1
            if (!AppStore.hasPendingItems()) return 1
        }

        var stepsDown = 0
        for ((dirIdx, goDown) in listOf(true, false).withIndex()) {
            if (shouldAbort() || !AppStore.hasPendingItems()) break
            if (gesture.yieldForUserIfNeeded(shouldAbort)) return -1

            if (dirIdx == 1 && stepsDown > 1) {
                for (b in 0 until (stepsDown - 1)) {
                    if (shouldAbort()) return 1
                    if (gesture.yieldForUserIfNeeded(shouldAbort)) return -1
                    gesture.performFastScroll(scrollDown = false)
                    gesture.sleepSafe(45L)
                }
                gesture.sleepSafe(50L)
            }

            var prevNames = if (dirIdx == 0) initRows.map { it.symbol } else emptyList()
            var scrolls = 0
            var sameCount = 0

            while (!shouldAbort() && AppStore.hasPendingItems() && scrolls < 35) {
                if (gesture.yieldForUserIfNeeded(shouldAbort)) return -1

                // 检测用户是否已经手动切走了颜色列表
                val curColorNow = inspector.detectActiveColorWatchlistFromTopNodes()
                if (curColorNow == null || curColorNow.color != colorWl.color) {
                    AppStore.log("检测到已离开颜色列表[${colorWl.name}]，重新统筹")
                    return -1
                }

                if (!gesture.performControlledScroll(scrollDown = goDown, stronger = (sameCount > 0))) {
                    return -1
                }
                gesture.sleepSafe(26L)
                if (shouldAbort()) return 1

                val remSyms = AppStore.snapshotTasks().map { it.symbol }.distinct()
                val fastHits = inspector.fastFindPendingRowsByText(remSyms)
                if (fastHits.isNotEmpty()) {
                    val intervened = processVisibleMatches(
                        rows = tagColorOnRows(fastHits),
                        currentWl = null,
                        activeColorWl = colorWl,
                        onSucceeded = onSucceeded,
                        onFailedMenu = onFailedMenu
                    )
                    if (shouldAbort()) return 1
                    if (intervened) return -1
                    if (!AppStore.hasPendingItems()) return 1
                    // 改色会导致该行从本颜色列表消失，本屏可能还有后续品种顶上来，直接续扫！
                    sameCount = 0
                    scrolls++
                    if (dirIdx == 0) stepsDown++
                    prevNames = emptyList()
                    continue
                }

                var currRows = inspector.scanWatchlistSymbolsFromNodes()
                var currNames = currRows.map { it.symbol }
                if (currNames.isNotEmpty() && currNames == prevNames) {
                    gesture.sleepSafe(55L)
                    currRows = inspector.scanWatchlistSymbolsFromNodes()
                    currNames = currRows.map { it.symbol }
                }

                if (currNames.isNotEmpty() && currNames == prevNames) {
                    sameCount++
                    if (sameCount >= 2) {
                        AppStore.log("颜色列表[${colorWl.name}]已达${if (goDown) "底部" else "顶部"}（翻 $scrolls 屏）")
                        break
                    }
                    continue
                }
                sameCount = 0
                scrolls++
                if (dirIdx == 0) stepsDown++
                prevNames = currNames
            }
        }
        return 1
    }

    /**
     * ≡抽屉点击目标列表后：先等抽屉真正关闭，再确认目标列表节点渲染完成（彻底消灭1.5秒误退OCR空等！）
     */
    private fun waitForDrawerCloseAndRender(targetWl: CatalogWatchlist) {
        // 第1步：等抽屉真正退场（通常 100~170ms）
        for (i in 0 until 15) {
            gesture.sleepSafe(18L)
            if (shouldAbort() || gesture.userIntervenedFlag.get()) return
            if (!inspector.isWatchlistDrawerOpen()) break
        }

        // 第2步：等目标列表的任意品种节点上屏（通常 20~60ms）
        val targetCheckSyms = (
            getPendingTasksForWatchlist(targetWl).map { it.symbol }.take(3) +
                targetWl.flattenInstruments().take(2).map { it.symbol }
            ).distinct().take(4)

        for (i in 0 until 10) {
            if (shouldAbort() || gesture.userIntervenedFlag.get()) return
            if (targetCheckSyms.any { inspector.isSymbolVisibleOnScreenFast(it) }) {
                return
            }
            gesture.sleepSafe(20L)
        }
    }

    private fun tryExpandCollapsedSectionsOnScreen(
        visibleRows: List<WatchlistRow>,
        pendingTasks: List<PendingTask>,
        currentWl: CatalogWatchlist,
        expandedSectionKeys: MutableSet<String>
    ): Boolean {
        val collapsed = inspector.findCollapsedSectionHeaders(visibleRows, pendingTasks, currentWl)
        var expandedAny = false
        for (sec in collapsed) {
            if (shouldAbort()) break
            val key = "${currentWl.id}::${sec.text}"
            if (!expandedSectionKeys.add(key)) continue

            val beforeBelowCount = visibleRows.count { it.centerY > sec.bottomY }
            AppStore.log("发现折叠板块「${sec.text.take(16)}」，点开展开")
            val clicked = gesture.clickNodeOrParent(sec.node) || gesture.dispatchTap(sec.centerX.toFloat(), sec.centerY.toFloat())
            if (!clicked) continue

            gesture.sleepSafe(110L)
            if (shouldAbort()) break

            // 自检防误折叠保险：点击后若下方品种数没有增加（反而变少或不变），说明原板块本来是展开的/装饰线，立刻点回原状！
            val afterRows = inspector.scanWatchlistSymbolsFromNodes()
            val afterBelowCount = afterRows.count { it.centerY > sec.bottomY }
            if (afterBelowCount > beforeBelowCount) {
                expandedAny = true
            } else {
                AppStore.log("自检：点击后未展开新行($beforeBelowCount->$afterBelowCount)，立即点击还原")
                gesture.clickNodeOrParent(sec.node) || gesture.dispatchTap(sec.centerX.toFloat(), sec.centerY.toFloat())
                gesture.sleepSafe(90L)
            }
        }
        return expandedAny
    }

    // ==================== 归属筛选与全局最短路径统筹 ====================

    private fun taskBelongsToWatchlist(task: PendingTask, wl: CatalogWatchlist?): Boolean {
        if (wl == null) return CatalogRepository.findLocations(task.symbol).isEmpty()
        if (task.preferredWatchlistId.isNotEmpty()) {
            return task.preferredWatchlistId == wl.id
        }
        val locs = CatalogRepository.findLocations(task.symbol)
        return locs.isEmpty() || locs.any { it.watchlistId == wl.id }
    }

    private fun getPendingTasksForWatchlist(wl: CatalogWatchlist?): List<PendingTask> {
        return AppStore.snapshotTasks().filter { taskBelongsToWatchlist(it, wl) }
    }

    private fun findNextCatalogTargetWatchlist(
        visitedIds: Set<String>,
        failedSwitchIds: Set<String>
    ): CatalogWatchlist? {
        for (task in AppStore.snapshotTasks()) {
            if (task.preferredWatchlistId.isNotEmpty()) {
                if (task.preferredWatchlistId !in visitedIds && task.preferredWatchlistId !in failedSwitchIds) {
                    CatalogRepository.getWatchlistById(task.preferredWatchlistId)?.let { return it }
                }
            } else {
                for (loc in CatalogRepository.findLocations(task.symbol)) {
                    if (loc.watchlistId !in visitedIds && loc.watchlistId !in failedSwitchIds) {
                        CatalogRepository.getWatchlistById(loc.watchlistId)?.let { return it }
                    }
                }
            }
        }
        return null
    }

    private fun planNextOptimalWatchlist(
        currentWl: CatalogWatchlist?,
        visitedIds: Set<String>,
        failedSwitchIds: Set<String>
    ): CatalogWatchlist? {
        val allTasks = AppStore.snapshotTasks()
        if (allTasks.isEmpty()) return null
        val allWls = CatalogRepository.getWatchlists()
        val currIdx = currentWl?.let { CatalogRepository.getWatchlistIndexById(it.id) } ?: 0

        val candidateIndices = LinkedHashSet<Int>()
        for (task in allTasks) {
            if (task.preferredWatchlistId.isNotEmpty()) {
                if (task.preferredWatchlistId !in visitedIds && task.preferredWatchlistId !in failedSwitchIds) {
                    val idx = allWls.indexOfFirst { it.id == task.preferredWatchlistId }
                    if (idx >= 0) candidateIndices.add(idx)
                }
            } else {
                for (loc in CatalogRepository.findLocations(task.symbol)) {
                    if (loc.watchlistId !in visitedIds && loc.watchlistId !in failedSwitchIds) {
                        val idx = allWls.indexOfFirst { it.id == loc.watchlistId }
                        if (idx >= 0) candidateIndices.add(idx)
                    }
                }
            }
        }
        if (candidateIndices.isEmpty()) return null

        val leftSide = candidateIndices.filter { it < currIdx }.sortedDescending()
        val rightSide = candidateIndices.filter { it > currIdx }.sorted()

        val bestIdx = when {
            leftSide.isEmpty() -> rightSide.first()
            rightSide.isEmpty() -> leftSide.first()
            else -> {
                val leftSpan = currIdx - leftSide.last()
                val rightSpan = rightSide.last() - currIdx
                if (leftSpan <= rightSpan) leftSide.first() else rightSide.first()
            }
        }
        return allWls.getOrNull(bestIdx)
    }

    // ==================== 跨列表极速切换：左上角 ≡ 抽屉直选（主力）+ 顶部横条（兜底） ====================

    private fun switchToWatchlist(
        currentWl: CatalogWatchlist?,
        targetWl: CatalogWatchlist,
        prevRowSymbols: List<String>
    ): Int {
        // 先 2ms 看一眼目标是不是已经在顶部栏里直接可见（相邻列表直接 1 次点击秒切，比开抽屉更快！）
        val (topTabs, topY) = inspector.findTopTabRowFromNodes()
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)
        val directTopHit = topTabs.firstOrNull { it.matchedCatalogIdx == targetIdx }
        if (directTopHit != null && directTopHit.node != null) {
            if (gesture.clickNodeOrParent(directTopHit.node)) {
                AppStore.log("顶栏直点相邻列表[${targetWl.name}]")
                waitForListSwitchEffect(prevRowSymbols, targetWl)
                return 1
            }
        }

        if (AppStore.isDrawerSwitchPreferred()) {
            val drawerRes = switchViaDrawer(targetWl, topY, prevRowSymbols)
            if (drawerRes != 0) return drawerRes
            AppStore.log("≡抽屉未直接命中[${targetWl.name}]，降级顶栏切换")
            return switchViaTopTabBar(currentWl, targetWl, prevRowSymbols)
        } else {
            val barRes = switchViaTopTabBar(currentWl, targetWl, prevRowSymbols)
            if (barRes != 0) return barRes
            return switchViaDrawer(targetWl, topY, prevRowSymbols)
        }
    }

    /**
     * 左上角 ≡ 列表抽屉 2 次点击秒切（12 个有效列表全在首屏，完全无视垃圾列表和横滑惯性！）
     */
    private fun switchViaDrawer(
        targetWl: CatalogWatchlist,
        knownTabY: Int,
        prevRowSymbols: List<String>
    ): Int {
        if (shouldAbort()) return 0
        if (gesture.yieldForUserIfNeeded(shouldAbort)) return -1

        val (sw, sh) = screenSizeProvider()
        val approxY = if (knownTabY > 0) knownTabY else {
            captureScreen(1)?.let { bmp ->
                try { vision.detectTabBarCenterY(bmp) } finally { bmp.recycle() }
            } ?: (sh * 0.095f).toInt()
        }

        // 1) 点击左上角 ≡ 打开列表抽屉
        val hambNode = inspector.findHamburgerButtonNode(approxY)
        val openedClick = if (hambNode != null && gesture.clickNodeOrParent(hambNode)) {
            true
        } else {
            gesture.dispatchTap(sw * 0.0423f, approxY.toFloat())
        }
        if (!openedClick) return -1

        // 2) 极速轮询抽屉弹出并直查目标列表（~60~150ms）
        var foundItem: DrawerItemCandidate? = null
        var drawerOpened = false
        val pollWaits = longArrayOf(20L, 25L, 30L, 35L, 40L, 45L, 55L)
        for (w in pollWaits) {
            gesture.sleepSafe(w)
            if (shouldAbort()) return 0
            if (gesture.yieldForUserIfNeeded(shouldAbort)) return -1
            if (!drawerOpened && inspector.isWatchlistDrawerOpen()) {
                drawerOpened = true
            }
            foundItem = inspector.findWatchlistInDrawer(targetWl)
            if (foundItem != null) break
        }

        if (foundItem != null) {
            val clicked = gesture.clickNodeOrParent(foundItem.node) ||
                gesture.dispatchTap(foundItem.centerX.toFloat(), foundItem.centerY.toFloat())
            if (!clicked) return -1
            AppStore.log("≡抽屉直选[${targetWl.name}]")
            waitForDrawerCloseAndRender(targetWl)
            gesture.markOwnActionJustFinished()
            return 1
        }

        // 若抽屉打开了但没在首屏找到（例如用户新增了第 20 个列表），关闭抽屉回退
        if (drawerOpened || inspector.isWatchlistDrawerOpen()) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            gesture.sleepSafe(120L)
            gesture.markOwnActionJustFinished()
        }
        return 0
    }

    private fun switchViaTopTabBar(
        currentWl: CatalogWatchlist?,
        targetWl: CatalogWatchlist,
        prevRowSymbols: List<String>
    ): Int {
        val totalWls = CatalogRepository.getWatchlists().size
        val lastCatalogIdx = (totalWls - 1).coerceAtLeast(0)
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)
        val currIdx = currentWl?.let { CatalogRepository.getWatchlistIndexById(it.id) } ?: -1

        val (sw, sh) = screenSizeProvider()
        val safeLeftX = (sw * 0.13f).toInt()
        val safeRightX = (sw * 0.93f).toInt()

        fun scanTopTabsDynamic(): Pair<List<TopTabNodeCandidate>, Int> {
            val (nodeTabs, nodeY) = inspector.findTopTabRowFromNodes()
            if (nodeTabs.isNotEmpty() && nodeTabs.any { it.matchedCatalogIdx >= 0 }) {
                return nodeTabs to nodeY
            }
            val bmp = captureScreen(2) ?: return nodeTabs to (if (nodeY > 0) nodeY else (sh * 0.095f).toInt())
            return try {
                val dynY = vision.detectTabBarCenterY(bmp)
                val ocrTabs = vision.scanTopWatchlistTabs(bmp).map { t ->
                    TopTabNodeCandidate(t, null, CatalogRepository.matchWatchlistIndexByTabText(t.name))
                }
                ocrTabs to dynY
            } finally {
                bmp.recycle()
            }
        }

        fun tryNativeScrollTabBar(cands: List<TopTabNodeCandidate>, goForwardRight: Boolean): Boolean {
            val anchorNode = cands.firstOrNull { it.node != null }?.node ?: return false
            val action = if (goForwardRight) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            var cur: AccessibilityNodeInfo? = anchorNode.parent
            var depth = 0
            while (cur != null && depth < 5) {
                if (cur.isScrollable || cur.actionList.any { it.id == action }) {
                    if (gesture.performNativeAction(cur, action)) {
                        gesture.sleepSafe(50L)
                        return true
                    }
                }
                cur = cur.parent
                depth++
            }
            return false
        }

        var prevSignature = ""
        var stuckCount = 0

        for (step in 0 until 10) {
            if (shouldAbort()) return 0
            if (gesture.yieldForUserIfNeeded(shouldAbort)) return -1

            val (candidates, tabY) = scanTopTabsDynamic()
            if (shouldAbort()) return 0
            if (gesture.yieldForUserIfNeeded(shouldAbort)) return -1

            val sig = candidates.joinToString("|") { "${it.info.name}:${it.matchedCatalogIdx}" }
            AppStore.log("顶栏#$step(Y=$tabY)：$sig")

            val targetHit = candidates.firstOrNull { it.matchedCatalogIdx == targetIdx }
            if (targetHit != null) {
                if (targetHit.node != null && gesture.clickNodeOrParent(targetHit.node)) {
                    AppStore.log("顶栏直点[${targetWl.name}]")
                    waitForListSwitchEffect(prevRowSymbols, targetWl)
                    gesture.markOwnActionJustFinished()
                    return 1
                }
                if (targetHit.info.centerX < safeLeftX && step < 9) {
                    if (!gesture.swipeTabBar(tabY, swipeFingerRightToLeft = false, distanceFrac = 0.30f)) return -1
                    continue
                }
                if (targetHit.info.centerX > safeRightX && step < 9) {
                    if (!gesture.swipeTabBar(tabY, swipeFingerRightToLeft = true, distanceFrac = 0.30f)) return -1
                    continue
                }
                val clickX = targetHit.info.centerX.coerceIn(safeLeftX, safeRightX)
                if (!gesture.dispatchTap(clickX.toFloat(), tabY.toFloat())) return -1
                waitForListSwitchEffect(prevRowSymbols, targetWl)
                gesture.markOwnActionJustFinished()
                return 1
            }

            if (sig == prevSignature && sig.isNotEmpty()) {
                stuckCount++
                if (stuckCount >= 3) return 0
            } else {
                stuckCount = 0
                prevSignature = sig
            }

            val knownIndices = candidates.map { it.matchedCatalogIdx }.filter { it >= 0 }
            val hasGarbage = candidates.any { it.matchedCatalogIdx < 0 }
            val seesLastCatalog = knownIndices.any { it >= lastCatalogIdx }

            val goRightToLeft: Boolean = when {
                knownIndices.isEmpty() -> {
                    if (candidates.isNotEmpty()) false
                    else if (currIdx >= 0 && targetIdx >= 0) (targetIdx > currIdx) else false
                }
                seesLastCatalog && targetIdx < lastCatalogIdx -> false
                hasGarbage && knownIndices.max() >= lastCatalogIdx - 1 && targetIdx < knownIndices.min() -> false
                knownIndices.min() > targetIdx -> false
                knownIndices.max() < targetIdx -> true
                else -> (targetIdx > knownIndices.average())
            }

            if (stuckCount == 0 && tryNativeScrollTabBar(candidates, goForwardRight = goRightToLeft)) {
                continue
            }

            if (stuckCount == 1 && tabY < (sh * 0.075f).toInt()) {
                val pullPath = Path().apply {
                    moveTo(sw * 0.50f, sh * 0.35f)
                    lineTo(sw * 0.50f, sh * 0.52f)
                }
                gesture.dispatchGestureSync(
                    GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pullPath, 0L, 120L)).build()
                )
                gesture.sleepSafe(65L)
                continue
            }

            val baseFrac = when {
                knownIndices.isEmpty() -> 0.68f
                else -> {
                    val nearest = knownIndices.minByOrNull { abs(it - targetIdx) } ?: targetIdx
                    when (abs(targetIdx - nearest)) {
                        in 0..2 -> 0.45f
                        in 3..4 -> 0.58f
                        else -> 0.68f
                    }
                }
            }
            val distFrac = if (stuckCount > 0) 0.68f else baseFrac
            val effectiveY = if (stuckCount > 0 && tabY < (sh * 0.08f).toInt()) tabY + 14 else tabY
            if (!gesture.swipeTabBar(effectiveY, swipeFingerRightToLeft = goRightToLeft, distanceFrac = distFrac)) {
                return -1
            }
        }
        return 0
    }

    /**
     * 2ms 原生直查等待新列表渲染完成（将原来的 3.5~4.7 秒空转压到 ~80~150ms！）
     */
    private fun waitForListSwitchEffect(prevRowSymbols: List<String>, targetWl: CatalogWatchlist) {
        val prevAnchor = prevRowSymbols.firstOrNull { sym ->
            !CatalogRepository.isSymbolInWatchlist(sym, targetWl.id)
        } ?: prevRowSymbols.firstOrNull()

        val targetPendingSyms = getPendingTasksForWatchlist(targetWl).map { it.symbol }.take(3)
        val targetFirstSyms = targetWl.flattenInstruments().take(2).map { it.symbol }
        val targetCheckSyms = (targetPendingSyms + targetFirstSyms).distinct().take(3)

        // 最多轮询 12 次 × 20ms (~240ms 上限)，单次检查仅 ~4ms
        for (i in 0 until 12) {
            gesture.sleepSafe(20L)
            if (shouldAbort() || gesture.userIntervenedFlag.get()) return
            // 条件A：原列表首品种已消失 -> 新列表已切过来了！
            if (prevAnchor != null && !inspector.isSymbolVisibleOnScreenFast(prevAnchor)) {
                gesture.sleepSafe(35L) // 给新列表行渲染留 35ms
                return
            }
            // 条件B：目标列表里的待办或首品种已经直接出现！
            if (targetCheckSyms.any { inspector.isSymbolVisibleOnScreenFast(it) }) {
                return
            }
        }
    }

    // ==================== 屏幕扫描 + 智能免截屏旗帜检测 ====================

    private fun scanScreenRows(waitForFreshNodes: Boolean): Triple<List<WatchlistRow>, IntArray?, Bitmap?> {
        val poolSymbols = AppStore.snapshotTasks().map { it.symbol }.toSet()
        val (_, screenH) = screenSizeProvider()

        var nodeRows = inspector.scanWatchlistSymbolsFromNodes()
        if (waitForFreshNodes && nodeRows.size < 3) {
            for (tryIdx in 0 until 3) {
                gesture.sleepSafe(30L)
                if (shouldAbort()) return Triple(emptyList(), null, null)
                nodeRows = inspector.scanWatchlistSymbolsFromNodes()
                if (nodeRows.size >= 3) break
            }
        }

        val nodeReliable = nodeRows.size >= 4 ||
            (nodeRows.size >= 2 && nodeRows.last().bottomY >= (screenH * 0.60f).toInt())

        if (nodeReliable) {
            val matchedNodes = nodeRows.filter { vision.findMatchingTaskKey(it.symbol, poolSymbols) != null }
            if (matchedNodes.isEmpty()) {
                return Triple(nodeRows, null, null)
            }

            // 极速跳过查小旗模式：0 截屏，直接零延迟开标！
            if (AppStore.isSkipFlagCheckTurbo()) {
                return Triple(nodeRows, null, null)
            }
            // 命中目标时直接单次截屏核验左边缘全 7 色旗帜
            val matchedSet = matchedNodes.toSet()
            val captured = captureScreen(3)
            if (captured != null) {
                val rowsWithFlags = nodeRows.map { r ->
                    if (r in matchedSet) {
                        val flagColor = vision.detectLeftEdgeFlagColor(captured, r.topY, r.bottomY)
                        r.copy(hasAnyFlag = (flagColor != null), existingFlagColor = flagColor)
                    } else r
                }
                val fp = vision.computeListFingerprint(captured)
                return Triple(rowsWithFlags, fp, captured)
            }
            return Triple(nodeRows, null, null)
        }

        var captured = captureScreen(3) ?: return Triple(emptyList(), null, null)
        var rows = vision.scanWatchlistSymbols(captured)
        if (waitForFreshNodes && rows.isEmpty() && !shouldAbort()) {
            captured.recycle()
            gesture.sleepSafe(50L)
            captured = captureScreen(2) ?: return Triple(emptyList(), null, null)
            rows = vision.scanWatchlistSymbols(captured)
        }
        val fp = vision.computeListFingerprint(captured)
        return Triple(rows, fp, captured)
    }

    // ==================== 同屏命中处理与长按标色 ====================

    private fun processVisibleMatches(
        rows: List<WatchlistRow>,
        currentWl: CatalogWatchlist?,
        activeColorWl: ActiveColorWatchlist?,
        onSucceeded: () -> Unit,
        onFailedMenu: (PendingTask, String) -> Unit
    ): Boolean {
        // 颜色列表包含来自任何普通列表的品种，因此直接匹配待办池全部任务；普通列表按所属列表精确匹配
        val eligibleTasks = if (activeColorWl != null) AppStore.snapshotTasks() else getPendingTasksForWatchlist(currentWl)
        if (eligibleTasks.isEmpty() || rows.isEmpty()) return false

        val taskBySymbol = HashMap<String, PendingTask>()
        for (t in eligibleTasks) {
            taskBySymbol.putIfAbsent(t.symbol, t)
        }

        val matchedPairs = ArrayList<Pair<WatchlistRow, PendingTask>>()
        for (row in rows) {
            val matchedSym = vision.findMatchingTaskKey(row.symbol, taskBySymbol.keys) ?: continue
            val task = taskBySymbol[matchedSym] ?: continue
            matchedPairs.add(row to task)
        }
        if (matchedPairs.isEmpty()) return false

        // 观察并记录不在《品种大全》中的品种上下文位置
        if (currentWl != null) {
            for (rIdx in rows.indices) {
                val rSym = rows[rIdx].symbol
                if (CatalogRepository.findLocations(rSym).isEmpty()) {
                    val isMatched = matchedPairs.any { it.first === rows[rIdx] }
                    if (isMatched) {
                        val prevSym = if (rIdx > 0) rows[rIdx - 1].symbol else ""
                        val nextSym = if (rIdx + 1 < rows.size) rows[rIdx + 1].symbol else ""
                        AppStore.recordUnknownSymbol(rSym, currentWl.id, currentWl.name, prevSym, nextSym)
                    }
                }
            }
        }

        val symbolOrdersInWl = currentWl?.let { CatalogRepository.getSymbolOrdersInWatchlist(it.id) } ?: emptyMap()
        val visibleOrderBounds = rows.flatMap { symbolOrdersInWl[it.symbol].orEmpty() }
        val visMinOrder = visibleOrderBounds.minOrNull()
        val visMaxOrder = visibleOrderBounds.maxOrNull()
        val overwriteDiff = AppStore.isOverwriteDifferentColorFlag()

        val skipFlagTurbo = AppStore.isSkipFlagCheckTurbo()

        fun shouldSkipByExistingFlag(row: WatchlistRow, targetColor: MarkColor): Pair<Boolean, String> {
            // 规则1：处在顶部“颜色列表”下 -> 同色跳过、异色重新标色！（零截屏秒判）
            if (activeColorWl != null) {
                val curColor = row.existingFlagColor ?: activeColorWl.color
                return if (curColor == targetColor) {
                    true to "颜色列表[${activeColorWl.name}]：已是${targetColor.label}色，无视跳过"
                } else {
                    false to ""
                }
            }

            // 规则2：处在非颜色列表（普通自选表）下 -> 只要检测到已有标色就不管（除非手动开启覆盖开关）
            if (skipFlagTurbo && !row.hasAnyFlag) {
                val prevSessColor = AppStore.getSessionMarkedColor(row.symbol, currentWl?.id)
                if (prevSessColor == targetColor) {
                    return true to "极速防误取消：本轮已标${targetColor.label}色，自动跳过"
                }
                return false to ""
            }
            if (!row.hasAnyFlag) return false to ""
            if (!overwriteDiff) {
                val cLabel = row.existingFlagColor?.label ?: "颜色"
                return true to "已有${cLabel}标记，无视跳过"
            }
            if (row.existingFlagColor == targetColor) {
                return true to "已有相同${targetColor.label}标，防误取消跳过"
            }
            return false to ""
        }

        for ((idx, pair) in matchedPairs.withIndex()) {
            if (shouldAbort()) return false
            if (gesture.yieldForUserIfNeeded(shouldAbort)) return true

            val (row, task) = pair
            val liveTask = AppStore.getTaskByKey(task.key) ?: continue

            val hasMoreSameOnScreen = matchedPairs.drop(idx + 1).any { it.second.key == liveTask.key }
            val allOrdersHere = symbolOrdersInWl[liveTask.symbol].orEmpty()
            val hasMoreDuplicateOutside = if (visMinOrder != null && visMaxOrder != null && allOrdersHere.size > 1) {
                allOrdersHere.any { it < visMinOrder || it > visMaxOrder }
            } else false

            val (skipFlag, skipReason) = shouldSkipByExistingFlag(row, liveTask.color)
            if (skipFlag) {
                AppStore.log("${row.symbol} $skipReason")
                AppStore.recordSessionMarked(liveTask.symbol, row.existingFlagColor ?: liveTask.color, currentWl?.id.orEmpty())
                onSucceeded()
                if (!hasMoreSameOnScreen && !hasMoreDuplicateOutside) {
                    AppStore.removeTaskByKey(liveTask.key)
                }
                continue
            }

            if (activeColorWl != null) {
                AppStore.log("颜色列表[${activeColorWl.name}]：${row.symbol} 由${activeColorWl.color.label}色改标为${liveTask.color.label}色")
            } else if (row.hasAnyFlag && overwriteDiff && row.existingFlagColor != null) {
                AppStore.log("${row.symbol} 原为${row.existingFlagColor.label}标 -> 覆盖改为${liveTask.color.label}标")
            }

            val isLastOpOverall = !hasMoreSameOnScreen && !hasMoreDuplicateOutside &&
                (idx == matchedPairs.lastIndex) && (AppStore.pendingCount() <= 1)
            val hasNextActionableOnScreen = matchedPairs.drop(idx + 1).any { (nextRow, nextTask) ->
                !shouldSkipByExistingFlag(nextRow, nextTask.color).first
            }

            val status = longPressAndSelectColor(
                row = row,
                color = liveTask.color,
                isLastOperation = isLastOpOverall,
                hasNextOnSameScreen = hasNextActionableOnScreen
            )
            if (status == -2) {
                return true
            } else if (status == 1) {
                AppStore.recordSessionMarked(liveTask.symbol, liveTask.color, currentWl?.id.orEmpty())
                onSucceeded()
                if (!hasMoreSameOnScreen && !hasMoreDuplicateOutside) {
                    AppStore.removeTaskByKey(liveTask.key)
                }
            } else if (!shouldAbort()) {
                val wlLabel = currentWl?.name ?: "当前列表"
                val msg = "未添加：${liveTask.symbol}（${liveTask.color.label}色），在 $wlLabel 未弹出颜色菜单"
                AppStore.log(msg)
                onFailedMenu(liveTask, msg)
                AppStore.removeTaskByKey(liveTask.key)
            }
        }
        return false
    }

    private fun tryNativeLongClickRow(row: WatchlistRow): Pair<ColorMenuDots, String>? {
        if (nativeRowLongClickSupport == -1) return null
        val startNode = row.rowNode ?: return null
        var cur: AccessibilityNodeInfo? = startNode
        var depth = 0
        var target: AccessibilityNodeInfo? = null
        while (cur != null && depth < 5) {
            if (cur.isLongClickable || cur.actionList.any { it.id == AccessibilityNodeInfo.ACTION_LONG_CLICK }) {
                target = cur
                break
            }
            cur = cur.parent
            depth++
        }
        if (target == null) {
            nativeRowLongClickSupport = -1
            return null
        }

        if (!gesture.performNativeAction(target, AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
            nativeRowLongClickSupport = -1
            return null
        }

        val steps = longArrayOf(25L, 30L, 35L, 40L, 45L)
        for (waitMs in steps) {
            gesture.sleepSafe(waitMs)
            if (shouldAbort()) return null
            val found = inspector.findColorMenuFromAccessibilityWindows()
            if (found != null) {
                if (nativeRowLongClickSupport != 1) {
                    nativeRowLongClickSupport = 1
                    AppStore.log("启用原生极速秒弹模式")
                }
                return found.first to "原生秒弹+${found.second}"
            }
        }
        nativeRowLongClickSupport = -1
        return null
    }

    /**
     * 返回 1=成功，-1=失败，-2=被用户触屏打断（礼让，不判失败）
     */
    private fun longPressAndSelectColor(
        row: WatchlistRow,
        color: MarkColor,
        isLastOperation: Boolean,
        hasNextOnSameScreen: Boolean
    ): Int {
        /**
         * 点击闭环验证：点完颜色点后确认菜单确实关闭；若未关说明点击落空，立即补点一次，绝不静默丢单！
         */
        fun finishWithMenu(menuDots: ColorMenuDots, method: String, isNative: Boolean): Boolean {
            val (tapX, tapY) = menuDots.pointFor(color)
            AppStore.log("命中7色栏($method) -> 点${color.label}($tapX,$tapY)")
            val tapDoneStart = SystemClock.uptimeMillis()
            gesture.dispatchTap(tapX.toFloat(), tapY.toFloat())
            lastColorDotTapAtMs = SystemClock.uptimeMillis()

            var menuClosed = false
            for (w in 0 until 9) {
                gesture.sleepSafe(18L)
                if (!inspector.isColorMenuStillOpenFast()) {
                    menuClosed = true
                    break
                }
            }

            // 闭环补点：160ms 后弹窗仍未关，说明刚才点击落空 -> 立刻微偏 +2px 补点验证！
            if (!menuClosed && !shouldAbort()) {
                AppStore.log("颜色点点击未关窗，立即补点验证")
                gesture.dispatchTap((tapX + 2).toFloat(), tapY.toFloat())
                lastColorDotTapAtMs = SystemClock.uptimeMillis()
                for (w in 0 until 9) {
                    gesture.sleepSafe(18L)
                    if (!inspector.isColorMenuStillOpenFast()) {
                        menuClosed = true
                        break
                    }
                }
            }

            if (!menuClosed) {
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                gesture.sleepSafe(90L)
                gesture.markOwnActionJustFinished()
                return false
            }

            if (!isLastOperation) {
                val minCooldown = when {
                    hasNextOnSameScreen && isNative -> 220L
                    hasNextOnSameScreen -> AppStore.getPostTapCooldownMs()
                    else -> 70L
                }
                val elapsedAfterTap = SystemClock.uptimeMillis() - tapDoneStart
                if (elapsedAfterTap < minCooldown) {
                    gesture.sleepSafe(minCooldown - elapsedAfterTap)
                }
                gesture.markOwnActionJustFinished()
            }
            return true
        }

        val nativeFound = tryNativeLongClickRow(row)
        if (nativeFound != null) {
            return if (finishWithMenu(nativeFound.first, nativeFound.second, isNative = true)) 1 else -1
        }

        val (_, sh) = screenSizeProvider()
        val firstDur = AppStore.getCustomLongPressMs()
        val secondDur = maxOf(firstDur + 115L, 845L)
        val durations = longArrayOf(firstDur, secondDur)
        val wasConsecutive = (SystemClock.uptimeMillis() - lastColorDotTapAtMs) < 950L

        for (idx in durations.indices) {
            if (shouldAbort()) return -2

            // 每次长按前 2ms 实时复核当前品种的最新屏幕坐标，杜绝滚动后坐标偏移误点板块标题！
            val liveRow = inspector.fastFindPendingRowsByText(listOf(row.symbol))
                .minByOrNull { abs(it.centerY - row.centerY) }
                ?: row
            val liveMidY = (liveRow.centerY + (sh * 0.006f).toInt()).coerceIn((sh * 0.09f).toInt(), (sh * 0.935f).toInt())
            val lx = if (idx == 0) liveRow.centerX else liveRow.centerX + 18
            val ly = if (idx == 0) liveMidY else liveRow.centerY
            val dur = durations[idx]
            AppStore.log("长按 ${row.symbol} 第${idx + 1}次 ($lx,$ly) ${dur}ms")

            if (!gesture.dispatchLongPress(lx.toFloat(), ly.toFloat(), dur)) {
                gesture.triggerTouchYield(600L)
                AppStore.log("检测到触屏中断长按，短礼让用户（待办已保留）")
                return -2
            }

            var found: Pair<ColorMenuDots, String>? = inspector.findColorMenuFromAccessibilityWindows()
            if (found == null) {
                val nodePollSteps = longArrayOf(20L, 25L, 30L, 35L, 45L)
                for (stepWait in nodePollSteps) {
                    gesture.sleepSafe(stepWait)
                    if (shouldAbort()) return -2
                    found = inspector.findColorMenuFromAccessibilityWindows()
                    if (found != null) break
                }
            }

            if (found == null && idx == 1) {
                val menuBmp = captureScreen(1)
                if (menuBmp != null) {
                    try {
                        val dots = vision.findColorMenu(menuBmp)
                        if (dots != null) {
                            found = dots to "截屏像素"
                        }
                    } finally {
                        menuBmp.recycle()
                    }
                }
            }

            if (found != null) {
                if (idx == 1 && wasConsecutive) {
                    val bumped = (AppStore.getPostTapCooldownMs() + 60L).coerceAtMost(600L)
                    AppStore.setPostTapCooldownMs(bumped)
                    AppStore.log("自适应优化连按冷却 -> ${bumped}ms")
                }
                val verified = finishWithMenu(found.first, found.second, isNative = false)
                if (verified) return 1
            } else {
                if (inspector.isSectionHeaderMenuOpenFast()) {
                    AppStore.log("检测到误弹板块菜单，自动关闭并重新定位 ${row.symbol}")
                    service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                    gesture.sleepSafe(110L)
                    gesture.markOwnActionJustFinished()
                } else {
                    AppStore.log("第${idx + 1}次长按 ${row.symbol} 未找到7色栏")
                }
            }
        }
        return -1
    }

    // ==================== 从 TV 一键自动采集/校准当前自选表 ====================

    fun runWatchlistCalibration() {
        gesture.sleepSafe(180L)
        if (shouldAbort()) return

        // 1) 识别当前列表
        val initRows = inspector.scanWatchlistSymbolsFromNodes()
        var currentWl = CatalogRepository.identifyWatchlistByVisibleSymbols(initRows.map { it.symbol })
            ?: inspector.detectActiveWatchlistFromTopNodes()
        if (currentWl == null) {
            val bmp = captureScreen(2)
            if (bmp != null) {
                try {
                    val tabName = vision.readActiveWatchlistName(bmp)
                    if (tabName != null) currentWl = CatalogRepository.getWatchlistByName(tabName)
                } finally {
                    bmp.recycle()
                }
            }
        }
        val targetWl = currentWl
        if (targetWl == null) {
            AppStore.cancelCalibrationMode()
            onShowCustomBanner("未识别列表")
            AppStore.log("自动采集失败：未能识别当前所在列表")
            return
        }

        AppStore.log("开始自动采集列表[${targetWl.name}]：先回顶再逐屏采集...")

        // 2) 快速滚到列表顶部
        var prevTopSig = initRows.map { it.symbol }
        var sameTop = 0
        for (i in 0 until 25) {
            if (shouldAbort()) return
            if (!gesture.performFastScroll(scrollDown = false)) {
                AppStore.cancelCalibrationMode()
                return
            }
            gesture.sleepSafe(75L)
            val nowSig = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }
            if (nowSig.isNotEmpty() && nowSig == prevTopSig) {
                sameTop++
                if (sameTop >= 2) break
            } else {
                sameTop = 0
                prevTopSig = nowSig
            }
        }
        gesture.sleepSafe(100L)

        // 3) 从顶部逐屏向下采集全部真实品种并按重叠段精确拼接（保留真实顺序与同名重复行）
        val collected = ArrayList<String>()
        var prevScreen = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }
        if (prevScreen.isEmpty()) {
            val bmp = captureScreen(2)
            if (bmp != null) {
                try { prevScreen = vision.scanWatchlistSymbols(bmp).map { it.symbol } } finally { bmp.recycle() }
            }
        }
        collected.addAll(prevScreen)

        var sameBottom = 0
        for (step in 0 until 45) {
            if (shouldAbort()) return
            if (!gesture.performControlledScroll(scrollDown = true, stronger = (sameBottom > 0))) {
                AppStore.cancelCalibrationMode()
                return
            }
            gesture.sleepSafe(55L)
            var currScreen = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }
            if (currScreen.isNotEmpty() && currScreen == prevScreen) {
                gesture.sleepSafe(75L)
                currScreen = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }
            }
            if (currScreen.isEmpty()) continue

            if (currScreen == prevScreen) {
                sameBottom++
                if (sameBottom >= 2) break
                continue
            }
            sameBottom = 0

            // 寻找上一屏尾部与当前屏头部的最大重叠段，精准拼接新露出的品种
            val maxOverlap = minOf(prevScreen.size, currScreen.size)
            var overlapLen = 0
            for (k in maxOverlap downTo 1) {
                if (prevScreen.subList(prevScreen.size - k, prevScreen.size) == currScreen.subList(0, k)) {
                    overlapLen = k
                    break
                }
            }
            if (overlapLen > 0) {
                for (idx in overlapLen until currScreen.size) {
                    collected.add(currScreen[idx])
                }
            } else {
                // 极少情况无严格重叠时，去重末尾后追加
                for (sym in currScreen) {
                    if (collected.takeLast(6).none { it == sym }) {
                        collected.add(sym)
                    }
                }
            }
            prevScreen = currScreen
        }

        if (shouldAbort()) return
        AppStore.submitCalibrationResult(targetWl.id, targetWl.name, collected)
        onShowCustomBanner("采集完成(${collected.size}个)")
    }
}
