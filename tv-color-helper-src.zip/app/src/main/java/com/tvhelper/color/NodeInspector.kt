package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs
import kotlin.math.roundToInt

enum class TvPageState { CHART, WATCHLIST, OTHER }

data class ActiveColorWatchlist(
    val name: String,
    val color: MarkColor
)

data class ChartWheelContext(
    val prevSymbol: String?,
    val currentSymbol: String?,
    val nextSymbol: String?
)

data class TopTabNodeCandidate(
    val info: WatchlistTabInfo,
    val node: AccessibilityNodeInfo?,
    val matchedCatalogIdx: Int
)

data class DrawerItemCandidate(
    val name: String,
    val centerX: Int,
    val centerY: Int,
    val node: AccessibilityNodeInfo
)

data class SectionHeaderCandidate(
    val text: String,
    val topY: Int,
    val bottomY: Int,
    val centerX: Int,
    val centerY: Int,
    val node: AccessibilityNodeInfo
)

/**
 * 职责单一的无障碍节点读取与页面识别模块（全空间剪枝 + 原生文本直查）
 */
class NodeInspector(
    private val service: AccessibilityService,
    private val vision: VisionEngine,
    private val screenSizeProvider: () -> Pair<Int, Int>
) {
    companion object {
        const val TV_PACKAGE = "com.tradingview.tradingviewapp"
        private val MENU_DOT_X_FRACS = floatArrayOf(0.088f, 0.226f, 0.358f, 0.496f, 0.633f, 0.765f, 0.903f)
        private val PRICE_REGEX = Regex("""^[+-]?\d[\d,.]*%?$""")
    }

    @Volatile
    private var lastMatchedMenuAnchor: String = "移至底部"

    /**
     * 始终返回全屏的 TradingView 主窗口（绝不把长按弹出的 7 色小弹窗误当主窗口导致 WATCHLIST -> OTHER 假中断！）
     */
    fun findTradingViewRoot(): AccessibilityNodeInfo? {
        val (sw, sh) = screenSizeProvider()
        val active = service.rootInActiveWindow
        if (active != null && active.packageName?.toString() == TV_PACKAGE) {
            val ar = Rect().also { active.getBoundsInScreen(it) }
            // 只有全屏主窗口才直接返回；如果是 7 色菜单等小弹窗，跳过它去 windows 里取底层的全屏 TV 主窗口！
            if (ar.isEmpty || (ar.width() >= (sw * 0.85f).toInt() && ar.height() >= (sh * 0.72f).toInt())) {
                return active
            }
        }
        try {
            val winList = service.windows
            if (winList != null) {
                var bestRoot: AccessibilityNodeInfo? = null
                var bestArea = -1L
                val r = Rect()
                for (w in winList) {
                    val root = w.root ?: continue
                    if (root.packageName?.toString() == TV_PACKAGE) {
                        w.getBoundsInScreen(r)
                        val area = r.width().toLong() * r.height().toLong()
                        if (area > bestArea) {
                            bestArea = area
                            bestRoot = root
                        }
                    }
                }
                if (bestRoot != null) return bestRoot
            }
        } catch (_: Exception) {
        }
        if (active != null && active.packageName?.toString() == TV_PACKAGE) {
            return active
        }
        return null
    }

    fun getTvWindowRootsOrderedBySmallFirst(): List<Pair<AccessibilityNodeInfo, Rect>> {
        val roots = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()
        val seenWinIds = HashSet<Int>()
        val winRect = Rect()

        val active = service.rootInActiveWindow
        if (active != null && active.packageName?.toString() == TV_PACKAGE) {
            active.getBoundsInScreen(winRect)
            seenWinIds.add(active.windowId)
            roots.add(active to Rect(winRect))
        }

        try {
            val winList = service.windows
            if (winList != null) {
                for (w in winList) {
                    val r = w.root ?: continue
                    if (r.packageName?.toString() != TV_PACKAGE) continue
                    if (seenWinIds.add(r.windowId)) {
                        w.getBoundsInScreen(winRect)
                        roots.add(r to Rect(winRect))
                    }
                }
            }
        } catch (_: Exception) {
        }
        roots.sortBy { it.second.width() }
        return roots
    }

    fun isNodeOrAncestorSelected(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isSelected || cur.isChecked) return true
            val desc = cur.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("已选") || desc.contains("selected")) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    /**
     * 双向精准空间剪枝判断当前 TV 页面（严格过滤不可见后台 Fragment，杜绝列表页残留圆球！）：
     * 1) 底部导航栏 + 图表底栏（反向DFS，严格跳过不可见节点）
     * 2) 顶部自选表头（正向BFS，绝不被中间大RecyclerView耗尽预算）
     * 3) 自选表特征永远优先于滚轮兜底，彻底杜绝列表最底行品种被误判成图表页！
     */
    fun detectTradingViewPage(
        root: AccessibilityNodeInfo,
        isBatchRunning: Boolean,
        onWheelContextFound: (ChartWheelContext) -> Unit
    ): TvPageState {
        val (_, sh) = screenSizeProvider()
        val navTopThreshold = (sh * 0.90f).toInt()
        val topMaxY = (sh * 0.145f).toInt()
        val botMinY = (sh * 0.890f).toInt()

        var watchlistNav: AccessibilityNodeInfo? = null
        var chartNav: AccessibilityNodeInfo? = null
        var otherBottomNav: AccessibilityNodeInfo? = null
        var hasTopWatchlistHeader = false
        var hasChartBottomToolbar = false
        val rect = Rect()

        // 1) 反向DFS直查底部 5 个导航栏标签与图表周期栏（跳过所有不可见后台页节点！）
        run {
            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(root)
            var visited = 0
            while (stack.isNotEmpty() && visited < 450) {
                val node = stack.removeLast()
                visited++
                if (!node.isVisibleToUser) continue
                node.getBoundsInScreen(rect)
                if (!rect.isEmpty && rect.bottom < botMinY) continue

                val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                    ?: node.contentDescription?.toString()?.trim().orEmpty()
                if (text.isNotEmpty()) {
                    if (rect.bottom >= navTopThreshold) {
                        when (text) {
                            "自选表", "Watchlist" -> watchlistNav = node
                            "图表", "Chart" -> chartNav = node
                            "探索", "Explore", "社区", "Community", "菜单", "Menu" -> {
                                if (isNodeOrAncestorSelected(node)) otherBottomNav = node
                            }
                        }
                    }
                    if (rect.centerY() in (sh * 0.915f).toInt()..(sh * 0.958f).toInt() &&
                        (text.contains("周") || text.contains("日") || text.contains("小时") || text.contains("分") ||
                            text.contains("月") || text.equals("1D", true) || text.equals("1W", true) || text.equals("4H", true))
                    ) {
                        hasChartBottomToolbar = true
                    }
                }
                for (i in 0 until node.childCount) {
                    val child = node.getChild(i) ?: continue
                    stack.add(child)
                }
            }
        }

        // 2) 正向BFS直查顶部自选表标签栏（1ms 内直达，绝不被中间大列表饿死！）
        run {
            val queue = ArrayDeque<AccessibilityNodeInfo>()
            queue.add(root)
            var visited = 0
            while (queue.isNotEmpty() && visited < 200) {
                val node = queue.removeFirst()
                visited++
                if (!node.isVisibleToUser) continue
                node.getBoundsInScreen(rect)
                if (!rect.isEmpty && rect.top > topMaxY) continue

                val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                    ?: node.contentDescription?.toString()?.trim().orEmpty()
                if (text.isNotEmpty() && rect.top < topMaxY) {
                    if (text.startsWith("-1") || text.startsWith("-2") || text.startsWith("-3") ||
                        text.startsWith("-4") || text.startsWith("-5") || text.startsWith("-6") ||
                        text.contains("0000") || text.contains("备") ||
                        CatalogRepository.matchWatchlistIndexByTabText(text) >= 0 ||
                        parseColorWatchlistName(text) != null
                    ) {
                        hasTopWatchlistHeader = true
                        break
                    }
                }
                for (i in 0 until node.childCount) {
                    val child = node.getChild(i) ?: continue
                    queue.add(child)
                }
            }
        }

        // 0) 明确排除搜索页，以及底部选中了“探索 / 社区 / 菜单”或新闻页（绝不误判为自选表页！）
        if (isSymbolSearchPage(root)) {
            return TvPageState.OTHER
        }
        if (otherBottomNav != null) {
            return TvPageState.OTHER
        }

        val isChartSelected = isNodeOrAncestorSelected(chartNav)
        val isWatchlistSelected = isNodeOrAncestorSelected(watchlistNav)

        if (isChartSelected && !isWatchlistSelected) return TvPageState.CHART
        if (isWatchlistSelected && !isChartSelected) return TvPageState.WATCHLIST

        if (isExploreOrNewsPage(root)) {
            return TvPageState.OTHER
        }

        // 仅当底部导航缺失且确实弹出了 7 色菜单或 ≡ 列表抽屉时，才在批处理期间维持 WATCHLIST；
        // 绝不再盲目把图表页或搜索页强行当成 WATCHLIST！
        if (isBatchRunning && watchlistNav == null && chartNav == null) {
            if (isColorMenuStillOpenFast() || isWatchlistDrawerOpen()) {
                return TvPageState.WATCHLIST
            }
        }

        // 关键硬约束：顶部有自选表栏且底部没有图表周期栏 -> 必为 WATCHLIST，绝不落入滚轮误判！
        if (hasTopWatchlistHeader && !hasChartBottomToolbar) return TvPageState.WATCHLIST
        if (hasChartBottomToolbar && !hasTopWatchlistHeader) return TvPageState.CHART

        // 兜底防线：如果在任意自选表（含 04备❸欧随 等非大全备份列表）上看到了 >= 3 行竖排品种，必为 WATCHLIST！
        if (!hasTopWatchlistHeader && !hasChartBottomToolbar) {
            val stackedRows = scanWatchlistSymbolsFromNodes()
            if (stackedRows.size >= 3) {
                return TvPageState.WATCHLIST
            }
        }

        // 仅当确认不在自选表页时，才走左下角滚轮铁律判 CHART
        if (!hasTopWatchlistHeader) {
            val wheelCtx = extractChartWheelContext(root)
            if (wheelCtx.currentSymbol != null) {
                onWheelContextFound(wheelCtx)
                return TvPageState.CHART
            }
        }

        if (watchlistNav == null && chartNav == null) return TvPageState.OTHER
        return TvPageState.OTHER
    }

    /**
     * <1.5ms 反向DFS读取左下角滚轮的「上一个 / 当前高亮 / 下一个」三联代码上下文：
     * - 严格过滤 !isVisibleToUser（彻底隔离隐藏在图表背后的自选表残留行如 NATURALGAS/RMS/Siemens Energy AG！）
     * - 精确对齐实测滚轮纵坐标（prev=92.45%, curr=94.05%, next=95.55%），不串行、不误读！
     */

    /**
     * 2ms 检测当前是否为 TradingView 商品搜索页（含“搜索商品代码”或“全部+股票/期货/加密货币”分类条）
     */

    /**
     * 2ms 检测当前是否为 TradingView 探索页或新闻页（防止被误判成自选表）
     */
    fun isExploreOrNewsPage(root: AccessibilityNodeInfo): Boolean {
        val (sw, sh) = screenSizeProvider()
        val r = Rect()
        for (marker in arrayOf("新闻流", "新闻", "探索")) {
            val hits = try { root.findAccessibilityNodeInfosByText(marker) } catch (_: Exception) { null }
            if (hits.isNullOrEmpty()) continue
            for (n in hits) {
                if (!n.isVisibleToUser) continue
                val t = n.text?.toString()?.trim().orEmpty()
                if (t != marker) continue
                n.getBoundsInScreen(r)
                // 顶部大标题（新闻 / 探索）或正文中的“新闻流”
                if ((marker == "新闻流" && r.top in (sh * 0.12f).toInt()..(sh * 0.88f).toInt()) ||
                    (r.top in (sh * 0.035f).toInt()..(sh * 0.15f).toInt() && r.left < (sw * 0.35f).toInt())
                ) {
                    return true
                }
            }
        }
        return false
    }

    /**
     * 2ms 查找 TradingView 底部导航栏指定按钮的可点击节点（同时兼容 text 与 contentDescription）
     */

    /**
     * 2ms 极速检测底部导航栏指定标签（如 "自选表" 或 "图表"）是否已处于选中态，
     * 替代 650 节点整屏页面识别，提速 50 倍以上！
     */
    fun isBottomTabSelectedFast(vararg labels: String): Boolean {
        val root = findTradingViewRoot() ?: return false
        val (_, sh) = screenSizeProvider()
        val navMinY = (sh * 0.91f).toInt()
        val r = Rect()
        var sawAnyMatch = false

        for (lbl in labels) {
            val hits = try { root.findAccessibilityNodeInfosByText(lbl) } catch (_: Exception) { null }
            if (hits.isNullOrEmpty()) continue
            for (n in hits) {
                if (!n.isVisibleToUser) continue
                val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
                if (!txt.equals(lbl, ignoreCase = true)) continue
                n.getBoundsInScreen(r)
                if (r.isEmpty || r.bottom < navMinY) continue
                sawAnyMatch = true
                if (isNodeOrAncestorSelected(n)) return true
            }
        }
        if (sawAnyMatch) return false

        val fallback = findBottomNavTabNode(root, *labels) ?: return false
        return isNodeOrAncestorSelected(fallback)
    }

    fun findBottomNavTabNode(root: AccessibilityNodeInfo, vararg labels: String): AccessibilityNodeInfo? {
        val (_, sh) = screenSizeProvider()
        val navMinY = (sh * 0.91f).toInt()
        val r = Rect()

        fun climbToClickable(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
            var cur: AccessibilityNodeInfo? = n
            var depth = 0
            while (cur != null && depth < 4) {
                if (cur.isClickable) return cur
                cur = cur.parent
                depth++
            }
            return n
        }

        // 1) 原生文本直查
        for (lbl in labels) {
            val hits = try { root.findAccessibilityNodeInfosByText(lbl) } catch (_: Exception) { null }
            if (hits.isNullOrEmpty()) continue
            for (n in hits) {
                if (!n.isVisibleToUser) continue
                val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
                if (!txt.equals(lbl, ignoreCase = true)) continue
                n.getBoundsInScreen(r)
                if (r.isEmpty || r.bottom < navMinY) continue
                return climbToClickable(n)
            }
        }

        // 2) 反向DFS兜底（兼容 contentDescription 存放“探索”/“自选表”的导航控件）
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < 380) {
            val node = stack.removeLast()
            visited++
            if (!node.isVisibleToUser) continue
            node.getBoundsInScreen(r)
            if (!r.isEmpty && r.bottom < navMinY) continue
            val t = node.text?.toString()?.trim().orEmpty()
            val d = node.contentDescription?.toString()?.trim().orEmpty()
            if (r.bottom >= navMinY && labels.any { it.equals(t, true) || it.equals(d, true) }) {
                return climbToClickable(node)
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return null
    }

    /**
     * 2ms 查找 TradingView 底部“探索”按钮的精确可点击矩形区域（完整覆盖第 3 格图标+文字，0ms 拦截点击不进原生探索页）
     */
    fun findExploreTabBounds(root: AccessibilityNodeInfo): Rect? {
        val (sw, sh) = screenSizeProvider()
        val navMinY = (sh * 0.91f).toInt()
        val r = Rect()

        val exploreNode = findBottomNavTabNode(root, "探索", "Explore")
        if (exploreNode != null) {
            exploreNode.getBoundsInScreen(r)
            if (!r.isEmpty && r.bottom >= navMinY) {
                val cx = r.centerX().coerceIn((sw * 0.42f).toInt(), (sw * 0.58f).toInt())
                val halfW = maxOf(r.width() / 2, (sw * 0.095f).toInt()).coerceAtMost((sw * 0.11f).toInt())
                val top = minOf(r.top, (sh * 0.950f).toInt()).coerceIn((sh * 0.935f).toInt(), (sh * 0.962f).toInt())
                return Rect(cx - halfW, top, cx + halfW, sh)
            }
        }

        // 兜底：若底部导航栏明确存在（看到“自选表”或“图表”），直接按底部 5 等分第 3 格计算“探索”精确热区
        val navAnchor = findBottomNavTabNode(root, "自选表", "Watchlist", "图表", "Chart") ?: return null
        navAnchor.getBoundsInScreen(r)
        if (r.isEmpty || r.bottom < navMinY) return null
        val top = minOf(r.top, (sh * 0.950f).toInt()).coerceIn((sh * 0.935f).toInt(), (sh * 0.962f).toInt())
        return Rect((sw * 0.405f).toInt(), top, (sw * 0.595f).toInt(), sh)
    }

    fun isSymbolSearchPage(root: AccessibilityNodeInfo): Boolean {
        val searchBoxHits = try {
            root.findAccessibilityNodeInfosByText("搜索商品代码")
                ?.takeIf { it.isNotEmpty() }
                ?: root.findAccessibilityNodeInfosByText("Search symbols")
        } catch (_: Exception) {
            null
        }
        if (!searchBoxHits.isNullOrEmpty() && searchBoxHits.any { it.isVisibleToUser }) {
            return true
        }
        val cryptoHits = try { root.findAccessibilityNodeInfosByText("加密货币") } catch (_: Exception) { null }
        val futuresHits = try { root.findAccessibilityNodeInfosByText("期货") } catch (_: Exception) { null }
        val r = Rect()
        val (_, sh) = screenSizeProvider()
        val hasSearchCatTab = (cryptoHits.orEmpty() + futuresHits.orEmpty()).any { n ->
            if (!n.isVisibleToUser) return@any false
            n.getBoundsInScreen(r)
            val t = n.text?.toString()?.trim().orEmpty()
            (t == "加密货币" || t == "期货" || t == "股票") && r.centerY() in (sh * 0.06f).toInt()..(sh * 0.16f).toInt()
        }
        if (hasSearchCatTab) {
            val allHits = try { root.findAccessibilityNodeInfosByText("全部") } catch (_: Exception) { null }
            if (!allHits.isNullOrEmpty() && allHits.any { it.isVisibleToUser }) return true
        }
        return false
    }

    /**
     * 跨列表点击 ≡ 或顶栏前的 3ms 安全确认：确认此刻确实处在自选表页（绝不是图表页或搜索页！）
     */
    fun isStillGenuineWatchlistScreen(): Boolean {
        val root = findTradingViewRoot() ?: return false
        if (isSymbolSearchPage(root)) return false
        val state = detectTradingViewPage(root, isBatchRunning = false) {}
        return state == TvPageState.WATCHLIST
    }

    fun extractChartWheelContext(root: AccessibilityNodeInfo): ChartWheelContext {
        val (sw, sh) = screenSizeProvider()
        val targetCenterY = (sh * 0.940f).toInt()
        val scanMinY = (sh * 0.905f).toInt()
        val scanMaxY = (sh * 0.966f).toInt()
        val currMinY = (sh * 0.928f).toInt()
        val currMaxY = (sh * 0.952f).toInt()
        val maxX = (sw * 0.34f).toInt()

        // Triple(centerY, normalizedTicker, priorityScore)
        val items = ArrayList<Triple<Int, String, Int>>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 650) {
            val node = stack.removeLast()
            visited++
            // 根治串号与不重置的核心：严格忽略隐藏后台页（如自选表）的不可见节点！
            if (!node.isVisibleToUser) continue
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < scanMinY - 30 || rect.top > scanMaxY + 30 || rect.left > maxX + 50)) {
                continue
            }
            val nodeText = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            val raw = nodeText ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                val cy = rect.centerY()
                if (cy in scanMinY..scanMaxY && rect.left in 0..maxX) {
                    val normalized = vision.normalizeTickerCandidate(raw)
                    if (normalized != null) {
                        val inCatalog = CatalogRepository.findLocations(normalized).isNotEmpty()
                        val score = (if (nodeText != null) 4 else 0) + (if (inCatalog) 8 else 0)
                        items.add(Triple(cy, normalized, score))
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }

        if (items.isEmpty()) return ChartWheelContext(null, null, null)

        // 按 Y 排序；同一行重叠节点优先保留评分高（可见文本 + 命中品种大全）的真正代码！
        items.sortBy { it.first }
        val deduped = ArrayList<Triple<Int, String, Int>>()
        for (it in items) {
            if (deduped.isEmpty() || abs(it.first - deduped.last().first) > 14) {
                deduped.add(it)
            } else if (it.third > deduped.last().third) {
                deduped[deduped.lastIndex] = it
            }
        }

        var currIdx = -1
        var bestDist = Int.MAX_VALUE
        for (i in deduped.indices) {
            val cy = deduped[i].first
            if (cy in currMinY..currMaxY) {
                val dist = abs(cy - targetCenterY)
                if (dist < bestDist) {
                    bestDist = dist
                    currIdx = i
                }
            }
        }

        if (currIdx < 0) return ChartWheelContext(null, null, null)
        val prevSym = if (currIdx > 0) deduped[currIdx - 1].second else null
        val currSym = deduped[currIdx].second
        val nextSym = if (currIdx + 1 < deduped.size) deduped[currIdx + 1].second else null
        return ChartWheelContext(prevSym, currSym, nextSym)
    }

    fun extractChartSymbolFromNodes(root: AccessibilityNodeInfo): String? {
        return extractChartWheelContext(root).currentSymbol
    }

    /**
     * 2ms 原生直查：判断某个品种代码当前是否显示在自选表屏幕中（单次 Binder 调用，替代3.5秒BFS轮询！）
     */
    fun isSymbolVisibleOnScreenFast(symbol: String): Boolean {
        val root = findTradingViewRoot() ?: return false
        val (sw, sh) = screenSizeProvider()
        val leftMax = (sw * 0.220f).toInt()
        val topMin = (sh * 0.075f).toInt()
        val bottomMax = (sh * 0.944f).toInt()
        val hits = try {
            root.findAccessibilityNodeInfosByText(symbol)
        } catch (_: Exception) {
            null
        } ?: return false

        val r = Rect()
        val targetUpper = symbol.trim().uppercase()
        for (n in hits) {
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(r)
            if (r.left in 0..leftMax && r.top >= topMin && r.bottom <= bottomMax) {
                val raw = n.text?.toString()?.trim().orEmpty()
                val extracted = vision.extractWatchlistSymbol(raw) ?: continue
                if (extracted == targetUpper || extracted.startsWith(targetUpper)) {
                    return true
                }
            }
        }
        return false
    }

    /**
     * 2ms/品种 原生直查：直接向 TV 进程索取指定待办品种在当前屏上的精确行坐标，无需遍历整棵树！
     */
    fun fastFindPendingRowsByText(symbols: Collection<String>): List<WatchlistRow> {
        if (symbols.isEmpty()) return emptyList()
        val root = findTradingViewRoot() ?: return emptyList()
        val (sw, sh) = screenSizeProvider()
        val leftMax = (sw * 0.220f).toInt()
        val topMin = (sh * 0.075f).toInt()
        val bottomMax = (sh * 0.944f).toInt()
        val r = Rect()
        val found = ArrayList<WatchlistRow>()

        for (sym in symbols) {
            val query = sym.trim()
            if (query.isEmpty()) continue
            val hits = try {
                root.findAccessibilityNodeInfosByText(query)
            } catch (_: Exception) {
                null
            } ?: continue

            for (n in hits) {
                if (!n.isVisibleToUser) continue
                n.getBoundsInScreen(r)
                if (r.left !in 0..leftMax || r.top < topMin || r.bottom > bottomMax) continue
                if (r.height() !in 14..(sh * 0.085f).toInt()) continue
                val raw = n.text?.toString()?.trim().orEmpty()
                if (CatalogRepository.matchWatchlistIndexByTabText(raw) >= 0) continue
                val extracted = vision.extractWatchlistSymbol(raw) ?: continue
                if (vision.findMatchingTaskKey(extracted, setOf(sym)) != null) {
                    val cx = if (r.left >= (sw * 0.08f).toInt()) {
                        ((r.left + minOf(r.right, (sw * 0.40f).toInt())) / 2)
                            .coerceIn((sw * 0.14f).toInt(), (sw * 0.36f).toInt())
                    } else {
                        (sw * 0.24f).toInt()
                    }
                    found.add(
                        WatchlistRow(
                            symbol = extracted,
                            centerX = cx,
                            centerY = r.centerY(),
                            topY = r.top,
                            bottomY = r.bottom,
                            hasAnyFlag = false,
                            existingFlagColor = null,
                            rowNode = n
                        )
                    )
                }
            }
        }

        found.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (row in found) {
            if (deduped.isEmpty() || abs(row.centerY - deduped.last().centerY) > (sh * 0.015f)) {
                deduped.add(row)
            }
        }
        return deduped
    }

    /**
     * 快速定位自选表主体竖向滚动容器（RecyclerView），跳过顶部栏和底部导航树，提速 2~3 倍
     */

    /**
     * 1ms 检查当前自选表列表主体是否还能继续向上滚回顶部（已到顶返回 false，省去多余上滑！）
     */
    fun canWatchlistBodyScrollBackward(): Boolean {
        val root = findTradingViewRoot() ?: return false
        val body = findWatchlistBodyContainer(root)
        if (body === root) return false
        return body.actionList.any { it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD }
    }

    /**
     * 查找顶部横向列表栏的可滚动父容器（用于将顶部栏一键倒回最左侧寻找颜色列表）
     */
    fun findTopTabScrollContainer(tabs: List<TopTabNodeCandidate>): AccessibilityNodeInfo? {
        val anchor = tabs.firstOrNull { it.node != null }?.node ?: return null
        var cur: AccessibilityNodeInfo? = anchor.parent
        var depth = 0
        while (cur != null && depth < 5) {
            if (cur.isScrollable || cur.actionList.any {
                    it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD ||
                        it.id == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                }
            ) {
                return cur
            }
            cur = cur.parent
            depth++
        }
        return null
    }

    private fun findWatchlistBodyContainer(root: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val (sw, sh) = screenSizeProvider()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()
        while (queue.isNotEmpty() && visited < 160) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            val cls = n.className?.toString().orEmpty()
            val isVertList = cls.contains("RecyclerView") || cls.contains("ListView") ||
                (n.isScrollable && rect.height() > rect.width())
            if (isVertList &&
                rect.width() >= (sw * 0.72f).toInt() &&
                rect.height() >= (sh * 0.48f).toInt()
            ) {
                return n
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }
        return root
    }

    /**
     * 扫描当前自选表屏幕上的全部品种行节点（直入 RecyclerView 主体 + 跳过不可见节点与右侧价格列）
     */
    fun scanWatchlistSymbolsFromNodes(): List<WatchlistRow> {
        val root = findTradingViewRoot() ?: return emptyList()
        val bodyRoot = findWatchlistBodyContainer(root)
        val (sw, sh) = screenSizeProvider()
        val leftMax = (sw * 0.220f).toInt()
        val topMin = (sh * 0.075f).toInt()
        val bottomMax = (sh * 0.944f).toInt()
        val pruneRightX = (sw * 0.38f).toInt()

        val rows = ArrayList<WatchlistRow>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(bodyRoot)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 520 && rows.size < 18) {
            val node = queue.removeFirst()
            visited++
            if (!node.isVisibleToUser) continue
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < topMin || rect.top > bottomMax || rect.left > pruneRightX)) {
                continue
            }

            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            if (!raw.isNullOrEmpty() &&
                rect.left in 0..leftMax &&
                rect.top >= topMin &&
                rect.bottom <= bottomMax &&
                rect.height() in 14..(sh * 0.085f).toInt()
            ) {
                if (CatalogRepository.matchWatchlistIndexByTabText(raw) >= 0) continue
                val sym = vision.extractWatchlistSymbol(raw)
                if (sym != null) {
                    val cx = if (rect.left >= (sw * 0.08f).toInt()) {
                        ((rect.left + minOf(rect.right, (sw * 0.40f).toInt())) / 2)
                            .coerceIn((sw * 0.14f).toInt(), (sw * 0.36f).toInt())
                    } else {
                        (sw * 0.24f).toInt()
                    }
                    rows.add(
                        WatchlistRow(
                            symbol = sym,
                            centerX = cx,
                            centerY = rect.centerY(),
                            topY = rect.top,
                            bottomY = rect.bottom,
                            hasAnyFlag = false,
                            existingFlagColor = null,
                            rowNode = node
                        )
                    )
                    // 品种文本节点是叶子，无需再展开
                    continue
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                queue.add(c)
            }
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || abs(r.centerY - deduped.last().centerY) > (sh * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    /**
     * 严格精准检测“真正处于折叠状态”且藏有待办品种的板块标题：
     * 1) 绝不碰屏幕底部的板块标题（bottomY >= 76% H 时下方品种只是在屏幕外，并非折叠！）
     * 2) 绝不碰纯虚线/装饰分割行（如 ————————————）
     * 3) 必须满足：紧挨其下方直接就是另一个板块标题且中间 0 个品种行，同时标题命中待办品种的中文名或类别提示！
     */
    fun findCollapsedSectionHeaders(
        visibleRows: List<WatchlistRow>,
        pendingTasks: List<PendingTask>,
        currentWl: CatalogWatchlist
    ): List<SectionHeaderCandidate> {
        val root = findTradingViewRoot() ?: return emptyList()
        val bodyRoot = findWatchlistBodyContainer(root)
        val (sw, sh) = screenSizeProvider()
        val topMin = (sh * 0.105f).toInt()
        val botMax = (sh * 0.900f).toInt()
        val safeExpandMaxY = (sh * 0.760f).toInt()

        val symbolSet = visibleRows.map { it.symbol }.toSet()
        val headers = ArrayList<SectionHeaderCandidate>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(bodyRoot)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 340) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < topMin || rect.top > botMax)) continue

            val txt = n.text?.toString()?.trim().orEmpty()
            // 严禁触碰装饰分割线（如 ——————软商——————）：不允许以横线开头，且横线占比不得超过 30%
            val startsWithDivider = txt.startsWith("—") || txt.startsWith("-") || txt.startsWith("_") ||
                txt.startsWith("■") || txt.startsWith("★") || txt.startsWith("●") || txt.startsWith("▲") || txt.startsWith("◆")
            val dashCount = txt.count { it == '—' || it == '-' || it == '=' || it == '_' }
            val realChineseCount = txt.count { it in '\u4E00'..'\u9FFF' }
            if (!startsWithDivider &&
                realChineseCount >= 3 &&
                (txt.isEmpty() || dashCount.toFloat() / txt.length < 0.30f) &&
                rect.top >= topMin &&
                rect.bottom <= botMax &&
                rect.left < (sw * 0.30f).toInt() &&
                rect.height() in 16..(sh * 0.055f).toInt() &&
                !PRICE_REGEX.matches(txt)
            ) {
                val isSubtitleRow = visibleRows.any { r ->
                    rect.top >= r.bottomY - 8 && rect.top <= r.bottomY + (sh * 0.025f).toInt() && rect.left >= (sw * 0.095f).toInt()
                }
                val isTicker = txt.uppercase() in symbolSet
                val isTopTab = CatalogRepository.matchWatchlistIndexByTabText(txt) >= 0

                if (!isSubtitleRow && !isTicker && !isTopTab) {
                    headers.add(SectionHeaderCandidate(txt, rect.top, rect.bottom, rect.centerX(), rect.centerY(), n))
                }
            }

            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }

        if (headers.size < 2) return emptyList()
        headers.sortBy { it.centerY }
        val dedupHeaders = ArrayList<SectionHeaderCandidate>()
        for (h in headers) {
            if (dedupHeaders.isEmpty() || abs(h.centerY - dedupHeaders.last().centerY) > (sh * 0.018f).toInt()) {
                dedupHeaders.add(h)
            }
        }

        val pendingHints = ArrayList<String>()
        for (task in pendingTasks) {
            pendingHints.addAll(CatalogRepository.findCategoryHintsForSymbol(currentWl.id, task.symbol))
        }
        val cleanHints = pendingHints
            .map { it.trimStart('★', '△', '▲', '●', '■', '◆', '〓', '【', ' ').trimEnd('】', ' ') }
            .filter { it.length >= 2 }
            .distinct()

        val collapsed = ArrayList<SectionHeaderCandidate>()
        for (i in 0 until dedupHeaders.lastIndex) {
            val cur = dedupHeaders[i]
            // 严禁触碰底部 24% 区域的板块标题，避免把“下屏品种在屏幕外”的展开板块误折叠！
            if (cur.bottomY > safeExpandMaxY) continue

            val nextHeader = dedupHeaders[i + 1]
            val gapPx = nextHeader.topY - cur.bottomY
            if (gapPx !in 0..(sh * 0.055f).toInt()) continue

            val hasSymbolBetween = visibleRows.any { r -> r.centerY > cur.bottomY && r.centerY < nextHeader.topY }
            if (hasSymbolBetween) continue

            // 必须同时满足：紧贴下板块无品种 + 标题命中当前待办品种的中文名或类别提示
            val matchesPendingHint = cleanHints.any { hint -> cur.text.contains(hint, ignoreCase = true) }
            if (matchesPendingHint) {
                collapsed.add(cur)
            }
        }
        return collapsed
    }

    // ==================== 顶部列表栏 & 左上角 ≡ 抽屉直选 ====================

    fun findTopTabRowFromNodes(): Pair<List<TopTabNodeCandidate>, Int> {
        val root = findTradingViewRoot() ?: return emptyList<TopTabNodeCandidate>() to 0
        val (sw, sh) = screenSizeProvider()
        val topMin = (sh * 0.036f).toInt()
        val botMax = (sh * 0.130f).toInt()
        val minX = (sw * 0.080f).toInt()

        val rawCandidates = ArrayList<TopTabNodeCandidate>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 280) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.top > botMax + 30 || rect.bottom < topMin - 30)) {
                continue
            }

            val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (txt.isNotEmpty() &&
                rect.centerY() in topMin..botMax &&
                rect.right > minX &&
                rect.left < sw &&
                rect.width() in 24..(sw * 0.44f).toInt() &&
                rect.height() in 18..(sh * 0.068f).toInt()
            ) {
                val isPrice = PRICE_REGEX.matches(txt)
                val isSection = txt.startsWith("---") || txt.startsWith("—") || txt.startsWith("✓") || txt.startsWith("▼") || txt.contains("——")
                val isKnownTicker = CatalogRepository.findLocations(txt).isNotEmpty()
                if (!isPrice && !isSection && !isKnownTicker) {
                    val matchedIdx = CatalogRepository.matchWatchlistIndexByTabText(txt)
                    val info = WatchlistTabInfo(txt, rect.left, rect.right, rect.centerX(), rect.centerY())
                    rawCandidates.add(TopTabNodeCandidate(info, n, matchedIdx))
                    if (rawCandidates.size >= 7 && rawCandidates.count { it.matchedCatalogIdx >= 0 } >= 2) {
                        break
                    }
                }
            }

            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }

        if (rawCandidates.isEmpty()) return emptyList<TopTabNodeCandidate>() to 0

        val rowGroups = ArrayList<MutableList<TopTabNodeCandidate>>()
        for (cand in rawCandidates.sortedBy { it.info.centerY }) {
            val group = rowGroups.firstOrNull { abs(it.first().info.centerY - cand.info.centerY) <= 24 }
            if (group != null) group.add(cand) else rowGroups.add(mutableListOf(cand))
        }

        val bestGroup = rowGroups.maxByOrNull { grp ->
            val catalogHits = grp.count { it.matchedCatalogIdx >= 0 }
            val colorListHits = grp.count { parseColorWatchlistName(it.info.name) != null }
            val dashHits = grp.count { it.info.name.startsWith("-") || it.info.name.contains("000") }
            val avgY = grp.map { it.info.centerY }.average()
            catalogHits * 20 + colorListHits * 18 + dashHits * 4 + grp.size * 2 - (avgY / sh * 3.0).toInt()
        } ?: return emptyList<TopTabNodeCandidate>() to 0

        val sorted = bestGroup.sortedBy { it.info.centerX }
        val deduped = ArrayList<TopTabNodeCandidate>()
        for (c in sorted) {
            if (deduped.isEmpty() || abs(c.info.centerX - deduped.last().info.centerX) > (sw * 0.04f).toInt()) {
                deduped.add(c)
            }
        }
        val avgY = deduped.map { it.info.centerY }.average().roundToInt()
        return deduped to avgY
    }


    /**
     * 精准识别顶部最前面的 7 种颜色列表名称（严格排除了后方垃圾列表如 "0备绿色列表"）
     */
    fun parseColorWatchlistName(raw: String): MarkColor? {
        val clean = raw.trim().replace(" ", "")
        if (clean.isEmpty()) return null
        // 排除带数字或“备”前缀的垃圾列表（如 "0备绿色列表"）
        val c0 = clean[0]
        if (c0 in '0'..'9' || c0 == '备' || clean.contains("备")) return null
        val lower = clean.lowercase()
        return when {
            clean == "红色列表" || clean == "红列表" || lower == "redlist" -> MarkColor.RED
            clean == "蓝色列表" || clean == "蓝列表" || lower == "bluelist" -> MarkColor.BLUE
            clean == "绿色列表" || clean == "绿列表" || lower == "greenlist" -> MarkColor.GREEN
            clean == "黄色列表" || clean == "黄列表" || clean == "橙色列表" || lower == "yellowlist" || lower == "orangelist" -> MarkColor.YELLOW
            clean == "紫色列表" || clean == "紫列表" || lower == "purplelist" -> MarkColor.PURPLE
            clean == "青色列表" || clean == "青列表" || lower == "cyanlist" -> MarkColor.CYAN
            clean == "粉色列表" || clean == "粉列表" || lower == "pinklist" -> MarkColor.PINK
            else -> null
        }
    }

    /**
     * 2ms 检测当前激活的自选表是否为“颜色列表”（红色列表/蓝色列表/绿色列表等）
     */
    fun detectActiveColorWatchlistFromTopNodes(): ActiveColorWatchlist? {
        val (tabs, _) = findTopTabRowFromNodes()
        for (t in tabs) {
            val col = parseColorWatchlistName(t.info.name) ?: continue
            if (t.node != null && isNodeOrAncestorSelected(t.node)) {
                return ActiveColorWatchlist(t.info.name, col)
            }
        }
        return null
    }


    /**
     * 2ms 查找顶栏左侧已选中的“纯图标颜色列表标签”矩形区域（位于 ≡ 右侧、-1商 左侧）：
     * 如果找到，直接对该矩形采样即可 100% 精准读出颜色列表色，不受灰底深浅影响！
     */
    fun findSelectedColorTabIconRect(): Rect? {
        val root = findTradingViewRoot() ?: return null
        val (sw, sh) = screenSizeProvider()
        val topMin = (sh * 0.036f).toInt()
        val botMax = (sh * 0.130f).toInt()
        val minX = (sw * 0.085f).toInt()
        val maxX = (sw * 0.72f).toInt()

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 280) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.top > botMax + 30 || rect.bottom < topMin - 30)) continue

            if ((n.isSelected || n.isChecked) &&
                rect.centerY() in topMin..botMax &&
                rect.left >= minX &&
                rect.right <= maxX &&
                rect.width() in (sw * 0.045f).toInt()..(sw * 0.20f).toInt() &&
                rect.height() in 24..(sh * 0.068f).toInt()
            ) {
                val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
                // 如果节点自身不含普通列表名（如 -1商），且其子节点也不含普通列表名 -> 它就是纯图标颜色列表！
                var hasCatalogChildText = txt.isNotEmpty() && CatalogRepository.matchWatchlistIndexByTabText(txt) >= 0
                if (!hasCatalogChildText) {
                    for (i in 0 until n.childCount) {
                        val cTxt = n.getChild(i)?.text?.toString()?.trim().orEmpty()
                        if (cTxt.isNotEmpty() && CatalogRepository.matchWatchlistIndexByTabText(cTxt) >= 0) {
                            hasCatalogChildText = true
                            break
                        }
                    }
                }
                if (!hasCatalogChildText) {
                    return Rect(rect)
                }
            }

            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }
        return null
    }


    /**
     * 单次扫描顶栏同时返回 (当前选中的普通列表?, 当前选中的颜色列表?)，避免颜色列表翻屏时重复扫两次顶栏
     */
    fun detectActiveTabSummary(): Pair<CatalogWatchlist?, ActiveColorWatchlist?> {
        val (tabs, _) = findTopTabRowFromNodes()
        var activeCatalog: CatalogWatchlist? = null
        var activeColor: ActiveColorWatchlist? = null
        for (t in tabs) {
            val node = t.node ?: continue
            if (!isNodeOrAncestorSelected(node)) continue
            if (t.matchedCatalogIdx >= 0 && activeCatalog == null) {
                activeCatalog = CatalogRepository.getWatchlists().getOrNull(t.matchedCatalogIdx)
            }
            if (activeColor == null) {
                parseColorWatchlistName(t.info.name)?.let { col ->
                    activeColor = ActiveColorWatchlist(t.info.name, col)
                }
            }
        }
        return activeCatalog to activeColor
    }

    fun detectActiveWatchlistFromTopNodes(): CatalogWatchlist? {
        val (tabs, _) = findTopTabRowFromNodes()
        for (t in tabs) {
            if (t.matchedCatalogIdx >= 0 && t.node != null && isNodeOrAncestorSelected(t.node)) {
                return CatalogRepository.getWatchlists().getOrNull(t.matchedCatalogIdx)
            }
        }
        return null
    }

    /**
     * 查找左上角 ≡ 列表抽屉按钮节点（位于 X: 0..10% W，与当前顶部列表栏同高度）
     */
    fun findHamburgerButtonNode(approxTabY: Int): AccessibilityNodeInfo? {
        val root = findTradingViewRoot() ?: return null
        val (sw, sh) = screenSizeProvider()
        val targetY = if (approxTabY > 0) approxTabY else (sh * 0.085f).toInt()
        val minY = if (approxTabY > 0) (targetY - (sh * 0.030f).toInt()).coerceAtLeast((sh * 0.032f).toInt()) else (sh * 0.035f).toInt()
        val maxY = if (approxTabY > 0) (targetY + (sh * 0.030f).toInt()).coerceAtMost((sh * 0.135f).toInt()) else (sh * 0.132f).toInt()
        val maxX = (sw * 0.115f).toInt()

        var bestNode: AccessibilityNodeInfo? = null
        var bestDist = Int.MAX_VALUE

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 260) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.top > maxY + 30 || rect.bottom < minY - 30 || rect.left > maxX + 40)) {
                continue
            }
            if (n.isClickable &&
                rect.centerX() in 6..maxX &&
                rect.centerY() in minY..maxY &&
                rect.width() in 24..(sw * 0.15f).toInt() &&
                rect.height() in 24..(sh * 0.08f).toInt()
            ) {
                val dist = abs(rect.centerY() - targetY) + abs(rect.centerX() - (sw * 0.042f).toInt())
                if (dist < bestDist) {
                    bestDist = dist
                    bestNode = n
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }
        return bestNode
    }

    /**
     * 判断左上角 ≡ 点开的“列表”抽屉页是否已打开
     */
    fun isWatchlistDrawerOpen(): Boolean {
        val (sw, sh) = screenSizeProvider()
        for ((root, _) in getTvWindowRootsOrderedBySmallFirst()) {
            val headerHits = try {
                root.findAccessibilityNodeInfosByText("列表")
                    ?.takeIf { it.isNotEmpty() }
                    ?: root.findAccessibilityNodeInfosByText("Watchlists")
            } catch (_: Exception) {
                null
            }
            if (!headerHits.isNullOrEmpty()) {
                val r = Rect()
                for (h in headerHits) {
                    h.getBoundsInScreen(r)
                    val txt = h.text?.toString()?.trim().orEmpty()
                    if ((txt == "列表" || txt.equals("Watchlists", ignoreCase = true)) && r.centerY() in (sh * 0.03f).toInt()..(sh * 0.15f).toInt() && r.left < (sw * 0.35f).toInt()) {
                        return true
                    }
                }
            }
        }
        return false
    }

    /**
     * 在打开的 ≡ 列表抽屉中极速直查目标列表（所有 12 个有效列表都在抽屉首屏，5ms 精准命中！）
     */
    fun findWatchlistInDrawer(targetWl: CatalogWatchlist): DrawerItemCandidate? {
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)
        if (targetIdx < 0) return null
        val (sw, sh) = screenSizeProvider()
        val minY = (sh * 0.125f).toInt()
        val maxY = (sh * 0.96f).toInt()
        val r = Rect()

        for ((root, _) in getTvWindowRootsOrderedBySmallFirst()) {
            // 1) 原生精确文本直查（~2ms）
            val directHits = try {
                root.findAccessibilityNodeInfosByText(targetWl.name)
            } catch (_: Exception) {
                null
            }
            if (!directHits.isNullOrEmpty()) {
                for (node in directHits) {
                    if (!node.isVisibleToUser) continue
                    node.getBoundsInScreen(r)
                    if (r.centerY() in minY..maxY && r.left < (sw * 0.50f).toInt()) {
                        return DrawerItemCandidate(targetWl.name, r.centerX(), r.centerY(), node)
                    }
                }
            }

            // 2) 抽屉内中文核心兜底直查（兼容 ❶/① 细微差异）
            val cnCore = CatalogRepository.extractChineseCore(targetWl.name)
            if (cnCore.isNotEmpty()) {
                val cnHits = try {
                    root.findAccessibilityNodeInfosByText(cnCore)
                } catch (_: Exception) {
                    null
                }
                if (!cnHits.isNullOrEmpty()) {
                    for (node in cnHits) {
                        if (!node.isVisibleToUser) continue
                        val txt = node.text?.toString()?.trim().orEmpty()
                        if (CatalogRepository.matchWatchlistIndexByTabText(txt) == targetIdx) {
                            node.getBoundsInScreen(r)
                            if (r.centerY() in minY..maxY && r.left < (sw * 0.50f).toInt()) {
                                return DrawerItemCandidate(txt, r.centerX(), r.centerY(), node)
                            }
                        }
                    }
                }
            }
        }
        return null
    }

    // ==================== 5ms 多锚点原生 7 色长按菜单定位（抗 TV 改版） ====================

    fun isColorMenuStillOpenFast(): Boolean {
        val primary = lastMatchedMenuAnchor
        val roots = getTvWindowRootsOrderedBySmallFirst()
        for ((r, _) in roots) {
            val hits = try { r.findAccessibilityNodeInfosByText(primary) } catch (_: Exception) { null }
            if (!hits.isNullOrEmpty()) return true
        }
        // 兜底：若该品种已在列表最底端导致菜单省略了“移至底部”，补查“添加警报 / 打开图表”避免漏认！
        val fallbacks = arrayOf("添加警报", "移至底部", "打开图表", "Add alert", "Move to bottom")
        for ((r, _) in roots) {
            for (anchor in fallbacks) {
                if (anchor == primary) continue
                val hits = try { r.findAccessibilityNodeInfosByText(anchor) } catch (_: Exception) { null }
                if (!hits.isNullOrEmpty()) return true
            }
        }
        return false
    }


    /**
     * 2ms 检测是否误弹了板块标题右键菜单（“重命名板块 / 在下方添加商品代码”）
     */
    fun isSectionHeaderMenuOpenFast(): Boolean {
        for ((r, _) in getTvWindowRootsOrderedBySmallFirst()) {
            for (anchor in arrayOf("重命名板块", "Rename section", "在下方添加商品代码")) {
                val hits = try { r.findAccessibilityNodeInfosByText(anchor) } catch (_: Exception) { null }
                if (!hits.isNullOrEmpty()) return true
            }
        }
        return false
    }

    private fun findFirstNodeByAnyText(root: AccessibilityNodeInfo, vararg texts: String): AccessibilityNodeInfo? {
        for (t in texts) {
            val hits = try { root.findAccessibilityNodeInfosByText(t) } catch (_: Exception) { null }
            if (!hits.isNullOrEmpty()) return hits[0]
        }
        return null
    }

    fun findColorMenuFromAccessibilityWindows(): Pair<ColorMenuDots, String>? {
        val (sw, sh) = screenSizeProvider()
        val roots = getTvWindowRootsOrderedBySmallFirst()

        for ((rootNode, wBounds) in roots) {
            val mbNode = findFirstNodeByAnyText(rootNode, "移至底部", "Move to bottom")
            val aaNode = findFirstNodeByAnyText(rootNode, "添加警报", "Add alert")
            val topNode = if (mbNode == null && aaNode == null) findFirstNodeByAnyText(rootNode, "移至顶部", "Move to top") else null
            val openChartNode = if (mbNode == null && aaNode == null && topNode == null) findFirstNodeByAnyText(rootNode, "打开图表", "Open chart") else null

            val anchorNode = mbNode ?: aaNode ?: topNode ?: openChartNode ?: continue
            anchorNode.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { lastMatchedMenuAnchor = it }
            val mbRect = mbNode?.let { n -> Rect().also { n.getBoundsInScreen(it) }.takeIf { !it.isEmpty } }
            val aaRect = aaNode?.let { n -> Rect().also { n.getBoundsInScreen(it) }.takeIf { !it.isEmpty } }
            val topRect = topNode?.let { n -> Rect().also { n.getBoundsInScreen(it) }.takeIf { !it.isEmpty } }
            val chartRect = openChartNode?.let { n -> Rect().also { n.getBoundsInScreen(it) }.takeIf { !it.isEmpty } }

            // 推算 7 色圆点所在的纵坐标带（支持多锚点任意组合兜底！）
            val estDotY: Int = when {
                mbRect != null && aaRect != null && aaRect.centerY() > mbRect.centerY() + 25 ->
                    (mbRect.centerY() + (aaRect.centerY() - mbRect.centerY()) * 0.412f).roundToInt()
                mbRect != null ->
                    (mbRect.centerY() + sh * 0.0352f).roundToInt()
                aaRect != null ->
                    (aaRect.centerY() - sh * 0.050f).roundToInt()
                topRect != null ->
                    (topRect.centerY() + sh * 0.080f).roundToInt()
                chartRect != null ->
                    (chartRect.centerY() - sh * 0.132f).roundToInt()
                else -> continue
            }
            if (estDotY !in (sh * 0.10f).toInt()..(sh * 0.94f).toInt()) continue

            val bandTop = if (mbRect != null) mbRect.bottom - 12 else (estDotY - (sh * 0.028f).toInt())
            val bandBottom = if (aaRect != null && aaRect.top > bandTop + 10) aaRect.top + 12 else (estDotY + (sh * 0.028f).toInt())

            var searchRoot: AccessibilityNodeInfo = rootNode
            if (wBounds.width() > (sw * 0.72f).toInt()) {
                var cur = anchorNode.parent
                var depth = 0
                val pRect = Rect()
                while (cur != null && depth < 5) {
                    cur.getBoundsInScreen(pRect)
                    if (pRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt() && pRect.height() > (sh * 0.22f).toInt()) {
                        searchRoot = cur
                        break
                    }
                    cur = cur.parent
                    depth++
                }
            }

            val dotCandidates = ArrayList<Rect>()
            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(searchRoot)
            var visited = 0
            val rect = Rect()
            while (stack.isNotEmpty() && visited < 120) {
                val n = stack.removeLast()
                visited++
                n.getBoundsInScreen(rect)
                if (!rect.isEmpty && (rect.bottom < bandTop - 20 || rect.top > bandBottom + 20)) {
                    continue
                }
                if (rect.width() in 16..(sw * 0.14f).toInt() &&
                    rect.height() in 16..(sw * 0.14f).toInt() &&
                    rect.centerY() in bandTop..bandBottom &&
                    rect.left >= 0 && rect.right <= (sw * 0.65f).toInt() &&
                    n.text.isNullOrEmpty() &&
                    (n.isClickable || n.childCount == 0)
                ) {
                    dotCandidates.add(Rect(rect))
                }
                for (i in 0 until n.childCount) {
                    val c = n.getChild(i) ?: continue
                    stack.add(c)
                }
            }

            dotCandidates.sortBy { it.centerX() }
            val distinctDots = ArrayList<Rect>()
            for (r in dotCandidates) {
                if (distinctDots.isEmpty() || abs(r.centerX() - distinctDots.last().centerX()) > (sw * 0.03f).toInt()) {
                    distinctDots.add(r)
                }
            }

            if (distinctDots.size == 7) {
                val xs = IntArray(7) { distinctDots[it].centerX() }
                val avgY = distinctDots.map { it.centerY() }.average().roundToInt()
                if (avgY in (sh * 0.10f).toInt()..(sh * 0.94f).toInt()) {
                    return ColorMenuDots(xs, avgY) to "节点直取7点"
                }
            }

            val srRect = Rect().also { searchRoot.getBoundsInScreen(it) }
            val menuLeft = if (srRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) srRect.left else (sw * 0.026f).toInt()
            val menuRight = if (srRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) srRect.right else (sw * 0.519f).toInt()
            val menuW = (menuRight - menuLeft).coerceAtLeast((sw * 0.40f).toInt())
            val xs = IntArray(7) { idx ->
                (menuLeft + menuW * MENU_DOT_X_FRACS[idx]).roundToInt().coerceIn(4, sw - 4)
            }
            return ColorMenuDots(xs, estDotY) to "多锚点零截屏"
        }
        return null
    }
}
