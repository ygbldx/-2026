package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs
import kotlin.math.roundToInt

enum class TvPageState { CHART, WATCHLIST, OTHER }

data class TopTabNodeCandidate(
    val info: WatchlistTabInfo,
    val node: AccessibilityNodeInfo?,
    val matchedCatalogIdx: Int
)

data class DrawerItemCandidate(
    val name: String,
    val centerX: Int,
    val centerY: Int,
    val node: AccessibilityNodeInfo
)

data class SectionHeaderCandidate(
    val text: String,
    val topY: Int,
    val bottomY: Int,
    val centerX: Int,
    val centerY: Int,
    val node: AccessibilityNodeInfo
)

/**
 * 职责单一的无障碍节点读取与页面识别模块（全空间剪枝 + 原生文本直查）
 */
class NodeInspector(
    private val service: AccessibilityService,
    private val vision: VisionEngine,
    private val screenSizeProvider: () -> Pair<Int, Int>
) {
    companion object {
        const val TV_PACKAGE = "com.tradingview.tradingviewapp"
        private val MENU_DOT_X_FRACS = floatArrayOf(0.088f, 0.226f, 0.358f, 0.496f, 0.633f, 0.765f, 0.903f)
        private val PRICE_REGEX = Regex("""^[+-]?\d[\d,.]*%?$""")
    }

    @Volatile
    private var loggedRowFlagProbeOnce = false

    fun findTradingViewRoot(): AccessibilityNodeInfo? {
        val active = service.rootInActiveWindow
        if (active != null && active.packageName?.toString() == TV_PACKAGE) {
            return active
        }
        try {
            val winList = service.windows
            if (winList != null) {
                var bestRoot: AccessibilityNodeInfo? = null
                var bestArea = -1L
                val r = Rect()
                for (w in winList) {
                    val root = w.root ?: continue
                    if (root.packageName?.toString() == TV_PACKAGE) {
                        w.getBoundsInScreen(r)
                        val area = r.width().toLong() * r.height().toLong()
                        if (area > bestArea) {
                            bestArea = area
                            bestRoot = root
                        }
                    }
                }
                if (bestRoot != null) return bestRoot
            }
        } catch (_: Exception) {
        }
        return null
    }

    fun getTvWindowRootsOrderedBySmallFirst(): List<Pair<AccessibilityNodeInfo, Rect>> {
        val roots = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()
        val seenWinIds = HashSet<Int>()
        val winRect = Rect()

        val active = service.rootInActiveWindow
        if (active != null && active.packageName?.toString() == TV_PACKAGE) {
            active.getBoundsInScreen(winRect)
            seenWinIds.add(active.windowId)
            roots.add(active to Rect(winRect))
        }

        try {
            val winList = service.windows
            if (winList != null) {
                for (w in winList) {
                    val r = w.root ?: continue
                    if (r.packageName?.toString() != TV_PACKAGE) continue
                    if (seenWinIds.add(r.windowId)) {
                        w.getBoundsInScreen(winRect)
                        roots.add(r to Rect(winRect))
                    }
                }
            }
        } catch (_: Exception) {
        }
        roots.sortBy { it.second.width() }
        return roots
    }

    fun isNodeOrAncestorSelected(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isSelected || cur.isChecked) return true
            val desc = cur.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("已选") || desc.contains("selected")) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    /**
     * 空间剪枝反向DFS判断当前 TV 页面：
     * 铁律：只要左下角滚轮出现品种名称（且未选中自选表），立即判定为 CHART，不管上方图表加载与否！
     */
    fun detectTradingViewPage(
        root: AccessibilityNodeInfo,
        isBatchRunning: Boolean,
        onWheelSymbolFound: (String) -> Unit
    ): TvPageState {
        val (_, sh) = screenSizeProvider()
        val navTopThreshold = (sh * 0.90f).toInt()

        var watchlistNav: AccessibilityNodeInfo? = null
        var chartNav: AccessibilityNodeInfo? = null
        var hasTopWatchlistHeader = false
        var hasChartBottomToolbar = false

        val topBound = (sh * 0.145f).toInt()
        val botBound = (sh * 0.890f).toInt()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 650) {
            val node = stack.removeLast()
            visited++
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && rect.top > topBound && rect.bottom < botBound) {
                continue
            }
            val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim().orEmpty()

            if (rect.bottom >= navTopThreshold && text.isNotEmpty()) {
                when (text) {
                    "自选表", "Watchlist" -> watchlistNav = node
                    "图表", "Chart" -> chartNav = node
                }
            } else if (rect.top < sh * 0.14f &&
                (text == "搜索" || text == "Search" || text.startsWith("-1") || text.startsWith("-2") || text.startsWith("-3") || text.startsWith("-4"))
            ) {
                hasTopWatchlistHeader = true
            } else if (rect.top in (sh * 0.90f).toInt()..(sh * 0.955f).toInt() &&
                (text.contains("周") || text.contains("日") || text.contains("小时") || text.contains("分") ||
                    text.equals("1D", true) || text.equals("1W", true))
            ) {
                hasChartBottomToolbar = true
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                stack.add(child)
            }
        }

        // 批处理期间打开了 ≡ 抽屉或 7 色菜单时，底部导航暂时不在，保持 WATCHLIST
        if (isBatchRunning && watchlistNav == null && chartNav == null) {
            return TvPageState.WATCHLIST
        }

        val isChartSelected = isNodeOrAncestorSelected(chartNav)
        val isWatchlistSelected = isNodeOrAncestorSelected(watchlistNav)

        if (isWatchlistSelected && !isChartSelected) return TvPageState.WATCHLIST
        if (isChartSelected && !isWatchlistSelected) return TvPageState.CHART

        // 铁律：左下角滚轮出现品种名立即判 CHART
        val wheelSym = extractChartSymbolFromNodes(root)
        if (wheelSym != null) {
            onWheelSymbolFound(wheelSym)
            return TvPageState.CHART
        }

        if (watchlistNav == null && chartNav == null) return TvPageState.OTHER

        return when {
            hasChartBottomToolbar && !hasTopWatchlistHeader -> TvPageState.CHART
            hasTopWatchlistHeader && !hasChartBottomToolbar -> TvPageState.WATCHLIST
            else -> TvPageState.OTHER
        }
    }

    /**
     * <1ms 反向DFS直奔左下角滚轮读取当前品种代码
     */
    fun extractChartSymbolFromNodes(root: AccessibilityNodeInfo): String? {
        val (sw, sh) = screenSizeProvider()
        val targetCenterY = (sh * 0.938f).toInt()
        val minY = (sh * 0.915f).toInt()
        val maxY = (sh * 0.955f).toInt()
        val maxX = (sw * 0.34f).toInt()

        var bestSym: String? = null
        var bestDist = Int.MAX_VALUE

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 800) {
            val node = stack.removeLast()
            visited++
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < minY - 50 || rect.top > maxY + 50 || rect.left > maxX + 60)) {
                continue
            }
            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                val cy = rect.centerY()
                if (cy in minY..maxY && rect.left in 0..maxX) {
                    val normalized = vision.normalizeTickerCandidate(raw)
                    if (normalized != null) {
                        val dist = abs(cy - targetCenterY)
                        if (dist < bestDist) {
                            bestDist = dist
                            bestSym = normalized
                            if (dist <= 18) break
                        }
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return bestSym
    }

    /**
     * 8ms 浅层快探：只读屏幕最上方前 limit 个可见品种
     */
    fun peekTopWatchlistSymbols(limit: Int): List<String> {
        val root = findTradingViewRoot() ?: return emptyList()
        val (sw, sh) = screenSizeProvider()
        val leftMax = (sw * 0.220f).toInt()
        val topMin = (sh * 0.075f).toInt()
        val bottomMax = (sh * 0.55f).toInt()
        val pruneRightX = (sw * 0.38f).toInt()

        val out = ArrayList<String>(limit)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 180 && out.size < limit) {
            val node = queue.removeFirst()
            visited++
            if (!node.isVisibleToUser) continue
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < topMin || rect.top > bottomMax || rect.left > pruneRightX)) {
                continue
            }
            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            if (!raw.isNullOrEmpty() &&
                rect.left in 0..leftMax &&
                rect.top >= topMin &&
                rect.bottom <= bottomMax &&
                rect.height() in 14..(sh * 0.085f).toInt()
            ) {
                if (CatalogRepository.matchWatchlistIndexByTabText(raw) < 0) {
                    val sym = vision.extractWatchlistSymbol(raw)
                    if (sym != null && sym !in out) {
                        out.add(sym)
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                queue.add(c)
            }
        }
        return out
    }

    /**
     * 扫描当前自选表屏幕上的全部品种行节点（跳过不可见节点与右侧价格列）
     */
    fun scanWatchlistSymbolsFromNodes(): List<WatchlistRow> {
        val root = findTradingViewRoot() ?: return emptyList()
        val (sw, sh) = screenSizeProvider()
        val leftMax = (sw * 0.220f).toInt()
        val topMin = (sh * 0.075f).toInt()
        val bottomMax = (sh * 0.944f).toInt()
        val pruneRightX = (sw * 0.38f).toInt()

        val rows = ArrayList<WatchlistRow>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 420) {
            val node = queue.removeFirst()
            visited++
            if (!node.isVisibleToUser) continue
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < topMin || rect.top > bottomMax || rect.left > pruneRightX)) {
                continue
            }

            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty() &&
                rect.left in 0..leftMax &&
                rect.top >= topMin &&
                rect.bottom <= bottomMax &&
                rect.height() in 14..(sh * 0.085f).toInt()
            ) {
                if (CatalogRepository.matchWatchlistIndexByTabText(raw) >= 0) continue
                val sym = vision.extractWatchlistSymbol(raw)
                if (sym != null) {
                    val cx = if (rect.left >= (sw * 0.08f).toInt()) {
                        ((rect.left + minOf(rect.right, (sw * 0.40f).toInt())) / 2)
                            .coerceIn((sw * 0.14f).toInt(), (sw * 0.36f).toInt())
                    } else {
                        (sw * 0.24f).toInt()
                    }
                    rows.add(
                        WatchlistRow(
                            symbol = sym,
                            centerX = cx,
                            centerY = rect.centerY(),
                            topY = rect.top,
                            bottomY = rect.bottom,
                            hasAnyFlag = false,
                            existingFlagColor = null,
                            rowNode = node
                        )
                    )
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                queue.add(c)
            }
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || abs(r.centerY - deduped.last().centerY) > (sh * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    /**
     * 零截屏行内旗帜节点探测：
     * 检查目标行的父容器最左侧是否暴露了独立颜色小旗子节点（或描述文字）。
     * 返回 Pair(节点确认有旗, 识别到的具体颜色?)；仅在有明确节点证据时返回 true，绝不误判！
     */
    fun probeNodeFlagInRow(row: WatchlistRow): Pair<Boolean, MarkColor?> {
        val startNode = row.rowNode ?: return false to null
        val (sw, sh) = screenSizeProvider()

        var rowContainer: AccessibilityNodeInfo? = startNode.parent
        var depth = 0
        val pRect = Rect()
        while (rowContainer != null && depth < 4) {
            rowContainer.getBoundsInScreen(pRect)
            if (pRect.width() >= (sw * 0.65f).toInt() && pRect.height() in (sh * 0.03f).toInt()..(sh * 0.11f).toInt()) {
                break
            }
            rowContainer = rowContainer.parent
            depth++
        }
        val container = rowContainer ?: return false to null

        val maxFlagRightX = (sw * 0.040f).toInt()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(container)
        var visited = 0
        val r = Rect()
        val debugItems = if (!loggedRowFlagProbeOnce) ArrayList<String>() else null

        while (stack.isNotEmpty() && visited < 40) {
            val n = stack.removeLast()
            visited++
            n.getBoundsInScreen(r)
            val desc = n.contentDescription?.toString()?.trim().orEmpty()
            val descLower = desc.lowercase()

            if (debugItems != null && r.left < (sw * 0.12f).toInt() && n !== container) {
                val cls = n.className?.toString()?.substringAfterLast('.') ?: ""
                debugItems.add("$cls(${r.left}..${r.right},d=$desc)")
            }

            // 1) 明确带颜色/标记描述的节点
            val colorFromDesc = when {
                descLower.contains("red") || desc.contains("红") -> MarkColor.RED
                descLower.contains("blue") || desc.contains("蓝") -> MarkColor.BLUE
                descLower.contains("green") || desc.contains("绿") -> MarkColor.GREEN
                descLower.contains("yellow") || descLower.contains("orange") || desc.contains("黄") -> MarkColor.YELLOW
                descLower.contains("purple") || descLower.contains("violet") || desc.contains("紫") -> MarkColor.PURPLE
                descLower.contains("cyan") || descLower.contains("teal") || desc.contains("青") -> MarkColor.CYAN
                descLower.contains("pink") || desc.contains("粉") -> MarkColor.PINK
                else -> null
            }
            if (colorFromDesc != null && (descLower.contains("flag") || descLower.contains("list") || desc.contains("列表") || desc.contains("标") || r.right <= maxFlagRightX)) {
                return true to colorFromDesc
            }

            // 2) 严格位于最左边缘（X: 0..4% 宽度，完全在圆形图标左侧）的独立可见 View
            if (n !== container && n.isVisibleToUser && r.left in 0..(sw * 0.012f).toInt() && r.right in 6..maxFlagRightX && r.height() in 10..(sh * 0.045f).toInt()) {
                return true to colorFromDesc
            }

            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                stack.add(c)
            }
        }

        if (debugItems != null && debugItems.isNotEmpty()) {
            loggedRowFlagProbeOnce = true
            AppStore.log("节点旗帜探针(${row.symbol})：${debugItems.take(6).joinToString(";")}")
        }
        return false to null
    }

    /**
     * 检测自选表屏幕中可能被折叠（隐藏了品种）的板块标题行：
     * 1) 两个板块标题紧挨着且中间没有任何品种行 -> 上方那个板块必然处于折叠状态！
     * 2) 板块标题文字包含待添加品种的中文名或细分类别提示（如“必选消费——可口可乐、宝洁...”包含“可口可乐”）
     */
    fun findCollapsedSectionHeaders(
        visibleRows: List<WatchlistRow>,
        pendingTasks: List<PendingTask>,
        currentWl: CatalogWatchlist
    ): List<SectionHeaderCandidate> {
        val root = findTradingViewRoot() ?: return emptyList()
        val (sw, sh) = screenSizeProvider()
        val topMin = (sh * 0.095f).toInt()
        val botMax = (sh * 0.925f).toInt()

        val symbolSet = visibleRows.map { it.symbol }.toSet()
        val headers = ArrayList<SectionHeaderCandidate>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 460) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < topMin || rect.top > botMax)) continue

            val txt = n.text?.toString()?.trim().orEmpty()
            if (txt.length >= 2 &&
                rect.top >= topMin &&
                rect.bottom <= botMax &&
                rect.left < (sw * 0.30f).toInt() &&
                rect.height() in 16..(sh * 0.055f).toInt() &&
                !PRICE_REGEX.matches(txt)
            ) {
                val hasChinese = txt.any { it in '\u4E00'..'\u9FFF' }
                val isSubtitleRow = visibleRows.any { r ->
                    rect.top >= r.bottomY - 8 && rect.top <= r.bottomY + (sh * 0.025f).toInt() && rect.left >= (sw * 0.095f).toInt()
                }
                val isTicker = txt.uppercase() in symbolSet
                val isTopTab = CatalogRepository.matchWatchlistIndexByTabText(txt) >= 0

                if (hasChinese && !isSubtitleRow && !isTicker && !isTopTab) {
                    headers.add(SectionHeaderCandidate(txt, rect.top, rect.bottom, rect.centerX(), rect.centerY(), n))
                }
            }

            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }

        if (headers.isEmpty()) return emptyList()
        headers.sortBy { it.centerY }
        val dedupHeaders = ArrayList<SectionHeaderCandidate>()
        for (h in headers) {
            if (dedupHeaders.isEmpty() || abs(h.centerY - dedupHeaders.last().centerY) > (sh * 0.018f).toInt()) {
                dedupHeaders.add(h)
            }
        }

        // 收集当前列表里所有待办品种的中文名 / 类别关键字
        val pendingHints = ArrayList<String>()
        for (task in pendingTasks) {
            pendingHints.addAll(CatalogRepository.findCategoryHintsForSymbol(currentWl.id, task.symbol))
        }
        val cleanHints = pendingHints
            .map { it.trimStart('★', '△', '▲', '●', '■', '◆', '〓', '【', ' ').trimEnd('】', ' ') }
            .filter { it.length >= 2 }
            .distinct()

        val collapsed = ArrayList<SectionHeaderCandidate>()
        for (i in dedupHeaders.indices) {
            val cur = dedupHeaders[i]
            val nextHeader = dedupHeaders.getOrNull(i + 1)
            val hasSymbolRightBelow = visibleRows.any { r ->
                r.centerY > cur.bottomY && (nextHeader == null || r.centerY < nextHeader.topY)
            }
            val adjacentEmptyHeader = nextHeader != null &&
                !hasSymbolRightBelow &&
                (nextHeader.topY - cur.bottomY) in 0..(sh * 0.065f).toInt()

            val matchesPendingHint = !hasSymbolRightBelow && cleanHints.any { hint -> cur.text.contains(hint, ignoreCase = true) }

            if (adjacentEmptyHeader || matchesPendingHint) {
                collapsed.add(cur)
            }
        }
        return collapsed
    }

    // ==================== 顶部列表栏 & 左上角 ≡ 抽屉直选 ====================

    fun findTopTabRowFromNodes(): Pair<List<TopTabNodeCandidate>, Int> {
        val root = findTradingViewRoot() ?: return emptyList<TopTabNodeCandidate>() to 0
        val (sw, sh) = screenSizeProvider()
        val topMin = (sh * 0.036f).toInt()
        val botMax = (sh * 0.130f).toInt()
        val minX = (sw * 0.080f).toInt()

        val rawCandidates = ArrayList<TopTabNodeCandidate>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 280) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.top > botMax + 30 || rect.bottom < topMin - 30)) {
                continue
            }

            val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (txt.isNotEmpty() &&
                rect.centerY() in topMin..botMax &&
                rect.right > minX &&
                rect.left < sw &&
                rect.width() in 24..(sw * 0.44f).toInt() &&
                rect.height() in 18..(sh * 0.068f).toInt()
            ) {
                val isPrice = PRICE_REGEX.matches(txt)
                val isSection = txt.startsWith("---") || txt.startsWith("—") || txt.startsWith("✓") || txt.startsWith("▼") || txt.contains("——")
                val isKnownTicker = CatalogRepository.findLocations(txt).isNotEmpty()
                if (!isPrice && !isSection && !isKnownTicker) {
                    val matchedIdx = CatalogRepository.matchWatchlistIndexByTabText(txt)
                    val info = WatchlistTabInfo(txt, rect.left, rect.right, rect.centerX(), rect.centerY())
                    rawCandidates.add(TopTabNodeCandidate(info, n, matchedIdx))
                    if (rawCandidates.size >= 7 && rawCandidates.count { it.matchedCatalogIdx >= 0 } >= 2) {
                        break
                    }
                }
            }

            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }

        if (rawCandidates.isEmpty()) return emptyList<TopTabNodeCandidate>() to 0

        val rowGroups = ArrayList<MutableList<TopTabNodeCandidate>>()
        for (cand in rawCandidates.sortedBy { it.info.centerY }) {
            val group = rowGroups.firstOrNull { abs(it.first().info.centerY - cand.info.centerY) <= 24 }
            if (group != null) group.add(cand) else rowGroups.add(mutableListOf(cand))
        }

        val bestGroup = rowGroups.maxByOrNull { grp ->
            val catalogHits = grp.count { it.matchedCatalogIdx >= 0 }
            val dashHits = grp.count { it.info.name.startsWith("-") || it.info.name.contains("000") }
            val avgY = grp.map { it.info.centerY }.average()
            catalogHits * 20 + dashHits * 4 + grp.size * 2 - (avgY / sh * 3.0).toInt()
        } ?: return emptyList<TopTabNodeCandidate>() to 0

        val sorted = bestGroup.sortedBy { it.info.centerX }
        val deduped = ArrayList<TopTabNodeCandidate>()
        for (c in sorted) {
            if (deduped.isEmpty() || abs(c.info.centerX - deduped.last().info.centerX) > (sw * 0.04f).toInt()) {
                deduped.add(c)
            }
        }
        val avgY = deduped.map { it.info.centerY }.average().roundToInt()
        return deduped to avgY
    }

    fun detectActiveWatchlistFromTopNodes(): CatalogWatchlist? {
        val (tabs, _) = findTopTabRowFromNodes()
        for (t in tabs) {
            if (t.matchedCatalogIdx >= 0 && t.node != null && isNodeOrAncestorSelected(t.node)) {
                return CatalogRepository.getWatchlists().getOrNull(t.matchedCatalogIdx)
            }
        }
        return null
    }

    /**
     * 查找左上角 ≡ 列表抽屉按钮节点（位于 X: 0..10% W，与当前顶部列表栏同高度）
     */
    fun findHamburgerButtonNode(approxTabY: Int): AccessibilityNodeInfo? {
        val root = findTradingViewRoot() ?: return null
        val (sw, sh) = screenSizeProvider()
        val targetY = if (approxTabY > 0) approxTabY else (sh * 0.095f).toInt()
        val minY = (targetY - (sh * 0.030f).toInt()).coerceAtLeast((sh * 0.032f).toInt())
        val maxY = (targetY + (sh * 0.030f).toInt()).coerceAtMost((sh * 0.135f).toInt())
        val maxX = (sw * 0.115f).toInt()

        var bestNode: AccessibilityNodeInfo? = null
        var bestDist = Int.MAX_VALUE

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 260) {
            val n = queue.removeFirst()
            visited++
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.top > maxY + 30 || rect.bottom < minY - 30 || rect.left > maxX + 40)) {
                continue
            }
            if (n.isClickable &&
                rect.centerX() in 6..maxX &&
                rect.centerY() in minY..maxY &&
                rect.width() in 24..(sw * 0.15f).toInt() &&
                rect.height() in 24..(sh * 0.08f).toInt()
            ) {
                val dist = abs(rect.centerY() - targetY) + abs(rect.centerX() - (sw * 0.042f).toInt())
                if (dist < bestDist) {
                    bestDist = dist
                    bestNode = n
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }
        return bestNode
    }

    /**
     * 判断左上角 ≡ 点开的“列表”抽屉页是否已打开
     */
    fun isWatchlistDrawerOpen(): Boolean {
        val (sw, sh) = screenSizeProvider()
        for ((root, _) in getTvWindowRootsOrderedBySmallFirst()) {
            val headerHits = try {
                root.findAccessibilityNodeInfosByText("列表")
                    ?.takeIf { it.isNotEmpty() }
                    ?: root.findAccessibilityNodeInfosByText("Watchlists")
            } catch (_: Exception) {
                null
            }
            if (!headerHits.isNullOrEmpty()) {
                val r = Rect()
                for (h in headerHits) {
                    h.getBoundsInScreen(r)
                    val txt = h.text?.toString()?.trim().orEmpty()
                    if ((txt == "列表" || txt.equals("Watchlists", ignoreCase = true)) && r.centerY() in (sh * 0.03f).toInt()..(sh * 0.15f).toInt() && r.left < (sw * 0.35f).toInt()) {
                        return true
                    }
                }
            }
        }
        return false
    }

    /**
     * 在打开的 ≡ 列表抽屉中极速直查目标列表（所有 12 个有效列表都在抽屉首屏，5ms 精准命中！）
     */
    fun findWatchlistInDrawer(targetWl: CatalogWatchlist): DrawerItemCandidate? {
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)
        if (targetIdx < 0) return null
        val (sw, sh) = screenSizeProvider()
        val minY = (sh * 0.125f).toInt()
        val maxY = (sh * 0.96f).toInt()
        val r = Rect()

        for ((root, _) in getTvWindowRootsOrderedBySmallFirst()) {
            // 1) 原生精确文本直查（~2ms）
            val directHits = try {
                root.findAccessibilityNodeInfosByText(targetWl.name)
            } catch (_: Exception) {
                null
            }
            if (!directHits.isNullOrEmpty()) {
                for (node in directHits) {
                    if (!node.isVisibleToUser) continue
                    node.getBoundsInScreen(r)
                    if (r.centerY() in minY..maxY && r.left < (sw * 0.50f).toInt()) {
                        return DrawerItemCandidate(targetWl.name, r.centerX(), r.centerY(), node)
                    }
                }
            }

            // 2) 抽屉内中文核心兜底直查（兼容 ❶/① 细微差异）
            val cnCore = CatalogRepository.extractChineseCore(targetWl.name)
            if (cnCore.isNotEmpty()) {
                val cnHits = try {
                    root.findAccessibilityNodeInfosByText(cnCore)
                } catch (_: Exception) {
                    null
                }
                if (!cnHits.isNullOrEmpty()) {
                    for (node in cnHits) {
                        if (!node.isVisibleToUser) continue
                        val txt = node.text?.toString()?.trim().orEmpty()
                        if (CatalogRepository.matchWatchlistIndexByTabText(txt) == targetIdx) {
                            node.getBoundsInScreen(r)
                            if (r.centerY() in minY..maxY && r.left < (sw * 0.50f).toInt()) {
                                return DrawerItemCandidate(txt, r.centerX(), r.centerY(), node)
                            }
                        }
                    }
                }
            }
        }
        return null
    }

    // ==================== 5ms 原生 7 色长按菜单定位 ====================

    fun isColorMenuStillOpenFast(): Boolean {
        for ((r, _) in getTvWindowRootsOrderedBySmallFirst()) {
            val hits = try {
                r.findAccessibilityNodeInfosByText("移至底部")
            } catch (_: Exception) {
                null
            }
            if (!hits.isNullOrEmpty()) return true
        }
        return false
    }

    fun findColorMenuFromAccessibilityWindows(): Pair<ColorMenuDots, String>? {
        val (sw, sh) = screenSizeProvider()
        val roots = getTvWindowRootsOrderedBySmallFirst()

        for ((rootNode, wBounds) in roots) {
            val mbNodes = try {
                rootNode.findAccessibilityNodeInfosByText("移至底部")
                    ?.takeIf { it.isNotEmpty() }
                    ?: rootNode.findAccessibilityNodeInfosByText("Move to bottom")
            } catch (_: Exception) {
                null
            }
            if (mbNodes.isNullOrEmpty()) continue

            val mbNode = mbNodes[0]
            val mbRect = Rect().also { mbNode.getBoundsInScreen(it) }
            if (mbRect.isEmpty) continue

            val aaNodes = try {
                rootNode.findAccessibilityNodeInfosByText("添加警报")
                    ?.takeIf { it.isNotEmpty() }
                    ?: rootNode.findAccessibilityNodeInfosByText("Add alert")
            } catch (_: Exception) {
                null
            }
            val aaRect: Rect? = aaNodes?.firstOrNull()?.let { n ->
                Rect().also { n.getBoundsInScreen(it) }.takeIf { it.centerY() > mbRect.centerY() + 25 }
            }

            val bandTop = mbRect.bottom - 12
            val bandBottom = if (aaRect != null) aaRect.top + 12 else (mbRect.bottom + (sh * 0.068f).toInt())
            var searchRoot: AccessibilityNodeInfo = rootNode
            if (wBounds.width() > (sw * 0.72f).toInt()) {
                var cur = mbNode.parent
                var depth = 0
                val pRect = Rect()
                while (cur != null && depth < 5) {
                    cur.getBoundsInScreen(pRect)
                    if (pRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt() && pRect.height() > (sh * 0.22f).toInt()) {
                        searchRoot = cur
                        break
                    }
                    cur = cur.parent
                    depth++
                }
            }

            val dotCandidates = ArrayList<Rect>()
            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(searchRoot)
            var visited = 0
            val rect = Rect()
            while (stack.isNotEmpty() && visited < 120) {
                val n = stack.removeLast()
                visited++
                n.getBoundsInScreen(rect)
                if (!rect.isEmpty && (rect.bottom < bandTop - 20 || rect.top > bandBottom + 20)) {
                    continue
                }
                if (rect.width() in 16..(sw * 0.14f).toInt() &&
                    rect.height() in 16..(sw * 0.14f).toInt() &&
                    rect.centerY() in bandTop..bandBottom &&
                    rect.left >= 0 && rect.right <= (sw * 0.65f).toInt() &&
                    n.text.isNullOrEmpty() &&
                    (n.isClickable || n.childCount == 0)
                ) {
                    dotCandidates.add(Rect(rect))
                }
                for (i in 0 until n.childCount) {
                    val c = n.getChild(i) ?: continue
                    stack.add(c)
                }
            }

            dotCandidates.sortBy { it.centerX() }
            val distinctDots = ArrayList<Rect>()
            for (r in dotCandidates) {
                if (distinctDots.isEmpty() || abs(r.centerX() - distinctDots.last().centerX()) > (sw * 0.03f).toInt()) {
                    distinctDots.add(r)
                }
            }

            if (distinctDots.size == 7) {
                val xs = IntArray(7) { distinctDots[it].centerX() }
                val avgY = distinctDots.map { it.centerY() }.average().roundToInt()
                if (avgY in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) {
                    return ColorMenuDots(xs, avgY) to "节点直取7点"
                }
            }

            val dotY = if (aaRect != null) {
                (mbRect.centerY() + (aaRect.centerY() - mbRect.centerY()) * 0.412f).roundToInt()
            } else {
                (mbRect.centerY() + sh * 0.0352f).roundToInt()
            }
            if (dotY !in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) continue

            val srRect = Rect().also { searchRoot.getBoundsInScreen(it) }
            val menuLeft = if (srRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) srRect.left else (sw * 0.026f).toInt()
            val menuRight = if (srRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) srRect.right else (sw * 0.519f).toInt()
            val menuW = (menuRight - menuLeft).coerceAtLeast((sw * 0.40f).toInt())
            val xs = IntArray(7) { idx ->
                (menuLeft + menuW * MENU_DOT_X_FRACS[idx]).roundToInt().coerceIn(4, sw - 4)
            }
            return ColorMenuDots(xs, dotY) to "锚点零截屏"
        }
        return null
    }
}
