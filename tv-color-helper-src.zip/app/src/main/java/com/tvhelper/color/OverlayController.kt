package com.tvhelper.color

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

data class InfoDisplayItem(
    val symbol: String,
    val cnName: String,
    val source: String,
    val color: MarkColor
)

class OverlayController(
    private val context: Context,
    private val onColorTap: (MarkColor) -> Unit,
    private val onRequestPauseService: (String) -> Unit,
    private val onInfoPanelDismissed: () -> Unit = {}
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    // 1. 多色圆球容器（单例容器，原地更新内部球，杜绝重影）
    private var buttonsContainer: LinearLayout? = null
    private var buttonsParams: WindowManager.LayoutParams? = null
    private val colorViews = LinkedHashMap<MarkColor, View>()
    @Volatile
    private var activeLitColor: MarkColor? = null
    private var isButtonsAttached = false
    private var lastBallTapMs = 0L

    // 2. 完活弹窗（纯黑白、3秒/点击消失、长按拖动记住位置、可选提示音、零震动）
    private var doneView: TextView? = null
    private var doneParams: WindowManager.LayoutParams? = null
    private val doneAutoDismiss = Runnable { hideDoneBannerInternal() }

    // 3. 右侧竖排清单面板（纯黑白、严格对齐、固定不随列表动、多选关闭方式）
    private var infoContainer: LinearLayout? = null
    private var infoParams: WindowManager.LayoutParams? = null
    private var lastInfoItems: List<InfoDisplayItem> = emptyList()
    private var isInfoAttached = false

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun screenSize(): Pair<Int, Int> {
        val bounds = wm.maximumWindowMetrics.bounds
        return bounds.width() to bounds.height()
    }

    // =========================================================================
    // 1. 多色悬浮球（支持任意 1~7 色、多选退出方式：双击 / 右滑 / 任意方向滑动）
    // =========================================================================

    fun showButtons() {
        mainHandler.post {
            ensureButtonsCreated()
            rebuildBallsInsideContainer()
            val view = buttonsContainer ?: return@post
            val params = buttonsParams ?: return@post
            if (isButtonsAttached || view.isAttachedToWindow) {
                try {
                    wm.updateViewLayout(view, params)
                } catch (_: Exception) {
                }
                isButtonsAttached = true
                return@post
            }
            try {
                wm.addView(view, params)
                isButtonsAttached = true
            } catch (_: Exception) {
            }
        }
    }

    fun hideButtons() {
        mainHandler.post {
            val view = buttonsContainer ?: return@post
            if (isButtonsAttached || view.isAttachedToWindow) {
                try {
                    wm.removeViewImmediate(view)
                } catch (_: Exception) {
                    try {
                        wm.removeView(view)
                    } catch (_: Exception) {
                    }
                }
            }
            isButtonsAttached = false
        }
    }

    fun refreshButtonsInPlace(resetPosition: Boolean = false) {
        mainHandler.post {
            if (buttonsContainer == null) return@post
            if (resetPosition) {
                val (sw, sh) = screenSize()
                buttonsParams?.x = (sw * 0.015f).toInt()
                buttonsParams?.y = (sh * 0.870f).toInt()
            }
            rebuildBallsInsideContainer()
        }
    }

    fun setLitColor(color: MarkColor?) {
        activeLitColor = color
        mainHandler.post {
            updateCircleDrawables()
        }
    }

    fun getLitColor(): MarkColor? = activeLitColor

    private fun ensureButtonsCreated() {
        if (buttonsContainer != null) return
        val (sw, sh) = screenSize()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
            setBackgroundColor(Color.TRANSPARENT)
        }

        val savedX = AppStore.getOverlayX()
        val savedY = AppStore.getOverlayY()
        val initX = if (savedX >= 0) savedX else (sw * 0.015f).toInt()
        val initY = if (savedY >= 0) savedY else (sh * 0.870f).toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX
            y = initY
        }

        buttonsContainer = container
        buttonsParams = params
        rebuildBallsInsideContainer()
    }

    private fun rebuildBallsInsideContainer() {
        val container = buttonsContainer ?: return
        val params = buttonsParams ?: return
        val (sw, sh) = screenSize()

        val enabledColors = AppStore.getEnabledColors()
        val diameterPx = dp(AppStore.getButtonDiameterDp())
        val gapPx = dp(AppStore.getButtonGapDp())
        val maxRowWidth = (sw - dp(12)).coerceAtLeast(diameterPx)

        container.removeAllViews()
        colorViews.clear()

        var currentRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        var currentRowWidth = 0
        var rowsCount = 1

        for (color in enabledColors) {
            val needWidth = if (currentRowWidth == 0) diameterPx else (gapPx + diameterPx)
            if (currentRowWidth > 0 && currentRowWidth + needWidth > maxRowWidth) {
                container.addView(currentRow)
                currentRow = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = gapPx.coerceAtMost(dp(16))
                    }
                }
                currentRowWidth = 0
                rowsCount++
            }

            val ball = View(context).apply {
                layoutParams = LinearLayout.LayoutParams(diameterPx, diameterPx).apply {
                    if (currentRowWidth > 0) marginStart = gapPx
                }
            }
            attachBallTouchLogic(ball, color, container, params)
            currentRow.addView(ball)
            colorViews[color] = ball
            currentRowWidth += if (currentRowWidth == 0) diameterPx else (gapPx + diameterPx)
        }
        if (currentRow.childCount > 0) {
            container.addView(currentRow)
        }

        updateCircleDrawables()

        container.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val totalW = container.measuredWidth.coerceAtLeast(diameterPx)
        val totalH = container.measuredHeight.coerceAtLeast(diameterPx * rowsCount)
        params.x = params.x.coerceIn(0, (sw - totalW).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (sh - totalH).coerceAtLeast(0))

        container.requestLayout()
        if (isButtonsAttached || container.isAttachedToWindow) {
            try {
                wm.updateViewLayout(container, params)
            } catch (_: Exception) {
            }
        }
    }

    private fun attachBallTouchLogic(
        target: View,
        color: MarkColor,
        container: LinearLayout,
        params: WindowManager.LayoutParams
    ) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var dragMode = false
        var swiped = false

        val tapSlop = dp(11).toFloat()
        val swipeTriggerPx = dp(38).toFloat()

        val enterDragRunnable = Runnable {
            if (!swiped) {
                dragMode = true
                container.scaleX = 1.12f
                container.scaleY = 1.12f
            }
        }

        target.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = params.x
                    startWinY = params.y
                    dragMode = false
                    swiped = false
                    mainHandler.postDelayed(enterDragRunnable, 360L)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (dragMode) {
                        val (sw, sh) = screenSize()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, (sw - container.width).coerceAtLeast(0))
                        params.y = (startWinY + dy.toInt()).coerceIn(0, (sh - container.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    } else if (abs(dx) > tapSlop || abs(dy) > tapSlop) {
                        swiped = true
                        mainHandler.removeCallbacks(enterDragRunnable)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(enterDragRunnable)
                    if (dragMode) {
                        container.scaleX = 1.0f
                        container.scaleY = 1.0f
                        AppStore.saveOverlayPosition(params.x, params.y)
                        AppStore.log("圆球位置已保存：(${params.x}, ${params.y})")
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        val ax = abs(dx)
                        val ay = abs(dy)

                        if (swiped) {
                            val isRightSwipe = dx >= swipeTriggerPx && ax > ay * 1.2f
                            val isAnyDirSwipe = ax >= swipeTriggerPx || ay >= swipeTriggerPx
                            if (AppStore.isBallExitSwipeAny() && isAnyDirSwipe) {
                                val dirName = when {
                                    ax >= ay && dx > 0 -> "右滑"
                                    ax >= ay && dx < 0 -> "左滑"
                                    dy > 0 -> "下滑"
                                    else -> "上滑"
                                }
                                onRequestPauseService("圆球${dirName}")
                            } else if (AppStore.isBallExitSwipeRight() && isRightSwipe) {
                                onRequestPauseService("圆球右滑")
                            }
                        } else {
                            if (AppStore.isBallExitDoubleTap()) {
                                val now = SystemClock.uptimeMillis()
                                if (now - lastBallTapMs <= 280L) {
                                    lastBallTapMs = 0L
                                    onRequestPauseService("圆球双击")
                                    dragMode = false
                                    return@setOnTouchListener true
                                } else {
                                    lastBallTapMs = now
                                }
                            }
                            onColorTap(color)
                        }
                    }
                    dragMode = false
                    true
                }

                else -> false
            }
        }
    }

    private fun updateCircleDrawables() {
        val unselPct = AppStore.getUnselectedBrightness()
        val selPct = AppStore.getSelectedBrightness()
        val showWhiteRing = AppStore.isSelectedWhiteRingEnabled()
        for ((color, view) in colorViews) {
            val isLit = activeLitColor == color
            view.background = makeCircleDrawable(
                context = context,
                color = color,
                selected = isLit,
                unselPct = unselPct,
                selPct = selPct,
                showWhiteRing = showWhiteRing
            )
        }
    }

    companion object {
        fun makeCircleDrawable(
            context: Context,
            color: MarkColor,
            selected: Boolean,
            unselPct: Int,
            selPct: Int,
            showWhiteRing: Boolean
        ): GradientDrawable {
            val pct = if (selected) selPct else unselPct
            val f = pct / 100f

            val alpha = if (selected) {
                (175 + 80 * f).toInt().coerceIn(80, 255)
            } else {
                (95 + 145 * f).toInt().coerceIn(45, 240)
            }
            val rgbScale = if (selected) (0.35f + 0.65f * f) else (0.20f + 0.62f * f)
            val fillColor = Color.argb(
                alpha,
                (color.baseR * rgbScale).toInt().coerceIn(0, 255),
                (color.baseG * rgbScale).toInt().coerceIn(0, 255),
                (color.baseB * rgbScale).toInt().coerceIn(0, 255)
            )

            val density = context.resources.displayMetrics.density
            val strokePx: Int
            val strokeColor: Int
            if (selected) {
                if (showWhiteRing) {
                    val strokeAlpha = (190 + 65 * f).toInt().coerceIn(90, 255)
                    val strokeGray = (170 + 85 * f).toInt().coerceIn(110, 255)
                    strokePx = (3f * density).toInt().coerceAtLeast(3)
                    strokeColor = Color.argb(strokeAlpha, strokeGray, strokeGray, strokeGray)
                } else {
                    strokePx = 0
                    strokeColor = Color.TRANSPARENT
                }
            } else {
                val strokeAlpha = (65 + 120 * f).toInt().coerceIn(35, 190)
                val strokeGray = (120 + 100 * f).toInt().coerceIn(80, 225)
                strokePx = (1f * density).toInt().coerceAtLeast(1)
                strokeColor = Color.argb(strokeAlpha, strokeGray, strokeGray, strokeGray)
            }

            return GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(fillColor)
                if (strokePx > 0) {
                    setStroke(strokePx, strokeColor)
                }
            }
        }
    }

    // =========================================================================
    // 2. 完活弹窗（纯黑白、无震动、可选提示音、3秒消失、点击消失、长按拖动）
    // =========================================================================

    fun showDoneBanner(previewMode: Boolean = false) {
        if (!previewMode) {
            SoundPlayer.playDoneSoundIfEnabled()
        }
        mainHandler.post {
            hideDoneBannerInternal()

            val textStr = AppStore.getDoneText()
            val sizeSp = AppStore.getDoneSizeSp().toFloat()
            val grayVal = (255f * AppStore.getDoneGrayPct() / 100f).toInt().coerceIn(30, 255)
            val borderGray = (grayVal * 0.55f).toInt().coerceIn(40, 220)

            val tv = TextView(context).apply {
                text = textStr
                setTextColor(Color.rgb(grayVal, grayVal, grayVal))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
                paint.isFakeBoldText = true
                gravity = Gravity.CENTER
                val padH = dp((sizeSp * 0.48f).toInt().coerceIn(16, 44))
                val padV = dp((sizeSp * 0.28f).toInt().coerceIn(10, 26))
                setPadding(padH, padV, padH, padV)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(Color.parseColor("#E0000000"))
                    setStroke(dp(1), Color.rgb(borderGray, borderGray, borderGray))
                }
            }

            tv.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val (sw, sh) = screenSize()
            val savedX = AppStore.getDoneX()
            val savedY = AppStore.getDoneY()
            val initX = if (savedX >= 0) savedX.coerceIn(0, (sw - tv.measuredWidth).coerceAtLeast(0))
            else ((sw - tv.measuredWidth) / 2).coerceAtLeast(0)
            val initY = if (savedY >= 0) savedY.coerceIn(0, (sh - tv.measuredHeight).coerceAtLeast(0))
            else ((sh - tv.measuredHeight) / 2).coerceAtLeast(0)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = initX
                y = initY
            }

            attachDoneTouchLogic(tv, params)

            try {
                wm.addView(tv, params)
                doneView = tv
                doneParams = params
                val dismissDelay = if (previewMode) 6_000L else 3_000L
                mainHandler.postDelayed(doneAutoDismiss, dismissDelay)
            } catch (_: Exception) {
            }
        }
    }

    private fun attachDoneTouchLogic(tv: TextView, params: WindowManager.LayoutParams) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var dragMode = false
        var movedBeforeLongPress = false

        val enterDragRunnable = Runnable {
            if (!movedBeforeLongPress) {
                dragMode = true
                tv.scaleX = 1.06f
                tv.scaleY = 1.06f
            }
        }

        tv.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_OUTSIDE -> {
                    hideDoneBannerInternal()
                    false
                }

                MotionEvent.ACTION_DOWN -> {
                    mainHandler.removeCallbacks(doneAutoDismiss)
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = params.x
                    startWinY = params.y
                    dragMode = false
                    movedBeforeLongPress = false
                    mainHandler.postDelayed(enterDragRunnable, 280L)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (dragMode) {
                        val (sw, sh) = screenSize()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, (sw - tv.width).coerceAtLeast(0))
                        params.y = (startWinY + dy.toInt()).coerceIn(0, (sh - tv.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(tv, params)
                        } catch (_: Exception) {
                        }
                    } else if (abs(dx) > dp(10) || abs(dy) > dp(10)) {
                        movedBeforeLongPress = true
                        mainHandler.removeCallbacks(enterDragRunnable)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(enterDragRunnable)
                    if (dragMode) {
                        tv.scaleX = 1.0f
                        tv.scaleY = 1.0f
                        AppStore.saveDonePosition(params.x, params.y)
                        AppStore.log("完活位置已保存：(${params.x}, ${params.y})")
                        mainHandler.postDelayed(doneAutoDismiss, 3_000L)
                    } else {
                        hideDoneBannerInternal()
                    }
                    dragMode = false
                    true
                }

                else -> false
            }
        }
    }

    fun hideDoneBanner() {
        mainHandler.post { hideDoneBannerInternal() }
    }

    private fun hideDoneBannerInternal() {
        mainHandler.removeCallbacks(doneAutoDismiss)
        doneView?.let {
            try {
                wm.removeViewImmediate(it)
            } catch (_: Exception) {
                try {
                    wm.removeView(it)
                } catch (_: Exception) {
                }
            }
        }
        doneView = null
        doneParams = null
    }

    // =========================================================================
    // 3. 右侧竖排清单提示（纯黑白、严格列对齐、多选关闭方式：双击 / 右滑 / 任意方向滑动）
    // =========================================================================

    fun showInfoPanel(items: List<InfoDisplayItem>, forcePreview: Boolean = false) {
        if (items.isEmpty()) {
            hideInfoPanel()
            return
        }
        if (!forcePreview && !AppStore.isInfoPanelEnabled()) return

        mainHandler.post {
            lastInfoItems = items
            val container = ensureInfoContainer()
            populateInfoRows(container, items)

            container.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val (sw, sh) = screenSize()
            val params = infoParams ?: return@post
            val savedX = AppStore.getInfoX()
            val savedY = AppStore.getInfoY()
            params.x = if (savedX >= 0) {
                savedX.coerceIn(0, (sw - container.measuredWidth).coerceAtLeast(0))
            } else {
                (sw - container.measuredWidth - dp(6)).coerceAtLeast(0)
            }
            params.y = if (savedY >= 0) {
                savedY.coerceIn(0, (sh - container.measuredHeight).coerceAtLeast(0))
            } else {
                (sh * 0.16f).toInt()
            }

            if (isInfoAttached || container.isAttachedToWindow) {
                try {
                    wm.updateViewLayout(container, params)
                } catch (_: Exception) {
                }
                isInfoAttached = true
            } else {
                try {
                    wm.addView(container, params)
                    isInfoAttached = true
                } catch (_: Exception) {
                }
            }
        }
    }

    fun refreshInfoPanelInPlace(resetPosition: Boolean = false) {
        mainHandler.post {
            val container = infoContainer ?: return@post
            if (!isInfoAttached && !container.isAttachedToWindow) return@post
            if (resetPosition) {
                AppStore.resetInfoPosition()
            }
            showInfoPanel(lastInfoItems, forcePreview = true)
        }
    }

    fun hideInfoPanel() {
        mainHandler.post {
            val container = infoContainer ?: return@post
            if (isInfoAttached || container.isAttachedToWindow) {
                try {
                    wm.removeViewImmediate(container)
                } catch (_: Exception) {
                    try {
                        wm.removeView(container)
                    } catch (_: Exception) {
                    }
                }
            }
            isInfoAttached = false
        }
    }

    private fun ensureInfoContainer(): LinearLayout {
        infoContainer?.let { return it }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        attachInfoTouchLogic(container, params)

        infoContainer = container
        infoParams = params
        return container
    }

    private fun populateInfoRows(container: LinearLayout, items: List<InfoDisplayItem>) {
        container.removeAllViews()

        val sizeSp = AppStore.getInfoSizeSp().toFloat()
        val grayVal = (255f * AppStore.getInfoGrayPct() / 100f).toInt().coerceIn(30, 255)
        val borderGray = (grayVal * 0.45f).toInt().coerceIn(35, 200)
        val textColor = Color.rgb(grayVal, grayVal, grayVal)
        val extraGapPx = dp(AppStore.getInfoGapDp())
        val showCn = AppStore.isInfoShowCnName()
        val showSrc = AppStore.isInfoShowSource()

        container.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(8).toFloat()
            setColor(Color.parseColor("#CC000000"))
            setStroke(dp(1), Color.argb(120, borderGray, borderGray, borderGray))
        }

        // 按《品种大全》拼接左侧文字：没有中文名/数据源的绝不显示占位符
        val rowLeftTexts = items.map { item ->
            val sb = StringBuilder(item.symbol)
            if (showCn && item.cnName.isNotBlank()) {
                sb.append(" ").append(item.cnName)
            }
            if (showSrc && item.source.isNotBlank()) {
                sb.append(" ").append(item.source)
            }
            sb.toString()
        }

        val measureTv = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            paint.isFakeBoldText = true
        }
        val oneSpacePx = measureTv.paint.measureText(" ").toInt().coerceAtLeast(dp(4))
        var maxLeftWidthPx = 0
        for (txt in rowLeftTexts) {
            val wPx = kotlin.math.ceil(measureTv.paint.measureText(txt).toDouble()).toInt()
            if (wPx > maxLeftWidthPx) maxLeftWidthPx = wPx
        }
        maxLeftWidthPx = maxLeftWidthPx.coerceAtLeast(dp(20))

        for ((idx, item) in items.withIndex()) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx > 0) topMargin = dp(4)
                }
            }

            val leftTv = TextView(context).apply {
                text = rowLeftTexts[idx]
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
                paint.isFakeBoldText = true
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    maxLeftWidthPx,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val colTv = TextView(context).apply {
                text = item.color.label
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
                paint.isFakeBoldText = true
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginStart = oneSpacePx + extraGapPx
                }
            }

            row.addView(leftTv)
            row.addView(colTv)
            container.addView(row)
        }
    }

    private fun attachInfoTouchLogic(container: LinearLayout, params: WindowManager.LayoutParams) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var dragMode = false
        var moved = false
        var lastTapTimeMs = 0L

        val tapSlop = dp(8).toFloat()
        val swipeTriggerPx = dp(38).toFloat()

        val enterLongDragRunnable = Runnable {
            if (!moved) {
                dragMode = true
                container.scaleX = 1.04f
                container.scaleY = 1.04f
            }
        }

        fun dismissPanel(reason: String) {
            hideInfoPanel()
            onInfoPanelDismissed()
            AppStore.log("关闭右侧清单：$reason")
        }

        container.setOnTouchListener { _, event ->
            val anySwipeCloseOn = AppStore.isInfoCloseSwipeRight() || AppStore.isInfoCloseSwipeAny()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = params.x
                    startWinY = params.y
                    dragMode = false
                    moved = false
                    if (anySwipeCloseOn) {
                        mainHandler.postDelayed(enterLongDragRunnable, 280L)
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY

                    if (!anySwipeCloseOn && !dragMode && (abs(dx) > tapSlop || abs(dy) > tapSlop)) {
                        dragMode = true
                    }

                    if (dragMode) {
                        val (sw, sh) = screenSize()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, (sw - container.width).coerceAtLeast(0))
                        params.y = (startWinY + dy.toInt()).coerceIn(0, (sh - container.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    } else if (abs(dx) > tapSlop || abs(dy) > tapSlop) {
                        moved = true
                        mainHandler.removeCallbacks(enterLongDragRunnable)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(enterLongDragRunnable)
                    if (dragMode) {
                        container.scaleX = 1.0f
                        container.scaleY = 1.0f
                        AppStore.saveInfoPosition(params.x, params.y)
                        AppStore.log("右侧信息位置已保存：(${params.x}, ${params.y})")
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        val ax = abs(dx)
                        val ay = abs(dy)

                        if (moved) {
                            val isRightSwipe = dx >= swipeTriggerPx && ax > ay * 1.2f
                            val isAnyDirSwipe = ax >= swipeTriggerPx || ay >= swipeTriggerPx
                            if (AppStore.isInfoCloseSwipeAny() && isAnyDirSwipe) {
                                val dirName = when {
                                    ax >= ay && dx > 0 -> "右滑"
                                    ax >= ay && dx < 0 -> "左滑"
                                    dy > 0 -> "下滑"
                                    else -> "上滑"
                                }
                                dismissPanel(dirName)
                            } else if (AppStore.isInfoCloseSwipeRight() && isRightSwipe) {
                                dismissPanel("右滑")
                            }
                        } else if (AppStore.isInfoCloseDoubleTap()) {
                            val now = SystemClock.uptimeMillis()
                            if (now - lastTapTimeMs <= 380L) {
                                lastTapTimeMs = 0L
                                dismissPanel("双击")
                            } else {
                                lastTapTimeMs = now
                            }
                        }
                    }
                    dragMode = false
                    true
                }

                else -> false
            }
        }
    }

    fun destroy() {
        hideButtons()
        hideDoneBanner()
        hideInfoPanel()
    }
}
