package com.tvhelper.color

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayController(
    private val context: Context,
    private val onColorTap: (MarkColor) -> Unit,
    private val onInfoPanelDoubleTapDismiss: () -> Unit = {}
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    // 1. 红蓝悬浮球（单例容器，原地更新，彻底杜绝重影）
    private var buttonsContainer: LinearLayout? = null
    private var buttonsParams: WindowManager.LayoutParams? = null
    private var redView: View? = null
    private var blueView: View? = null
    @Volatile
    private var activeLitColor: MarkColor? = null
    private var isButtonsAttached = false

    // 2. 完活弹窗（纯黑白、可自定义文字/大小/灰度、长按拖动记住位置、3秒或点击消失、无声无震）
    private var doneView: TextView? = null
    private var doneParams: WindowManager.LayoutParams? = null
    private val doneAutoDismiss = Runnable { hideDoneBannerInternal() }

    // 3. 右侧竖排信息提示面板（纯黑白、固定位置不随列表滚动、按住拖动记住位置、双击消失）
    private var infoContainer: LinearLayout? = null
    private var infoParams: WindowManager.LayoutParams? = null
    private var lastInfoItems: List<Pair<String, MarkColor>> = emptyList()
    private var isInfoAttached = false

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun screenSize(): Pair<Int, Int> {
        val bounds = wm.maximumWindowMetrics.bounds
        return bounds.width() to bounds.height()
    }

    // =========================================================================
    // 1. 红蓝圆球悬浮窗（无重影原地更新）
    // =========================================================================

    fun showButtons() {
        mainHandler.post {
            ensureButtonsCreated()
            applyButtonsStyleInPlace()
            val view = buttonsContainer ?: return@post
            val params = buttonsParams ?: return@post
            if (isButtonsAttached || view.isAttachedToWindow) {
                try {
                    wm.updateViewLayout(view, params)
                } catch (_: Exception) {
                }
                isButtonsAttached = true
                return@post
            }
            try {
                wm.addView(view, params)
                isButtonsAttached = true
            } catch (_: Exception) {
            }
        }
    }

    fun hideButtons() {
        mainHandler.post {
            val view = buttonsContainer ?: return@post
            if (isButtonsAttached || view.isAttachedToWindow) {
                try {
                    wm.removeViewImmediate(view)
                } catch (_: Exception) {
                    try {
                        wm.removeView(view)
                    } catch (_: Exception) {
                    }
                }
            }
            isButtonsAttached = false
        }
    }

    /**
     * 原地刷新圆点尺寸、间距、明暗度、重置位置（绝不重复 addView，彻底消除重影）
     */
    fun refreshButtonsInPlace(resetPosition: Boolean = false) {
        mainHandler.post {
            if (buttonsContainer == null) return@post
            if (resetPosition) {
                val (sw, sh) = screenSize()
                buttonsParams?.x = (sw * 0.015f).toInt()
                buttonsParams?.y = (sh * 0.870f).toInt()
            }
            applyButtonsStyleInPlace()
        }
    }

    fun setLitColor(color: MarkColor?) {
        activeLitColor = color
        mainHandler.post {
            updateCircleDrawables()
        }
    }

    fun getLitColor(): MarkColor? = activeLitColor

    private fun ensureButtonsCreated() {
        if (buttonsContainer != null) return
        val (sw, sh) = screenSize()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
        }

        val redBtn = View(context)
        val blueBtn = View(context)
        container.addView(redBtn)
        container.addView(blueBtn)

        val savedX = AppStore.getOverlayX()
        val savedY = AppStore.getOverlayY()
        val initX = if (savedX >= 0) savedX else (sw * 0.015f).toInt()
        val initY = if (savedY >= 0) savedY else (sh * 0.870f).toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX
            y = initY
        }

        attachButtonTapAndLongPressDrag(redBtn, MarkColor.RED, container, params)
        attachButtonTapAndLongPressDrag(blueBtn, MarkColor.BLUE, container, params)

        redView = redBtn
        blueView = blueBtn
        buttonsContainer = container
        buttonsParams = params
        applyButtonsStyleInPlace()
    }

    private fun applyButtonsStyleInPlace() {
        val diameterPx = dp(AppStore.getButtonDiameterDp())
        val gapPx = dp(AppStore.getButtonGapDp())

        redView?.layoutParams = LinearLayout.LayoutParams(diameterPx, diameterPx)
        blueView?.layoutParams = LinearLayout.LayoutParams(diameterPx, diameterPx).apply {
            marginStart = gapPx
        }
        updateCircleDrawables()

        val container = buttonsContainer ?: return
        val params = buttonsParams ?: return
        val (sw, sh) = screenSize()
        val totalW = diameterPx * 2 + gapPx
        params.x = params.x.coerceIn(0, (sw - totalW).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (sh - diameterPx).coerceAtLeast(0))

        container.requestLayout()
        if (isButtonsAttached || container.isAttachedToWindow) {
            try {
                wm.updateViewLayout(container, params)
            } catch (_: Exception) {
            }
        }
    }

    private fun attachButtonTapAndLongPressDrag(
        target: View,
        color: MarkColor,
        container: LinearLayout,
        params: WindowManager.LayoutParams
    ) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var dragMode = false
        var movedBeforeLongPress = false

        val enterDragRunnable = Runnable {
            if (!movedBeforeLongPress) {
                dragMode = true
                container.scaleX = 1.12f
                container.scaleY = 1.12f
            }
        }

        target.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = params.x
                    startWinY = params.y
                    dragMode = false
                    movedBeforeLongPress = false
                    mainHandler.postDelayed(enterDragRunnable, 360L)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (dragMode) {
                        val (sw, sh) = screenSize()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, (sw - container.width).coerceAtLeast(0))
                        params.y = (startWinY + dy.toInt()).coerceIn(0, (sh - container.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    } else if (abs(dx) > dp(10) || abs(dy) > dp(10)) {
                        movedBeforeLongPress = true
                        mainHandler.removeCallbacks(enterDragRunnable)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(enterDragRunnable)
                    if (dragMode) {
                        container.scaleX = 1.0f
                        container.scaleY = 1.0f
                        AppStore.saveOverlayPosition(params.x, params.y)
                        AppStore.log("红蓝球位置已保存：(${params.x}, ${params.y})")
                    } else if (event.actionMasked == MotionEvent.ACTION_UP && !movedBeforeLongPress) {
                        onColorTap(color)
                    }
                    dragMode = false
                    true
                }

                else -> false
            }
        }
    }

    private fun updateCircleDrawables() {
        val redLit = activeLitColor == MarkColor.RED
        val blueLit = activeLitColor == MarkColor.BLUE
        val unselPct = AppStore.getUnselectedBrightness()
        val selPct = AppStore.getSelectedBrightness()

        redView?.background = buildCircleDrawable(isRed = true, selected = redLit, unselPct = unselPct, selPct = selPct)
        blueView?.background = buildCircleDrawable(isRed = false, selected = blueLit, unselPct = unselPct, selPct = selPct)
    }

    fun buildCircleDrawable(isRed: Boolean, selected: Boolean, unselPct: Int, selPct: Int): GradientDrawable {
        val pct = if (selected) selPct else unselPct
        val f = pct / 100f
        val baseR = if (isRed) 255 else 35
        val baseG = if (isRed) 42 else 112
        val baseB = if (isRed) 58 else 255

        val alpha = if (selected) {
            (175 + 80 * f).toInt().coerceIn(80, 255)
        } else {
            (95 + 145 * f).toInt().coerceIn(45, 240)
        }
        val rgbScale = if (selected) (0.35f + 0.65f * f) else (0.20f + 0.62f * f)
        val fillColor = Color.argb(
            alpha,
            (baseR * rgbScale).toInt().coerceIn(0, 255),
            (baseG * rgbScale).toInt().coerceIn(0, 255),
            (baseB * rgbScale).toInt().coerceIn(0, 255)
        )

        val strokeAlpha = if (selected) (190 + 65 * f).toInt().coerceIn(90, 255) else (70 + 130 * f).toInt().coerceIn(40, 200)
        val strokeGray = if (selected) (160 + 95 * f).toInt().coerceIn(100, 255) else (120 + 110 * f).toInt().coerceIn(80, 230)
        val strokeColor = Color.argb(strokeAlpha, strokeGray, strokeGray, strokeGray)

        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fillColor)
            setStroke(if (selected) dp(3) else dp(1), strokeColor)
        }
    }

    // =========================================================================
    // 2. 完活弹窗（纯黑白、无声无震、3秒自动消失、点击消失、长按拖动记住位置）
    // =========================================================================

    fun showDoneBanner(previewMode: Boolean = false) {
        mainHandler.post {
            hideDoneBannerInternal()

            val textStr = AppStore.getDoneText()
            val sizeSp = AppStore.getDoneSizeSp().toFloat()
            val grayVal = (255f * AppStore.getDoneGrayPct() / 100f).toInt().coerceIn(30, 255)
            val borderGray = (grayVal * 0.55f).toInt().coerceIn(40, 220)

            val tv = TextView(context).apply {
                text = textStr
                setTextColor(Color.rgb(grayVal, grayVal, grayVal))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
                paint.isFakeBoldText = true
                gravity = Gravity.CENTER
                val padH = dp((sizeSp * 0.48f).toInt().coerceIn(16, 44))
                val padV = dp((sizeSp * 0.28f).toInt().coerceIn(10, 26))
                setPadding(padH, padV, padH, padV)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(Color.parseColor("#E0000000"))
                    setStroke(dp(1), Color.rgb(borderGray, borderGray, borderGray))
                }
            }

            // 预测量尺寸以便默认精确居中
            tv.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val (sw, sh) = screenSize()
            val savedX = AppStore.getDoneX()
            val savedY = AppStore.getDoneY()
            val initX = if (savedX >= 0) savedX.coerceIn(0, (sw - tv.measuredWidth).coerceAtLeast(0))
            else ((sw - tv.measuredWidth) / 2).coerceAtLeast(0)
            val initY = if (savedY >= 0) savedY.coerceIn(0, (sh - tv.measuredHeight).coerceAtLeast(0))
            else ((sh - tv.measuredHeight) / 2).coerceAtLeast(0)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = initX
                y = initY
            }

            attachDoneTouchLogic(tv, params)

            try {
                wm.addView(tv, params)
                doneView = tv
                doneParams = params
                val dismissDelay = if (previewMode) 6_000L else 3_000L
                mainHandler.postDelayed(doneAutoDismiss, dismissDelay)
            } catch (_: Exception) {
            }
        }
    }

    private fun attachDoneTouchLogic(tv: TextView, params: WindowManager.LayoutParams) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var dragMode = false
        var movedBeforeLongPress = false

        val enterDragRunnable = Runnable {
            if (!movedBeforeLongPress) {
                dragMode = true
                tv.scaleX = 1.06f
                tv.scaleY = 1.06f
            }
        }

        tv.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_OUTSIDE -> {
                    hideDoneBannerInternal()
                    false
                }

                MotionEvent.ACTION_DOWN -> {
                    // 按下时暂停 3 秒自动消失，避免长按拖动中途消失
                    mainHandler.removeCallbacks(doneAutoDismiss)
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = params.x
                    startWinY = params.y
                    dragMode = false
                    movedBeforeLongPress = false
                    mainHandler.postDelayed(enterDragRunnable, 280L)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (dragMode) {
                        val (sw, sh) = screenSize()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, (sw - tv.width).coerceAtLeast(0))
                        params.y = (startWinY + dy.toInt()).coerceIn(0, (sh - tv.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(tv, params)
                        } catch (_: Exception) {
                        }
                    } else if (abs(dx) > dp(10) || abs(dy) > dp(10)) {
                        movedBeforeLongPress = true
                        mainHandler.removeCallbacks(enterDragRunnable)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(enterDragRunnable)
                    if (dragMode) {
                        tv.scaleX = 1.0f
                        tv.scaleY = 1.0f
                        AppStore.saveDonePosition(params.x, params.y)
                        AppStore.log("完活位置已保存：(${params.x}, ${params.y})")
                        mainHandler.postDelayed(doneAutoDismiss, 3_000L)
                    } else {
                        // 短按完活文字直接消失
                        hideDoneBannerInternal()
                    }
                    dragMode = false
                    true
                }

                else -> false
            }
        }
    }

    fun hideDoneBanner() {
        mainHandler.post { hideDoneBannerInternal() }
    }

    private fun hideDoneBannerInternal() {
        mainHandler.removeCallbacks(doneAutoDismiss)
        doneView?.let {
            try {
                wm.removeViewImmediate(it)
            } catch (_: Exception) {
                try {
                    wm.removeView(it)
                } catch (_: Exception) {
                }
            }
        }
        doneView = null
        doneParams = null
    }

    // =========================================================================
    // 3. 右侧竖排信息提示面板（纯黑白、固定位置、按住整体拖动、双击消失）
    // =========================================================================

    fun showInfoPanel(items: List<Pair<String, MarkColor>>) {
        if (items.isEmpty()) return
        mainHandler.post {
            lastInfoItems = items
            val container = ensureInfoContainer()
            populateInfoRows(container, items)

            container.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val (sw, sh) = screenSize()
            val params = infoParams ?: return@post
            val savedX = AppStore.getInfoX()
            val savedY = AppStore.getInfoY()
            params.x = if (savedX >= 0) {
                savedX.coerceIn(0, (sw - container.measuredWidth).coerceAtLeast(0))
            } else {
                (sw - container.measuredWidth - dp(6)).coerceAtLeast(0)
            }
            params.y = if (savedY >= 0) {
                savedY.coerceIn(0, (sh - container.measuredHeight).coerceAtLeast(0))
            } else {
                (sh * 0.16f).toInt()
            }

            if (isInfoAttached || container.isAttachedToWindow) {
                try {
                    wm.updateViewLayout(container, params)
                } catch (_: Exception) {
                }
                isInfoAttached = true
            } else {
                try {
                    wm.addView(container, params)
                    isInfoAttached = true
                } catch (_: Exception) {
                }
            }
        }
    }

    fun refreshInfoPanelInPlace(resetPosition: Boolean = false) {
        mainHandler.post {
            val container = infoContainer ?: return@post
            if (!isInfoAttached && !container.isAttachedToWindow) return@post
            if (resetPosition) {
                AppStore.resetInfoPosition()
            }
            showInfoPanel(lastInfoItems)
        }
    }

    fun hideInfoPanel() {
        mainHandler.post {
            val container = infoContainer ?: return@post
            if (isInfoAttached || container.isAttachedToWindow) {
                try {
                    wm.removeViewImmediate(container)
                } catch (_: Exception) {
                    try {
                        wm.removeView(container)
                    } catch (_: Exception) {
                    }
                }
            }
            isInfoAttached = false
        }
    }

    private fun ensureInfoContainer(): LinearLayout {
        infoContainer?.let { return it }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        attachInfoDragAndDoubleTap(container, params)

        infoContainer = container
        infoParams = params
        return container
    }

    private fun populateInfoRows(container: LinearLayout, items: List<Pair<String, MarkColor>>) {
        container.removeAllViews()

        val sizeSp = AppStore.getInfoSizeSp().toFloat()
        val grayVal = (255f * AppStore.getInfoGrayPct() / 100f).toInt().coerceIn(30, 255)
        val borderGray = (grayVal * 0.45f).toInt().coerceIn(35, 200)
        val textColor = Color.rgb(grayVal, grayVal, grayVal)
        val extraGapPx = dp(AppStore.getInfoGapDp())

        container.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(8).toFloat()
            setColor(Color.parseColor("#CC000000"))
            setStroke(dp(1), Color.argb(120, borderGray, borderGray, borderGray))
        }

        for ((idx, item) in items.withIndex()) {
            val (symbol, color) = item
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx > 0) topMargin = dp(4)
                }
            }

            val symTv = TextView(context).apply {
                text = symbol
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
                paint.isFakeBoldText = true
            }
            val oneSpacePx = symTv.paint.measureText(" ").toInt().coerceAtLeast(dp(4))

            val colTv = TextView(context).apply {
                text = color.label
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
                paint.isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginStart = oneSpacePx + extraGapPx
                }
            }

            row.addView(symTv)
            row.addView(colTv)
            container.addView(row)
        }
    }

    private fun attachInfoDragAndDoubleTap(container: LinearLayout, params: WindowManager.LayoutParams) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var isDragging = false
        var lastTapTimeMs = 0L

        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = params.x
                    startWinY = params.y
                    isDragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!isDragging && (abs(dx) > dp(6) || abs(dy) > dp(6))) {
                        isDragging = true
                    }
                    if (isDragging) {
                        val (sw, sh) = screenSize()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, (sw - container.width).coerceAtLeast(0))
                        params.y = (startWinY + dy.toInt()).coerceIn(0, (sh - container.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging) {
                        AppStore.saveInfoPosition(params.x, params.y)
                        AppStore.log("右侧信息位置已保存：(${params.x}, ${params.y})")
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastTapTimeMs <= 380L) {
                            lastTapTimeMs = 0L
                            hideInfoPanel()
                            onInfoPanelDoubleTapDismiss()
                            AppStore.log("双击关闭右侧信息提示")
                        } else {
                            lastTapTimeMs = now
                        }
                    }
                    isDragging = false
                    true
                }

                else -> false
            }
        }
    }

    fun destroy() {
        hideButtons()
        hideDoneBanner()
        hideInfoPanel()
    }
}
