package com.tvhelper.color

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayController(
    private val context: Context,
    private val onColorTap: (MarkColor) -> Unit
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var buttonsContainer: LinearLayout? = null
    private var buttonsParams: WindowManager.LayoutParams? = null
    private var redView: View? = null
    private var blueView: View? = null
    private var activeLitColor: MarkColor? = null
    private var isButtonsVisible = false

    private var doneView: TextView? = null
    private val doneAutoDismiss = Runnable { hideDoneBanner() }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun screenSize(): Pair<Int, Int> {
        val bounds = wm.maximumWindowMetrics.bounds
        return bounds.width() to bounds.height()
    }

    fun showButtons() {
        mainHandler.post {
            if (isButtonsVisible) return@post
            createButtonsIfNeeded()
            val view = buttonsContainer ?: return@post
            val params = buttonsParams ?: return@post
            try {
                wm.addView(view, params)
                isButtonsVisible = true
            } catch (_: Exception) {
            }
        }
    }

    fun hideButtons() {
        mainHandler.post {
            if (!isButtonsVisible) return@post
            val view = buttonsContainer ?: return@post
            try {
                wm.removeView(view)
            } catch (_: Exception) {
            }
            isButtonsVisible = false
        }
    }

    fun rebuildButtons() {
        mainHandler.post {
            val wasVisible = isButtonsVisible
            if (wasVisible) {
                try {
                    buttonsContainer?.let { wm.removeView(it) }
                } catch (_: Exception) {
                }
                isButtonsVisible = false
            }
            buttonsContainer = null
            buttonsParams = null
            if (wasVisible) {
                showButtons()
            }
        }
    }

    fun setLitColor(color: MarkColor?) {
        mainHandler.post {
            activeLitColor = color
            updateCircleDrawables()
        }
    }

    fun getLitColor(): MarkColor? = activeLitColor

    private fun createButtonsIfNeeded() {
        if (buttonsContainer != null) return
        val (sw, sh) = screenSize()
        val diameterPx = dp(AppStore.getButtonDiameterDp())
        val gapPx = dp(5)

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
        }

        val redBtn = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(diameterPx, diameterPx)
        }
        val blueBtn = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(diameterPx, diameterPx).apply {
                marginStart = gapPx
            }
        }

        container.addView(redBtn)
        container.addView(blueBtn)

        val savedX = AppStore.getOverlayX()
        val savedY = AppStore.getOverlayY()
        val initX = if (savedX >= 0) savedX else (sw * 0.015f).toInt()
        val initY = if (savedY >= 0) savedY else (sh * 0.872f).toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initX
            y = initY
        }

        attachTapAndLongPressDrag(redBtn, MarkColor.RED, container, params)
        attachTapAndLongPressDrag(blueBtn, MarkColor.BLUE, container, params)

        redView = redBtn
        blueView = blueBtn
        buttonsContainer = container
        buttonsParams = params
        updateCircleDrawables()
    }

    private fun attachTapAndLongPressDrag(
        target: View,
        color: MarkColor,
        container: LinearLayout,
        params: WindowManager.LayoutParams
    ) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var dragMode = false
        var movedTooFarBeforeLongPress = false

        val enterDragRunnable = Runnable {
            if (!movedTooFarBeforeLongPress) {
                dragMode = true
                container.scaleX = 1.18f
                container.scaleY = 1.18f
            }
        }

        target.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startWinX = params.x
                    startWinY = params.y
                    dragMode = false
                    movedTooFarBeforeLongPress = false
                    mainHandler.postDelayed(enterDragRunnable, 380L)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (dragMode) {
                        val (sw, sh) = screenSize()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, sw - container.width)
                        params.y = (startWinY + dy.toInt()).coerceIn(0, sh - container.height)
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    } else if (abs(dx) > dp(10) || abs(dy) > dp(10)) {
                        movedTooFarBeforeLongPress = true
                        mainHandler.removeCallbacks(enterDragRunnable)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(enterDragRunnable)
                    if (dragMode) {
                        container.scaleX = 1.0f
                        container.scaleY = 1.0f
                        AppStore.saveOverlayPosition(params.x, params.y)
                        AppStore.log("悬浮球位置已保存：(${params.x}, ${params.y})")
                    } else if (event.actionMasked == MotionEvent.ACTION_UP && !movedTooFarBeforeLongPress) {
                        onColorTap(color)
                    }
                    dragMode = false
                    true
                }

                else -> false
            }
        }
    }

    private fun updateCircleDrawables() {
        val redLit = activeLitColor == MarkColor.RED
        val blueLit = activeLitColor == MarkColor.BLUE

        redView?.background = makeCircleDrawable(
            fillColor = if (redLit) Color.parseColor("#FFFF293B") else Color.parseColor("#CC7A1C24"),
            strokeColor = if (redLit) Color.WHITE else Color.parseColor("#AAFF7A85"),
            strokeWidthPx = if (redLit) dp(3) else dp(1)
        )

        blueView?.background = makeCircleDrawable(
            fillColor = if (blueLit) Color.parseColor("#FF1F6BFF") else Color.parseColor("#CC14387A"),
            strokeColor = if (blueLit) Color.WHITE else Color.parseColor("#AA78A8FF"),
            strokeWidthPx = if (blueLit) dp(3) else dp(1)
        )
    }

    private fun makeCircleDrawable(fillColor: Int, strokeColor: Int, strokeWidthPx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fillColor)
            setStroke(strokeWidthPx, strokeColor)
        }
    }

    fun showDoneBanner() {
        mainHandler.post {
            hideDoneBannerInternal()

            val tv = TextView(context).apply {
                text = "完活"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 60f)
                paint.isFakeBoldText = true
                gravity = Gravity.CENTER
                setPadding(dp(44), dp(26), dp(44), dp(26))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.parseColor("#EE161B22"))
                    setStroke(dp(3), Color.parseColor("#FF26A69A"))
                }
                setOnTouchListener { _, event ->
                    if (event.actionMasked == MotionEvent.ACTION_DOWN ||
                        event.actionMasked == MotionEvent.ACTION_OUTSIDE
                    ) {
                        hideDoneBannerInternal()
                    }
                    false
                }
            }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }

            try {
                wm.addView(tv, params)
                doneView = tv
                mainHandler.postDelayed(doneAutoDismiss, 10_000L)
            } catch (_: Exception) {
            }
        }
    }

    fun hideDoneBanner() {
        mainHandler.post { hideDoneBannerInternal() }
    }

    private fun hideDoneBannerInternal() {
        mainHandler.removeCallbacks(doneAutoDismiss)
        doneView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        doneView = null
    }

    fun destroy() {
        hideButtons()
        hideDoneBanner()
    }
}
