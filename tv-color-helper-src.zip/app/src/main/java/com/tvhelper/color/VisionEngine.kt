package com.tvhelper.color

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class WatchlistRow(
    val symbol: String,
    val centerX: Int,
    val centerY: Int,
    val topY: Int,
    val bottomY: Int,
    val hasAnyFlag: Boolean
)

data class ColorMenuDots(
    val redX: Int,
    val redY: Int,
    val blueX: Int,
    val blueY: Int
)

class VisionEngine {

    private val latinRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val chineseRecognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }

    fun close() {
        try { latinRecognizer.close() } catch (_: Exception) {}
        try { chineseRecognizer.close() } catch (_: Exception) {}
    }

    /**
     * 极速计算图表底部左下角品种代码区域的像素特征，用于毫秒级检测切换品种
     */
    fun computeChartTickerPatchHash(bitmap: Bitmap): IntArray {
        val w = bitmap.width
        val h = bitmap.height
        val cols = 10
        val rows = 4
        val hash = IntArray(cols * rows)
        var idx = 0
        for (r in 0 until rows) {
            val y = (h * (0.935f + 0.011f * r / (rows - 1))).toInt().coerceIn(0, h - 1)
            for (c in 0 until cols) {
                val x = (w * (0.022f + 0.21f * c / (cols - 1))).toInt().coerceIn(0, w - 1)
                val p = bitmap.getPixel(x, y)
                val luma = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                hash[idx++] = if (luma >= 145) 1 else 0
            }
        }
        return hash
    }

    fun isChartPatchChanged(a: IntArray?, b: IntArray?): Boolean {
        if (a == null || b == null || a.size != b.size) return true
        var diff = 0
        for (i in a.indices) {
            if (a[i] != b[i]) diff++
        }
        return diff >= 3
    }

    /**
     * 读取图表当前品种代码：
     * 1) 读左下角滚轮高亮代码（降低边缘淡出阈值，避免最后一个字母被吃掉）
     * 2) 若代码较长(>=5字符)或左下角没读到，自动核对顶部标题栏完整代码（如 BTCUSD · 比特币/美元）
     */
    fun readChartSymbolFromBitmap(bitmap: Bitmap): String? {
        val bottomSym = readBottomWheelSymbol(bitmap)
        if (bottomSym == null || bottomSym.length >= 5) {
            val topSym = readTopHeaderSymbol(bitmap)
            if (topSym != null) {
                if (bottomSym == null) return topSym
                val commonPrefixLen = min(3, min(bottomSym.length, topSym.length))
                if (commonPrefixLen >= 2 &&
                    topSym.startsWith(bottomSym.substring(0, commonPrefixLen)) &&
                    topSym.length >= bottomSym.length
                ) {
                    return topSym
                }
            }
        }
        return bottomSym
    }

    private fun readBottomWheelSymbol(bitmap: Bitmap): String? {
        val w = bitmap.width
        val h = bitmap.height
        val left = 0
        val top = (h * 0.928f).toInt().coerceIn(0, h - 1)
        val right = (w * 0.28f).toInt().coerceIn(1, w)
        val bottom = (h * 0.950f).toInt().coerceIn(top + 1, h)
        val cropW = right - left
        val cropH = bottom - top
        if (cropW <= 10 || cropH <= 10) return null

        val rawCrop = Bitmap.createBitmap(bitmap, left, top, cropW, cropH)
        // 阈值 120：保留滚轮右边缘淡出变暗的字母，避免 D 被切一半变成 I
        val filtered = filterBrightWhiteOnly(rawCrop, minBrightness = 120)
        rawCrop.recycle()

        val scaled = Bitmap.createScaledBitmap(filtered, cropW * 2, cropH * 2, true)
        filtered.recycle()

        return try {
            val result = Tasks.await(
                latinRecognizer.process(InputImage.fromBitmap(scaled, 0)),
                3,
                TimeUnit.SECONDS
            )

            val elements = ArrayList<Pair<Rect, String>>()
            for (block in result.textBlocks) {
                for (line in block.lines) {
                    for (el in line.elements) {
                        val box = el.boundingBox ?: continue
                        val txt = el.text.trim()
                        if (txt.isNotEmpty()) {
                            elements.add(box to txt)
                        }
                    }
                }
            }
            elements.sortBy { it.first.left }
            if (elements.isEmpty()) return null

            val merged = StringBuilder()
            var prevBox: Rect? = null
            for ((box, txt) in elements) {
                if (prevBox == null) {
                    if (box.left > scaled.width * 0.48f) break
                    merged.append(txt)
                    prevBox = box
                } else {
                    val gap = box.left - prevBox.right
                    val refH = max(prevBox.height(), box.height())
                    if (gap <= refH * 0.55f) {
                        merged.append(txt)
                        prevBox = Rect(
                            min(prevBox.left, box.left),
                            min(prevBox.top, box.top),
                            max(prevBox.right, box.right),
                            max(prevBox.bottom, box.bottom)
                        )
                    } else {
                        break
                    }
                }
            }
            normalizeTickerCandidate(merged.toString())
        } catch (e: Exception) {
            AppStore.log("图表左下OCR异常：${e.message}")
            null
        } finally {
            scaled.recycle()
        }
    }

    /**
     * 读取图表顶部标题栏左侧的品种代码（例如 "BTCUSD · 比特币/美元" -> "BTCUSD"）
     * 若被截断带省略号（如 "RE..."），直接返回 null
     */
    private fun readTopHeaderSymbol(bitmap: Bitmap): String? {
        val w = bitmap.width
        val h = bitmap.height
        val left = (w * 0.042f).toInt().coerceIn(0, w - 1)
        val top = (h * 0.042f).toInt().coerceIn(0, h - 1)
        val right = (w * 0.42f).toInt().coerceIn(left + 1, w)
        val bottom = (h * 0.066f).toInt().coerceIn(top + 1, h)
        val cropW = right - left
        val cropH = bottom - top
        if (cropW <= 10 || cropH <= 8) return null

        val rawCrop = Bitmap.createBitmap(bitmap, left, top, cropW, cropH)
        val filtered = filterBrightWhiteOnly(rawCrop, minBrightness = 145)
        rawCrop.recycle()

        val scaled = Bitmap.createScaledBitmap(filtered, cropW * 2, cropH * 2, true)
        filtered.recycle()

        return try {
            val result = Tasks.await(
                latinRecognizer.process(InputImage.fromBitmap(scaled, 0)),
                2,
                TimeUnit.SECONDS
            )
            val fullLine = result.textBlocks
                .flatMap { it.lines }
                .minByOrNull { it.boundingBox?.left ?: Int.MAX_VALUE }
                ?.text
                ?.trim() ?: return null

            // 如果顶部代码带省略号（例如 RE...），放弃顶部
            val firstPart = fullLine.split(Regex("""[\s·•・]+""")).firstOrNull()?.trim() ?: return null
            if (firstPart.contains("..") || firstPart.contains("…")) return null
            normalizeTickerCandidate(firstPart)
        } catch (_: Exception) {
            null
        } finally {
            scaled.recycle()
        }
    }

    /**
     * 列表品种名与待办队列名的宽松前缀匹配：
     * 1) 完全相等优先
     * 2) 队列名长度>=4 且列表品种名以前缀开头（例如 BTCUS -> BTCUSD，RBOBG -> RBOBGASOLINE）
     * 3) 队列名长度>=5 且非纯数字时，容忍末尾1个被滚轮淡出切坏的字符（例如 BTCUSI -> BTCUS -> BTCUSD）
     */
    fun findMatchingTaskKey(watchlistSymbol: String, remainingKeys: Set<String>): String? {
        if (watchlistSymbol in remainingKeys) return watchlistSymbol

        val wSym = watchlistSymbol.trim().uppercase(Locale.US)
        if (wSym.isEmpty()) return null

        var bestKey: String? = null
        var bestScore = -1

        for (rawKey in remainingKeys) {
            val qKey = rawKey.trim().uppercase(Locale.US)
            if (qKey.isEmpty()) continue

            if (wSym == qKey) return rawKey

            // 规则2：直接前缀匹配（列表名以队列名开头）
            if (qKey.length >= 4 && wSym.length > qKey.length && wSym.startsWith(qKey)) {
                val score = 100 + qKey.length
                if (score > bestScore) {
                    bestScore = score
                    bestKey = rawKey
                }
                continue
            }

            // 规则3：滚轮右侧淡出导致末尾1个字母识别失真（如 BTCUSD 读成 BTCUSI），取前 len-1 位做前缀匹配
            // 纯数字代码（如 8035 / 8031）不做去尾匹配，避免误伤同板块股票
            if (qKey.length >= 5 && !qKey.all { it.isDigit() } && wSym.length >= qKey.length) {
                val prefix = qKey.dropLast(1)
                if (prefix.length >= 4 && wSym.startsWith(prefix)) {
                    val score = 50 + prefix.length
                    if (score > bestScore) {
                        bestScore = score
                        bestKey = rawKey
                    }
                }
            }
        }
        return bestKey
    }

    /**
     * 懒加载识别自选表顶部当前高亮（灰底胶囊）的列表名称，仅在漏项报错时调用
     */
    fun readActiveWatchlistName(bitmap: Bitmap): String? {
        val w = bitmap.width
        val h = bitmap.height
        val bandTop = (h * 0.078f).toInt().coerceIn(0, h - 1)
        val bandBottom = (h * 0.116f).toInt().coerceIn(bandTop + 1, h)
        val bandMidTop = bandTop + (bandBottom - bandTop) / 5
        val bandMidBottom = bandBottom - (bandBottom - bandTop) / 5

        val startX = (w * 0.16f).toInt()
        val endX = (w * 0.98f).toInt()
        var bestLeft = -1
        var bestRight = -1
        var curLeft = -1

        for (x in startX until endX) {
            var pillHits = 0
            var samples = 0
            var y = bandMidTop
            while (y < bandMidBottom) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val isPillBg = maxC in 34..95 && (maxC - minC) <= 18
                val isWhiteText = minC >= 150
                if (isPillBg || isWhiteText) pillHits++
                samples++
                y += 3
            }
            val isPillCol = samples > 0 && pillHits.toFloat() / samples >= 0.55f
            if (isPillCol) {
                if (curLeft == -1) curLeft = x
            } else if (curLeft != -1) {
                val curWidth = x - curLeft
                if (curWidth > bestRight - bestLeft) {
                    bestLeft = curLeft
                    bestRight = x
                }
                curLeft = -1
            }
        }
        if (curLeft != -1 && (endX - curLeft) > (bestRight - bestLeft)) {
            bestLeft = curLeft
            bestRight = endX
        }

        if (bestLeft == -1 || bestRight - bestLeft < w * 0.05f) return null

        val padX = (w * 0.012f).toInt()
        val cropL = (bestLeft - padX).coerceAtLeast(0)
        val cropR = (bestRight + padX).coerceAtMost(w)
        val cropW = cropR - cropL
        val cropH = bandBottom - bandTop
        if (cropW <= 8 || cropH <= 8) return null

        val crop = Bitmap.createBitmap(bitmap, cropL, bandTop, cropW, cropH)
        val scaled = Bitmap.createScaledBitmap(crop, cropW * 2, cropH * 2, true)
        crop.recycle()

        return try {
            val result = Tasks.await(
                chineseRecognizer.process(InputImage.fromBitmap(scaled, 0)),
                3,
                TimeUnit.SECONDS
            )
            val text = result.text.replace("\n", "").replace(" ", "").trim()
            if (text.isNotEmpty()) text else null
        } catch (_: Exception) {
            null
        } finally {
            scaled.recycle()
        }
    }

    /**
     * 扫描当前自选表屏幕上所有品种代码、坐标及最左边缘是否存在任意颜色小旗
     * 裁剪宽度紧缩至 0.090~0.470 并适度缩放 0.8x，兼顾极速与高准确率
     */
    fun scanWatchlistSymbols(bitmap: Bitmap): List<WatchlistRow> {
        val w = bitmap.width
        val h = bitmap.height
        val cropLeft = (w * 0.090f).toInt()
        val cropTop = (h * 0.120f).toInt()
        val cropRight = (w * 0.47f).toInt()
        val cropBottom = (h * 0.950f).toInt()
        val cropW = cropRight - cropLeft
        val cropH = cropBottom - cropTop
        if (cropW <= 20 || cropH <= 20) return emptyList()

        val scale = 0.80f
        val rawCrop = Bitmap.createBitmap(bitmap, cropLeft, cropTop, cropW, cropH)
        val ocrBmp = Bitmap.createScaledBitmap(
            rawCrop,
            (cropW * scale).toInt().coerceAtLeast(20),
            (cropH * scale).toInt().coerceAtLeast(20),
            true
        )
        rawCrop.recycle()

        val rows = ArrayList<WatchlistRow>()

        try {
            val result = Tasks.await(
                latinRecognizer.process(InputImage.fromBitmap(ocrBmp, 0)),
                4,
                TimeUnit.SECONDS
            )

            val expectedLeftMin = (w * 0.095f).toInt()
            val expectedLeftMax = (w * 0.175f).toInt()

            for (block in result.textBlocks) {
                for (line in block.lines) {
                    val box = line.boundingBox ?: continue
                    val screenLeft = cropLeft + (box.left / scale).toInt()
                    val screenRight = cropLeft + (box.right / scale).toInt()
                    val screenTop = cropTop + (box.top / scale).toInt()
                    val screenBottom = cropTop + (box.bottom / scale).toInt()

                    if (screenLeft < expectedLeftMin || screenLeft > expectedLeftMax) continue
                    if (screenTop < h * 0.125f || screenBottom > h * 0.942f) continue

                    if (!hasBrightWhiteInk(bitmap, screenLeft, screenTop, screenRight, screenBottom)) {
                        continue
                    }

                    val parsed = extractWatchlistSymbol(line.text) ?: continue
                    val centerX = ((screenLeft + min(screenRight, (w * 0.42f).toInt())) / 2)
                        .coerceIn((w * 0.13f).toInt(), (w * 0.40f).toInt())
                    val centerY = (screenTop + screenBottom) / 2
                    val flagged = hasAnyLeftEdgeFlag(bitmap, screenTop, screenBottom)

                    rows.add(
                        WatchlistRow(
                            symbol = parsed,
                            centerX = centerX,
                            centerY = centerY,
                            topY = screenTop,
                            bottomY = screenBottom,
                            hasAnyFlag = flagged
                        )
                    )
                }
            }
        } catch (e: Exception) {
            AppStore.log("自选表OCR异常：${e.message}")
        } finally {
            ocrBmp.recycle()
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || abs(r.centerY - deduped.last().centerY) > (h * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    /**
     * 检测该行最左边缘（X: 0 ~ 1.9% 屏幕宽度）是否存在任意颜色（红/蓝/绿/黄/紫/青/粉）的已标记小旗
     * 圆形品种图标位于 X >= 2.6%，完全不会误触发
     */
    fun hasAnyLeftEdgeFlag(bitmap: Bitmap, symbolTop: Int, symbolBottom: Int): Boolean {
        val w = bitmap.width
        val h = bitmap.height
        val maxX = (w * 0.019f).toInt().coerceAtLeast(8)
        val yStart = (symbolTop - (h * 0.005f).toInt()).coerceIn(0, h - 1)
        val yEnd = (symbolBottom + (h * 0.028f).toInt()).coerceIn(yStart + 1, h)

        var coloredCount = 0
        var totalSamples = 0
        var y = yStart
        while (y < yEnd) {
            var x = 0
            while (x < maxX) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                if (maxC >= 88 && (maxC - minC) >= 38) {
                    coloredCount++
                }
                totalSamples++
                x += 2
            }
            y += 2
        }
        if (totalSamples == 0) return false
        return coloredCount >= 6 && coloredCount.toFloat() / totalSamples >= 0.06f
    }

    /**
     * 核心：全屏左半区域像素扫描“红 -> 蓝 -> 绿 -> 黄”等距横向四连实心圆点（耗时 < 5ms）
     */
    fun findColorMenu(bitmap: Bitmap): ColorMenuDots? {
        val w = bitmap.width
        val h = bitmap.height

        val minY = (h * 0.12f).toInt()
        val maxY = (h * 0.94f).toInt()
        val redSearchMinX = (w * 0.02f).toInt()
        val redSearchMaxX = (w * 0.48f).toInt()
        val minDotW = (w * 0.014f).toInt().coerceAtLeast(10)
        val maxDotW = (w * 0.075f).toInt().coerceAtLeast(40)
        val minSpacing = (w * 0.038f).toInt()
        val maxSpacing = (w * 0.115f).toInt()

        var y = minY
        while (y < maxY) {
            var x = redSearchMinX
            while (x < redSearchMaxX) {
                if (isMenuRed(bitmap.getPixel(x, y))) {
                    val runStart = x
                    while (x < redSearchMaxX && isMenuRed(bitmap.getPixel(x, y))) {
                        x++
                    }
                    val runW = x - runStart
                    if (runW in minDotW..maxDotW) {
                        val redCenterX = (runStart + x) / 2
                        val blueCenterX = findAdjacentBlueDot(
                            bitmap, y, redCenterX + minSpacing, min(w - 5, redCenterX + maxSpacing), minDotW, maxDotW
                        )
                        if (blueCenterX != -1) {
                            val spacing = blueCenterX - redCenterX
                            val midBg = bitmap.getPixel((redCenterX + blueCenterX) / 2, y)
                            val isDarkGap = Color.red(midBg) < 85 && Color.green(midBg) < 85 && Color.blue(midBg) < 95

                            val greenX = redCenterX + spacing * 2
                            val yellowX = redCenterX + spacing * 3
                            if (isDarkGap &&
                                yellowX + minDotW < w &&
                                hasColorPatch(bitmap, greenX, y, (spacing * 0.28f).toInt(), ::isMenuGreen) &&
                                hasColorPatch(bitmap, yellowX, y, (spacing * 0.28f).toInt(), ::isMenuYellow)
                            ) {
                                val refinedY = refineVerticalCenter(bitmap, redCenterX, y, ::isMenuRed)
                                val refinedRedX = refineHorizontalCenter(bitmap, redCenterX, refinedY, ::isMenuRed)
                                val refinedBlueX = refineHorizontalCenter(bitmap, blueCenterX, refinedY, ::isMenuBlue)
                                return ColorMenuDots(
                                    redX = refinedRedX,
                                    redY = refinedY,
                                    blueX = refinedBlueX,
                                    blueY = refinedY
                                )
                            }
                        }
                    }
                } else {
                    x += 2
                }
            }
            y += 4
        }
        return null
    }

    fun computeListFingerprint(bitmap: Bitmap): IntArray {
        val w = bitmap.width
        val h = bitmap.height
        val cols = 5
        val rows = 14
        val fp = IntArray(cols * rows)
        var idx = 0
        for (r in 0 until rows) {
            val y = (h * (0.16f + 0.74f * r / (rows - 1))).toInt().coerceIn(0, h - 1)
            for (c in 0 until cols) {
                val x = (w * (0.06f + 0.36f * c / (cols - 1))).toInt().coerceIn(0, w - 1)
                val p = bitmap.getPixel(x, y)
                fp[idx++] = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
            }
        }
        return fp
    }

    fun isSameFrame(a: IntArray?, b: IntArray?): Boolean {
        if (a == null || b == null || a.size != b.size) return false
        var match = 0
        for (i in a.indices) {
            if (abs(a[i] - b[i]) <= 12) match++
        }
        return match.toFloat() / a.size >= 0.94f
    }

    private fun filterBrightWhiteOnly(src: Bitmap, minBrightness: Int): Bitmap {
        val w = src.width
        val h = src.height
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val maxC = max(r, max(g, b))
            val minC = min(r, min(g, b))
            if (maxC >= minBrightness && (maxC - minC) <= 45) {
                pixels[i] = Color.WHITE
            } else {
                pixels[i] = Color.BLACK
            }
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun hasBrightWhiteInk(bitmap: Bitmap, left: Int, top: Int, right: Int, bottom: Int): Boolean {
        val l = left.coerceIn(0, bitmap.width - 1)
        val r = right.coerceIn(l + 1, bitmap.width)
        val t = top.coerceIn(0, bitmap.height - 1)
        val b = bottom.coerceIn(t + 1, bitmap.height)
        var brightPixels = 0
        var y = t
        while (y < b) {
            var x = l
            while (x < r) {
                val p = bitmap.getPixel(x, y)
                if (Color.red(p) >= 188 && Color.green(p) >= 188 && Color.blue(p) >= 188) {
                    brightPixels++
                    if (brightPixels >= 6) return true
                }
                x += 2
            }
            y += 2
        }
        return false
    }

    fun extractWatchlistSymbol(rawLine: String): String? {
        var s = rawLine.trim()
        if (s.isEmpty()) return null
        if (s.any { it in 'a'..'z' }) return null
        s = s.replace(Regex("""[\s\-—·~]+D$"""), "").trim()
        val token = s.split(Regex("""\s+""")).firstOrNull()?.trim() ?: return null
        return normalizeTickerCandidate(token)
    }

    fun normalizeTickerCandidate(raw: String): String? {
        val cleaned = raw.trim()
            .replace(" ", "")
            .replace("…", "")
            .uppercase(Locale.US)

        if (cleaned.isEmpty() || cleaned.length > 20) return null
        if (cleaned.endsWith("...")) return null
        if (!cleaned.matches(Regex("""^[A-Z0-9][A-Z0-9._!:/-]{0,19}$"""))) return null
        if (cleaned.matches(Regex("""^\d{1,3}[MHWDYS]?$"""))) return null
        if (cleaned in setOf("USD", "EUR", "CNY", "HKD", "JPY", "GBP", "AUD", "CAD")) return null
        return cleaned
    }

    private fun findAdjacentBlueDot(
        bitmap: Bitmap,
        y: Int,
        minX: Int,
        maxX: Int,
        minDotW: Int,
        maxDotW: Int
    ): Int {
        val yOffsets = intArrayOf(0, -4, 4)
        for (dy in yOffsets) {
            val sy = (y + dy).coerceIn(0, bitmap.height - 1)
            var x = minX.coerceAtLeast(0)
            while (x < maxX) {
                if (isMenuBlue(bitmap.getPixel(x, sy))) {
                    val start = x
                    while (x < maxX && isMenuBlue(bitmap.getPixel(x, sy))) {
                        x++
                    }
                    val runW = x - start
                    if (runW in minDotW..maxDotW) {
                        return (start + x) / 2
                    }
                } else {
                    x += 2
                }
            }
        }
        return -1
    }

    private fun hasColorPatch(
        bitmap: Bitmap,
        cx: Int,
        cy: Int,
        radius: Int,
        predicate: (Int) -> Boolean
    ): Boolean {
        val l = (cx - radius).coerceIn(0, bitmap.width - 1)
        val r = (cx + radius).coerceIn(l + 1, bitmap.width)
        val t = (cy - 8).coerceIn(0, bitmap.height - 1)
        val b = (cy + 8).coerceIn(t + 1, bitmap.height)
        var hits = 0
        var y = t
        while (y < b) {
            var x = l
            while (x < r) {
                if (predicate(bitmap.getPixel(x, y))) {
                    hits++
                    if (hits >= 6) return true
                }
                x += 2
            }
            y += 2
        }
        return false
    }

    private fun refineVerticalCenter(bitmap: Bitmap, x: Int, y: Int, predicate: (Int) -> Boolean): Int {
        val cx = x.coerceIn(0, bitmap.width - 1)
        var top = y
        var bottom = y
        while (top > 0 && predicate(bitmap.getPixel(cx, top - 1))) top--
        while (bottom < bitmap.height - 1 && predicate(bitmap.getPixel(cx, bottom + 1))) bottom++
        return (top + bottom) / 2
    }

    private fun refineHorizontalCenter(bitmap: Bitmap, x: Int, y: Int, predicate: (Int) -> Boolean): Int {
        val cy = y.coerceIn(0, bitmap.height - 1)
        var left = x
        var right = x
        while (left > 0 && predicate(bitmap.getPixel(left - 1, cy))) left--
        while (right < bitmap.width - 1 && predicate(bitmap.getPixel(right + 1, cy))) right++
        return (left + right) / 2
    }

    private fun isMenuRed(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return r >= 180 && g in 25..145 && b in 35..150 && (r - g) >= 75 && (r - b) >= 65
    }

    private fun isMenuBlue(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return b >= 145 && r <= 120 && g in 35..185 && (b - r) >= 65
    }

    private fun isMenuGreen(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return g >= 135 && r in 40..195 && b in 40..195 && (g - r) >= 16 && (g - b) >= 15
    }

    private fun isMenuYellow(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return r >= 185 && g >= 135 && b <= 130 && (r - b) >= 75 && (g - b) >= 45
    }
}
