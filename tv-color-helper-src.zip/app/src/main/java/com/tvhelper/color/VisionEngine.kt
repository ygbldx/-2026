package com.tvhelper.color

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class WatchlistTabInfo(
    val name: String,
    val leftX: Int,
    val rightX: Int,
    val centerX: Int,
    val centerY: Int
)

data class WatchlistRow(
    val symbol: String,
    val centerX: Int,
    val centerY: Int,
    val topY: Int,
    val bottomY: Int,
    val hasAnyFlag: Boolean,
    val existingFlagColor: MarkColor? = null,
    val rowNode: AccessibilityNodeInfo? = null
)

/**
 * 7个颜色圆点中心坐标（按 TradingView 菜单从左到右：红0、蓝1、绿2、黄3、紫4、青5、粉6）
 */
data class ColorMenuDots(
    val dotXs: IntArray,
    val y: Int
) {
    fun pointFor(color: MarkColor): Pair<Int, Int> {
        val idx = color.menuIndex.coerceIn(0, dotXs.lastIndex)
        return dotXs[idx] to y
    }
}

class VisionEngine {

    private val latinRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val chineseRecognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }

    /**
     * 后台预热 ML Kit 模型，消除首次识别冷启动耗时
     */
    fun warmUp() {
        val tiny = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        tiny.eraseColor(Color.BLACK)
        try {
            Tasks.await(latinRecognizer.process(InputImage.fromBitmap(tiny, 0)), 3, TimeUnit.SECONDS)
        } catch (_: Exception) {
        }
        try {
            Tasks.await(chineseRecognizer.process(InputImage.fromBitmap(tiny, 0)), 3, TimeUnit.SECONDS)
        } catch (_: Exception) {
        } finally {
            tiny.recycle()
        }
    }

    fun close() {
        try { latinRecognizer.close() } catch (_: Exception) {}
        try { chineseRecognizer.close() } catch (_: Exception) {}
    }

    fun computeChartTickerPatchHash(bitmap: Bitmap): IntArray {
        val w = bitmap.width
        val h = bitmap.height
        val cols = 10
        val rows = 4
        val hash = IntArray(cols * rows)
        var idx = 0
        for (r in 0 until rows) {
            val y = (h * (0.935f + 0.011f * r / (rows - 1))).toInt().coerceIn(0, h - 1)
            for (c in 0 until cols) {
                val x = (w * (0.022f + 0.21f * c / (cols - 1))).toInt().coerceIn(0, w - 1)
                val p = bitmap.getPixel(x, y)
                val luma = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                hash[idx++] = if (luma >= 145) 1 else 0
            }
        }
        return hash
    }

    fun isChartPatchChanged(a: IntArray?, b: IntArray?): Boolean {
        if (a == null || b == null || a.size != b.size) return true
        var diff = 0
        for (i in a.indices) {
            if (a[i] != b[i]) diff++
        }
        return diff >= 3
    }

    /**
     * 读取图表当前品种代码：
     * 1) 读左下角滚轮高亮代码（降低边缘淡出阈值，避免最后一位被吃掉）
     * 2) 代码>=5位或左下角未读到时，核对顶部标题栏完整代码（如 BTCUSD · 比特币/美元）
     */
    /**
     * 专读左下角滚轮代码（完全不管上方图表加载出来没有！）：
     * 只有左下角未读到或滚轮长代码未能直接匹配《品种大全》时，才兜底看一眼顶部标题
     */
    fun readChartSymbolFromBitmap(bitmap: Bitmap): String? {
        val bottomSym = readBottomWheelSymbol(bitmap)
        if (bottomSym != null) {
            // 如果左下角滚轮代码在《品种大全》中已经能直接匹配（含前缀校准），直接秒返，绝不等上方图表！
            if (CatalogRepository.resolveChartSymbolInCatalog(bottomSym) != null) {
                return bottomSym
            }
        }
        if (bottomSym == null || bottomSym.length >= 5) {
            val topSym = readTopHeaderSymbol(bitmap)
            if (topSym != null) {
                if (bottomSym == null) return topSym
                val commonPrefixLen = min(3, min(bottomSym.length, topSym.length))
                if (commonPrefixLen >= 2 &&
                    topSym.startsWith(bottomSym.substring(0, commonPrefixLen)) &&
                    topSym.length >= bottomSym.length
                ) {
                    return topSym
                }
            }
        }
        return bottomSym
    }

    private fun readBottomWheelSymbol(bitmap: Bitmap): String? {
        val w = bitmap.width
        val h = bitmap.height
        val left = 0
        val top = (h * 0.928f).toInt().coerceIn(0, h - 1)
        val right = (w * 0.28f).toInt().coerceIn(1, w)
        val bottom = (h * 0.950f).toInt().coerceIn(top + 1, h)
        val cropW = right - left
        val cropH = bottom - top
        if (cropW <= 10 || cropH <= 10) return null

        val rawCrop = Bitmap.createBitmap(bitmap, left, top, cropW, cropH)
        val filtered = filterBrightWhiteOnly(rawCrop, minBrightness = 120)
        rawCrop.recycle()

        val scaled = Bitmap.createScaledBitmap(filtered, cropW * 2, cropH * 2, true)
        filtered.recycle()

        return try {
            val result = Tasks.await(
                latinRecognizer.process(InputImage.fromBitmap(scaled, 0)),
                3,
                TimeUnit.SECONDS
            )

            val elements = ArrayList<Pair<Rect, String>>()
            for (block in result.textBlocks) {
                for (line in block.lines) {
                    for (el in line.elements) {
                        val box = el.boundingBox ?: continue
                        val txt = el.text.trim()
                        if (txt.isNotEmpty()) {
                            elements.add(box to txt)
                        }
                    }
                }
            }
            elements.sortBy { it.first.left }
            if (elements.isEmpty()) return null

            val merged = StringBuilder()
            var prevBox: Rect? = null
            for ((box, txt) in elements) {
                if (prevBox == null) {
                    if (box.left > scaled.width * 0.48f) break
                    merged.append(txt)
                    prevBox = box
                } else {
                    val gap = box.left - prevBox.right
                    val refH = max(prevBox.height(), box.height())
                    if (gap <= refH * 0.55f) {
                        merged.append(txt)
                        prevBox = Rect(
                            min(prevBox.left, box.left),
                            min(prevBox.top, box.top),
                            max(prevBox.right, box.right),
                            max(prevBox.bottom, box.bottom)
                        )
                    } else {
                        break
                    }
                }
            }
            normalizeTickerCandidate(merged.toString())
        } catch (e: Exception) {
            AppStore.log("图表左下OCR异常：${e.message}")
            null
        } finally {
            scaled.recycle()
        }
    }

    private fun readTopHeaderSymbol(bitmap: Bitmap): String? {
        val w = bitmap.width
        val h = bitmap.height
        val left = (w * 0.042f).toInt().coerceIn(0, w - 1)
        val top = (h * 0.042f).toInt().coerceIn(0, h - 1)
        val right = (w * 0.42f).toInt().coerceIn(left + 1, w)
        val bottom = (h * 0.066f).toInt().coerceIn(top + 1, h)
        val cropW = right - left
        val cropH = bottom - top
        if (cropW <= 10 || cropH <= 8) return null

        val rawCrop = Bitmap.createBitmap(bitmap, left, top, cropW, cropH)
        val filtered = filterBrightWhiteOnly(rawCrop, minBrightness = 145)
        rawCrop.recycle()

        val scaled = Bitmap.createScaledBitmap(filtered, cropW * 2, cropH * 2, true)
        filtered.recycle()

        return try {
            val result = Tasks.await(
                latinRecognizer.process(InputImage.fromBitmap(scaled, 0)),
                2,
                TimeUnit.SECONDS
            )
            val fullLine = result.textBlocks
                .flatMap { it.lines }
                .minByOrNull { it.boundingBox?.left ?: Int.MAX_VALUE }
                ?.text
                ?.trim() ?: return null

            val firstPart = fullLine.split(Regex("""[\s·•・]+""")).firstOrNull()?.trim() ?: return null
            if (firstPart.contains("..") || firstPart.contains("…")) return null
            normalizeTickerCandidate(firstPart)
        } catch (_: Exception) {
            null
        } finally {
            scaled.recycle()
        }
    }

    /**
     * 列表品种名与待办队列名的宽松前缀匹配：
     * 1) 完全相等优先
     * 2) 队列名长度>=4 且列表品种名以前缀开头（如 BTCUS -> BTCUSD）
     * 3) 队列名长度>=5 且非纯数字时，容忍末尾1个被滚轮淡出切坏的字符（如 BTCUSI -> BTCUSD）
     */
    fun findMatchingTaskKey(watchlistSymbol: String, remainingKeys: Set<String>): String? {
        if (watchlistSymbol in remainingKeys) return watchlistSymbol

        val wSym = watchlistSymbol.trim().uppercase(Locale.US)
        if (wSym.isEmpty()) return null
        val wCompact = wSym.replace(" ", "")

        var bestKey: String? = null
        var bestScore = -1

        for (rawKey in remainingKeys) {
            val qKey = rawKey.trim().uppercase(Locale.US)
            if (qKey.isEmpty()) continue
            val qCompact = qKey.replace(" ", "")

            if (wSym == qKey || wCompact == qCompact) return rawKey

            if (qCompact.length >= 4 && wCompact.length > qCompact.length && wCompact.startsWith(qCompact)) {
                val score = 100 + qCompact.length
                if (score > bestScore) {
                    bestScore = score
                    bestKey = rawKey
                }
                continue
            }

            // 兼容 MAERSK B 在列表中第一词为 MAERSK
            if (wCompact.length >= 5 && qCompact.length > wCompact.length && qCompact.startsWith(wCompact)) {
                val score = 80 + wCompact.length
                if (score > bestScore) {
                    bestScore = score
                    bestKey = rawKey
                }
                continue
            }

            if (qCompact.length >= 5 && !qCompact.all { it.isDigit() } && wCompact.length >= qCompact.length) {
                val prefix = qCompact.dropLast(1)
                if (prefix.length >= 4 && wCompact.startsWith(prefix)) {
                    val score = 50 + prefix.length
                    if (score > bestScore) {
                        bestScore = score
                        bestKey = rawKey
                    }
                    continue
                }
            }

            // 长代码单字符拼写/OCR容错（如 HEATINGOIL <-> HEATIOGOIL）
            if (qCompact.length >= 8 && wCompact.length >= 8 &&
                abs(qCompact.length - wCompact.length) <= 1 &&
                qCompact.filter { it.isDigit() } == wCompact.filter { it.isDigit() } &&
                isEditDistAtMostOne(wCompact, qCompact)
            ) {
                val score = 40 + qCompact.length
                if (score > bestScore) {
                    bestScore = score
                    bestKey = rawKey
                }
            }
        }
        return bestKey
    }

    private fun isEditDistAtMostOne(a: String, b: String): Boolean {
        val la = a.length
        val lb = b.length
        if (abs(la - lb) > 1) return false
        var i = 0
        var j = 0
        var diffs = 0
        while (i < la && j < lb) {
            if (a[i] == b[j]) {
                i++; j++
            } else {
                diffs++
                if (diffs > 1) return false
                when {
                    la > lb -> i++
                    lb > la -> j++
                    else -> { i++; j++ }
                }
            }
        }
        if (i < la || j < lb) diffs++
        return diffs <= 1
    }


    /**
     * 扫描自选表顶部标签栏可见的所有列表标签及点击坐标（用于跨列表自动切换）
     */
    /**
     * <0.5ms 通过最左侧 ≡ 菜单图标精准锁定当前动态顶部列表栏的真实 Y 坐标（兼容展开 9.5%、半收起 7.3%、全收起 5.9%）
     */
    fun detectTabBarCenterY(bitmap: Bitmap): Int {
        val w = bitmap.width
        val h = bitmap.height
        val x0 = (w * 0.028f).toInt().coerceIn(0, w - 2)
        val x1 = (w * 0.056f).toInt().coerceIn(x0 + 1, w - 1)
        val y0 = (h * 0.044f).toInt().coerceIn(0, h - 2)
        val y1 = (h * 0.114f).toInt().coerceIn(y0 + 1, h - 1)

        val clusters = ArrayList<IntArray>()
        var inCluster = false
        var startY = 0
        for (y in y0..y1) {
            var bright = false
            var x = x0
            while (x <= x1) {
                val p = bitmap.getPixel(x, y)
                val luma = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                if (luma > 130) {
                    bright = true
                    break
                }
                x += 2
            }
            if (bright && !inCluster) {
                inCluster = true
                startY = y
            } else if (!bright && inCluster) {
                inCluster = false
                clusters.add(intArrayOf(startY, y - 1))
            }
        }
        if (inCluster) {
            clusters.add(intArrayOf(startY, y1))
        }

        // 合并 ≡ 三条横杠（间距 <= 0.8% H）
        val merged = ArrayList<IntArray>()
        val mergeGap = (h * 0.0085f).toInt().coerceAtLeast(4)
        for (c in clusters) {
            if (merged.isEmpty() || (c[0] - merged.last()[1]) > mergeGap) {
                merged.add(intArrayOf(c[0], c[1]))
            } else {
                merged.last()[1] = c[1]
            }
        }

        // ≡ 图标高度 >= 0.6% H，排除顶部 ... (0.2% H) 和下方板块折叠箭头 v (0.4% H)
        val minHamburgerH = (h * 0.0058f).toInt().coerceAtLeast(6)
        val hamburgers = merged.filter { (it[1] - it[0]) >= minHamburgerH }
        if (hamburgers.isNotEmpty()) {
            val best = hamburgers.last()
            return (best[0] + best[1]) / 2
        }
        return (h * 0.095f).toInt()
    }

    fun scanTopWatchlistTabs(bitmap: Bitmap): List<WatchlistTabInfo> {
        val w = bitmap.width
        val h = bitmap.height
        val tabCenterY = detectTabBarCenterY(bitmap)
        val halfBand = (h * 0.022f).toInt().coerceAtLeast(18)
        val cropLeft = (w * 0.085f).toInt()
        val cropTop = (tabCenterY - halfBand).coerceIn((h * 0.035f).toInt(), h - 20)
        val cropRight = (w * 0.995f).toInt()
        val cropBottom = (tabCenterY + halfBand).coerceIn(cropTop + 12, (h * 0.132f).toInt())
        val cropW = cropRight - cropLeft
        val cropH = cropBottom - cropTop
        if (cropW <= 20 || cropH <= 10) return emptyList()

        val crop = Bitmap.createBitmap(bitmap, cropLeft, cropTop, cropW, cropH)
        val scaled = Bitmap.createScaledBitmap(crop, cropW * 2, cropH * 2, true)
        crop.recycle()

        val rawEls = ArrayList<Pair<Rect, String>>()
        try {
            val result = Tasks.await(
                chineseRecognizer.process(InputImage.fromBitmap(scaled, 0)),
                3,
                TimeUnit.SECONDS
            )
            val centerY = (cropTop + cropBottom) / 2
            for (block in result.textBlocks) {
                for (line in block.lines) {
                    for (el in line.elements) {
                        val box = el.boundingBox ?: continue
                        val txt = el.text.replace(" ", "").trim()
                        if (txt.isEmpty()) continue
                        val screenRect = Rect(
                            cropLeft + box.left / 2,
                            cropTop + box.top / 2,
                            cropLeft + box.right / 2,
                            cropTop + box.bottom / 2
                        )
                        rawEls.add(screenRect to txt)
                    }
                }
            }
            // 按实际边界框间隙合并同一标签内字符（标签内间隙 < 1.5% 宽，标签之间间隙约 7.2% 宽）
            rawEls.sortBy { it.first.left }
            val maxInnerGap = (w * 0.036f).toInt()
            val merged = ArrayList<WatchlistTabInfo>()
            var i = 0
            while (i < rawEls.size) {
                var left = rawEls[i].first.left
                var right = rawEls[i].first.right
                val sb = StringBuilder(rawEls[i].second)
                var j = i + 1
                while (j < rawEls.size && (rawEls[j].first.left - right) <= maxInnerGap) {
                    right = max(right, rawEls[j].first.right)
                    sb.append(rawEls[j].second)
                    j++
                }
                merged.add(WatchlistTabInfo(sb.toString(), left, right, (left + right) / 2, centerY))
                i = j
            }
            return merged
        } catch (_: Exception) {
            return emptyList()
        } finally {
            scaled.recycle()
        }
    }


    /**
     * 精准检测顶部列表栏中当前高亮灰底胶囊内是否为“纯彩色小旗图标”（颜色列表：红/蓝/绿/黄/紫/青/粉）：
     * - 兼容 TradingView 顶部颜色列表只显示彩色旗帜图标、无中文文字的情况
     * - 灰底胶囊内是纯白文字（如 -1商）时 coloredCount ≈ 0，返回 null，绝不误判！
     */
    fun detectActiveColorWatchlistFromTopPill(bitmap: Bitmap): MarkColor? {
        val w = bitmap.width
        val h = bitmap.height
        val tabCenterY = detectTabBarCenterY(bitmap)
        val halfBand = (h * 0.017f).toInt().coerceAtLeast(14)
        val bandTop = (tabCenterY - halfBand).coerceIn((h * 0.036f).toInt(), h - 16)
        val bandBottom = (tabCenterY + halfBand).coerceIn(bandTop + 10, (h * 0.130f).toInt())

        val startX = (w * 0.085f).toInt()
        val endX = (w * 0.96f).toInt()
        var bestLeft = -1
        var bestRight = -1
        var curLeft = -1

        for (x in startX until endX) {
            var pillHits = 0
            var samples = 0
            var y = bandTop
            while (y < bandBottom) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val isPillBg = maxC in 32..88 && (maxC - minC) <= 18
                val isWhite = minC >= 150
                val isColored = maxC >= 88 && (maxC - minC) >= 42
                if (isPillBg || isWhite || isColored) pillHits++
                samples++
                y += 2
            }
            val isPillCol = samples > 0 && pillHits.toFloat() / samples >= 0.55f
            if (isPillCol) {
                if (curLeft == -1) curLeft = x
            } else if (curLeft != -1) {
                if ((x - curLeft) > (bestRight - bestLeft)) {
                    bestLeft = curLeft
                    bestRight = x
                }
                curLeft = -1
            }
        }
        if (curLeft != -1 && (endX - curLeft) > (bestRight - bestLeft)) {
            bestLeft = curLeft
            bestRight = endX
        }

        if (bestLeft == -1 || (bestRight - bestLeft) < (w * 0.045f).toInt()) return null

        // 统计当前高亮灰底胶囊内部的有效彩色像素 vs 亮白文字像素
        var coloredCount = 0
        var whiteCount = 0
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var y = bandTop
        while (y < bandBottom) {
            var x = bestLeft
            while (x < bestRight) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                if (maxC >= 88 && (maxC - minC) >= 42) {
                    coloredCount++
                    sumR += r
                    sumG += g
                    sumB += b
                } else if (minC >= 150) {
                    whiteCount++
                }
                x += 2
            }
            y += 2
        }

        if (coloredCount < 16 || whiteCount > coloredCount) return null

        val avgR = (sumR / coloredCount).toInt()
        val avgG = (sumG / coloredCount).toInt()
        val avgB = (sumB / coloredCount).toInt()
        val hsv = FloatArray(3)
        Color.RGBToHSV(avgR, avgG, avgB, hsv)
        val hue = hsv[0]
        return when {
            hue < 24f || hue >= 346f -> MarkColor.RED
            hue in 24f..68f -> MarkColor.YELLOW
            hue in 68f..162f -> MarkColor.GREEN
            hue in 162f..206f -> MarkColor.CYAN
            hue in 206f..258f -> MarkColor.BLUE
            hue in 258f..312f -> MarkColor.PURPLE
            else -> MarkColor.PINK
        }
    }

    fun readActiveWatchlistName(bitmap: Bitmap): String? {
        val w = bitmap.width
        val h = bitmap.height
        val tabCenterY = detectTabBarCenterY(bitmap)
        val halfBand = (h * 0.020f).toInt().coerceAtLeast(16)
        val bandTop = (tabCenterY - halfBand).coerceIn((h * 0.036f).toInt(), h - 16)
        val bandBottom = (tabCenterY + halfBand).coerceIn(bandTop + 10, (h * 0.130f).toInt())
        val bandMidTop = bandTop + (bandBottom - bandTop) / 5
        val bandMidBottom = bandBottom - (bandBottom - bandTop) / 5

        val startX = (w * 0.16f).toInt()
        val endX = (w * 0.98f).toInt()
        var bestLeft = -1
        var bestRight = -1
        var curLeft = -1

        for (x in startX until endX) {
            var pillHits = 0
            var samples = 0
            var y = bandMidTop
            while (y < bandMidBottom) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val isPillBg = maxC in 34..95 && (maxC - minC) <= 18
                val isWhiteText = minC >= 150
                if (isPillBg || isWhiteText) pillHits++
                samples++
                y += 3
            }
            val isPillCol = samples > 0 && pillHits.toFloat() / samples >= 0.55f
            if (isPillCol) {
                if (curLeft == -1) curLeft = x
            } else if (curLeft != -1) {
                val curWidth = x - curLeft
                if (curWidth > bestRight - bestLeft) {
                    bestLeft = curLeft
                    bestRight = x
                }
                curLeft = -1
            }
        }
        if (curLeft != -1 && (endX - curLeft) > (bestRight - bestLeft)) {
            bestLeft = curLeft
            bestRight = endX
        }

        if (bestLeft == -1 || bestRight - bestLeft < w * 0.05f) return null

        val padX = (w * 0.012f).toInt()
        val cropL = (bestLeft - padX).coerceAtLeast(0)
        val cropR = (bestRight + padX).coerceAtMost(w)
        val cropW = cropR - cropL
        val cropH = bandBottom - bandTop
        if (cropW <= 8 || cropH <= 8) return null

        val crop = Bitmap.createBitmap(bitmap, cropL, bandTop, cropW, cropH)
        val scaled = Bitmap.createScaledBitmap(crop, cropW * 2, cropH * 2, true)
        crop.recycle()

        return try {
            val result = Tasks.await(
                chineseRecognizer.process(InputImage.fromBitmap(scaled, 0)),
                3,
                TimeUnit.SECONDS
            )
            val text = result.text.replace("\n", "").replace(" ", "").trim()
            if (text.isNotEmpty()) text else null
        } catch (_: Exception) {
            null
        } finally {
            scaled.recycle()
        }
    }

    /**
     * 极速扫描当前自选表屏幕上的所有品种代码：
     * 1) 精准裁剪品种代码列 (10% ~ 44% 宽度)
     * 2) 缩放到 0.62x 后用 2ms 像素过滤抹除所有暗灰副标题(亮度<=130)和橙色 D 标，只留亮白主代码
     *    OCR 文字量直降 65%，单屏速度提升 2.5~3 倍
     */
    fun scanWatchlistSymbols(bitmap: Bitmap): List<WatchlistRow> {
        val w = bitmap.width
        val h = bitmap.height
        val cropLeft = (w * 0.095f).toInt()
        val tabCenterY = detectTabBarCenterY(bitmap)
        val cropTop = (tabCenterY + (h * 0.020f).toInt()).coerceIn((h * 0.078f).toInt(), (h * 0.125f).toInt())
        val cropRight = (w * 0.445f).toInt()
        val cropBottom = (h * 0.950f).toInt()
        val cropW = cropRight - cropLeft
        val cropH = cropBottom - cropTop
        if (cropW <= 20 || cropH <= 20) return emptyList()

        val scale = 0.55f
        val rawCrop = Bitmap.createBitmap(bitmap, cropLeft, cropTop, cropW, cropH)
        val smallCrop = Bitmap.createScaledBitmap(
            rawCrop,
            (cropW * scale).toInt().coerceAtLeast(20),
            (cropH * scale).toInt().coerceAtLeast(20),
            true
        )
        rawCrop.recycle()

        // 抹掉暗灰副标题（max<=131）与彩色 D 标，只保留纯净亮白代码（max>=148，低饱和）
        val ocrBmp = filterBrightWhiteOnly(smallCrop, minBrightness = 148)
        smallCrop.recycle()

        val rows = ArrayList<WatchlistRow>()

        try {
            val result = Tasks.await(
                latinRecognizer.process(InputImage.fromBitmap(ocrBmp, 0)),
                3,
                TimeUnit.SECONDS
            )

            val expectedLeftMin = (w * 0.095f).toInt()
            val expectedLeftMax = (w * 0.175f).toInt()

            for (block in result.textBlocks) {
                for (line in block.lines) {
                    val box = line.boundingBox ?: continue
                    val screenLeft = cropLeft + (box.left / scale).toInt()
                    val screenRight = cropLeft + (box.right / scale).toInt()
                    val screenTop = cropTop + (box.top / scale).toInt()
                    val screenBottom = cropTop + (box.bottom / scale).toInt()

                    if (screenLeft < expectedLeftMin || screenLeft > expectedLeftMax) continue
                    if (screenTop < cropTop || screenBottom > h * 0.944f) continue

                    val parsed = extractWatchlistSymbol(line.text) ?: continue
                    val centerX = ((screenLeft + min(screenRight, (w * 0.40f).toInt())) / 2)
                        .coerceIn((w * 0.13f).toInt(), (w * 0.38f).toInt())
                    val centerY = (screenTop + screenBottom) / 2
                    val flagColor = detectLeftEdgeFlagColor(bitmap, screenTop, screenBottom)

                    rows.add(
                        WatchlistRow(
                            symbol = parsed,
                            centerX = centerX,
                            centerY = centerY,
                            topY = screenTop,
                            bottomY = screenBottom,
                            hasAnyFlag = (flagColor != null),
                            existingFlagColor = flagColor
                        )
                    )
                }
            }
        } catch (e: Exception) {
            AppStore.log("自选表OCR异常：${e.message}")
        } finally {
            ocrBmp.recycle()
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || abs(r.centerY - deduped.last().centerY) > (h * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    /**
     * 检测该行最左边缘（X: 0 ~ 1.9% 屏幕宽度）是否存在任意颜色的已标记小旗
     */
    /**
     * 精准识别该行最左边缘（X: 0 ~ 1.9% 宽度）是否已有颜色小旗及具体颜色（全 7 色分类）
     */
    fun detectLeftEdgeFlagColor(bitmap: Bitmap, symbolTop: Int, symbolBottom: Int): MarkColor? {
        val w = bitmap.width
        val h = bitmap.height
        val maxX = (w * 0.019f).toInt().coerceAtLeast(8)
        val yStart = (symbolTop - (h * 0.005f).toInt()).coerceIn(0, h - 1)
        val yEnd = (symbolBottom + (h * 0.028f).toInt()).coerceIn(yStart + 1, h)

        var coloredCount = 0
        var totalSamples = 0
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var y = yStart
        while (y < yEnd) {
            var x = 0
            while (x < maxX) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                if (maxC >= 88 && (maxC - minC) >= 38) {
                    coloredCount++
                    sumR += r
                    sumG += g
                    sumB += b
                }
                totalSamples++
                x += 2
            }
            y += 2
        }
        if (totalSamples == 0 || coloredCount < 6 || coloredCount.toFloat() / totalSamples < 0.06f) {
            return null
        }

        val avgR = (sumR / coloredCount).toInt()
        val avgG = (sumG / coloredCount).toInt()
        val avgB = (sumB / coloredCount).toInt()
        val hsv = FloatArray(3)
        Color.RGBToHSV(avgR, avgG, avgB, hsv)
        val hue = hsv[0] // 0..360

        return when {
            hue < 24f || hue >= 346f -> MarkColor.RED
            hue in 24f..68f -> MarkColor.YELLOW
            hue in 68f..162f -> MarkColor.GREEN
            hue in 162f..206f -> MarkColor.CYAN
            hue in 206f..258f -> MarkColor.BLUE
            hue in 258f..312f -> MarkColor.PURPLE
            else -> MarkColor.PINK
        }
    }

    fun hasAnyLeftEdgeFlag(bitmap: Bitmap, symbolTop: Int, symbolBottom: Int): Boolean {
        return detectLeftEdgeFlagColor(bitmap, symbolTop, symbolBottom) != null
    }

    /**
     * 核心：扫描红->蓝->绿->黄四连色点并高精度推算全部 7 颗颜色圆点的中心坐标（耗时 < 5ms）
     */
    fun findColorMenu(bitmap: Bitmap): ColorMenuDots? {
        val w = bitmap.width
        val h = bitmap.height

        val minY = (h * 0.12f).toInt()
        val maxY = (h * 0.94f).toInt()
        val redSearchMinX = (w * 0.02f).toInt()
        val redSearchMaxX = (w * 0.48f).toInt()
        val minDotW = (w * 0.014f).toInt().coerceAtLeast(10)
        val maxDotW = (w * 0.075f).toInt().coerceAtLeast(40)
        val minSpacing = (w * 0.038f).toInt()
        val maxSpacing = (w * 0.115f).toInt()

        var y = minY
        while (y < maxY) {
            var x = redSearchMinX
            while (x < redSearchMaxX) {
                if (isMenuRed(bitmap.getPixel(x, y))) {
                    val runStart = x
                    while (x < redSearchMaxX && isMenuRed(bitmap.getPixel(x, y))) {
                        x++
                    }
                    val runW = x - runStart
                    if (runW in minDotW..maxDotW) {
                        val redCenterX = (runStart + x) / 2
                        val blueCenterX = findAdjacentBlueDot(
                            bitmap, y, redCenterX + minSpacing, min(w - 5, redCenterX + maxSpacing), minDotW, maxDotW
                        )
                        if (blueCenterX != -1) {
                            val spacing = blueCenterX - redCenterX
                            val midBg = bitmap.getPixel((redCenterX + blueCenterX) / 2, y)
                            val isDarkGap = Color.red(midBg) < 85 && Color.green(midBg) < 85 && Color.blue(midBg) < 95

                            val greenX = redCenterX + spacing * 2
                            val yellowX = redCenterX + spacing * 3
                            if (isDarkGap &&
                                yellowX + minDotW < w &&
                                hasColorPatch(bitmap, greenX, y, (spacing * 0.28f).toInt(), ::isMenuGreen) &&
                                hasColorPatch(bitmap, yellowX, y, (spacing * 0.28f).toInt(), ::isMenuYellow)
                            ) {
                                val refinedY = refineVerticalCenter(bitmap, redCenterX, y, ::isMenuRed)
                                val refinedRedX = refineHorizontalCenter(bitmap, redCenterX, refinedY, ::isMenuRed)
                                val refinedYellowX = refineHorizontalCenter(bitmap, yellowX, refinedY, ::isMenuYellow)
                                val exactStep = if (refinedYellowX > refinedRedX + minSpacing * 2) {
                                    (refinedYellowX - refinedRedX) / 3.0f
                                } else {
                                    (refineHorizontalCenter(bitmap, blueCenterX, refinedY, ::isMenuBlue) - refinedRedX).toFloat()
                                }
                                val dotXs = IntArray(7) { idx ->
                                    (refinedRedX + idx * exactStep).roundToInt().coerceIn(4, w - 4)
                                }
                                return ColorMenuDots(dotXs = dotXs, y = refinedY)
                            }
                        }
                    }
                } else {
                    x += 2
                }
            }
            y += 4
        }
        return null
    }

    fun computeListFingerprint(bitmap: Bitmap): IntArray {
        val w = bitmap.width
        val h = bitmap.height
        val cols = 5
        val rows = 14
        val fp = IntArray(cols * rows)
        var idx = 0
        for (r in 0 until rows) {
            val y = (h * (0.16f + 0.74f * r / (rows - 1))).toInt().coerceIn(0, h - 1)
            for (c in 0 until cols) {
                val x = (w * (0.06f + 0.36f * c / (cols - 1))).toInt().coerceIn(0, w - 1)
                val p = bitmap.getPixel(x, y)
                fp[idx++] = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
            }
        }
        return fp
    }

    fun isSameFrame(a: IntArray?, b: IntArray?): Boolean {
        if (a == null || b == null || a.size != b.size) return false
        var match = 0
        for (i in a.indices) {
            if (abs(a[i] - b[i]) <= 12) match++
        }
        return match.toFloat() / a.size >= 0.94f
    }

    private fun filterBrightWhiteOnly(src: Bitmap, minBrightness: Int): Bitmap {
        val w = src.width
        val h = src.height
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val maxC = max(r, max(g, b))
            val minC = min(r, min(g, b))
            if (maxC >= minBrightness && (maxC - minC) <= 42) {
                pixels[i] = Color.WHITE
            } else {
                pixels[i] = Color.BLACK
            }
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }

    fun extractWatchlistSymbol(rawLine: String): String? {
        val firstLine = rawLine.lineSequence().firstOrNull()?.trim() ?: return null
        var s = firstLine
        if (s.isEmpty()) return null
        if (s.any { it in 'a'..'z' }) return null
        s = s.replace(Regex("""[\s\-—·~]+D$"""), "").trim()
        s = s.replace(Regex("""[\s\-—·~]+$"""), "").trim()
        val token = s.split(Regex("""\s+""")).firstOrNull()?.trim()?.trimEnd('-', '—', '·', '~') ?: return null
        return normalizeTickerCandidate(token)
    }

    fun normalizeTickerCandidate(raw: String): String? {
        val cleaned = raw.trim()
            .replace(" ", "")
            .replace("…", "")
            .uppercase(Locale.US)

        if (cleaned.isEmpty() || cleaned.length > 20) return null
        if (cleaned.endsWith("...")) return null
        if (!cleaned.matches(Regex("""^[A-Z0-9][A-Z0-9._!:/_-]{0,21}$"""))) return null
        // 彻底拦截纯小数价格/指标数值（如 6.1439、20.78、103.722，保留含字母的 BRK.A / U.UN / RR. 及纯整数港股代码）
        if (cleaned.matches(Regex("""^\d+\.\d*$"""))) return null
        if (cleaned.matches(Regex("""^\d+:\d+$"""))) return null
        // 仅过滤带字母周期后缀如 1D / 1W / 4H / 15M，保留 1~3 位纯数字港股代码（如 1、5、16、700）
        if (cleaned.matches(Regex("""^\d{1,3}[MHWDYS]$"""))) return null
        if (cleaned in setOf("USD", "EUR", "CNY", "HKD", "JPY", "GBP", "AUD", "CAD")) return null
        return cleaned
    }

    private fun findAdjacentBlueDot(
        bitmap: Bitmap,
        y: Int,
        minX: Int,
        maxX: Int,
        minDotW: Int,
        maxDotW: Int
    ): Int {
        val yOffsets = intArrayOf(0, -4, 4)
        for (dy in yOffsets) {
            val sy = (y + dy).coerceIn(0, bitmap.height - 1)
            var x = minX.coerceAtLeast(0)
            while (x < maxX) {
                if (isMenuBlue(bitmap.getPixel(x, sy))) {
                    val start = x
                    while (x < maxX && isMenuBlue(bitmap.getPixel(x, sy))) {
                        x++
                    }
                    val runW = x - start
                    if (runW in minDotW..maxDotW) {
                        return (start + x) / 2
                    }
                } else {
                    x += 2
                }
            }
        }
        return -1
    }

    private fun hasColorPatch(
        bitmap: Bitmap,
        cx: Int,
        cy: Int,
        radius: Int,
        predicate: (Int) -> Boolean
    ): Boolean {
        val l = (cx - radius).coerceIn(0, bitmap.width - 1)
        val r = (cx + radius).coerceIn(l + 1, bitmap.width)
        val t = (cy - 8).coerceIn(0, bitmap.height - 1)
        val b = (cy + 8).coerceIn(t + 1, bitmap.height)
        var hits = 0
        var y = t
        while (y < b) {
            var x = l
            while (x < r) {
                if (predicate(bitmap.getPixel(x, y))) {
                    hits++
                    if (hits >= 6) return true
                }
                x += 2
            }
            y += 2
        }
        return false
    }

    private fun refineVerticalCenter(bitmap: Bitmap, x: Int, y: Int, predicate: (Int) -> Boolean): Int {
        val cx = x.coerceIn(0, bitmap.width - 1)
        var top = y
        var bottom = y
        while (top > 0 && predicate(bitmap.getPixel(cx, top - 1))) top--
        while (bottom < bitmap.height - 1 && predicate(bitmap.getPixel(cx, bottom + 1))) bottom++
        return (top + bottom) / 2
    }

    private fun refineHorizontalCenter(bitmap: Bitmap, x: Int, y: Int, predicate: (Int) -> Boolean): Int {
        val cy = y.coerceIn(0, bitmap.height - 1)
        var left = x
        var right = x
        while (left > 0 && predicate(bitmap.getPixel(left - 1, cy))) left--
        while (right < bitmap.width - 1 && predicate(bitmap.getPixel(right + 1, cy))) right++
        return (left + right) / 2
    }

    private fun isMenuRed(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return r >= 175 && g in 25..145 && b in 35..150 && (r - g) >= 75 && (r - b) >= 65
    }

    private fun isMenuBlue(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return b >= 120 && r <= 120 && g in 35..185 && (b - r) >= 60
    }

    private fun isMenuGreen(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return g >= 130 && r in 40..195 && b in 40..195 && (g - r) >= 16 && (g - b) >= 15
    }

    private fun isMenuYellow(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val b = Color.blue(p)
        return r >= 165 && g >= 125 && b <= 130 && (r - b) >= 70 && (g - b) >= 45
    }
}
