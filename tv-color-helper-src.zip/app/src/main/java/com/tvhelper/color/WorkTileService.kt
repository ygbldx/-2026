package com.tvhelper.color

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * 下拉状态栏（控制中心）快捷开关：
 * 仅切换 APP 层面服务开关，严格与 APP 顶部大开关同步，绝不关闭系统无障碍服务
 */
class WorkTileService : TileService() {

    companion object {
        fun requestTileSync(context: Context) {
            try {
                requestListeningState(
                    context.applicationContext,
                    ComponentName(context.applicationContext, WorkTileService::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }

    override fun onTileAdded() {
        super.onTileAdded()
        AppStore.init(this)
        updateTileAppearance()
    }

    override fun onStartListening() {
        super.onStartListening()
        AppStore.init(this)
        updateTileAppearance()
    }

    override fun onClick() {
        super.onClick()
        AppStore.init(this)
        val nextEnabled = !AppStore.isWorkEnabled()
        AppStore.setWorkEnabled(this, nextEnabled, source = "状态栏快捷开关")
        updateTileAppearance()
    }

    private fun updateTileAppearance() {
        val tile = qsTile ?: return
        val enabled = AppStore.isWorkEnabled()
        tile.label = getString(R.string.tile_label)
        tile.subtitle = if (enabled) "已开启" else "已关闭"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
