package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * 职责单一的手势调度与“用户手动操作优先”礼让控制模块
 */
class GestureDriver(
    private val service: AccessibilityService,
    private val screenSizeProvider: () -> Pair<Int, Int>
) {
    private val ownActionDepth = AtomicInteger(0)
    @Volatile
    private var lastOwnActionEndMs = 0L
    @Volatile
    private var userManualYieldUntilMs = 0L
    val userIntervenedFlag = AtomicBoolean(false)

    fun resetYieldOnBatchStart() {
        userIntervenedFlag.set(false)
        userManualYieldUntilMs = 0L
        lastOwnActionEndMs = SystemClock.uptimeMillis()
    }

    fun markOwnActionJustFinished() {
        lastOwnActionEndMs = SystemClock.uptimeMillis()
    }

    fun triggerTouchYield(ms: Long = 600L) {
        userManualYieldUntilMs = SystemClock.uptimeMillis() + ms
        userIntervenedFlag.set(true)
    }

    fun onExternalTvEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED
        ) return

        val now = SystemClock.uptimeMillis()
        val sinceOwn = now - lastOwnActionEndMs
        val isBottomWatchlistClick = event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            ((event.text?.joinToString("") ?: "") + (event.contentDescription?.toString() ?: "")).let {
                it.contains("自选表") || it.contains("Watchlist", ignoreCase = true)
            }
        val graceMs = if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) 1600L else 600L
        if (!isBottomWatchlistClick && ownActionDepth.get() == 0 && sinceOwn > graceMs) {
            val yieldMs = if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) 520L else 420L
            val wasYielding = now < userManualYieldUntilMs
            userManualYieldUntilMs = now + yieldMs
            userIntervenedFlag.set(true)
            if (!wasYielding) {
                AppStore.log("检测到你正在手动操作，短暂停礼让")
            }
        }
    }

    fun yieldForUserIfNeeded(shouldAbort: () -> Boolean): Boolean {
        var yielded = userIntervenedFlag.getAndSet(false)
        while (!shouldAbort()) {
            val remain = userManualYieldUntilMs - SystemClock.uptimeMillis()
            if (remain <= 0L) break
            yielded = true
            sleepSafe(minOf(remain, 100L))
        }
        if (userIntervenedFlag.getAndSet(false)) {
            yielded = true
        }
        return yielded
    }

    fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 5) {
            if (cur.isClickable) {
                return performNativeAction(cur, AccessibilityNodeInfo.ACTION_CLICK)
            }
            cur = cur.parent
            depth++
        }
        return false
    }

    fun performNativeAction(node: AccessibilityNodeInfo, action: Int): Boolean {
        ownActionDepth.incrementAndGet()
        return try {
            node.performAction(action)
        } catch (_: Exception) {
            false
        } finally {
            lastOwnActionEndMs = SystemClock.uptimeMillis()
            ownActionDepth.decrementAndGet()
        }
    }

    fun dispatchTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 24L)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    fun dispatchLongPress(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    fun performControlledScroll(scrollDown: Boolean, stronger: Boolean = false): Boolean {
        val (sw, sh) = screenSizeProvider()
        val x = sw * 0.46f
        val y1 = if (scrollDown) (if (stronger) sh * 0.81f else sh * 0.78f) else (if (stronger) sh * 0.19f else sh * 0.22f)
        val y2 = if (scrollDown) (if (stronger) sh * 0.19f else sh * 0.22f) else (if (stronger) sh * 0.81f else sh * 0.78f)
        val dragMs = AppStore.getScrollDurationMs()

        val dragPath = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, dragMs, true)
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)

        ownActionDepth.incrementAndGet()
        try {
            val accepted = service.dispatchGesture(
                GestureDescription.Builder().addStroke(stroke1).build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        val holdPath = Path().apply {
                            moveTo(x, y2)
                            lineTo(x, y2)
                        }
                        val stroke2 = stroke1.continueStroke(holdPath, 0L, 32L, false)
                        service.dispatchGesture(
                            GestureDescription.Builder().addStroke(stroke2).build(),
                            object : AccessibilityService.GestureResultCallback() {
                                override fun onCompleted(g: GestureDescription?) {
                                    ok.set(true)
                                    latch.countDown()
                                }
                                override fun onCancelled(g: GestureDescription?) {
                                    ok.set(false)
                                    triggerTouchYield(600L)
                                    latch.countDown()
                                }
                            },
                            null
                        )
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        ok.set(false)
                        triggerTouchYield(600L)
                        latch.countDown()
                    }
                },
                null
            )
            if (accepted) {
                latch.await(2, TimeUnit.SECONDS)
            }
        } finally {
            lastOwnActionEndMs = SystemClock.uptimeMillis()
            ownActionDepth.decrementAndGet()
        }
        return ok.get()
    }

    fun performFastScroll(scrollDown: Boolean): Boolean {
        val (sw, sh) = screenSizeProvider()
        val x = sw * 0.44f
        val y1 = if (scrollDown) sh * 0.83f else sh * 0.19f
        val y2 = if (scrollDown) sh * 0.19f else sh * 0.83f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 95L)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    fun swipeTabBar(tabY: Int, swipeFingerRightToLeft: Boolean, distanceFrac: Float): Boolean {
        val (sw, sh) = screenSizeProvider()
        val y = tabY.toFloat().coerceIn(sh * 0.045f, sh * 0.125f)
        val span = distanceFrac.coerceIn(0.24f, 0.70f)
        val x1: Float
        val x2: Float
        if (swipeFingerRightToLeft) {
            x1 = sw * 0.86f
            x2 = (sw * (0.86f - span)).coerceAtLeast(sw * 0.15f)
        } else {
            x1 = sw * 0.18f
            x2 = (sw * (0.18f + span)).coerceAtMost(sw * 0.88f)
        }

        val dragPath = Path().apply {
            moveTo(x1, y)
            lineTo(x2, y)
        }
        val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, 140L, true)
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)

        ownActionDepth.incrementAndGet()
        try {
            val accepted = service.dispatchGesture(
                GestureDescription.Builder().addStroke(stroke1).build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        val holdPath = Path().apply {
                            moveTo(x2, y)
                            lineTo(x2, y)
                        }
                        val stroke2 = stroke1.continueStroke(holdPath, 0L, 42L, false)
                        service.dispatchGesture(
                            GestureDescription.Builder().addStroke(stroke2).build(),
                            object : AccessibilityService.GestureResultCallback() {
                                override fun onCompleted(g: GestureDescription?) {
                                    ok.set(true)
                                    latch.countDown()
                                }
                                override fun onCancelled(g: GestureDescription?) {
                                    ok.set(false)
                                    triggerTouchYield(600L)
                                    latch.countDown()
                                }
                            },
                            null
                        )
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        ok.set(false)
                        triggerTouchYield(600L)
                        latch.countDown()
                    }
                },
                null
            )
            if (accepted) {
                latch.await(2, TimeUnit.SECONDS)
            }
        } finally {
            lastOwnActionEndMs = SystemClock.uptimeMillis()
            ownActionDepth.decrementAndGet()
        }
        if (ok.get()) sleepSafe(40L)
        return ok.get()
    }

    fun dispatchGestureSync(gesture: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        ownActionDepth.incrementAndGet()
        try {
            val accepted = service.dispatchGesture(
                gesture,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        ok.set(true)
                        latch.countDown()
                    }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        ok.set(false)
                        latch.countDown()
                    }
                },
                null
            )
            if (!accepted) return false
            latch.await(2, TimeUnit.SECONDS)
        } finally {
            lastOwnActionEndMs = SystemClock.uptimeMillis()
            ownActionDepth.decrementAndGet()
        }
        return ok.get()
    }

    fun sleepSafe(ms: Long) {
        if (ms <= 0L) return
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }
}
