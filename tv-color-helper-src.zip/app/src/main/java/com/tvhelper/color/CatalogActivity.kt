package com.tvhelper.color

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

private sealed class FlatCatalogRow {
    data class WatchlistHeader(
        val wl: CatalogWatchlist,
        val wlIdx: Int,
        val instCount: Int,
        val collapsed: Boolean
    ) : FlatCatalogRow()

    data class CategoryRow(
        val cat: CatalogNode.Category,
        val parentList: MutableList<CatalogNode>,
        val idxInParent: Int,
        val depth: Int,
        val collapsed: Boolean
    ) : FlatCatalogRow()

    data class InstrumentRow(
        val inst: CatalogNode.Instrument,
        val parentList: MutableList<CatalogNode>,
        val idxInParent: Int,
        val depth: Int
    ) : FlatCatalogRow()
}

/**
 * 全新 RecyclerView 虚拟复用架构：
 * 无论有 500 还是 50000 个品种，屏幕内只常驻 ~16 个 ViewHolder，
 * 秒进页面、120fps 顺滑滚动、增删改排序零卡顿！
 */
class CatalogActivity : AppCompatActivity() {

    private lateinit var summaryText: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: CatalogAdapter

    // 默认进入时折叠全部 12 个列表（点列表名瞬间展开），进入耗时 < 15ms
    private val expandedIds = HashSet<String>()
    private var searchKeyword = ""
    private val uiHandler = Handler(Looper.getMainLooper())
    private val debouncedSearchRunnable = Runnable { rebuildFlatList() }

    private val catalogListener: () -> Unit = {
        runOnUiThread { rebuildFlatList() }
    }

    private val exportBackupLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(CatalogRepository.exportAllToText().toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(this, "已导出《品种大全》备份文件", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "导出失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private val importBackupLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val content = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (content.isBlank()) {
                Toast.makeText(this, "所选文件内容为空", Toast.LENGTH_SHORT).show()
                return@registerForActivityResult
            }
            val (wlCnt, instCnt) = CatalogRepository.replaceWithRawText(content)
            expandedIds.clear()
            Toast.makeText(this, "文件导入完成：$wlCnt 列表 / $instCnt 品种", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "导入失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildRootLayout())
        rebuildFlatList()
    }

    override fun onResume() {
        super.onResume()
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(true)
        CatalogRepository.addListener(catalogListener)
        rebuildFlatList()
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(debouncedSearchRunnable)
        CatalogRepository.removeListener(catalogListener)
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(false)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun buildRootLayout(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(10))
            setBackgroundColor(Color.parseColor("#161B22"))
        }
        topBar.addView(makeSmallBtn("← 返回", "#30363D") { finish() })
        topBar.addView(TextView(this).apply {
            text = "《品种大全》管理"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            paint.isFakeBoldText = true
            setPadding(dp(10), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        topBar.addView(makeSmallBtn("+ 新增列表", "#1F6FEB") {
            showAddWatchlistDialog()
        })
        root.addView(topBar)

        val copyAllBtn = Button(this).apply {
            text = "一键复制全部《品种大全》内容"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(42)
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
                topMargin = dp(8)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#238636"))
            }
            setOnClickListener {
                copyTextToClipboard(
                    label = "品种大全全部内容",
                    content = CatalogRepository.exportAllToText(),
                    toastMsg = "已复制全部《品种大全》（${CatalogRepository.getWatchlists().size}列表 / ${CatalogRepository.totalInstrumentCount()}品种）"
                )
            }
        }
        root.addView(copyAllBtn)

        val toolBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(6), dp(12), dp(2))
        }
        toolBar.addView(makeBarBtn("批量粘贴导入") { showBatchImportDialog() })
        toolBar.addView(makeBarBtn("全部折叠") {
            expandedIds.clear()
            rebuildFlatList()
        })
        toolBar.addView(makeBarBtn("全部展开") {
            expandedIds.clear()
            fun collectAll(nodes: List<CatalogNode>) {
                for (n in nodes) {
                    if (n is CatalogNode.Category) {
                        expandedIds.add(n.id)
                        collectAll(n.children)
                    }
                }
            }
            for (wl in CatalogRepository.getWatchlists()) {
                expandedIds.add(wl.id)
                collectAll(wl.children)
            }
            rebuildFlatList()
        })
        toolBar.addView(makeBarBtn("重置默认") {
            AlertDialog.Builder(this)
                .setTitle("恢复默认《品种大全》")
                .setMessage("确定要覆盖当前修改并恢复内置默认《品种大全》吗？")
                .setPositiveButton("恢复") { _, _ ->
                    val (wCount, iCount) = CatalogRepository.resetToDefault()
                    Toast.makeText(this, "已恢复：$wCount 个列表 / $iCount 个品种", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("取消", null)
                .show()
        })
        root.addView(toolBar)

        val backupBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), 0, dp(12), dp(2))
        }
        backupBar.addView(makeBarBtn("导出本地备份文件") {
            exportBackupLauncher.launch("品种大全备份.txt")
        })
        backupBar.addView(makeBarBtn("从备份文件导入") {
            importBackupLauncher.launch(arrayOf("text/plain", "text/*", "*/*"))
        })
        root.addView(backupBar)

        val searchBox = EditText(this).apply {
            hint = "搜索品种代码 / 中文名 / 数据源 / 类别..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6E7681"))
            setSingleLine(true)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
                topMargin = dp(4)
                bottomMargin = dp(4)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    searchKeyword = s?.toString()?.trim().orEmpty()
                    uiHandler.removeCallbacks(debouncedSearchRunnable)
                    uiHandler.postDelayed(debouncedSearchRunnable, 100L)
                }
            })
        }
        root.addView(searchBox)

        summaryText = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(14), dp(2), dp(14), dp(6))
        }
        root.addView(summaryText)

        adapter = CatalogAdapter()
        recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@CatalogActivity)
            this.adapter = this@CatalogActivity.adapter
            setHasFixedSize(false)
            itemAnimator = null
            setPadding(dp(10), 0, dp(10), dp(32))
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        root.addView(recyclerView)

        return root
    }

    private fun rebuildFlatList() {
        val wls = CatalogRepository.getWatchlists()
        val totalInsts = CatalogRepository.totalInstrumentCount()
        summaryText.text = "共 ${wls.size} 个列表 / $totalInsts 个品种｜点列表展开，点任意行可编辑排序"

        val kw = searchKeyword.lowercase(Locale.US)
        val searching = kw.isNotEmpty()
        val flat = ArrayList<FlatCatalogRow>(128)

        fun appendNodes(nodes: MutableList<CatalogNode>, depth: Int) {
            for ((idx, node) in nodes.withIndex()) {
                when (node) {
                    is CatalogNode.Category -> {
                        if (searching && !nodeMatchesSearch(node, kw)) continue
                        // 细分类别默认随父列表展开（除非用户手动折叠），搜索时全展开
                        val catCollapsed = !searching && ("CAT_CLOSED_${node.id}" in expandedIds)
                        flat.add(FlatCatalogRow.CategoryRow(node, nodes, idx, depth, catCollapsed))
                        if (!catCollapsed) {
                            appendNodes(node.children, depth + 1)
                        }
                    }
                    is CatalogNode.Instrument -> {
                        if (searching && !nodeMatchesSearch(node, kw)) continue
                        flat.add(FlatCatalogRow.InstrumentRow(node, nodes, idx, depth))
                    }
                }
            }
        }

        for ((wlIdx, wl) in wls.withIndex()) {
            if (searching && !watchlistMatchesSearch(wl, kw)) continue
            val collapsed = !searching && (wl.id !in expandedIds)
            val count = wl.flattenInstruments().size
            flat.add(FlatCatalogRow.WatchlistHeader(wl, wlIdx, count, collapsed))
            if (!collapsed) {
                appendNodes(wl.children, depth = 0)
            }
        }

        adapter.submitRows(flat)
    }

    private fun watchlistMatchesSearch(wl: CatalogWatchlist, kw: String): Boolean {
        if (wl.name.lowercase(Locale.US).contains(kw)) return true
        return wl.children.any { nodeMatchesSearch(it, kw) }
    }

    private fun nodeMatchesSearch(node: CatalogNode, kw: String): Boolean {
        return when (node) {
            is CatalogNode.Category -> node.name.lowercase(Locale.US).contains(kw) ||
                node.children.any { nodeMatchesSearch(it, kw) }
            is CatalogNode.Instrument -> node.symbol.lowercase(Locale.US).contains(kw) ||
                node.cnName.lowercase(Locale.US).contains(kw) ||
                node.source.lowercase(Locale.US).contains(kw)
        }
    }

    // ==================== 高性能 RecyclerView Adapter（仅常驻 3 种复用 ViewHolder） ====================

    private inner class CatalogAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        private val TYPE_WL = 0
        private val TYPE_CAT = 1
        private val TYPE_INST = 2

        private var rows: List<FlatCatalogRow> = emptyList()

        fun submitRows(newRows: List<FlatCatalogRow>) {
            rows = newRows
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = rows.size

        override fun getItemViewType(position: Int): Int = when (rows[position]) {
            is FlatCatalogRow.WatchlistHeader -> TYPE_WL
            is FlatCatalogRow.CategoryRow -> TYPE_CAT
            is FlatCatalogRow.InstrumentRow -> TYPE_INST
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return when (viewType) {
                TYPE_WL -> WatchlistVH(createWatchlistView())
                TYPE_CAT -> CategoryVH(createCategoryView())
                else -> InstrumentVH(createInstrumentView())
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val item = rows[position]) {
                is FlatCatalogRow.WatchlistHeader -> (holder as WatchlistVH).bind(item)
                is FlatCatalogRow.CategoryRow -> (holder as CategoryVH).bind(item)
                is FlatCatalogRow.InstrumentRow -> (holder as InstrumentVH).bind(item)
            }
        }
    }

    private fun createWatchlistView(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(8), dp(10))
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
            background = GradientDrawable().apply {
                cornerRadius = dp(9).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
        }
        val titleTv = TextView(this).apply {
            tag = "title"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val copyBtn = makeCopyChipBtn("复制") {}.apply { tag = "copy" }
        val upBtn = makeTinyBtn("↑") {}.apply { tag = "up" }
        val downBtn = makeTinyBtn("↓") {}.apply { tag = "down" }
        val manageBtn = makeTinyBtn("管理") {}.apply { tag = "manage" }
        row.addView(titleTv)
        row.addView(copyBtn)
        row.addView(upBtn)
        row.addView(downBtn)
        row.addView(manageBtn)
        return row
    }

    private inner class WatchlistVH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val titleTv = root.findViewWithTag<TextView>("title")
        val copyBtn = root.findViewWithTag<TextView>("copy")
        val upBtn = root.findViewWithTag<TextView>("up")
        val downBtn = root.findViewWithTag<TextView>("down")
        val manageBtn = root.findViewWithTag<TextView>("manage")

        fun bind(item: FlatCatalogRow.WatchlistHeader) {
            val arrow = if (item.collapsed) "▶" else "▼"
            titleTv.text = "$arrow  ${item.wl.name}  (${item.instCount})"
            titleTv.setOnClickListener {
                if (item.wl.id in expandedIds) expandedIds.remove(item.wl.id) else expandedIds.add(item.wl.id)
                rebuildFlatList()
            }
            copyBtn.setOnClickListener {
                copyTextToClipboard(
                    label = item.wl.name,
                    content = CatalogRepository.exportWatchlistToText(item.wl),
                    toastMsg = "已复制列表「${item.wl.name}」全部内容（${item.instCount}个品种）"
                )
            }
            upBtn.setOnClickListener { CatalogRepository.moveWatchlist(item.wlIdx, -1) }
            downBtn.setOnClickListener { CatalogRepository.moveWatchlist(item.wlIdx, 1) }
            manageBtn.setOnClickListener { showWatchlistActionMenu(item.wl, item.wlIdx) }
        }
    }

    private fun createCategoryView(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(6), dp(7))
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4) }
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#21262D"))
            }
        }
        val titleTv = TextView(this).apply {
            tag = "title"
            setTextColor(Color.parseColor("#79C0FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val upBtn = makeTinyBtn("↑") {}.apply { tag = "up" }
        val downBtn = makeTinyBtn("↓") {}.apply { tag = "down" }
        val manageBtn = makeTinyBtn("管理") {}.apply { tag = "manage" }
        row.addView(titleTv)
        row.addView(upBtn)
        row.addView(downBtn)
        row.addView(manageBtn)
        return row
    }

    private inner class CategoryVH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val titleTv = root.findViewWithTag<TextView>("title")
        val upBtn = root.findViewWithTag<TextView>("up")
        val downBtn = root.findViewWithTag<TextView>("down")
        val manageBtn = root.findViewWithTag<TextView>("manage")

        fun bind(item: FlatCatalogRow.CategoryRow) {
            val lp = root.layoutParams as RecyclerView.LayoutParams
            lp.marginStart = dp(8 + item.depth * 14)
            root.layoutParams = lp

            val arrow = if (item.collapsed) "▸" else "▾"
            titleTv.text = "$arrow ${item.cat.name}"
            titleTv.setOnClickListener {
                val key = "CAT_CLOSED_${item.cat.id}"
                if (key in expandedIds) expandedIds.remove(key) else expandedIds.add(key)
                rebuildFlatList()
            }
            upBtn.setOnClickListener { CatalogRepository.moveNode(item.parentList, item.idxInParent, -1) }
            downBtn.setOnClickListener { CatalogRepository.moveNode(item.parentList, item.idxInParent, 1) }
            manageBtn.setOnClickListener { showCategoryActionMenu(item.cat, item.parentList, item.idxInParent) }
        }
    }

    private fun createInstrumentView(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(6), dp(6))
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(1) }
            setBackgroundColor(Color.parseColor("#11161E"))
        }
        val titleTv = TextView(this).apply {
            tag = "title"
            setTextColor(Color.parseColor("#E6EDF3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val upBtn = makeTinyBtn("↑") {}.apply { tag = "up" }
        val downBtn = makeTinyBtn("↓") {}.apply { tag = "down" }
        val editBtn = makeTinyBtn("改") {}.apply { tag = "edit" }
        row.addView(titleTv)
        row.addView(upBtn)
        row.addView(downBtn)
        row.addView(editBtn)
        return row
    }

    private inner class InstrumentVH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val titleTv = root.findViewWithTag<TextView>("title")
        val upBtn = root.findViewWithTag<TextView>("up")
        val downBtn = root.findViewWithTag<TextView>("down")
        val editBtn = root.findViewWithTag<TextView>("edit")

        fun bind(item: FlatCatalogRow.InstrumentRow) {
            val lp = root.layoutParams as RecyclerView.LayoutParams
            lp.marginStart = dp(12 + item.depth * 14)
            root.layoutParams = lp

            val inst = item.inst
            titleTv.text = buildString {
                append(inst.symbol)
                if (inst.cnName.isNotBlank()) append("  ").append(inst.cnName)
                if (inst.source.isNotBlank()) append("  [").append(inst.source).append("]")
            }
            titleTv.setOnClickListener { showInstrumentActionMenu(inst, item.parentList, item.idxInParent) }
            upBtn.setOnClickListener { CatalogRepository.moveNode(item.parentList, item.idxInParent, -1) }
            downBtn.setOnClickListener { CatalogRepository.moveNode(item.parentList, item.idxInParent, 1) }
            editBtn.setOnClickListener { showInstrumentActionMenu(inst, item.parentList, item.idxInParent) }
        }
    }

    // ==================== 各种增删改查移动弹窗 ====================

    private fun showAddWatchlistDialog() {
        val input = makeDialogInput("列表名称（如 -7新列表）", "")
        AlertDialog.Builder(this)
            .setTitle("新增列表")
            .setView(wrapDialogView(input))
            .setPositiveButton("添加") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val wl = CatalogRepository.addWatchlist(name)
                    expandedIds.add(wl.id)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showWatchlistActionMenu(wl: CatalogWatchlist, wlIdx: Int) {
        val actions = arrayOf(
            "复制此列表全部内容",
            "修改列表名称",
            "+ 在此列表下新增细分类别",
            "+ 在此列表下新增品种",
            "上移列表顺序",
            "下移列表顺序",
            "删除此列表"
        )
        AlertDialog.Builder(this)
            .setTitle("列表：${wl.name}")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> copyTextToClipboard(
                        label = wl.name,
                        content = CatalogRepository.exportWatchlistToText(wl),
                        toastMsg = "已复制列表「${wl.name}」全部内容（${wl.flattenInstruments().size}个品种）"
                    )
                    1 -> showRenameDialog("修改列表名称", wl.name) { newName ->
                        wl.name = newName
                        CatalogRepository.save()
                    }
                    2 -> {
                        expandedIds.add(wl.id)
                        showAddCategoryDialog("在[${wl.name}]下新增细分类别", wl.children)
                    }
                    3 -> {
                        expandedIds.add(wl.id)
                        showEditInstrumentDialog("在[${wl.name}]下新增品种", null, wl.children)
                    }
                    4 -> CatalogRepository.moveWatchlist(wlIdx, -1)
                    5 -> CatalogRepository.moveWatchlist(wlIdx, 1)
                    6 -> confirmDelete("删除列表[${wl.name}]（含其下全部类别与品种）？") {
                        CatalogRepository.removeWatchlist(wlIdx)
                    }
                }
            }
            .show()
    }

    private fun showCategoryActionMenu(
        cat: CatalogNode.Category,
        parentList: MutableList<CatalogNode>,
        idx: Int
    ) {
        val actions = arrayOf(
            "修改细分类别名称",
            "+ 新增下级再细分类别",
            "+ 在此类别下新增品种",
            "上移顺序",
            "下移顺序",
            "移动到其它列表/类别",
            "删除此细分类别"
        )
        AlertDialog.Builder(this)
            .setTitle("类别：${cat.name}")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> showRenameDialog("修改细分类别名称", cat.name) { newName ->
                        cat.name = newName
                        CatalogRepository.save()
                    }
                    1 -> showAddCategoryDialog("在[${cat.name}]下新增再细分类别", cat.children)
                    2 -> showEditInstrumentDialog("在[${cat.name}]下新增品种", null, cat.children)
                    3 -> CatalogRepository.moveNode(parentList, idx, -1)
                    4 -> CatalogRepository.moveNode(parentList, idx, 1)
                    5 -> showMoveNodeDialog(cat, parentList, idx)
                    6 -> confirmDelete("删除细分类别[${cat.name}]（含下级全部内容）？") {
                        CatalogRepository.removeNode(parentList, idx)
                    }
                }
            }
            .show()
    }

    private fun showInstrumentActionMenu(
        inst: CatalogNode.Instrument,
        parentList: MutableList<CatalogNode>,
        idx: Int
    ) {
        val actions = arrayOf(
            "编辑品种（名称 / 中文名 / 数据源）",
            "上移顺序",
            "下移顺序",
            "移动到其它列表/类别",
            "删除此品种"
        )
        AlertDialog.Builder(this)
            .setTitle("品种：${inst.symbol}")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> showEditInstrumentDialog("编辑品种", inst, parentList)
                    1 -> CatalogRepository.moveNode(parentList, idx, -1)
                    2 -> CatalogRepository.moveNode(parentList, idx, 1)
                    3 -> showMoveNodeDialog(inst, parentList, idx)
                    4 -> confirmDelete("删除品种 ${inst.symbol}？") {
                        CatalogRepository.removeNode(parentList, idx)
                    }
                }
            }
            .show()
    }

    private fun showRenameDialog(title: String, oldVal: String, onSave: (String) -> Unit) {
        val input = makeDialogInput("请输入名称", oldVal)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrapDialogView(input))
            .setPositiveButton("保存") { _, _ ->
                val v = input.text.toString().trim()
                if (v.isNotEmpty()) onSave(v)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showAddCategoryDialog(title: String, targetList: MutableList<CatalogNode>) {
        val input = makeDialogInput("细分类别名称", "")
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrapDialogView(input))
            .setPositiveButton("添加") { _, _ ->
                val v = input.text.toString().trim()
                if (v.isNotEmpty()) {
                    targetList.add(CatalogNode.Category(name = v))
                    CatalogRepository.save()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showEditInstrumentDialog(
        title: String,
        existing: CatalogNode.Instrument?,
        targetList: MutableList<CatalogNode>
    ) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(6))
        }
        val symInput = makeDialogInput("品种代码（如 BTCUSD / 8035）", existing?.symbol.orEmpty())
        val cnInput = makeDialogInput("品种中文名（可留空）", existing?.cnName.orEmpty())
        val srcInput = makeDialogInput("品种数据源（如 IG，可留空）", existing?.source.orEmpty())

        box.addView(makeDialogLabel("品种名称（代码）："))
        box.addView(symInput)
        box.addView(makeDialogLabel("品种中文名："))
        box.addView(cnInput)
        box.addView(makeDialogLabel("品种数据源："))
        box.addView(srcInput)

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("保存") { _, _ ->
                val sym = symInput.text.toString().trim().uppercase(Locale.US)
                val cn = cnInput.text.toString().trim()
                val src = srcInput.text.toString().trim()
                if (sym.isEmpty()) {
                    Toast.makeText(this, "品种名称不能为空", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (existing != null) {
                    existing.symbol = sym
                    existing.cnName = cn
                    existing.source = src
                } else {
                    targetList.add(CatalogNode.Instrument(symbol = sym, cnName = cn, source = src))
                }
                CatalogRepository.save()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showMoveNodeDialog(
        node: CatalogNode,
        sourceList: MutableList<CatalogNode>,
        sourceIdx: Int
    ) {
        val destinations = ArrayList<Pair<String, MutableList<CatalogNode>>>()
        fun collectCats(prefix: String, nodes: List<CatalogNode>) {
            for (n in nodes) {
                if (n is CatalogNode.Category && n.id != node.id) {
                    val label = "$prefix / ${n.name}"
                    destinations.add(label to n.children)
                    collectCats(label, n.children)
                }
            }
        }
        for (wl in CatalogRepository.getWatchlists()) {
            destinations.add("[列表] ${wl.name}" to wl.children)
            collectCats("[列表] ${wl.name}", wl.children)
        }

        val labels = destinations.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("选择移动目标位置")
            .setItems(labels) { _, which ->
                val destList = destinations[which].second
                if (destList !== sourceList) {
                    val removed = sourceList.removeAt(sourceIdx)
                    destList.add(removed)
                    CatalogRepository.save()
                    Toast.makeText(this, "已移动到：${labels[which]}", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showBatchImportDialog() {
        val input = EditText(this).apply {
            hint = "粘贴《品种大全》文本（支持 (●—●)列表名、细分类别、品种名▰中文名、品种名——中文名—数据源）"
            minLines = 8
            maxLines = 16
            gravity = Gravity.TOP or Gravity.START
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        AlertDialog.Builder(this)
            .setTitle("批量粘贴导入《品种大全》")
            .setView(wrapDialogView(input))
            .setPositiveButton("覆盖导入") { _, _ ->
                val txt = input.text.toString()
                if (txt.isBlank()) return@setPositiveButton
                val (wlCnt, instCnt) = CatalogRepository.replaceWithRawText(txt)
                expandedIds.clear()
                Toast.makeText(this, "导入完成：$wlCnt 个列表 / $instCnt 个品种", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmDelete(msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("确认删除")
            .setMessage(msg)
            .setPositiveButton("删除") { _, _ -> onYes() }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun copyTextToClipboard(label: String, content: String, toastMsg: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, content))
        Toast.makeText(this, toastMsg, Toast.LENGTH_SHORT).show()
    }

    private fun makeDialogLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        setPadding(0, dp(6), 0, dp(2))
    }

    private fun makeDialogInput(hint: String, initVal: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(initVal)
        setSingleLine(true)
    }

    private fun wrapDialogView(v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(10), dp(18), dp(6))
        addView(v)
    }

    private fun makeSmallBtn(label: String, bgHex: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        isAllCaps = false
        setPadding(dp(10), dp(4), dp(10), dp(4))
        minHeight = 0
        minimumHeight = dp(34)
        minWidth = 0
        minimumWidth = 0
        background = GradientDrawable().apply {
            cornerRadius = dp(6).toFloat()
            setColor(Color.parseColor(bgHex))
        }
        setOnClickListener { onClick() }
    }

    private fun makeBarBtn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.parseColor("#58A6FF"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(6), dp(6), dp(6))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        setOnClickListener { onClick() }
    }

    private fun makeCopyChipBtn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.parseColor("#58A6FF"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        paint.isFakeBoldText = true
        setPadding(dp(8), dp(3), dp(8), dp(3))
        background = GradientDrawable().apply {
            cornerRadius = dp(5).toFloat()
            setColor(Color.parseColor("#21262D"))
            setStroke(dp(1), Color.parseColor("#388BFD"))
        }
        setOnClickListener { onClick() }
    }

    private fun makeTinyBtn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.parseColor("#8B949E"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        setPadding(dp(7), dp(4), dp(7), dp(4))
        setOnClickListener { onClick() }
    }
}
