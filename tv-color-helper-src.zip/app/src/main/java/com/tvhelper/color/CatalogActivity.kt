package com.tvhelper.color

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class CatalogActivity : AppCompatActivity() {

    private lateinit var summaryText: TextView
    private lateinit var treeContainer: LinearLayout
    private val collapsedIds = HashSet<String>()
    private var searchKeyword = ""

    private val catalogListener: () -> Unit = {
        runOnUiThread { renderTree() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildRootLayout())
        renderTree()
    }

    override fun onResume() {
        super.onResume()
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(true)
        CatalogRepository.addListener(catalogListener)
        renderTree()
    }

    override fun onPause() {
        super.onPause()
        CatalogRepository.removeListener(catalogListener)
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(false)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun buildRootLayout(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        // 顶部标题栏
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(10))
            setBackgroundColor(Color.parseColor("#161B22"))
        }
        topBar.addView(makeSmallBtn("← 返回", "#30363D") { finish() })
        topBar.addView(TextView(this).apply {
            text = "《品种大全》管理"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            paint.isFakeBoldText = true
            setPadding(dp(10), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        topBar.addView(makeSmallBtn("+ 新增列表", "#1F6FEB") {
            showAddWatchlistDialog()
        })
        root.addView(topBar)

        // 醒目一键复制全部按钮
        val copyAllBtn = Button(this).apply {
            text = "一键复制全部《品种大全》内容"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(42)
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
                topMargin = dp(8)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#238636"))
            }
            setOnClickListener {
                copyTextToClipboard(
                    label = "品种大全全部内容",
                    content = CatalogRepository.exportAllToText(),
                    toastMsg = "已复制全部《品种大全》（${CatalogRepository.getWatchlists().size}列表 / ${CatalogRepository.totalInstrumentCount()}品种）"
                )
            }
        }
        root.addView(copyAllBtn)

        // 工具栏：批量文本导入 / 全部展开折叠 / 恢复默认
        val toolBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(6), dp(12), dp(2))
        }
        toolBar.addView(makeBarBtn("批量粘贴导入") { showBatchImportDialog() })
        toolBar.addView(makeBarBtn("全部折叠") {
            collapsedIds.clear()
            for (wl in CatalogRepository.getWatchlists()) {
                collapsedIds.add(wl.id)
            }
            renderTree()
        })
        toolBar.addView(makeBarBtn("全部展开") {
            collapsedIds.clear()
            renderTree()
        })
        toolBar.addView(makeBarBtn("重置默认") {
            AlertDialog.Builder(this)
                .setTitle("恢复默认《品种大全》")
                .setMessage("确定要覆盖当前修改并恢复内置默认《品种大全》吗？")
                .setPositiveButton("恢复") { _, _ ->
                    val (wCount, iCount) = CatalogRepository.resetToDefault()
                    Toast.makeText(this, "已恢复：$wCount 个列表 / $iCount 个品种", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("取消", null)
                .show()
        })
        root.addView(toolBar)

        // 搜索框
        val searchBox = EditText(this).apply {
            hint = "搜索品种代码 / 中文名 / 数据源 / 类别..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6E7681"))
            setSingleLine(true)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
                topMargin = dp(4)
                bottomMargin = dp(4)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    searchKeyword = s?.toString()?.trim().orEmpty()
                    renderTree()
                }
            })
        }
        root.addView(searchBox)

        summaryText = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(14), dp(2), dp(14), dp(6))
        }
        root.addView(summaryText)

        // 主体树形列表滚动区
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        treeContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(36))
        }
        scroll.addView(treeContainer)
        root.addView(scroll)

        return root
    }

    private fun renderTree() {
        treeContainer.removeAllViews()
        val wls = CatalogRepository.getWatchlists()
        summaryText.text = "共 ${wls.size} 个列表，${CatalogRepository.totalInstrumentCount()} 个品种｜点击任意行可编辑/新增/移动/删除"

        val kw = searchKeyword.lowercase(Locale.US)
        val searching = kw.isNotEmpty()

        for ((wlIdx, wl) in wls.withIndex()) {
            if (searching && !watchlistMatchesSearch(wl, kw)) continue

            val collapsed = !searching && (wl.id in collapsedIds)
            val instCount = wl.flattenInstruments().size

            // 列表头部卡片
            val wlCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(8) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor(Color.parseColor("#161B22"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }

            val headerRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val arrow = if (collapsed) "▶" else "▼"
            val titleTv = TextView(this).apply {
                text = "$arrow  ${wl.name}  ($instCount)"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
                paint.isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    if (wl.id in collapsedIds) collapsedIds.remove(wl.id) else collapsedIds.add(wl.id)
                    renderTree()
                }
            }
            headerRow.addView(titleTv)
            headerRow.addView(makeCopyChipBtn("复制") {
                copyTextToClipboard(
                    label = wl.name,
                    content = CatalogRepository.exportWatchlistToText(wl),
                    toastMsg = "已复制列表「${wl.name}」全部内容（${instCount}个品种）"
                )
            })
            headerRow.addView(makeTinyBtn("↑") { CatalogRepository.moveWatchlist(wlIdx, -1) })
            headerRow.addView(makeTinyBtn("↓") { CatalogRepository.moveWatchlist(wlIdx, 1) })
            headerRow.addView(makeTinyBtn("管理") { showWatchlistActionMenu(wl, wlIdx) })
            wlCard.addView(headerRow)

            if (!collapsed) {
                renderNodes(wlCard, wl.children, depth = 0, kw = kw)
            }
            treeContainer.addView(wlCard)
        }
    }

    private fun renderNodes(
        parentLayout: LinearLayout,
        nodes: MutableList<CatalogNode>,
        depth: Int,
        kw: String
    ) {
        val searching = kw.isNotEmpty()
        val indentPx = dp(8 + depth * 14)

        for ((idx, node) in nodes.withIndex()) {
            when (node) {
                is CatalogNode.Category -> {
                    if (searching && !nodeMatchesSearch(node, kw)) continue
                    val collapsed = !searching && (node.id in collapsedIds)
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(indentPx, dp(7), dp(2), dp(7))
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = dp(4) }
                        background = GradientDrawable().apply {
                            cornerRadius = dp(6).toFloat()
                            setColor(Color.parseColor("#21262D"))
                        }
                    }

                    val arrow = if (collapsed) "▸" else "▾"
                    row.addView(TextView(this).apply {
                        text = "$arrow ${node.name}"
                        setTextColor(Color.parseColor("#79C0FF"))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                        paint.isFakeBoldText = true
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        setOnClickListener {
                            if (node.id in collapsedIds) collapsedIds.remove(node.id) else collapsedIds.add(node.id)
                            renderTree()
                        }
                    })
                    row.addView(makeTinyBtn("↑") { CatalogRepository.moveNode(nodes, idx, -1) })
                    row.addView(makeTinyBtn("↓") { CatalogRepository.moveNode(nodes, idx, 1) })
                    row.addView(makeTinyBtn("管理") { showCategoryActionMenu(node, nodes, idx) })
                    parentLayout.addView(row)

                    if (!collapsed) {
                        renderNodes(parentLayout, node.children, depth + 1, kw)
                    }
                }

                is CatalogNode.Instrument -> {
                    if (searching && !nodeMatchesSearch(node, kw)) continue
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(indentPx + dp(6), dp(5), dp(2), dp(5))
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = dp(2) }
                    }

                    val detail = buildString {
                        append(node.symbol)
                        if (node.cnName.isNotBlank()) append("  ").append(node.cnName)
                        if (node.source.isNotBlank()) append("  [").append(node.source).append("]")
                    }
                    row.addView(TextView(this).apply {
                        text = detail
                        setTextColor(Color.parseColor("#E6EDF3"))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        setOnClickListener { showInstrumentActionMenu(node, nodes, idx) }
                    })
                    row.addView(makeTinyBtn("↑") { CatalogRepository.moveNode(nodes, idx, -1) })
                    row.addView(makeTinyBtn("↓") { CatalogRepository.moveNode(nodes, idx, 1) })
                    row.addView(makeTinyBtn("改") { showInstrumentActionMenu(node, nodes, idx) })
                    parentLayout.addView(row)
                }
            }
        }
    }

    private fun watchlistMatchesSearch(wl: CatalogWatchlist, kw: String): Boolean {
        if (wl.name.lowercase(Locale.US).contains(kw)) return true
        return wl.children.any { nodeMatchesSearch(it, kw) }
    }

    private fun nodeMatchesSearch(node: CatalogNode, kw: String): Boolean {
        return when (node) {
            is CatalogNode.Category -> node.name.lowercase(Locale.US).contains(kw) ||
                node.children.any { nodeMatchesSearch(it, kw) }
            is CatalogNode.Instrument -> node.symbol.lowercase(Locale.US).contains(kw) ||
                node.cnName.lowercase(Locale.US).contains(kw) ||
                node.source.lowercase(Locale.US).contains(kw)
        }
    }

    // ==================== 各种增删改查移动弹窗 ====================

    private fun showAddWatchlistDialog() {
        val input = makeDialogInput("列表名称（如 -7新列表）", "")
        AlertDialog.Builder(this)
            .setTitle("新增列表")
            .setView(wrapDialogView(input))
            .setPositiveButton("添加") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    CatalogRepository.addWatchlist(name)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showWatchlistActionMenu(wl: CatalogWatchlist, wlIdx: Int) {
        val actions = arrayOf(
            "复制此列表全部内容",
            "修改列表名称",
            "+ 在此列表下新增细分类别",
            "+ 在此列表下新增品种",
            "上移列表顺序",
            "下移列表顺序",
            "删除此列表"
        )
        AlertDialog.Builder(this)
            .setTitle("列表：${wl.name}")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> copyTextToClipboard(
                        label = wl.name,
                        content = CatalogRepository.exportWatchlistToText(wl),
                        toastMsg = "已复制列表「${wl.name}」全部内容（${wl.flattenInstruments().size}个品种）"
                    )
                    1 -> showRenameDialog("修改列表名称", wl.name) { newName ->
                        wl.name = newName
                        CatalogRepository.save()
                    }
                    2 -> showAddCategoryDialog("在[${wl.name}]下新增细分类别", wl.children)
                    3 -> showEditInstrumentDialog(title = "在[${wl.name}]下新增品种", existing = null, targetList = wl.children)
                    4 -> CatalogRepository.moveWatchlist(wlIdx, -1)
                    5 -> CatalogRepository.moveWatchlist(wlIdx, 1)
                    6 -> confirmDelete("删除列表[${wl.name}]（含其下全部类别与品种）？") {
                        CatalogRepository.removeWatchlist(wlIdx)
                    }
                }
            }
            .show()
    }

    private fun showCategoryActionMenu(
        cat: CatalogNode.Category,
        parentList: MutableList<CatalogNode>,
        idx: Int
    ) {
        val actions = arrayOf(
            "修改细分类别名称",
            "+ 新增下级再细分类别",
            "+ 在此类别下新增品种",
            "上移顺序",
            "下移顺序",
            "移动到其它列表/类别",
            "删除此细分类别"
        )
        AlertDialog.Builder(this)
            .setTitle("类别：${cat.name}")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> showRenameDialog("修改细分类别名称", cat.name) { newName ->
                        cat.name = newName
                        CatalogRepository.save()
                    }
                    1 -> showAddCategoryDialog("在[${cat.name}]下新增再细分类别", cat.children)
                    2 -> showEditInstrumentDialog(title = "在[${cat.name}]下新增品种", existing = null, targetList = cat.children)
                    3 -> CatalogRepository.moveNode(parentList, idx, -1)
                    4 -> CatalogRepository.moveNode(parentList, idx, 1)
                    5 -> showMoveNodeDialog(cat, parentList, idx)
                    6 -> confirmDelete("删除细分类别[${cat.name}]（含下级全部内容）？") {
                        CatalogRepository.removeNode(parentList, idx)
                    }
                }
            }
            .show()
    }

    private fun showInstrumentActionMenu(
        inst: CatalogNode.Instrument,
        parentList: MutableList<CatalogNode>,
        idx: Int
    ) {
        val actions = arrayOf(
            "编辑品种（名称 / 中文名 / 数据源）",
            "上移顺序",
            "下移顺序",
            "移动到其它列表/类别",
            "删除此品种"
        )
        AlertDialog.Builder(this)
            .setTitle("品种：${inst.symbol}")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> showEditInstrumentDialog(title = "编辑品种", existing = inst, targetList = parentList)
                    1 -> CatalogRepository.moveNode(parentList, idx, -1)
                    2 -> CatalogRepository.moveNode(parentList, idx, 1)
                    3 -> showMoveNodeDialog(inst, parentList, idx)
                    4 -> confirmDelete("删除品种 ${inst.symbol}？") {
                        CatalogRepository.removeNode(parentList, idx)
                    }
                }
            }
            .show()
    }

    private fun showRenameDialog(title: String, oldVal: String, onSave: (String) -> Unit) {
        val input = makeDialogInput("请输入名称", oldVal)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrapDialogView(input))
            .setPositiveButton("保存") { _, _ ->
                val v = input.text.toString().trim()
                if (v.isNotEmpty()) onSave(v)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showAddCategoryDialog(title: String, targetList: MutableList<CatalogNode>) {
        val input = makeDialogInput("细分类别名称", "")
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrapDialogView(input))
            .setPositiveButton("添加") { _, _ ->
                val v = input.text.toString().trim()
                if (v.isNotEmpty()) {
                    targetList.add(CatalogNode.Category(name = v))
                    CatalogRepository.save()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showEditInstrumentDialog(
        title: String,
        existing: CatalogNode.Instrument?,
        targetList: MutableList<CatalogNode>
    ) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(6))
        }
        val symInput = makeDialogInput("品种代码（如 BTCUSD / 8035）", existing?.symbol.orEmpty())
        val cnInput = makeDialogInput("品种中文名（可留空）", existing?.cnName.orEmpty())
        val srcInput = makeDialogInput("品种数据源（如 IG，可留空）", existing?.source.orEmpty())

        box.addView(makeDialogLabel("品种名称（代码）："))
        box.addView(symInput)
        box.addView(makeDialogLabel("品种中文名："))
        box.addView(cnInput)
        box.addView(makeDialogLabel("品种数据源："))
        box.addView(srcInput)

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("保存") { _, _ ->
                val sym = symInput.text.toString().trim().uppercase(Locale.US)
                val cn = cnInput.text.toString().trim()
                val src = srcInput.text.toString().trim()
                if (sym.isEmpty()) {
                    Toast.makeText(this, "品种名称不能为空", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (existing != null) {
                    existing.symbol = sym
                    existing.cnName = cn
                    existing.source = src
                } else {
                    targetList.add(CatalogNode.Instrument(symbol = sym, cnName = cn, source = src))
                }
                CatalogRepository.save()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showMoveNodeDialog(
        node: CatalogNode,
        sourceList: MutableList<CatalogNode>,
        sourceIdx: Int
    ) {
        val destinations = ArrayList<Pair<String, MutableList<CatalogNode>>>()
        fun collectCats(prefix: String, nodes: List<CatalogNode>) {
            for (n in nodes) {
                if (n is CatalogNode.Category && n.id != node.id) {
                    val label = "$prefix / ${n.name}"
                    destinations.add(label to n.children)
                    collectCats(label, n.children)
                }
            }
        }
        for (wl in CatalogRepository.getWatchlists()) {
            destinations.add("[列表] ${wl.name}" to wl.children)
            collectCats("[列表] ${wl.name}", wl.children)
        }

        val labels = destinations.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("选择移动目标位置")
            .setItems(labels) { _, which ->
                val destList = destinations[which].second
                if (destList !== sourceList) {
                    val removed = sourceList.removeAt(sourceIdx)
                    destList.add(removed)
                    CatalogRepository.save()
                    Toast.makeText(this, "已移动到：${labels[which]}", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showBatchImportDialog() {
        val input = EditText(this).apply {
            hint = "粘贴《品种大全》文本（支持 (●—●)列表名、细分类别、品种名▰中文名、品种名——中文名—数据源）"
            minLines = 8
            maxLines = 16
            gravity = Gravity.TOP or Gravity.START
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        AlertDialog.Builder(this)
            .setTitle("批量粘贴导入《品种大全》")
            .setView(wrapDialogView(input))
            .setPositiveButton("覆盖导入") { _, _ ->
                val txt = input.text.toString()
                if (txt.isBlank()) return@setPositiveButton
                val (wlCnt, instCnt) = CatalogRepository.replaceWithRawText(txt)
                Toast.makeText(this, "导入完成：$wlCnt 个列表 / $instCnt 个品种", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmDelete(msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("确认删除")
            .setMessage(msg)
            .setPositiveButton("删除") { _, _ -> onYes() }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun makeDialogLabel(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(6), 0, dp(2))
        }
    }

    private fun makeDialogInput(hint: String, initVal: String): EditText {
        return EditText(this).apply {
            this.hint = hint
            setText(initVal)
            setSingleLine(true)
        }
    }

    private fun wrapDialogView(v: EditText): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(6))
            addView(v)
        }
    }

    private fun makeSmallBtn(label: String, bgHex: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            isAllCaps = false
            setPadding(dp(10), dp(4), dp(10), dp(4))
            minHeight = 0
            minimumHeight = dp(34)
            minWidth = 0
            minimumWidth = 0
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor(bgHex))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeBarBtn(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { onClick() }
        }
    }

    private fun copyTextToClipboard(label: String, content: String, toastMsg: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, content))
        Toast.makeText(this, toastMsg, Toast.LENGTH_SHORT).show()
    }

    private fun makeCopyChipBtn(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            paint.isFakeBoldText = true
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = GradientDrawable().apply {
                cornerRadius = dp(5).toFloat()
                setColor(Color.parseColor("#21262D"))
                setStroke(dp(1), Color.parseColor("#388BFD"))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeTinyBtn(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(dp(7), dp(4), dp(7), dp(4))
            setOnClickListener { onClick() }
        }
    }
}
