package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

enum class QuickJumpOutcome {
    SUCCESS,
    COLOR_LIST_NOT_FOUND,
    FAILED
}

/**
 * 独立的“探索栏快切列表直达图表”执行引擎（v7.1.2 稳态极速版，与原标色 WatchlistExecutor 完全解耦）：
 * - 等待弹窗彻底撤除恢复 TV 可见性后再操作，零误读
 * - 严格按顶栏选中态判定当前列表，杜绝 04备❸欧随 等备份列表冒充目标列表
 * - 列表内目标改用零惯性精准翻屏（不再对中部目标做狂甩过头），稳定 1~3 秒直达图表
 */
class QuickJumpExecutor(
    private val service: AccessibilityService,
    private val vision: VisionEngine,
    private val inspector: NodeInspector,
    private val gesture: GestureDriver,
    private val screenSizeProvider: () -> Pair<Int, Int>,
    private val captureScreen: (Int) -> Bitmap?,
    private val shouldAbort: () -> Boolean,
    private val onWatchlistIdentified: (String) -> Unit
) {

    fun executeJump(entry: QuickJumpEntry): QuickJumpOutcome {
        // 先等 85ms 让全屏选择弹窗彻底从 WindowManager 移除，确保 TV 底层节点 100% 恢复可见！
        gesture.sleepSafe(85L)
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        return when (entry.targetType) {
            QuickJumpTargetType.COLOR_SLOT -> executeColorSlotJump(entry)
            QuickJumpTargetType.CATALOG_TARGET -> executeCatalogJump(entry)
        }
    }

    // ==================== 模式 A：顶部最左侧第 N 个颜色列表直达首品种图表 ====================

    private fun executeColorSlotJump(entry: QuickJumpEntry): QuickJumpOutcome {
        val startMs = SystemClock.uptimeMillis()
        val slotIndex = entry.colorSlotIndex.coerceIn(1, 7)
        AppStore.log("列表快切启动：${entry.displayName}（最左侧第${slotIndex}个颜色列表）")

        if (!ensureOnWatchlistPage()) {
            AppStore.log("列表快切中止：未能切到自选表页")
            return QuickJumpOutcome.FAILED
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        val (leftTabs, tabY) = rewindTopTabBarToLeftmost()
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        val firstCatalogTab = leftTabs.firstOrNull { it.matchedCatalogIdx >= 0 }
        val maxRightX = if (firstCatalogTab != null) {
            (firstCatalogTab.info.leftX - 4).coerceAtLeast(0)
        } else {
            0
        }

        val nodeColorTabs = leftTabs
            .filter { inspector.parseColorWatchlistName(it.info.name) != null }
            .sortedBy { it.info.centerX }

        var targetX = -1
        var targetY = tabY
        var targetNode: AccessibilityNodeInfo? = null
        var targetColor: MarkColor? = null
        var alreadyOnTarget = false

        if (nodeColorTabs.isNotEmpty()) {
            if (nodeColorTabs.size < slotIndex) {
                AppStore.log("列表快切：当前仅有 ${nodeColorTabs.size} 个颜色列表，不存在第${slotIndex}个，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }
            val chosen = nodeColorTabs[slotIndex - 1]
            targetX = chosen.info.centerX
            targetY = chosen.info.centerY
            targetNode = chosen.node
            targetColor = inspector.parseColorWatchlistName(chosen.info.name)
            alreadyOnTarget = chosen.node != null && inspector.isNodeOrAncestorSelected(chosen.node)
        } else {
            val (sw, _) = screenSizeProvider()
            if (firstCatalogTab != null && firstCatalogTab.info.leftX < (sw * 0.145f).toInt()) {
                AppStore.log("列表快切：顶部栏最左侧无任何颜色列表，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }

            val bmp = captureScreen(2)
            if (bmp == null) {
                AppStore.log("列表快切：未能读取顶部颜色列表栏，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }
            val detectedPair: Pair<Int, List<Pair<Int, MarkColor>>>
            val activePillColor: MarkColor?
            try {
                detectedPair = vision.detectTopBarColorFlagTabs(bmp, knownTabY = tabY, maxRightX = maxRightX)
                activePillColor = vision.detectActiveColorWatchlistFromTopPill(bmp)
            } finally {
                bmp.recycle()
            }

            val (realTabY, flagTabs) = detectedPair
            if (flagTabs.size < slotIndex) {
                AppStore.log("列表快切：当前仅检测到 ${flagTabs.size} 个颜色列表，不存在第${slotIndex}个，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }

            val chosenFlag = flagTabs[slotIndex - 1]
            targetX = chosenFlag.first
            targetY = realTabY
            targetColor = chosenFlag.second
            alreadyOnTarget = (activePillColor != null && activePillColor == chosenFlag.second)
        }

        if (shouldAbort()) return QuickJumpOutcome.FAILED

        if (!alreadyOnTarget) {
            val prevSyms = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }
            val clicked = (targetNode != null && gesture.clickNodeOrParent(targetNode)) ||
                gesture.dispatchTap(targetX.toFloat(), targetY.toFloat())
            if (!clicked) return QuickJumpOutcome.FAILED
            waitForAnyWatchlistChange(prevSyms)
            gesture.markOwnActionJustFinished()
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        scrollCurrentWatchlistToTopFast()
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        var rows = inspector.scanWatchlistSymbolsFromNodes()
        if (rows.isEmpty()) {
            gesture.sleepSafe(70L)
            rows = inspector.scanWatchlistSymbolsFromNodes()
        }
        val firstRow = rows.firstOrNull()
        if (firstRow == null) {
            AppStore.log("列表快切：第${slotIndex}个颜色列表(${targetColor?.label ?: ""})内暂无品种，返回列表选择页")
            return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
        }

        val opened = clickRowToOpenChart(firstRow)
        if (opened) {
            val elapsed = SystemClock.uptimeMillis() - startMs
            AppStore.log("列表快切完成：${entry.displayName}(${targetColor?.label ?: ""}标) -> ${firstRow.symbol}（用时 ${elapsed}ms）")
            return QuickJumpOutcome.SUCCESS
        }
        return QuickJumpOutcome.FAILED
    }

    private fun rewindTopTabBarToLeftmost(): Pair<List<TopTabNodeCandidate>, Int> {
        val (sw, sh) = screenSizeProvider()
        var (tabs, tabY) = inspector.findTopTabRowFromNodes()

        for (step in 0 until 5) {
            if (shouldAbort()) break
            val scrollBox = inspector.findTopTabScrollContainer(tabs)
            if (scrollBox != null) {
                val canScrollLeft = scrollBox.actionList.any { it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD }
                if (!canScrollLeft) {
                    return tabs to tabY
                }
                val prevSig = tabs.joinToString("|") { "${it.info.name}:${it.info.leftX}" }
                if (gesture.performNativeAction(scrollBox, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                    gesture.sleepSafe(65L)
                    val next = inspector.findTopTabRowFromNodes()
                    tabs = next.first
                    tabY = next.second
                    val newSig = tabs.joinToString("|") { "${it.info.name}:${it.info.leftX}" }
                    if (newSig == prevSig) break
                    continue
                }
            }

            // 如果已看到 -1商 且其左侧贴近 ≡，无需多余滑动
            val firstCat = tabs.firstOrNull { it.matchedCatalogIdx == 0 }
            if (firstCat != null && firstCat.info.leftX < (sw * 0.16f).toInt()) {
                return tabs to tabY
            }
            val prevSig = tabs.joinToString("|") { "${it.info.name}:${it.info.leftX}" }
            val effY = if (tabY > 0) tabY else (sh * 0.095f).toInt()
            if (!gesture.swipeTabBar(effY, swipeFingerRightToLeft = false, distanceFrac = 0.70f)) {
                break
            }
            gesture.sleepSafe(40L)
            val next = inspector.findTopTabRowFromNodes()
            tabs = next.first
            tabY = next.second
            val newSig = tabs.joinToString("|") { "${it.info.name}:${it.info.leftX}" }
            if (newSig == prevSig) break
        }
        return tabs to tabY
    }

    private fun waitForAnyWatchlistChange(prevSyms: List<String>) {
        val anchor = prevSyms.firstOrNull()
        for (i in 0 until 12) {
            gesture.sleepSafe(20L)
            if (shouldAbort()) return
            if (anchor != null && !inspector.isSymbolVisibleOnScreenFast(anchor)) {
                gesture.sleepSafe(35L)
                return
            }
            val nowHead = inspector.scanWatchlistSymbolsFromNodes().take(2).map { it.symbol }
            if (nowHead.isNotEmpty() && nowHead != prevSyms.take(2)) {
                return
            }
        }
    }

    private fun scrollCurrentWatchlistToTopFast() {
        var prevHead = inspector.scanWatchlistSymbolsFromNodes().take(2).map { it.symbol }
        if (!inspector.canWatchlistBodyScrollBackward()) return
        for (i in 0 until 5) {
            if (shouldAbort()) return
            if (!gesture.performFastScroll(scrollDown = false)) return
            gesture.sleepSafe(70L)
            val nowHead = inspector.scanWatchlistSymbolsFromNodes().take(2).map { it.symbol }
            if (nowHead.isNotEmpty() && nowHead == prevHead) break
            prevHead = nowHead
            if (!inspector.canWatchlistBodyScrollBackward()) break
        }
    }

    // ==================== 模式 B：《品种大全》列表 -> 细分类别 -> 指定/首位品种直达图表 ====================

    private fun executeCatalogJump(entry: QuickJumpEntry): QuickJumpOutcome {
        val startMs = SystemClock.uptimeMillis()
        val (resolvedWl, autoSym) = CatalogRepository.findFirstSymbolForQuickJumpByIdOrName(
            entry.watchlistId,
            entry.watchlistName,
            entry.categoryName
        )
        val targetWl = resolvedWl ?: CatalogRepository.getWatchlistByName(entry.watchlistName)
        if (targetWl == null) {
            AppStore.log("列表快切失败：未在《品种大全》找到列表 ${entry.watchlistName}")
            return QuickJumpOutcome.FAILED
        }
        val targetSymbol = entry.targetSymbol.trim().uppercase()
            .ifBlank { autoSym ?: entry.fallbackSymbol }
        if (targetSymbol.isBlank()) {
            AppStore.log("列表快切失败：列表[${targetWl.name}]内暂无品种")
            return QuickJumpOutcome.FAILED
        }
        val isFirstOfWatchlist = targetWl.flattenInstruments().firstOrNull()?.symbol
            ?.equals(targetSymbol, ignoreCase = true) == true

        AppStore.log("列表快切启动：${entry.displayName} -> [${targetWl.name}] -> $targetSymbol")

        if (!ensureOnWatchlistPage()) {
            AppStore.log("列表快切中止：未能切到自选表页")
            return QuickJumpOutcome.FAILED
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        val switched = ensureOnTargetWatchlist(targetWl)
        if (!switched || shouldAbort()) {
            if (!shouldAbort()) AppStore.log("列表快切失败：未能切至[${targetWl.name}]")
            return QuickJumpOutcome.FAILED
        }
        onWatchlistIdentified(targetWl.id)

        val clickedRow = findAndClickTargetSymbol(targetWl, targetSymbol, isFirstOfWatchlist)
        if (clickedRow) {
            val elapsed = SystemClock.uptimeMillis() - startMs
            AppStore.log("列表快切完成：${entry.displayName} -> $targetSymbol（用时 ${elapsed}ms）")
            return QuickJumpOutcome.SUCCESS
        } else if (!shouldAbort()) {
            AppStore.log("列表快切未找到目标品种：$targetSymbol（[${targetWl.name}]）")
        }
        return QuickJumpOutcome.FAILED
    }

    private fun isGenuineWatchlistNow(): Boolean {
        val r = inspector.findTradingViewRoot() ?: return false
        if (inspector.isExploreOrNewsPage(r) || inspector.isSymbolSearchPage(r)) return false
        return inspector.detectTradingViewPage(r, isBatchRunning = false) {} == TvPageState.WATCHLIST
    }

    private fun ensureOnWatchlistPage(): Boolean {
        if (isGenuineWatchlistNow()) {
            return true
        }

        val (sw, sh) = screenSizeProvider()
        for (attempt in 0 until 2) {
            if (shouldAbort()) return false
            val rootNow = inspector.findTradingViewRoot() ?: return false
            val wlTab = inspector.findBottomNavTabNode(rootNow, "自选表", "Watchlist")
            val clicked = if (attempt == 0 && wlTab != null) {
                gesture.clickNodeOrParent(wlTab) || gesture.dispatchTap(sw * 0.10f, sh * 0.975f)
            } else {
                gesture.dispatchTap(sw * 0.10f, sh * 0.975f)
            }
            if (!clicked) return false

            for (i in 0 until 20) {
                gesture.sleepSafe(20L)
                if (shouldAbort()) return false
                if (isGenuineWatchlistNow()) {
                    for (w in 0 until 5) {
                        if (inspector.findTopTabRowFromNodes().first.isNotEmpty() ||
                            inspector.scanWatchlistSymbolsFromNodes().isNotEmpty()
                        ) {
                            return true
                        }
                        gesture.sleepSafe(20L)
                    }
                    return true
                }
            }
        }
        return false
    }

    private fun ensureOnTargetWatchlist(targetWl: CatalogWatchlist): Boolean {
        val (topTabs, topY) = inspector.findTopTabRowFromNodes()
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)

        // 严格只以顶栏选中标签确认“已在目标列表”，绝不凭品种重合度把 04备❸欧随 误当成 -4❸欧股！
        val activeTop = inspector.detectActiveWatchlistFromTopNodes()
        if (activeTop?.id == targetWl.id) {
            return true
        }

        val prevSymbols = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }

        // 通道 A：目标列表已在顶部栏可见 -> 1 次点击秒切（~150ms）
        val (sw, _) = screenSizeProvider()
        val directHit = topTabs.firstOrNull {
            it.matchedCatalogIdx == targetIdx &&
                it.info.centerX in (sw * 0.11f).toInt()..(sw * 0.95f).toInt()
        }
        if (directHit != null) {
            val clicked = (directHit.node != null && gesture.clickNodeOrParent(directHit.node)) ||
                gesture.dispatchTap(directHit.info.centerX.toFloat(), directHit.info.centerY.toFloat())
            if (clicked) {
                waitForTargetWatchlistRender(prevSymbols, targetWl)
                gesture.markOwnActionJustFinished()
                return true
            }
        }

        // 通道 B：左上角 ≡ 列表抽屉 2 次点击直选（12 个列表全在首屏，彻底免疫备份垃圾列表！）
        if (switchViaDrawerFast(targetWl, topY, prevSymbols)) {
            return true
        }

        // 通道 C：顶栏原生滚动 + 防垃圾列表横滑兜底
        return switchViaTopBarFallback(targetWl, targetIdx, prevSymbols)
    }

    private fun switchViaDrawerFast(
        targetWl: CatalogWatchlist,
        knownTabY: Int,
        prevSymbols: List<String>
    ): Boolean {
        if (shouldAbort()) return false
        if (!isGenuineWatchlistNow()) return false
        val (sw, sh) = screenSizeProvider()
        val approxY = if (knownTabY > 0) knownTabY else {
            captureScreen(1)?.let { bmp ->
                try { vision.detectTabBarCenterY(bmp) } finally { bmp.recycle() }
            } ?: (sh * 0.095f).toInt()
        }

        val hambNode = inspector.findHamburgerButtonNode(approxY)
        val opened = (hambNode != null && gesture.clickNodeOrParent(hambNode)) ||
            gesture.dispatchTap(sw * 0.0423f, approxY.toFloat())
        if (!opened) return false

        var foundItem: DrawerItemCandidate? = null
        var drawerOpened = false
        val waits = longArrayOf(25L, 30L, 35L, 40L, 45L, 55L, 65L, 75L)
        for (w in waits) {
            gesture.sleepSafe(w)
            if (shouldAbort()) return false
            if (!drawerOpened && inspector.isWatchlistDrawerOpen()) drawerOpened = true
            foundItem = inspector.findWatchlistInDrawer(targetWl)
            if (foundItem != null) break
        }

        val item = foundItem
        if (item != null) {
            val clicked = gesture.clickNodeOrParent(item.node) ||
                gesture.dispatchTap(item.centerX.toFloat(), item.centerY.toFloat())
            if (!clicked) return false

            // 1) 等抽屉关闭
            for (i in 0 until 16) {
                gesture.sleepSafe(18L)
                if (shouldAbort()) return false
                if (!inspector.isWatchlistDrawerOpen()) break
            }
            // 2) 严格确认顶栏已切至 targetWl 或旧列表已刷新为新列表
            waitForTargetWatchlistRender(prevSymbols, targetWl)
            gesture.markOwnActionJustFinished()
            return true
        }

        if (drawerOpened || inspector.isWatchlistDrawerOpen()) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            gesture.sleepSafe(110L)
            gesture.markOwnActionJustFinished()
        }
        return false
    }

    private fun switchViaTopBarFallback(
        targetWl: CatalogWatchlist,
        targetIdx: Int,
        prevSymbols: List<String>
    ): Boolean {
        val totalWls = CatalogRepository.getWatchlists().size
        val lastCatalogIdx = (totalWls - 1).coerceAtLeast(0)
        val (sw, sh) = screenSizeProvider()
        val safeLeftX = (sw * 0.13f).toInt()
        val safeRightX = (sw * 0.93f).toInt()

        var prevSig = ""
        var stuck = 0

        for (step in 0 until 9) {
            if (shouldAbort()) return false
            val (tabs, tabY) = inspector.findTopTabRowFromNodes()
            val hit = tabs.firstOrNull { it.matchedCatalogIdx == targetIdx }
            if (hit != null) {
                val ok = (hit.node != null && gesture.clickNodeOrParent(hit.node)) ||
                    gesture.dispatchTap(hit.info.centerX.coerceIn(safeLeftX, safeRightX).toFloat(), tabY.toFloat())
                if (ok) {
                    waitForTargetWatchlistRender(prevSymbols, targetWl)
                    gesture.markOwnActionJustFinished()
                    return true
                }
            }

            val sig = tabs.joinToString("|") { "${it.info.name}:${it.matchedCatalogIdx}" }
            if (sig == prevSig && sig.isNotEmpty()) {
                stuck++
                if (stuck >= 3) return false
            } else {
                stuck = 0
                prevSig = sig
            }

            // 严格防垃圾列表方向判定（若滑进 00000000 / 04备... 备份区，一律往左回拉！）
            val known = tabs.map { it.matchedCatalogIdx }.filter { it >= 0 }
            val hasGarbage = tabs.any { it.matchedCatalogIdx < 0 }
            val seesLast = known.any { it >= lastCatalogIdx }
            val goRightToLeft = when {
                known.isEmpty() -> false
                seesLast && targetIdx < lastCatalogIdx -> false
                hasGarbage && known.max() >= lastCatalogIdx - 1 && targetIdx < known.min() -> false
                known.min() > targetIdx -> false
                known.max() < targetIdx -> true
                else -> targetIdx > known.average()
            }

            // 优先原生快滚
            if (stuck == 0) {
                val scrollBox = inspector.findTopTabScrollContainer(tabs)
                if (scrollBox != null) {
                    val act = if (goRightToLeft) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    if (gesture.performNativeAction(scrollBox, act)) {
                        gesture.sleepSafe(60L)
                        continue
                    }
                }
            }

            val effY = if (tabY > 0) tabY else (sh * 0.095f).toInt()
            if (!gesture.swipeTabBar(effY, swipeFingerRightToLeft = goRightToLeft, distanceFrac = 0.60f)) {
                return false
            }
        }
        return false
    }

    private fun waitForTargetWatchlistRender(prevSymbols: List<String>, targetWl: CatalogWatchlist) {
        val prevAnchor = prevSymbols.firstOrNull { !CatalogRepository.isSymbolInWatchlist(it, targetWl.id) }
        val targetSyms = targetWl.flattenInstruments().take(3).map { it.symbol }
        for (i in 0 until 15) {
            gesture.sleepSafe(20L)
            if (shouldAbort()) return
            if (inspector.detectActiveWatchlistFromTopNodes()?.id == targetWl.id) {
                if (prevAnchor == null || !inspector.isSymbolVisibleOnScreenFast(prevAnchor) ||
                    targetSyms.any { inspector.isSymbolVisibleOnScreenFast(it) }
                ) {
                    gesture.sleepSafe(25L)
                    return
                }
            }
            if (prevAnchor != null && !inspector.isSymbolVisibleOnScreenFast(prevAnchor)) {
                gesture.sleepSafe(35L)
                return
            }
        }
    }

    private fun findAndClickTargetSymbol(
        targetWl: CatalogWatchlist,
        targetSymbol: String,
        isFirstOfWatchlist: Boolean
    ): Boolean {
        // 1) 0 翻屏秒查：目标品种如果就在眼前，3ms 直接点进图表！
        val instantHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
        if (instantHit != null) {
            return clickRowToOpenChart(instantHit)
        }

        val firstRows = inspector.scanWatchlistSymbolsFromNodes()
        val matchInFirst = firstRows.firstOrNull { vision.findMatchingTaskKey(it.symbol, setOf(targetSymbol)) != null }
        if (matchInFirst != null) {
            return clickRowToOpenChart(matchInFirst)
        }

        // 2) 若目标是“本列表最顶部的第 1 个品种”：极速回顶后直接点击！
        if (isFirstOfWatchlist) {
            scrollCurrentWatchlistToTopFast()
            if (shouldAbort()) return false
            val topHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                ?: inspector.scanWatchlistSymbolsFromNodes().firstOrNull()
            if (topHit != null) {
                return clickRowToOpenChart(topHit)
            }
            return false
        }

        // 3) 列表中部目标（如 中一->700 / 欧股-法它->MC / 亚股->8035）：
        //    按《品种大全》顺序确定主方向，全程使用零惯性精准翻屏（绝不用狂甩 fling 冲过头浪费 15 秒！）
        val symbolOrders = CatalogRepository.getSymbolOrdersInWatchlist(targetWl.id)
        val targetOrder = symbolOrders[targetSymbol.uppercase()]?.firstOrNull() ?: 0
        val visIndices = firstRows.flatMap { symbolOrders[it.symbol].orEmpty() }
        val visMin = visIndices.minOrNull()
        val visMax = visIndices.maxOrNull()

        val primaryDown: Boolean = when {
            visMin != null && targetOrder < visMin -> false
            visMax != null && targetOrder > visMax -> true
            else -> true
        }

        val directions = listOf(primaryDown, !primaryDown)
        val expandedKeys = HashSet<String>()

        for ((dirIdx, goDown) in directions.withIndex()) {
            if (shouldAbort()) return false

            var prevHead = if (dirIdx == 0) firstRows.take(3).map { it.symbol } else emptyList()
            var sameCount = 0

            for (scrollStep in 0 until 28) {
                if (shouldAbort()) return false

                if (!gesture.performControlledScroll(scrollDown = goDown, stronger = (sameCount > 0))) {
                    return false
                }
                gesture.sleepSafe(24L)
                if (shouldAbort()) return false

                // 先用 3ms 原生直查目标品种，命中立刻点进图表，无需扫描整屏！
                val hit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                if (hit != null) {
                    return clickRowToOpenChart(hit)
                }

                val rows = inspector.scanWatchlistSymbolsFromNodes()
                val matchRow = rows.firstOrNull { vision.findMatchingTaskKey(it.symbol, setOf(targetSymbol)) != null }
                if (matchRow != null) {
                    return clickRowToOpenChart(matchRow)
                }

                // 若翻过目标在《品种大全》中的区间却未见它，检查是否被折叠板块藏起并自动展开
                val rowOrds = rows.flatMap { symbolOrders[it.symbol].orEmpty() }
                val rMin = rowOrds.minOrNull()
                val rMax = rowOrds.maxOrNull()
                if (rMin != null && rMax != null && targetOrder in (rMin - 2)..(rMax + 2)) {
                    val dummyTask = PendingTask(
                        key = "JUMP::$targetSymbol",
                        symbol = targetSymbol,
                        color = MarkColor.RED,
                        preferredWatchlistId = targetWl.id
                    )
                    val collapsed = inspector.findCollapsedSectionHeaders(rows, listOf(dummyTask), targetWl)
                    for (sec in collapsed) {
                        val k = "${targetWl.id}::${sec.text}"
                        if (!expandedKeys.add(k)) continue
                        gesture.clickNodeOrParent(sec.node) || gesture.dispatchTap(sec.centerX.toFloat(), sec.centerY.toFloat())
                        gesture.sleepSafe(110L)
                        val afterHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                        if (afterHit != null) return clickRowToOpenChart(afterHit)
                    }
                }

                val curHead = rows.take(3).map { it.symbol }
                if (curHead.isNotEmpty() && curHead == prevHead) {
                    sameCount++
                    if (sameCount >= 2) break
                    continue
                }
                sameCount = 0
                prevHead = curHead
            }
        }
        return false
    }

    private fun clickRowToOpenChart(row: WatchlistRow): Boolean {
        if (shouldAbort()) return false
        val (sw, sh) = screenSizeProvider()
        val topSafe = (sh * 0.125f).toInt()
        val botSafe = (sh * 0.900f).toInt()

        var liveRow = inspector.fastFindPendingRowsByText(listOf(row.symbol))
            .minByOrNull { abs(it.centerY - row.centerY) }
            ?: row

        // 如果目标行紧贴顶部栏或底部栏边缘，先微移 16% 到安全点击区再点，杜绝点偏无效！
        if (liveRow.centerY < topSafe || liveRow.centerY > botSafe) {
            val nudgeDown = liveRow.centerY > botSafe
            val y1 = if (nudgeDown) sh * 0.65f else sh * 0.45f
            val y2 = if (nudgeDown) sh * 0.49f else sh * 0.61f
            val p = Path().apply { moveTo(sw * 0.48f, y1); lineTo(sw * 0.48f, y2) }
            gesture.dispatchGestureSync(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0L, 180L, false)).build())
            gesture.sleepSafe(90L)
            liveRow = inspector.fastFindPendingRowsByText(listOf(row.symbol))
                .minByOrNull { abs(it.centerY - row.centerY) }
                ?: liveRow
        }

        val safeY = liveRow.centerY.coerceIn(topSafe, botSafe)
        val clickPoints = listOf(
            liveRow.centerX.toFloat() to safeY.toFloat(),
            (sw * 0.42f) to safeY.toFloat()
        )

        for ((attemptIdx, pt) in clickPoints.withIndex()) {
            if (shouldAbort()) return false
            val ok = if (attemptIdx == 1 && liveRow.rowNode != null) {
                gesture.clickNodeOrParent(liveRow.rowNode!!) || gesture.dispatchTap(pt.first, pt.second)
            } else {
                gesture.dispatchTap(pt.first, pt.second)
            }
            if (!ok) continue

            for (i in 0 until 14) {
                gesture.sleepSafe(24L)
                if (shouldAbort()) return true
                val root = inspector.findTradingViewRoot() ?: continue
                if (inspector.detectTradingViewPage(root, isBatchRunning = false) {} == TvPageState.CHART) {
                    return true
                }
            }
        }
        return false
    }
}
