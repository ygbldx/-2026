package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

enum class QuickJumpOutcome {
    SUCCESS,
    COLOR_LIST_NOT_FOUND,
    FAILED
}

/**
 * 独立的“探索栏快切列表直达图表”极速稳态引擎（v7.1.4，与原标色 WatchlistExecutor 完全隔离）：
 * - 全程以 2ms 原生直查替代重型轮询（消灭 3.3s 切表空转与 1.5s 进图空转）
 * - 第一/第二颜色列表强制倒回至 -1商 左侧并防过渡帧误判
 * - 常规列表严格校验顶栏选中态，零惯性精准定位直达图表
 */
class QuickJumpExecutor(
    private val service: AccessibilityService,
    private val vision: VisionEngine,
    private val inspector: NodeInspector,
    private val gesture: GestureDriver,
    private val screenSizeProvider: () -> Pair<Int, Int>,
    private val captureScreen: (Int) -> Bitmap?,
    private val shouldAbort: () -> Boolean,
    private val onWatchlistIdentified: (String) -> Unit
) {

    fun executeJump(entry: QuickJumpEntry): QuickJumpOutcome {
        // 等 65ms 让选择弹窗彻底从 WindowManager 撤除、TV 窗口恢复可见
        gesture.sleepSafe(65L)
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        return when (entry.targetType) {
            QuickJumpTargetType.COLOR_SLOT -> executeColorSlotJump(entry)
            QuickJumpTargetType.CATALOG_TARGET -> executeCatalogJump(entry)
        }
    }

    // ==================== 模式 A：顶部最左侧第 N 个颜色列表直达首品种图表 ====================

    private fun executeColorSlotJump(entry: QuickJumpEntry): QuickJumpOutcome {
        val startMs = SystemClock.uptimeMillis()
        val slotIndex = entry.colorSlotIndex.coerceIn(1, 7)
        AppStore.log("列表快切启动：${entry.displayName}（最左侧第${slotIndex}个颜色列表）")

        val cameFromOtherPage = !isGenuineWatchlistNow()
        if (!ensureOnWatchlistPage()) {
            AppStore.log("列表快切中止：未能切到自选表页")
            return QuickJumpOutcome.FAILED
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED
        if (cameFromOtherPage) {
            // 刚从图表切回自选表时给顶部栏渲染留 80ms，避免截到过渡帧误报 0 个颜色列表
            gesture.sleepSafe(80L)
        }
        val tWatchlist = SystemClock.uptimeMillis()

        // 强制倒回顶部列表栏最左侧（直到看到 -1商 且无法继续右拉）
        val (leftTabs, tabY) = rewindTopTabBarToLeftmost()
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        // 仅用 -1商（matchedCatalogIdx == 0）作为右边界，绝不用中部列表误裁！
        val firstCatalogTab = leftTabs.firstOrNull { it.matchedCatalogIdx == 0 }
        val maxRightX = if (firstCatalogTab != null) {
            (firstCatalogTab.info.leftX - 4).coerceAtLeast(0)
        } else {
            0
        }

        val nodeColorTabs = leftTabs
            .filter { inspector.parseColorWatchlistName(it.info.name) != null }
            .sortedBy { it.info.centerX }

        var targetX = -1
        var targetY = tabY
        var targetNode: AccessibilityNodeInfo? = null
        var targetColor: MarkColor? = null
        var alreadyOnTarget = false

        if (nodeColorTabs.isNotEmpty()) {
            if (nodeColorTabs.size < slotIndex) {
                AppStore.log("列表快切：当前仅有 ${nodeColorTabs.size} 个颜色列表，不存在第${slotIndex}个，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }
            val chosen = nodeColorTabs[slotIndex - 1]
            targetX = chosen.info.centerX
            targetY = chosen.info.centerY
            targetNode = chosen.node
            targetColor = inspector.parseColorWatchlistName(chosen.info.name)
            alreadyOnTarget = chosen.node != null && inspector.isNodeOrAncestorSelected(chosen.node)
        } else {
            val (sw, _) = screenSizeProvider()
            if (firstCatalogTab != null && firstCatalogTab.info.leftX < (sw * 0.135f).toInt()) {
                AppStore.log("列表快切：顶部栏最左侧(-1商左缘=${firstCatalogTab.info.leftX})无任何颜色列表，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }

            // 最多尝试 2 次截屏核验（防切页瞬间过渡帧导致偶发误报 0 个颜色列表；首次命中则零额外耗时）
            var foundFlags: List<Pair<Int, MarkColor>> = emptyList()
            var realTabY = tabY
            var activePillColor: MarkColor? = null

            for (capTry in 0 until 2) {
                val bmp = captureScreen(2) ?: break
                try {
                    val pair = vision.detectTopBarColorFlagTabs(bmp, knownTabY = tabY, maxRightX = maxRightX)
                    realTabY = pair.first
                    foundFlags = pair.second
                    activePillColor = vision.detectActiveColorWatchlistFromTopPill(bmp)
                } finally {
                    bmp.recycle()
                }
                if (foundFlags.size >= slotIndex) break
                if (capTry == 0 && foundFlags.isEmpty() && cameFromOtherPage) {
                    gesture.sleepSafe(120L)
                } else {
                    break
                }
            }

            if (foundFlags.size < slotIndex) {
                AppStore.log("列表快切：当前仅检测到 ${foundFlags.size} 个颜色列表，不存在第${slotIndex}个，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }

            val chosenFlag = foundFlags[slotIndex - 1]
            targetX = chosenFlag.first
            targetY = realTabY
            targetColor = chosenFlag.second
            alreadyOnTarget = (activePillColor != null && activePillColor == chosenFlag.second)
        }

        if (shouldAbort()) return QuickJumpOutcome.FAILED

        if (!alreadyOnTarget) {
            val prevSyms = inspector.scanWatchlistSymbolsFromNodes().take(2).map { it.symbol }
            val clicked = (targetNode != null && gesture.clickNodeOrParent(targetNode)) ||
                gesture.dispatchTap(targetX.toFloat(), targetY.toFloat())
            if (!clicked) return QuickJumpOutcome.FAILED
            waitForAnyWatchlistChangeFast(prevSyms)
            gesture.markOwnActionJustFinished()
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED
        val tSwitch = SystemClock.uptimeMillis()

        scrollCurrentWatchlistToTopFast(targetSymbol = null)
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        var rows = inspector.scanWatchlistSymbolsFromNodes()
        if (rows.isEmpty()) {
            gesture.sleepSafe(65L)
            rows = inspector.scanWatchlistSymbolsFromNodes()
        }
        val firstRow = rows.firstOrNull()
        if (firstRow == null) {
            AppStore.log("列表快切：第${slotIndex}个颜色列表(${targetColor?.label ?: ""})内暂无品种，返回列表选择页")
            return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
        }

        val opened = clickRowToOpenChart(firstRow)
        if (opened) {
            val now = SystemClock.uptimeMillis()
            AppStore.log(
                "列表快切完成：${entry.displayName}(${targetColor?.label ?: ""}标) -> ${firstRow.symbol}" +
                    "（总${now - startMs}ms｜进表${tWatchlist - startMs}+切表${tSwitch - tWatchlist}+点图${now - tSwitch}）"
            )
            return QuickJumpOutcome.SUCCESS
        }
        return QuickJumpOutcome.FAILED
    }

    /**
     * 稳妥倒回顶部栏最左侧：
     * - 没看到 -1商（idx==0）时绝不轻信 canScrollLeft==false 提前退出，改用横滑拉到底
     * - 看到 -1商 后若其左侧仍有余量且还可左滚，补拉一次确保所有颜色小旗全部露在最左侧
     */
    private fun rewindTopTabBarToLeftmost(): Pair<List<TopTabNodeCandidate>, Int> {
        val (sw, sh) = screenSizeProvider()
        var (tabs, tabY) = inspector.findTopTabRowFromNodes()
        var unchangedCount = 0

        for (step in 0 until 6) {
            if (shouldAbort()) break
            val hasFirstCatalog = tabs.any { it.matchedCatalogIdx == 0 }
            val firstCatalog = tabs.firstOrNull { it.matchedCatalogIdx == 0 }
            val scrollBox = inspector.findTopTabScrollContainer(tabs)
            val canNativeBack = scrollBox?.actionList?.any { it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD } == true

            // 仅当已经看到 -1商 且（原生确认已到最左 或 已经拉过一次未再移动）才提前结束！
            if (hasFirstCatalog && scrollBox != null && !canNativeBack) {
                return tabs to tabY
            }
            if (firstCatalog != null && firstCatalog.info.leftX >= (sw * 0.48f).toInt()) {
                // -1商 已被 4~5 个颜色旗帜推到右半屏，必然已在最左侧，直接 0ms 结束！
                return tabs to tabY
            }

            val prevSig = tabs.joinToString("|") { "${it.info.name}:${it.info.leftX}" }
            var moved = false
            if (scrollBox != null && canNativeBack) {
                if (gesture.performNativeAction(scrollBox, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                    gesture.sleepSafe(60L)
                    moved = true
                }
            }
            if (!moved) {
                val effY = if (tabY > 0) tabY else (sh * 0.095f).toInt()
                if (!gesture.swipeTabBar(effY, swipeFingerRightToLeft = false, distanceFrac = 0.72f)) {
                    break
                }
                gesture.sleepSafe(40L)
            }

            val next = inspector.findTopTabRowFromNodes()
            tabs = next.first
            tabY = next.second
            val newSig = tabs.joinToString("|") { "${it.info.name}:${it.info.leftX}" }
            if (newSig == prevSig && newSig.isNotEmpty()) {
                unchangedCount++
                if (unchangedCount >= 1 && (hasFirstCatalog || tabs.isEmpty())) break
                if (unchangedCount >= 2) break
            } else {
                unchangedCount = 0
            }
        }
        return tabs to tabY
    }

    private fun waitForAnyWatchlistChangeFast(prevSyms: List<String>) {
        val anchor = prevSyms.firstOrNull()
        for (i in 0 until 12) {
            gesture.sleepSafe(22L)
            if (shouldAbort()) return
            if (anchor != null && !inspector.isSymbolVisibleOnScreenFast(anchor)) {
                gesture.sleepSafe(35L)
                return
            }
        }
    }

    private fun scrollCurrentWatchlistToTopFast(targetSymbol: String?) {
        if (!inspector.canWatchlistBodyScrollBackward()) return
        for (i in 0 until 4) {
            if (shouldAbort()) return
            if (!gesture.performFastScroll(scrollDown = false)) return
            gesture.sleepSafe(65L)
            if (targetSymbol != null && inspector.isSymbolVisibleOnScreenFast(targetSymbol)) {
                return
            }
            if (!inspector.canWatchlistBodyScrollBackward()) {
                return
            }
        }
    }

    // ==================== 模式 B：《品种大全》列表 -> 细分类别 -> 指定/首位品种直达图表 ====================

    private fun executeCatalogJump(entry: QuickJumpEntry): QuickJumpOutcome {
        val startMs = SystemClock.uptimeMillis()
        val (resolvedWl, autoSym) = CatalogRepository.findFirstSymbolForQuickJumpByIdOrName(
            entry.watchlistId,
            entry.watchlistName,
            entry.categoryName
        )
        val targetWl = resolvedWl ?: CatalogRepository.getWatchlistByName(entry.watchlistName)
        if (targetWl == null) {
            AppStore.log("列表快切失败：未在《品种大全》找到列表 ${entry.watchlistName}")
            return QuickJumpOutcome.FAILED
        }
        val targetSymbol = entry.targetSymbol.trim().uppercase()
            .ifBlank { autoSym ?: entry.fallbackSymbol }
        if (targetSymbol.isBlank()) {
            AppStore.log("列表快切失败：列表[${targetWl.name}]内暂无品种")
            return QuickJumpOutcome.FAILED
        }
        val isFirstOfWatchlist = targetWl.flattenInstruments().firstOrNull()?.symbol
            ?.equals(targetSymbol, ignoreCase = true) == true

        AppStore.log("列表快切启动：${entry.displayName} -> [${targetWl.name}] -> $targetSymbol")

        if (!ensureOnWatchlistPage()) {
            AppStore.log("列表快切中止：未能切到自选表页")
            return QuickJumpOutcome.FAILED
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED
        val tWatchlist = SystemClock.uptimeMillis()

        val switchWay = ensureOnTargetWatchlist(targetWl)
        if (switchWay == null || shouldAbort()) {
            if (!shouldAbort()) AppStore.log("列表快切失败：未能切至[${targetWl.name}]")
            return QuickJumpOutcome.FAILED
        }
        onWatchlistIdentified(targetWl.id)
        val tSwitch = SystemClock.uptimeMillis()

        val clickedRow = findAndClickTargetSymbol(targetWl, targetSymbol, isFirstOfWatchlist)
        if (clickedRow) {
            val now = SystemClock.uptimeMillis()
            AppStore.log(
                "列表快切完成：${entry.displayName} -> $targetSymbol" +
                    "（总${now - startMs}ms｜进表${tWatchlist - startMs}+切表[$switchWay]${tSwitch - tWatchlist}+点图${now - tSwitch}）"
            )
            return QuickJumpOutcome.SUCCESS
        } else if (!shouldAbort()) {
            AppStore.log("列表快切未找到目标品种：$targetSymbol（[${targetWl.name}]）")
        }
        return QuickJumpOutcome.FAILED
    }

    private fun isGenuineWatchlistNow(): Boolean {
        val r = inspector.findTradingViewRoot() ?: return false
        if (inspector.isExploreOrNewsPage(r) || inspector.isSymbolSearchPage(r)) return false
        return inspector.detectTradingViewPage(r, isBatchRunning = false) {} == TvPageState.WATCHLIST
    }

    private fun isOnChartPageNow(): Boolean {
        val r = inspector.findTradingViewRoot() ?: return false
        return inspector.detectTradingViewPage(r, isBatchRunning = false) {} == TvPageState.CHART
    }

    private fun ensureOnWatchlistPage(): Boolean {
        if (isGenuineWatchlistNow()) {
            return true
        }

        val (sw, sh) = screenSizeProvider()
        for (attempt in 0 until 2) {
            if (shouldAbort()) return false
            val clicked = if (attempt == 0) {
                // 直接点击底部最左侧“自选表”固定位置（0ms 免搜树，精准稳定）
                gesture.dispatchTap(sw * 0.10f, sh * 0.978f)
            } else {
                val rootNow = inspector.findTradingViewRoot() ?: return false
                val wlTab = inspector.findBottomNavTabNode(rootNow, "自选表", "Watchlist")
                (wlTab != null && gesture.clickNodeOrParent(wlTab)) || gesture.dispatchTap(sw * 0.10f, sh * 0.978f)
            }
            if (!clicked) return false

            gesture.sleepSafe(60L)
            for (i in 0 until 10) {
                if (shouldAbort()) return false
                if (isGenuineWatchlistNow()) {
                    gesture.sleepSafe(25L)
                    return true
                }
                gesture.sleepSafe(45L)
            }
        }
        return false
    }

    /**
     * 返回切表通道名（"已在" / "顶栏直点" / "≡抽屉" / "顶栏滑"），失败返回 null
     */
    private fun ensureOnTargetWatchlist(targetWl: CatalogWatchlist): String? {
        val (topTabs, topY) = inspector.findTopTabRowFromNodes()
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)

        // 0ms 直接用刚刚扫好的 topTabs 判定是否已在目标列表（绝不再重复扫第二遍 280 节点！）
        val alreadySelected = topTabs.any {
            it.matchedCatalogIdx == targetIdx && it.node != null && inspector.isNodeOrAncestorSelected(it.node)
        }
        if (alreadySelected) {
            return "已在"
        }

        // 通道 A：目标列表已在顶部栏可见 -> 1 次点击秒切（~100ms）
        val (sw, _) = screenSizeProvider()
        val directHit = topTabs.firstOrNull {
            it.matchedCatalogIdx == targetIdx &&
                it.info.centerX in (sw * 0.11f).toInt()..(sw * 0.95f).toInt()
        }
        if (directHit != null) {
            val (prevAnchor, prevSymSet) = snapshotPrevSwitchContext(targetWl)
            val clicked = (directHit.node != null && gesture.clickNodeOrParent(directHit.node)) ||
                gesture.dispatchTap(directHit.info.centerX.toFloat(), directHit.info.centerY.toFloat())
            if (clicked) {
                waitForTargetWatchlistRenderFast(prevAnchor, prevSymSet, targetWl)
                gesture.markOwnActionJustFinished()
                return "顶栏直点"
            }
        }

        // 通道 B：左上角 ≡ 列表抽屉 2 次点击直选（12 个列表全在首屏，彻底免疫 04备 等备份垃圾列表！）
        val (prevAnchor, prevSymSet) = snapshotPrevSwitchContext(targetWl)
        if (switchViaDrawerFast(targetWl, topY, prevAnchor, prevSymSet)) {
            return "≡抽屉"
        }

        // 通道 C：顶栏原生滚动 + 防垃圾列表横滑兜底
        if (switchViaTopBarFallback(targetWl, targetIdx, prevAnchor, prevSymSet)) {
            return "顶栏滑"
        }
        return null
    }

    private fun snapshotPrevSwitchContext(targetWl: CatalogWatchlist): Pair<String?, Set<String>> {
        val syms = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }
        val anchor = syms.firstOrNull { !CatalogRepository.isSymbolInWatchlist(it, targetWl.id) }
        return anchor to syms.toSet()
    }

    private fun switchViaDrawerFast(
        targetWl: CatalogWatchlist,
        knownTabY: Int,
        prevAnchor: String?,
        prevSymSet: Set<String>
    ): Boolean {
        if (shouldAbort()) return false
        if (!isGenuineWatchlistNow()) return false

        val (sw, sh) = screenSizeProvider()
        // 优先 0 截屏查找 ≡ 节点（即使 knownTabY == 0 也能直接搜顶部全带找到！）
        val hambNode = inspector.findHamburgerButtonNode(knownTabY)
        val opened = if (hambNode != null && gesture.clickNodeOrParent(hambNode)) {
            true
        } else {
            val approxY = if (knownTabY > 0) knownTabY else {
                captureScreen(1)?.let { bmp ->
                    try { vision.detectTabBarCenterY(bmp) } finally { bmp.recycle() }
                } ?: (sh * 0.095f).toInt()
            }
            gesture.dispatchTap(sw * 0.0423f, approxY.toFloat())
        }
        if (!opened) return false

        var foundItem: DrawerItemCandidate? = null
        var drawerOpened = false
        val waits = longArrayOf(22L, 25L, 30L, 35L, 40L, 50L, 60L, 70L)
        for (w in waits) {
            gesture.sleepSafe(w)
            if (shouldAbort()) return false
            if (!drawerOpened && inspector.isWatchlistDrawerOpen()) drawerOpened = true
            foundItem = inspector.findWatchlistInDrawer(targetWl)
            if (foundItem != null) break
        }

        val item = foundItem
        if (item != null) {
            val clicked = gesture.clickNodeOrParent(item.node) ||
                gesture.dispatchTap(item.centerX.toFloat(), item.centerY.toFloat())
            if (!clicked) return false

            for (i in 0 until 15) {
                gesture.sleepSafe(16L)
                if (shouldAbort()) return false
                if (!inspector.isWatchlistDrawerOpen()) break
            }
            waitForTargetWatchlistRenderFast(prevAnchor, prevSymSet, targetWl)
            gesture.markOwnActionJustFinished()
            return true
        }

        if (drawerOpened || inspector.isWatchlistDrawerOpen()) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            gesture.sleepSafe(100L)
            gesture.markOwnActionJustFinished()
        }
        return false
    }

    private fun switchViaTopBarFallback(
        targetWl: CatalogWatchlist,
        targetIdx: Int,
        prevAnchor: String?,
        prevSymSet: Set<String>
    ): Boolean {
        val totalWls = CatalogRepository.getWatchlists().size
        val lastCatalogIdx = (totalWls - 1).coerceAtLeast(0)
        val (sw, sh) = screenSizeProvider()
        val safeLeftX = (sw * 0.13f).toInt()
        val safeRightX = (sw * 0.93f).toInt()

        var prevSig = ""
        var stuck = 0

        for (step in 0 until 9) {
            if (shouldAbort()) return false
            val (tabs, tabY) = inspector.findTopTabRowFromNodes()
            val hit = tabs.firstOrNull { it.matchedCatalogIdx == targetIdx }
            if (hit != null) {
                val ok = (hit.node != null && gesture.clickNodeOrParent(hit.node)) ||
                    gesture.dispatchTap(hit.info.centerX.coerceIn(safeLeftX, safeRightX).toFloat(), tabY.toFloat())
                if (ok) {
                    waitForTargetWatchlistRenderFast(prevAnchor, prevSymSet, targetWl)
                    gesture.markOwnActionJustFinished()
                    return true
                }
            }

            val sig = tabs.joinToString("|") { "${it.info.name}:${it.matchedCatalogIdx}" }
            if (sig == prevSig && sig.isNotEmpty()) {
                stuck++
                if (stuck >= 3) return false
            } else {
                stuck = 0
                prevSig = sig
            }

            val known = tabs.map { it.matchedCatalogIdx }.filter { it >= 0 }
            val hasGarbage = tabs.any { it.matchedCatalogIdx < 0 }
            val seesLast = known.any { it >= lastCatalogIdx }
            val goRightToLeft = when {
                known.isEmpty() -> false
                seesLast && targetIdx < lastCatalogIdx -> false
                hasGarbage && known.max() >= lastCatalogIdx - 1 && targetIdx < known.min() -> false
                known.min() > targetIdx -> false
                known.max() < targetIdx -> true
                else -> targetIdx > known.average()
            }

            if (stuck == 0) {
                val scrollBox = inspector.findTopTabScrollContainer(tabs)
                if (scrollBox != null) {
                    val act = if (goRightToLeft) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    if (gesture.performNativeAction(scrollBox, act)) {
                        gesture.sleepSafe(55L)
                        continue
                    }
                }
            }

            val effY = if (tabY > 0) tabY else (sh * 0.095f).toInt()
            if (!gesture.swipeTabBar(effY, swipeFingerRightToLeft = goRightToLeft, distanceFrac = 0.60f)) {
                return false
            }
        }
        return false
    }

    /**
     * 极速 2ms 原生等待新列表渲染（绝不在循环里做 280 节点全树遍历！彻底消灭 3.3 秒死等！）
     */
    private fun waitForTargetWatchlistRenderFast(
        prevAnchor: String?,
        prevSymSet: Set<String>,
        targetWl: CatalogWatchlist
    ) {
        // 排除切表前已经可见的共享代码（如 SAP 同时在欧概/欧股），防止还没切完就提前退出！
        val freshTargetSyms = targetWl.flattenInstruments()
            .map { it.symbol }
            .filter { it !in prevSymSet }
            .take(3)
        for (i in 0 until 14) {
            gesture.sleepSafe(20L)
            if (shouldAbort()) return
            if (prevAnchor != null && !inspector.isSymbolVisibleOnScreenFast(prevAnchor)) {
                gesture.sleepSafe(35L)
                return
            }
            if (freshTargetSyms.isNotEmpty() && freshTargetSyms.any { inspector.isSymbolVisibleOnScreenFast(it) }) {
                return
            }
        }
    }

    private fun findAndClickTargetSymbol(
        targetWl: CatalogWatchlist,
        targetSymbol: String,
        isFirstOfWatchlist: Boolean
    ): Boolean {
        // 1) 0 翻屏秒查：目标品种就在当前屏 -> 2ms 直接点进图表！
        val instantHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
        if (instantHit != null) {
            return clickRowToOpenChart(instantHit)
        }

        // 2) 若目标是“本列表最顶部的第 1 个品种”：直接极速回顶后点击，免去一次冗余整屏扫！
        if (isFirstOfWatchlist) {
            scrollCurrentWatchlistToTopFast(targetSymbol = targetSymbol)
            if (shouldAbort()) return false
            val topHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                ?: inspector.scanWatchlistSymbolsFromNodes().firstOrNull()
            if (topHit != null) {
                return clickRowToOpenChart(topHit)
            }
            return false
        }

        // 3) 列表中部目标（如 中一->700 / 欧股-法它->MC / 亚股->8035）：零惯性精准翻屏查找
        val firstRows = inspector.scanWatchlistSymbolsFromNodes()
        val matchInFirst = firstRows.firstOrNull { vision.findMatchingTaskKey(it.symbol, setOf(targetSymbol)) != null }
        if (matchInFirst != null) {
            return clickRowToOpenChart(matchInFirst)
        }

        val symbolOrders = CatalogRepository.getSymbolOrdersInWatchlist(targetWl.id)
        val targetOrder = symbolOrders[targetSymbol.uppercase()]?.firstOrNull() ?: 0
        val visIndices = firstRows.flatMap { symbolOrders[it.symbol].orEmpty() }
        val visMin = visIndices.minOrNull()
        val visMax = visIndices.maxOrNull()

        val primaryDown: Boolean = when {
            visMin != null && targetOrder < visMin -> false
            visMax != null && targetOrder > visMax -> true
            else -> true
        }

        val directions = listOf(primaryDown, !primaryDown)
        val expandedKeys = HashSet<String>()

        for ((dirIdx, goDown) in directions.withIndex()) {
            if (shouldAbort()) return false

            var prevHead = if (dirIdx == 0) firstRows.take(3).map { it.symbol } else emptyList()
            var sameCount = 0

            for (scrollStep in 0 until 26) {
                if (shouldAbort()) return false

                if (!gesture.performControlledScroll(scrollDown = goDown, stronger = (sameCount > 0))) {
                    return false
                }
                gesture.sleepSafe(20L)
                if (shouldAbort()) return false

                // 2ms 原生直查目标品种，命中立刻进图表！
                val hit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                if (hit != null) {
                    return clickRowToOpenChart(hit)
                }

                val rows = inspector.scanWatchlistSymbolsFromNodes()
                val matchRow = rows.firstOrNull { vision.findMatchingTaskKey(it.symbol, setOf(targetSymbol)) != null }
                if (matchRow != null) {
                    return clickRowToOpenChart(matchRow)
                }

                val rowOrds = rows.flatMap { symbolOrders[it.symbol].orEmpty() }
                val rMin = rowOrds.minOrNull()
                val rMax = rowOrds.maxOrNull()
                if (rMin != null && rMax != null && targetOrder in (rMin - 2)..(rMax + 2)) {
                    val dummyTask = PendingTask(
                        key = "JUMP::$targetSymbol",
                        symbol = targetSymbol,
                        color = MarkColor.RED,
                        preferredWatchlistId = targetWl.id
                    )
                    val collapsed = inspector.findCollapsedSectionHeaders(rows, listOf(dummyTask), targetWl)
                    for (sec in collapsed) {
                        val k = "${targetWl.id}::${sec.text}"
                        if (!expandedKeys.add(k)) continue
                        gesture.clickNodeOrParent(sec.node) || gesture.dispatchTap(sec.centerX.toFloat(), sec.centerY.toFloat())
                        gesture.sleepSafe(110L)
                        val afterHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                        if (afterHit != null) return clickRowToOpenChart(afterHit)
                    }
                }

                val curHead = rows.take(3).map { it.symbol }
                if (curHead.isNotEmpty() && curHead == prevHead) {
                    sameCount++
                    if (sameCount >= 2) break
                    continue
                }
                sameCount = 0
                prevHead = curHead
            }
        }
        return false
    }

    private fun clickRowToOpenChart(row: WatchlistRow): Boolean {
        if (shouldAbort()) return false
        val (sw, sh) = screenSizeProvider()
        val topSafe = (sh * 0.105f).toInt()
        val botSafe = (sh * 0.905f).toInt()

        var liveRow = inspector.fastFindPendingRowsByText(listOf(row.symbol))
            .minByOrNull { abs(it.centerY - row.centerY) }
            ?: row

        // 仅当目标行确实紧贴边缘被顶栏/底栏遮挡时才微移进安全区
        if (liveRow.centerY < topSafe || liveRow.centerY > botSafe) {
            val nudgeDown = liveRow.centerY > botSafe
            val y1 = if (nudgeDown) sh * 0.65f else sh * 0.45f
            val y2 = if (nudgeDown) sh * 0.49f else sh * 0.61f
            val p = Path().apply { moveTo(sw * 0.48f, y1); lineTo(sw * 0.48f, y2) }
            gesture.dispatchGestureSync(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0L, 180L, false)).build())
            gesture.sleepSafe(85L)
            liveRow = inspector.fastFindPendingRowsByText(listOf(row.symbol))
                .minByOrNull { abs(it.centerY - row.centerY) }
                ?: liveRow
        }

        val safeY = liveRow.centerY.coerceIn(topSafe, botSafe)
        val clickPoints = listOf(
            liveRow.centerX.toFloat() to safeY.toFloat(),
            (sw * 0.42f) to safeY.toFloat()
        )

        for ((attemptIdx, pt) in clickPoints.withIndex()) {
            if (shouldAbort()) return false
            val rn = liveRow.rowNode
            val ok = if (attemptIdx == 1 && rn != null) {
                gesture.clickNodeOrParent(rn) || gesture.dispatchTap(pt.first, pt.second)
            } else {
                gesture.dispatchTap(pt.first, pt.second)
            }
            if (!ok) continue

            gesture.sleepSafe(65L)
            for (i in 0 until 9) {
                if (shouldAbort()) return true
                if (isOnChartPageNow()) {
                    return true
                }
                gesture.sleepSafe(45L)
            }
        }
        return false
    }
}
