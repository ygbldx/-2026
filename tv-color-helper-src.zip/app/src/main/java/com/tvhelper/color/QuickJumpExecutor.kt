package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

enum class QuickJumpOutcome {
    SUCCESS,
    COLOR_LIST_NOT_FOUND,
    FAILED
}

/**
 * 独立的“探索栏快切列表直达图表”执行引擎（与原标色 WatchlistExecutor 完全解耦）：
 * - 支持“第一颜色 / 第二颜色 / ...”：倒回顶部栏最左侧 -> 精准识别第 N 个颜色列表 -> 点进其最上方品种图表；
 *   若不存在第 N 个颜色列表，直接返回 COLOR_LIST_NOT_FOUND 立即重新弹出列表选择页！
 * - 支持“《品种大全》列表 -> 可选细分类别 -> 可选指定品种（或自动取首位品种）”极速直达图表页！
 */
class QuickJumpExecutor(
    private val service: AccessibilityService,
    private val vision: VisionEngine,
    private val inspector: NodeInspector,
    private val gesture: GestureDriver,
    private val screenSizeProvider: () -> Pair<Int, Int>,
    private val captureScreen: (Int) -> Bitmap?,
    private val shouldAbort: () -> Boolean,
    private val onWatchlistIdentified: (String) -> Unit
) {

    fun executeJump(entry: QuickJumpEntry): QuickJumpOutcome {
        return when (entry.targetType) {
            QuickJumpTargetType.COLOR_SLOT -> executeColorSlotJump(entry)
            QuickJumpTargetType.CATALOG_TARGET -> executeCatalogJump(entry)
        }
    }

    // ==================== 模式 A：顶部最左侧第 N 个颜色列表直达首品种图表 ====================

    private fun executeColorSlotJump(entry: QuickJumpEntry): QuickJumpOutcome {
        val startMs = SystemClock.uptimeMillis()
        val slotIndex = entry.colorSlotIndex.coerceIn(1, 7)
        AppStore.log("列表快切启动：${entry.displayName}（顶部最左侧第${slotIndex}个颜色列表）")

        // 1) 确保处于自选表页
        if (!ensureOnWatchlistPage()) {
            AppStore.log("列表快切中止：未能切到自选表页")
            return QuickJumpOutcome.FAILED
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        // 2) 将顶部列表栏倒回最左侧（如果已在最左侧，0ms 零滑动！）
        val (leftTabs, tabY) = rewindTopTabBarToLeftmost()
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        // 3) 检测最左侧的所有颜色列表标签（优先节点文字直查，其次像素精准识别纯彩色小旗图标）
        val firstCatalogTab = leftTabs.firstOrNull { it.matchedCatalogIdx >= 0 }
        val maxRightX = if (firstCatalogTab != null) {
            (firstCatalogTab.info.left - 4).coerceAtLeast(0)
        } else {
            0
        }

        // 3a) 先查是否有带文字的颜色列表节点
        val nodeColorTabs = leftTabs
            .filter { inspector.parseColorWatchlistName(it.info.name) != null }
            .sortedBy { it.info.centerX }

        var targetX = -1
        var targetY = tabY
        var targetNode: AccessibilityNodeInfo? = null
        var targetColor: MarkColor? = null
        var alreadyOnTarget = false

        if (nodeColorTabs.isNotEmpty()) {
            if (nodeColorTabs.size < slotIndex) {
                AppStore.log("列表快切：当前仅有 ${nodeColorTabs.size} 个颜色列表，不存在第${slotIndex}个，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }
            val chosen = nodeColorTabs[slotIndex - 1]
            targetX = chosen.info.centerX
            targetY = chosen.info.centerY
            targetNode = chosen.node
            targetColor = inspector.parseColorWatchlistName(chosen.info.name)
            alreadyOnTarget = chosen.node != null && inspector.isNodeOrAncestorSelected(chosen.node)
        } else {
            // 3b) TradingView 顶部最左侧为纯彩色小旗图标（无文字）：如果 -1商 已紧贴 ≡ 按钮左侧（无空隙），说明 0 个颜色列表
            val (sw, _) = screenSizeProvider()
            if (firstCatalogTab != null && firstCatalogTab.info.left < (sw * 0.145f).toInt()) {
                AppStore.log("列表快切：顶部栏最左侧无任何颜色列表，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }

            val bmp = captureScreen(2)
            if (bmp == null) {
                AppStore.log("列表快切：未能读取顶部颜色列表栏，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }
            val detectedPair: Pair<Int, List<Pair<Int, MarkColor>>>
            val activePillColor: MarkColor?
            try {
                detectedPair = vision.detectTopBarColorFlagTabs(bmp, knownTabY = tabY, maxRightX = maxRightX)
                activePillColor = vision.detectActiveColorWatchlistFromTopPill(bmp)
            } finally {
                bmp.recycle()
            }

            val (realTabY, flagTabs) = detectedPair
            if (flagTabs.size < slotIndex) {
                AppStore.log("列表快切：当前仅检测到 ${flagTabs.size} 个颜色列表，不存在第${slotIndex}个，返回列表选择页")
                return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
            }

            val chosenFlag = flagTabs[slotIndex - 1]
            targetX = chosenFlag.first
            targetY = realTabY
            targetColor = chosenFlag.second
            alreadyOnTarget = (activePillColor != null && activePillColor == chosenFlag.second)
        }

        if (shouldAbort()) return QuickJumpOutcome.FAILED

        // 4) 若尚未在该颜色列表，点击切入并等待列表渲染
        if (!alreadyOnTarget) {
            val prevSyms = inspector.scanWatchlistSymbolsFromNodes().map { it.symbol }
            val clicked = (targetNode != null && gesture.clickNodeOrParent(targetNode)) ||
                gesture.dispatchTap(targetX.toFloat(), targetY.toFloat())
            if (!clicked) return QuickJumpOutcome.FAILED
            waitForAnyWatchlistChange(prevSyms)
            gesture.markOwnActionJustFinished()
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        // 5) 确保已处于该颜色列表最顶部（若不在顶则极速回顶；已在顶 0ms 不滑！）
        scrollCurrentWatchlistToTopIfNeeded()
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        // 6) 读取最上方的第 1 个品种并单击直入图表页
        var rows = inspector.scanWatchlistSymbolsFromNodes()
        if (rows.isEmpty()) {
            gesture.sleepSafe(70L)
            rows = inspector.scanWatchlistSymbolsFromNodes()
        }
        val firstRow = rows.firstOrNull()
        if (firstRow == null) {
            AppStore.log("列表快切：第${slotIndex}个颜色列表(${targetColor?.label ?: ""})内暂无品种，返回列表选择页")
            return QuickJumpOutcome.COLOR_LIST_NOT_FOUND
        }

        val opened = clickRowToOpenChart(firstRow)
        if (opened) {
            val elapsed = SystemClock.uptimeMillis() - startMs
            AppStore.log("列表快切完成：${entry.displayName}(${targetColor?.label ?: ""}标) -> ${firstRow.symbol}（用时 ${elapsed}ms）")
            return QuickJumpOutcome.SUCCESS
        }
        return QuickJumpOutcome.FAILED
    }

    private fun rewindTopTabBarToLeftmost(): Pair<List<TopTabNodeCandidate>, Int> {
        val (sw, sh) = screenSizeProvider()
        var (tabs, tabY) = inspector.findTopTabRowFromNodes()

        for (step in 0 until 5) {
            if (shouldAbort()) break
            val scrollBox = inspector.findTopTabScrollContainer(tabs)
            if (scrollBox != null) {
                val canScrollLeft = scrollBox.actionList.any { it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD }
                if (!canScrollLeft) {
                    // 已经处于顶部栏绝对最左侧，0ms 直接返回！
                    return tabs to tabY
                }
                val prevSig = tabs.joinToString("|") { "${it.info.name}:${it.info.left}" }
                if (gesture.performNativeAction(scrollBox, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                    gesture.sleepSafe(75L)
                    val next = inspector.findTopTabRowFromNodes()
                    tabs = next.first
                    tabY = next.second
                    val newSig = tabs.joinToString("|") { "${it.info.name}:${it.info.left}" }
                    if (newSig == prevSig) break
                    continue
                }
            }

            // 若无原生容器：如果已看到 -1商 且其位置已在左半屏附近，检查一次左滑是否仍能拉动
            val firstCat = tabs.firstOrNull { it.matchedCatalogIdx == 0 }
            if (firstCat != null && firstCat.info.left < (sw * 0.20f).toInt()) {
                return tabs to tabY
            }
            val prevSig = tabs.joinToString("|") { "${it.info.name}:${it.info.left}" }
            val effY = if (tabY > 0) tabY else (sh * 0.095f).toInt()
            if (!gesture.swipeTabBar(effY, swipeFingerRightToLeft = false, distanceFrac = 0.70f)) {
                break
            }
            gesture.sleepSafe(45L)
            val next = inspector.findTopTabRowFromNodes()
            tabs = next.first
            tabY = next.second
            val newSig = tabs.joinToString("|") { "${it.info.name}:${it.info.left}" }
            if (newSig == prevSig) break
        }
        return tabs to tabY
    }

    private fun waitForAnyWatchlistChange(prevSyms: List<String>) {
        val anchor = prevSyms.firstOrNull()
        for (i in 0 until 12) {
            gesture.sleepSafe(22L)
            if (shouldAbort()) return
            if (anchor != null && !inspector.isSymbolVisibleOnScreenFast(anchor)) {
                gesture.sleepSafe(40L)
                return
            }
            val nowHead = inspector.scanWatchlistSymbolsFromNodes().take(2).map { it.symbol }
            if (nowHead.isNotEmpty() && nowHead != prevSyms.take(2)) {
                return
            }
        }
    }

    private fun scrollCurrentWatchlistToTopIfNeeded() {
        if (!inspector.canWatchlistBodyScrollBackward()) return
        var prevHead = inspector.scanWatchlistSymbolsFromNodes().take(2).map { it.symbol }
        for (i in 0 until 8) {
            if (shouldAbort()) return
            if (!inspector.canWatchlistBodyScrollBackward()) return
            if (!gesture.performFastScroll(scrollDown = false)) return
            gesture.sleepSafe(65L)
            val nowHead = inspector.scanWatchlistSymbolsFromNodes().take(2).map { it.symbol }
            if (nowHead.isNotEmpty() && nowHead == prevHead) break
            prevHead = nowHead
        }
    }

    // ==================== 模式 B：《品种大全》列表 -> 细分类别 -> 指定/首位品种直达图表 ====================

    private fun executeCatalogJump(entry: QuickJumpEntry): QuickJumpOutcome {
        val startMs = SystemClock.uptimeMillis()
        val (resolvedWl, autoSym) = CatalogRepository.findFirstSymbolForQuickJumpByIdOrName(
            entry.watchlistId,
            entry.watchlistName,
            entry.categoryName
        )
        val targetWl = resolvedWl ?: CatalogRepository.getWatchlistByName(entry.watchlistName)
        if (targetWl == null) {
            AppStore.log("列表快切失败：未在《品种大全》找到列表 ${entry.watchlistName}")
            return QuickJumpOutcome.FAILED
        }
        val targetSymbol = entry.targetSymbol.trim().uppercase()
            .ifBlank { autoSym ?: entry.fallbackSymbol }
        if (targetSymbol.isBlank()) {
            AppStore.log("列表快切失败：列表[${targetWl.name}]内暂无品种")
            return QuickJumpOutcome.FAILED
        }
        val isFirstOfWatchlist = targetWl.flattenInstruments().firstOrNull()?.symbol
            ?.equals(targetSymbol, ignoreCase = true) == true

        AppStore.log("列表快切启动：${entry.displayName} -> [${targetWl.name}] -> $targetSymbol")

        if (!ensureOnWatchlistPage()) {
            AppStore.log("列表快切中止：未能切到自选表页")
            return QuickJumpOutcome.FAILED
        }
        if (shouldAbort()) return QuickJumpOutcome.FAILED

        val switched = ensureOnTargetWatchlist(targetWl)
        if (!switched || shouldAbort()) {
            if (!shouldAbort()) AppStore.log("列表快切失败：未能切至[${targetWl.name}]")
            return QuickJumpOutcome.FAILED
        }
        onWatchlistIdentified(targetWl.id)

        val clickedRow = findAndClickTargetSymbol(targetWl, targetSymbol, isFirstOfWatchlist)
        if (clickedRow) {
            val elapsed = SystemClock.uptimeMillis() - startMs
            AppStore.log("列表快切完成：${entry.displayName} -> $targetSymbol（用时 ${elapsed}ms）")
            return QuickJumpOutcome.SUCCESS
        } else if (!shouldAbort()) {
            AppStore.log("列表快切未找到目标品种：$targetSymbol（[${targetWl.name}]）")
        }
        return QuickJumpOutcome.FAILED
    }

    private fun ensureOnWatchlistPage(): Boolean {
        val root0 = inspector.findTradingViewRoot() ?: return false
        val state0 = inspector.detectTradingViewPage(root0, isBatchRunning = false) {}
        if (state0 == TvPageState.WATCHLIST) return true

        val (sw, sh) = screenSizeProvider()
        val wlTab = inspector.findBottomNavTabNode(root0, "自选表", "Watchlist")
        val clicked = (wlTab != null && gesture.clickNodeOrParent(wlTab)) ||
            gesture.dispatchTap(sw * 0.10f, sh * 0.972f)
        if (!clicked) return false

        for (i in 0 until 24) {
            gesture.sleepSafe(20L)
            if (shouldAbort()) return false
            val r = inspector.findTradingViewRoot() ?: continue
            val st = inspector.detectTradingViewPage(r, isBatchRunning = false) {}
            if (st == TvPageState.WATCHLIST) {
                for (w in 0 until 4) {
                    if (inspector.scanWatchlistSymbolsFromNodes().isNotEmpty() || inspector.findTopTabRowFromNodes().first.isNotEmpty()) {
                        return true
                    }
                    gesture.sleepSafe(20L)
                }
                return true
            }
        }
        return false
    }

    private fun ensureOnTargetWatchlist(targetWl: CatalogWatchlist): Boolean {
        val (topTabs, topY) = inspector.findTopTabRowFromNodes()
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)

        val activeTop = inspector.detectActiveWatchlistFromTopNodes()
        if (activeTop?.id == targetWl.id) {
            return true
        }
        val activeColor = inspector.detectActiveColorWatchlistFromTopNodes()
        val currentRows = inspector.scanWatchlistSymbolsFromNodes()
        val prevSymbols = currentRows.map { it.symbol }
        if (activeTop == null && activeColor == null && prevSymbols.size >= 3) {
            val bySyms = CatalogRepository.identifyWatchlistByVisibleSymbols(prevSymbols)
            if (bySyms?.id == targetWl.id) {
                return true
            }
        }

        val (sw, _) = screenSizeProvider()
        val directHit = topTabs.firstOrNull {
            it.matchedCatalogIdx == targetIdx &&
                it.info.centerX in (sw * 0.11f).toInt()..(sw * 0.95f).toInt()
        }
        if (directHit != null) {
            val clicked = (directHit.node != null && gesture.clickNodeOrParent(directHit.node)) ||
                gesture.dispatchTap(directHit.info.centerX.toFloat(), directHit.info.centerY.toFloat())
            if (clicked) {
                waitForTargetWatchlistRender(prevSymbols, targetWl)
                gesture.markOwnActionJustFinished()
                return true
            }
        }

        if (switchViaDrawerFast(targetWl, topY)) {
            return true
        }

        return switchViaTopBarFallback(targetWl, targetIdx, prevSymbols)
    }

    private fun switchViaDrawerFast(targetWl: CatalogWatchlist, knownTabY: Int): Boolean {
        if (shouldAbort()) return false
        val (sw, sh) = screenSizeProvider()
        val approxY = if (knownTabY > 0) knownTabY else {
            captureScreen(1)?.let { bmp ->
                try { vision.detectTabBarCenterY(bmp) } finally { bmp.recycle() }
            } ?: (sh * 0.095f).toInt()
        }

        val hambNode = inspector.findHamburgerButtonNode(approxY)
        val opened = (hambNode != null && gesture.clickNodeOrParent(hambNode)) ||
            gesture.dispatchTap(sw * 0.0423f, approxY.toFloat())
        if (!opened) return false

        var foundItem: DrawerItemCandidate? = null
        var drawerOpened = false
        val waits = longArrayOf(20L, 25L, 30L, 35L, 40L, 45L, 55L)
        for (w in waits) {
            gesture.sleepSafe(w)
            if (shouldAbort()) return false
            if (!drawerOpened && inspector.isWatchlistDrawerOpen()) drawerOpened = true
            foundItem = inspector.findWatchlistInDrawer(targetWl)
            if (foundItem != null) break
        }

        val item = foundItem
        if (item != null) {
            val clicked = gesture.clickNodeOrParent(item.node) ||
                gesture.dispatchTap(item.centerX.toFloat(), item.centerY.toFloat())
            if (!clicked) return false

            for (i in 0 until 15) {
                gesture.sleepSafe(18L)
                if (shouldAbort()) return false
                if (!inspector.isWatchlistDrawerOpen()) break
            }
            val checkSyms = targetWl.flattenInstruments().take(3).map { it.symbol }
            for (i in 0 until 12) {
                if (shouldAbort()) return false
                if (checkSyms.any { inspector.isSymbolVisibleOnScreenFast(it) } ||
                    inspector.scanWatchlistSymbolsFromNodes().isNotEmpty()
                ) {
                    gesture.sleepSafe(25L)
                    break
                }
                gesture.sleepSafe(20L)
            }
            gesture.markOwnActionJustFinished()
            return true
        }

        if (drawerOpened || inspector.isWatchlistDrawerOpen()) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            gesture.sleepSafe(110L)
            gesture.markOwnActionJustFinished()
        }
        return false
    }

    private fun switchViaTopBarFallback(
        targetWl: CatalogWatchlist,
        targetIdx: Int,
        prevSymbols: List<String>
    ): Boolean {
        val (sw, sh) = screenSizeProvider()
        val safeLeftX = (sw * 0.13f).toInt()
        val safeRightX = (sw * 0.93f).toInt()
        for (step in 0 until 8) {
            if (shouldAbort()) return false
            val (tabs, tabY) = inspector.findTopTabRowFromNodes()
            val hit = tabs.firstOrNull { it.matchedCatalogIdx == targetIdx }
            if (hit != null) {
                val ok = (hit.node != null && gesture.clickNodeOrParent(hit.node)) ||
                    gesture.dispatchTap(hit.info.centerX.coerceIn(safeLeftX, safeRightX).toFloat(), tabY.toFloat())
                if (ok) {
                    waitForTargetWatchlistRender(prevSymbols, targetWl)
                    gesture.markOwnActionJustFinished()
                    return true
                }
            }
            val known = tabs.map { it.matchedCatalogIdx }.filter { it >= 0 }
            val goRightToLeft = when {
                known.isEmpty() -> false
                known.min() > targetIdx -> false
                known.max() < targetIdx -> true
                else -> targetIdx > known.average()
            }
            val effY = if (tabY > 0) tabY else (sh * 0.095f).toInt()
            if (!gesture.swipeTabBar(effY, swipeFingerRightToLeft = goRightToLeft, distanceFrac = 0.58f)) {
                return false
            }
        }
        return false
    }

    private fun waitForTargetWatchlistRender(prevSymbols: List<String>, targetWl: CatalogWatchlist) {
        val prevAnchor = prevSymbols.firstOrNull { !CatalogRepository.isSymbolInWatchlist(it, targetWl.id) }
            ?: prevSymbols.firstOrNull()
        val targetSyms = targetWl.flattenInstruments().take(3).map { it.symbol }
        for (i in 0 until 14) {
            gesture.sleepSafe(20L)
            if (shouldAbort()) return
            if (prevAnchor != null && !inspector.isSymbolVisibleOnScreenFast(prevAnchor)) {
                gesture.sleepSafe(35L)
                return
            }
            if (targetSyms.any { inspector.isSymbolVisibleOnScreenFast(it) }) {
                return
            }
        }
    }

    private fun findAndClickTargetSymbol(
        targetWl: CatalogWatchlist,
        targetSymbol: String,
        isFirstOfWatchlist: Boolean
    ): Boolean {
        val instantHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
        if (instantHit != null) {
            return clickRowToOpenChart(instantHit)
        }

        val firstRows = inspector.scanWatchlistSymbolsFromNodes()
        val matchInFirst = firstRows.firstOrNull { vision.findMatchingTaskKey(it.symbol, setOf(targetSymbol)) != null }
        if (matchInFirst != null) {
            return clickRowToOpenChart(matchInFirst)
        }

        val symbolOrders = CatalogRepository.getSymbolOrdersInWatchlist(targetWl.id)
        val targetOrder = symbolOrders[targetSymbol.uppercase()]?.firstOrNull() ?: 0
        val visIndices = firstRows.flatMap { symbolOrders[it.symbol].orEmpty() }
        val visMin = visIndices.minOrNull()
        val visMax = visIndices.maxOrNull()

        val primaryDown: Boolean = when {
            isFirstOfWatchlist -> false
            visMin != null && targetOrder < visMin -> false
            visMax != null && targetOrder > visMax -> true
            else -> true
        }
        val estDist: Int = when {
            !primaryDown && visMin != null -> (visMin - targetOrder).coerceAtLeast(0)
            primaryDown && visMax != null -> (targetOrder - visMax).coerceAtLeast(0)
            else -> 0
        }

        val directions = listOf(primaryDown, !primaryDown)
        val expandedKeys = HashSet<String>()

        for ((dirIdx, goDown) in directions.withIndex()) {
            if (shouldAbort()) return false

            var jumped = false
            if (dirIdx == 0 && estDist >= 14) {
                val jumps = ((estDist - 8) / 11).coerceIn(1, 5)
                for (j in 0 until jumps) {
                    if (shouldAbort()) return false
                    if (!gesture.performFastScroll(scrollDown = goDown)) return false
                    gesture.sleepSafe(48L)
                }
                gesture.sleepSafe(50L)
                jumped = true
            }

            var prevNames = if (dirIdx == 0 && !jumped) firstRows.map { it.symbol } else emptyList()
            var sameCount = 0

            for (scrollStep in 0 until 40) {
                if (shouldAbort()) return false

                if (jumped && scrollStep == 0) {
                    jumped = false
                } else {
                    if (!gesture.performControlledScroll(scrollDown = goDown, stronger = (sameCount > 0))) {
                        return false
                    }
                    gesture.sleepSafe(26L)
                    if (shouldAbort()) return false
                }

                val hit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                if (hit != null) {
                    return clickRowToOpenChart(hit)
                }

                val rows = inspector.scanWatchlistSymbolsFromNodes()
                val matchRow = rows.firstOrNull { vision.findMatchingTaskKey(it.symbol, setOf(targetSymbol)) != null }
                if (matchRow != null) {
                    return clickRowToOpenChart(matchRow)
                }

                val rowOrds = rows.flatMap { symbolOrders[it.symbol].orEmpty() }
                val rMin = rowOrds.minOrNull()
                val rMax = rowOrds.maxOrNull()
                if (rMin != null && rMax != null && targetOrder in (rMin - 2)..(rMax + 2)) {
                    val dummyTask = PendingTask(
                        key = "JUMP::$targetSymbol",
                        symbol = targetSymbol,
                        color = MarkColor.RED,
                        preferredWatchlistId = targetWl.id
                    )
                    val collapsed = inspector.findCollapsedSectionHeaders(rows, listOf(dummyTask), targetWl)
                    for (sec in collapsed) {
                        val k = "${targetWl.id}::${sec.text}"
                        if (!expandedKeys.add(k)) continue
                        gesture.clickNodeOrParent(sec.node) || gesture.dispatchTap(sec.centerX.toFloat(), sec.centerY.toFloat())
                        gesture.sleepSafe(110L)
                        val afterHit = inspector.fastFindPendingRowsByText(listOf(targetSymbol)).firstOrNull()
                        if (afterHit != null) return clickRowToOpenChart(afterHit)
                    }
                }

                val names = rows.map { it.symbol }
                if (names.isNotEmpty() && names == prevNames) {
                    sameCount++
                    if (sameCount >= 2) {
                        if (isFirstOfWatchlist && !goDown && rows.isNotEmpty()) {
                            return clickRowToOpenChart(rows.first())
                        }
                        break
                    }
                    continue
                }
                sameCount = 0
                prevNames = names
            }
        }
        return false
    }

    private fun clickRowToOpenChart(row: WatchlistRow): Boolean {
        if (shouldAbort()) return false
        val (_, sh) = screenSizeProvider()
        val liveRow = inspector.fastFindPendingRowsByText(listOf(row.symbol))
            .minByOrNull { abs(it.centerY - row.centerY) }
            ?: row
        val safeY = liveRow.centerY.coerceIn((sh * 0.09f).toInt(), (sh * 0.925f).toInt())

        val tapped = gesture.dispatchTap(liveRow.centerX.toFloat(), safeY.toFloat())
        if (!tapped) return false

        for (i in 0 until 10) {
            gesture.sleepSafe(24L)
            if (shouldAbort()) return true
            val root = inspector.findTradingViewRoot() ?: continue
            if (inspector.detectTradingViewPage(root, isBatchRunning = false) {} == TvPageState.CHART) {
                return true
            }
        }
        if (liveRow.rowNode != null) {
            gesture.clickNodeOrParent(liveRow.rowNode)
        } else {
            gesture.dispatchTap(liveRow.centerX.toFloat(), safeY.toFloat())
        }
        gesture.sleepSafe(120L)
        return true
    }
}
