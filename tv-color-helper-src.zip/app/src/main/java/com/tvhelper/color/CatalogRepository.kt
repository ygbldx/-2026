package com.tvhelper.color

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import kotlin.math.abs

sealed class CatalogNode {
    abstract val id: String

    data class Category(
        override val id: String = UUID.randomUUID().toString(),
        var name: String,
        val children: MutableList<CatalogNode> = mutableListOf()
    ) : CatalogNode() {
        fun flattenInstruments(): List<Instrument> {
            val out = ArrayList<Instrument>()
            fun walk(nodes: List<CatalogNode>) {
                for (n in nodes) {
                    when (n) {
                        is Instrument -> out.add(n)
                        is Category -> walk(n.children)
                    }
                }
            }
            walk(children)
            return out
        }
    }

    data class Instrument(
        override val id: String = UUID.randomUUID().toString(),
        var symbol: String,
        var cnName: String = "",
        var source: String = ""
    ) : CatalogNode()
}

data class CatalogWatchlist(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val children: MutableList<CatalogNode> = mutableListOf()
) {
    fun flattenInstruments(): List<CatalogNode.Instrument> {
        val out = ArrayList<CatalogNode.Instrument>()
        fun walk(nodes: List<CatalogNode>) {
            for (n in nodes) {
                when (n) {
                    is CatalogNode.Instrument -> out.add(n)
                    is CatalogNode.Category -> walk(n.children)
                }
            }
        }
        walk(children)
        return out
    }
}

data class CatalogInstrumentLocation(
    val watchlistIndex: Int,
    val watchlistId: String,
    val watchlistName: String,
    val orderInWatchlist: Int,
    val instrument: CatalogNode.Instrument
)

data class CatalogSnapshotInfo(
    val id: String,
    val timestamp: String,
    val reason: String,
    val summary: String
)

data class CalibrationDiff(
    val watchlistName: String,
    val observedCount: Int,
    val addedSymbols: List<String>,
    val missingInTvSymbols: List<String>,
    val matchedCount: Int,
    val orderChanged: Boolean = false
)

object CatalogRepository {
    private const val FILE_NAME = "catalog_master_v1.json"
    private const val SNAPSHOTS_FILE_NAME = "catalog_snapshots_v1.json"
    private const val PREF_KEY_CATALOG_VER = "catalog_builtin_version"

    private var appContext: Context? = null
    private val watchlists = ArrayList<CatalogWatchlist>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    // 内存高速索引（精确代码 + 去空格紧凑代码双索引）
    private val symbolToLocations = HashMap<String, MutableList<CatalogInstrumentLocation>>()
    private val compactToCanonical = HashMap<String, String>()
    private val allSymbolsOrdered = ArrayList<String>()
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val undoStack = ArrayDeque<String>()
    private val snapTimeFmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault())

    @Synchronized
    fun init(context: Context) {
        if (appContext != null && watchlists.isNotEmpty()) return
        appContext = context.applicationContext
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        val prefs = context.applicationContext.getSharedPreferences("tv_color_helper_prefs", Context.MODE_PRIVATE)
        val savedBuiltinVer = prefs.getInt(PREF_KEY_CATALOG_VER, 0)

        var loaded = false
        // 永不覆盖用户已有修改！只要本地已保存过《品种大全》，始终以用户数据为准
        if (file.exists()) {
            try {
                val jsonStr = file.readText(Charsets.UTF_8)
                val parsed = fromJson(jsonStr)
                if (parsed.isNotEmpty()) {
                    watchlists.clear()
                    watchlists.addAll(parsed)
                    loaded = true
                }
            } catch (_: Exception) {
            }
        }

        if (!loaded) {
            watchlists.clear()
            watchlists.addAll(parseRawText(CatalogDefaultData.RAW_TEXT))
            prefs.edit().putInt(PREF_KEY_CATALOG_VER, CatalogDefaultData.BUILTIN_VERSION).apply()
            saveLocked()
        } else {
            // 若 APK 内置版本升级，仅做无损增量修正（如修已知拼写错误，绝不删除或重置用户手动修改！）
            if (savedBuiltinVer < CatalogDefaultData.BUILTIN_VERSION) {
                applyNonDestructiveMigrationsLocked()
                prefs.edit().putInt(PREF_KEY_CATALOG_VER, CatalogDefaultData.BUILTIN_VERSION).apply()
                saveLocked()
            } else {
                rebuildIndexesLocked()
            }
        }
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (_: Exception) {
            }
        }
    }

    @Synchronized
    fun getWatchlists(): List<CatalogWatchlist> = watchlists.toList()

    @Synchronized
    fun getWatchlistById(id: String): CatalogWatchlist? = watchlists.firstOrNull { it.id == id }

    @Synchronized
    fun getWatchlistIndexById(id: String): Int = watchlists.indexOfFirst { it.id == id }

    fun extractChineseCore(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw) {
            if (ch in '\u4E00'..'\u9FFF') sb.append(ch)
        }
        return sb.toString()
    }

    /**
     * 将顶部标签栏 OCR/节点文本精准匹配到《品种大全》中的列表索引（0..N-1），未命中（垃圾列表）返回 -1
     * 完全免疫 OCR 把 ❶❷❸❹ 误认成 0/O/●/8 或漏认的问题！
     */
    /**
     * 严格防误判顶部标签匹配：
     * - 完整归一化匹配优先
     * - 凡以 ASCII 数字/字母开头且不带 '-' 的后方垃圾列表（如 05㊀商、1商、4指、8亚、0备4❹亚、A4软），一律严格判为 -1！
     * - 单字核心列表（-1商/-2指/-3基/-4❹亚）必须同时校验前导 '-' 与首数字完全一致
     * - 多字核心列表（-4❶中一/-4❷美二等）允许 '-' + 同首数字，或左边缘裁切残留（如 "美二"、"❷美二"）
     */
    @Synchronized
    fun matchWatchlistIndexByTabText(rawTabText: String): Int {
        val clean = rawTabText.trim()
        if (clean.isEmpty()) return -1
        val norm = normalizeListName(clean)
        val tabCn = extractChineseCore(clean)

        // 1) 完整归一化精确匹配
        watchlists.indexOfFirst { normalizeListName(it.name) == norm }.let { if (it >= 0) return it }

        val c0 = clean[0]
        val hasDash = c0 == '-' || c0 == '—' || c0 == '–'
        val startsWithAsciiAlnum = (c0 in '0'..'9') || (c0 in 'A'..'Z') || (c0 in 'a'..'z')

        // 2) 中文核心匹配（带严格前导字符防线，绝不把 05㊀商 / 1商 误当 -1商）
        if (tabCn.isNotEmpty()) {
            val cnMatches = ArrayList<Int>()
            for ((idx, wl) in watchlists.withIndex()) {
                if (extractChineseCore(wl.name) == tabCn) {
                    cnMatches.add(idx)
                }
            }
            if (cnMatches.size == 1) {
                val idx = cnMatches[0]
                val wlName = watchlists[idx].name
                if (wlName.startsWith("-")) {
                    // 任何以 ASCII 数字/字母开头且无 '-' 的标签（05㊀商、1商、4指、8亚等）全部拒之门外！
                    if (startsWithAsciiAlnum) return -1

                    val wlLeadDigit = Regex("""^-([0-9])""").find(wlName)?.groupValues?.getOrNull(1)
                    val rawLeadDigit = Regex("""^[-—–]([0-9])""").find(clean)?.groupValues?.getOrNull(1)

                    if (tabCn.length == 1) {
                        return if (hasDash && wlLeadDigit != null && wlLeadDigit == rawLeadDigit) idx else -1
                    } else {
                        if (hasDash) {
                            if (wlLeadDigit != null && rawLeadDigit != null && wlLeadDigit != rawLeadDigit) {
                                return -1
                            }
                            return idx
                        }
                        val firstCnIdx = clean.indexOfFirst { it in '\u4E00'..'\u9FFF' }
                        val prefix = if (firstCnIdx > 0) clean.substring(0, firstCnIdx) else ""
                        val allowedClippedPrefix = prefix.all { it in "❶❷❸❹❺①②③④⑤●○〇" }
                        return if (allowedClippedPrefix) idx else -1
                    }
                } else {
                    return idx
                }
            }
        }

        // 3) 纯英文/数字自定义列表精确匹配
        if (tabCn.isEmpty() && norm.length >= 2) {
            for ((idx, wl) in watchlists.withIndex()) {
                if (extractChineseCore(wl.name).isEmpty() && normalizeListName(wl.name) == norm) {
                    return idx
                }
            }
        }
        return -1
    }

    @Synchronized
    fun getWatchlistByName(name: String): CatalogWatchlist? {
        val idx = matchWatchlistIndexByTabText(name)
        return if (idx in watchlists.indices) watchlists[idx] else null
    }

    @Synchronized
    fun totalInstrumentCount(): Int = symbolToLocations.values.sumOf { it.size }

    @Synchronized
    fun save() {
        saveLocked()
        notifyListeners()
    }

    @Synchronized
    fun recordUndoPoint() {
        if (watchlists.isEmpty()) return
        val snap = toJson(watchlists)
        if (undoStack.lastOrNull() == snap) return
        undoStack.addLast(snap)
        while (undoStack.size > 15) {
            undoStack.removeFirst()
        }
    }

    @Synchronized
    fun canUndo(): Boolean = undoStack.isNotEmpty()

    @Synchronized
    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        val prevJson = undoStack.removeLast()
        return try {
            val parsed = fromJson(prevJson)
            if (parsed.isNotEmpty()) {
                watchlists.clear()
                watchlists.addAll(parsed)
                saveLocked()
                notifyListeners()
                true
            } else false
        } catch (_: Exception) {
            false
        }
    }

    private fun saveAutoSnapshotLocked(reason: String) {
        val ctx = appContext ?: return
        if (watchlists.isEmpty()) return
        val snapJson = toJson(watchlists)
        val summary = "${watchlists.size}列表/${totalInstrumentCount()}品种"
        val ts = snapTimeFmt.format(Date())
        val id = UUID.randomUUID().toString()
        ioExecutor.execute {
            try {
                val file = File(ctx.filesDir, SNAPSHOTS_FILE_NAME)
                val arr = if (file.exists()) {
                    try { JSONArray(file.readText(Charsets.UTF_8)) } catch (_: Exception) { JSONArray() }
                } else JSONArray()

                val newArr = JSONArray()
                val obj = JSONObject()
                obj.put("id", id)
                obj.put("ts", ts)
                obj.put("reason", reason)
                obj.put("summary", summary)
                obj.put("data", snapJson)
                newArr.put(obj)
                for (i in 0 until minOf(arr.length(), 4)) {
                    newArr.put(arr.getJSONObject(i))
                }
                file.writeText(newArr.toString(), Charsets.UTF_8)
            } catch (_: Exception) {
            }
        }
    }

    @Synchronized
    fun getSnapshots(): List<CatalogSnapshotInfo> {
        val ctx = appContext ?: return emptyList()
        val file = File(ctx.filesDir, SNAPSHOTS_FILE_NAME)
        if (!file.exists()) return emptyList()
        val out = ArrayList<CatalogSnapshotInfo>()
        try {
            val arr = JSONArray(file.readText(Charsets.UTF_8))
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(
                    CatalogSnapshotInfo(
                        id = o.optString("id"),
                        timestamp = o.optString("ts"),
                        reason = o.optString("reason"),
                        summary = o.optString("summary")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    @Synchronized
    fun restoreSnapshot(snapshotId: String): Pair<Int, Int> {
        val ctx = appContext ?: return 0 to 0
        val file = File(ctx.filesDir, SNAPSHOTS_FILE_NAME)
        if (!file.exists()) return 0 to 0
        try {
            val arr = JSONArray(file.readText(Charsets.UTF_8))
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optString("id") == snapshotId) {
                    val data = o.optString("data")
                    val parsed = fromJson(data)
                    if (parsed.isNotEmpty()) {
                        recordUndoPoint()
                        watchlists.clear()
                        watchlists.addAll(parsed)
                        saveLocked()
                        notifyListeners()
                        return watchlists.size to totalInstrumentCount()
                    }
                }
            }
        } catch (_: Exception) {
        }
        return 0 to 0
    }

    @Synchronized
    fun replaceWithRawText(rawText: String): Pair<Int, Int> {
        val parsed = parseRawText(rawText)
        if (parsed.isEmpty()) return 0 to 0
        recordUndoPoint()
        saveAutoSnapshotLocked("批量覆盖导入前自动备份")
        watchlists.clear()
        watchlists.addAll(parsed)
        saveLocked()
        notifyListeners()
        return watchlists.size to totalInstrumentCount()
    }

    @Synchronized
    fun resetToDefault(): Pair<Int, Int> {
        return replaceWithRawText(CatalogDefaultData.RAW_TEXT)
    }

    @Synchronized
    fun addWatchlist(name: String): CatalogWatchlist {
        recordUndoPoint()
        val wl = CatalogWatchlist(name = name.trim())
        watchlists.add(wl)
        saveLocked()
        notifyListeners()
        return wl
    }

    @Synchronized
    fun swapWatchlistsQuiet(fromIdx: Int, toIdx: Int): Boolean {
        if (fromIdx !in watchlists.indices || toIdx !in watchlists.indices || fromIdx == toIdx) return false
        val item = watchlists.removeAt(fromIdx)
        watchlists.add(toIdx, item)
        return true
    }

    @Synchronized
    fun moveWatchlist(index: Int, delta: Int) {
        val target = index + delta
        if (index !in watchlists.indices || target !in watchlists.indices) return
        recordUndoPoint()
        val item = watchlists.removeAt(index)
        watchlists.add(target, item)
        saveLocked()
        notifyListeners()
    }

    @Synchronized
    fun removeWatchlist(index: Int) {
        if (index !in watchlists.indices) return
        recordUndoPoint()
        saveAutoSnapshotLocked("删除列表前自动备份")
        watchlists.removeAt(index)
        saveLocked()
        notifyListeners()
    }


    /**
     * 按在列表页观察到的上下文（所属列表、上方相邻品种、下方相邻品种）将新发现品种精准插入《品种大全》
     */
    @Synchronized
    fun insertObservedInstrument(
        symbol: String,
        watchlistId: String,
        prevSymbol: String = "",
        nextSymbol: String = ""
    ): String {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        if (cleanSym.isEmpty()) return "品种代码为空"
        val wl = getWatchlistById(watchlistId) ?: return "未找到目标列表"

        // 若该列表里已存在该品种则不重复插入
        if (isSymbolInWatchlist(cleanSym, wl.id)) {
            return "$cleanSym 已存在于[${wl.name}]中"
        }

        val newInst = CatalogNode.Instrument(symbol = cleanSym)
        val cleanPrev = prevSymbol.trim().uppercase(Locale.US)
        val cleanNext = nextSymbol.trim().uppercase(Locale.US)

        fun insertRelative(nodes: MutableList<CatalogNode>, targetSym: String, after: Boolean): Boolean {
            for (i in nodes.indices) {
                when (val n = nodes[i]) {
                    is CatalogNode.Instrument -> {
                        if (n.symbol.trim().uppercase(Locale.US) == targetSym) {
                            val insertIdx = if (after) i + 1 else i
                            nodes.add(insertIdx, newInst)
                            return true
                        }
                    }
                    is CatalogNode.Category -> {
                        if (insertRelative(n.children, targetSym, after)) return true
                    }
                }
            }
            return false
        }

        val posDesc: String = when {
            cleanPrev.isNotEmpty() && insertRelative(wl.children, cleanPrev, after = true) ->
                "紧跟 $cleanPrev 之后"
            cleanNext.isNotEmpty() && insertRelative(wl.children, cleanNext, after = false) ->
                "紧靠 $cleanNext 之前"
            else -> {
                val lastCat = wl.children.lastOrNull { it is CatalogNode.Category } as? CatalogNode.Category
                if (lastCat != null) {
                    lastCat.children.add(newInst)
                } else {
                    wl.children.add(newInst)
                }
                "列表末尾"
            }
        }

        saveLocked()
        notifyListeners()
        return "已将 $cleanSym 写入[${wl.name}]（$posDesc）"
    }

    @Synchronized
    fun moveNode(list: MutableList<CatalogNode>, index: Int, delta: Int) {
        val target = index + delta
        if (index !in list.indices || target !in list.indices) return
        recordUndoPoint()
        val item = list.removeAt(index)
        list.add(target, item)
        saveLocked()
        notifyListeners()
    }

    @Synchronized
    fun removeNode(list: MutableList<CatalogNode>, index: Int) {
        if (index !in list.indices) return
        recordUndoPoint()
        list.removeAt(index)
        saveLocked()
        notifyListeners()
    }

    // ---------- 文本导出（一键复制全部 / 单独复制单个列表） ----------

    @Synchronized
    fun exportWatchlistToText(wl: CatalogWatchlist): String {
        val sb = StringBuilder()
        sb.append("(●—●)").append(wl.name).append("\n")
        fun writeNodes(nodes: List<CatalogNode>) {
            for (n in nodes) {
                when (n) {
                    is CatalogNode.Category -> {
                        sb.append(n.name).append("\n")
                        writeNodes(n.children)
                    }
                    is CatalogNode.Instrument -> {
                        sb.append(n.symbol)
                        if (n.cnName.isNotBlank() && n.source.isNotBlank()) {
                            sb.append("——").append(n.cnName).append("—").append(n.source)
                        } else if (n.cnName.isNotBlank()) {
                            sb.append("——").append(n.cnName)
                        } else if (n.source.isNotBlank()) {
                            sb.append("——").append(n.source)
                        }
                        sb.append("\n")
                    }
                }
            }
        }
        writeNodes(wl.children)
        return sb.toString().trimEnd()
    }

    @Synchronized
    fun exportAllToText(): String {
        return watchlists.joinToString("\n\n") { exportWatchlistToText(it) }
    }

    // ---------- 查询与校准 ----------

    @Synchronized
    fun findLocations(symbol: String): List<CatalogInstrumentLocation> {
        val key = symbol.trim().uppercase(Locale.US)
        symbolToLocations[key]?.let { return it.toList() }
        val compact = key.replace(" ", "")
        val canonical = compactToCanonical[compact] ?: return emptyList()
        return symbolToLocations[canonical]?.toList() ?: emptyList()
    }

    @Synchronized
    fun findInstrumentInfo(symbol: String, preferredWatchlistId: String? = null): CatalogNode.Instrument? {
        val locs = findLocations(symbol)
        if (locs.isEmpty()) return null
        if (preferredWatchlistId != null) {
            locs.firstOrNull { it.watchlistId == preferredWatchlistId }?.let { return it.instrument }
        }
        return locs.first().instrument
    }

    @Synchronized
    fun isSymbolInWatchlist(symbol: String, watchlistId: String): Boolean {
        return findLocations(symbol).any { it.watchlistId == watchlistId }
    }

    /**
     * 将图表识别到的代码（可能因左下角滚轮截断、无空格、末尾淡出）校准为《品种大全》中的标准规范名
     */
    @Synchronized
    fun resolveChartSymbolInCatalog(rawSymbol: String, preferredWatchlistId: String? = null): String? {
        val q = rawSymbol.trim().uppercase(Locale.US)
        if (q.isEmpty()) return null
        val qCompact = q.replace(" ", "")

        // 1) 精确命中（含去空格形式，如 MAERSKB -> MAERSK B）
        if (symbolToLocations.containsKey(q)) return q
        compactToCanonical[qCompact]?.let { return it }

        // 2) 前缀匹配（如滚轮截断 BTCUS -> BTCUSD、RBOBG -> RBOBGASOLINE、MAERSK -> MAERSK B）
        if (qCompact.length >= 3) {
            val prefixCandidates = ArrayList<String>()
            for (sym in allSymbolsOrdered) {
                val sCompact = sym.replace(" ", "")
                if (sCompact.length > qCompact.length && sCompact.startsWith(qCompact)) {
                    prefixCandidates.add(sym)
                }
            }
            if (prefixCandidates.isNotEmpty()) {
                if (preferredWatchlistId != null) {
                    prefixCandidates.firstOrNull { isSymbolInWatchlist(it, preferredWatchlistId) }?.let { return it }
                }
                return prefixCandidates.minByOrNull { it.length }
            }
        }

        // 3) 滚轮边缘淡出导致末尾1位失真（如 BTCUSD -> BTCUSI，仅限>=5位非纯数字）
        if (qCompact.length >= 5 && !qCompact.all { it.isDigit() }) {
            val prefix = qCompact.dropLast(1)
            val fuzzyCandidates = ArrayList<String>()
            for (sym in allSymbolsOrdered) {
                val sCompact = sym.replace(" ", "")
                if (sCompact.length >= qCompact.length && sCompact.startsWith(prefix)) {
                    fuzzyCandidates.add(sym)
                }
            }
            if (fuzzyCandidates.isNotEmpty()) {
                if (preferredWatchlistId != null) {
                    fuzzyCandidates.firstOrNull { isSymbolInWatchlist(it, preferredWatchlistId) }?.let { return it }
                }
                return fuzzyCandidates.minByOrNull { it.length }
            }
        }

        // 4) 长代码单字符拼写/OCR容错（如 HEATINGOIL <-> HEATIOGOIL，长度>=8且数字完全一致）
        if (qCompact.length >= 8) {
            val qDigits = qCompact.filter { it.isDigit() }
            for (sym in allSymbolsOrdered) {
                val sCompact = sym.replace(" ", "")
                if (sCompact.length >= 8 &&
                    abs(sCompact.length - qCompact.length) <= 1 &&
                    sCompact.filter { it.isDigit() } == qDigits &&
                    editDistanceAtMostOne(qCompact, sCompact)
                ) {
                    return sym
                }
            }
        }

        return null
    }


    /**
     * 核心防串号：通过图表左下角滚轮同时可见的「上一个 / 当前 / 下一个」相邻代码序列，
     * 100% 实时反推当前图表真正所属的列表 ID（彻底消除 ASX / SAF 等跨市场同名品种串号！）
     */
    @Synchronized
    fun inferWatchlistIdFromWheelContext(
        prevSym: String?,
        currSym: String?,
        nextSym: String?
    ): String? {
        if (currSym.isNullOrBlank()) return null
        val currCanonical = resolveChartSymbolInCatalog(currSym) ?: currSym.trim().uppercase(Locale.US)
        val locs = findLocations(currCanonical)
        if (locs.isEmpty()) return null
        val uniqueWls = locs.map { it.watchlistId }.distinct()
        if (uniqueWls.size == 1) return uniqueWls[0]

        val prevCanon = prevSym?.let { resolveChartSymbolInCatalog(it) ?: it.trim().uppercase(Locale.US) }
        val nextCanon = nextSym?.let { resolveChartSymbolInCatalog(it) ?: it.trim().uppercase(Locale.US) }

        var bestWlId: String? = null
        var bestScore = 0

        for (wlId in uniqueWls) {
            val wl = getWatchlistById(wlId) ?: continue
            val flatSyms = wl.flattenInstruments().map { it.symbol.trim().uppercase(Locale.US) }
            var wlBest = 0
            for (i in flatSyms.indices) {
                if (flatSyms[i] != currCanonical) continue
                var score = 0
                if (prevCanon != null) {
                    if (i > 0 && flatSyms[i - 1] == prevCanon) score += 12
                    else if ((maxOf(0, i - 3) until i).any { flatSyms[it] == prevCanon }) score += 4
                    else if (prevCanon in flatSyms) score += 1
                }
                if (nextCanon != null) {
                    if (i + 1 < flatSyms.size && flatSyms[i + 1] == nextCanon) score += 12
                    else if (((i + 1)..minOf(flatSyms.lastIndex, i + 3)).any { flatSyms[it] == nextCanon }) score += 4
                    else if (nextCanon in flatSyms) score += 1
                }
                if (score > wlBest) wlBest = score
            }
            if (wlBest > bestScore) {
                bestScore = wlBest
                bestWlId = wlId
            }
        }
        return if (bestScore > 0) bestWlId else null
    }

    /**
     * 预览从 TV 采集到的品种清单与本地《品种大全》该列表的差异
     */
    @Synchronized
    fun previewCalibrationDiff(watchlistId: String, observedSymbols: List<String>): CalibrationDiff {
        val wl = getWatchlistById(watchlistId)
        val wlName = wl?.name ?: "未知列表"
        val obsNorm = observedSymbols.map { it.trim().uppercase(Locale.US) }.filter { it.isNotEmpty() }
        val obsSet = obsNorm.toSet()

        if (wl == null) {
            return CalibrationDiff(wlName, obsNorm.size, obsNorm.distinct(), emptyList(), 0)
        }
        val existingList = wl.flattenInstruments().map { it.symbol.trim().uppercase(Locale.US) }
        val existingSet = existingList.toSet()

        val added = obsNorm.filter { it !in existingSet }.distinct()
        val missingInTv = existingList.filter { it !in obsSet }.distinct()
        val matched = existingList.count { it in obsSet }
        val commonExisting = existingList.filter { it in obsSet }.distinct()
        val commonObs = obsNorm.filter { it in existingSet }.distinct()
        val orderChanged = commonExisting != commonObs
        return CalibrationDiff(wlName, obsNorm.size, added, missingInTv, matched, orderChanged)
    }

    /**
     * 从 TV 采集结果智能合并到《品种大全》：
     * - 完整保留所有已有品种的中文名、数据源与细分类别归属
     * - 新增品种按 TV 中观察到的紧邻上下品种精准插入对应类别位置
     * - 可选清理在 TV 中已删除的品种
     */
    @Synchronized
    fun applyCalibrationMerge(
        watchlistId: String,
        observedSymbols: List<String>,
        removeMissingInTv: Boolean,
        reorderByTvList: Boolean = false
    ): String {
        val wl = getWatchlistById(watchlistId) ?: return "未找到目标列表"
        val obsNorm = observedSymbols.map { it.trim().uppercase(Locale.US) }.filter { it.isNotEmpty() }
        if (obsNorm.isEmpty()) return "采集结果为空，未做改动"

        recordUndoPoint()
        saveAutoSnapshotLocked("TV自动校准[${wl.name}]前自动备份")

        val obsSet = obsNorm.toSet()
        var removedCount = 0
        if (removeMissingInTv) {
            fun pruneMissing(nodes: MutableList<CatalogNode>) {
                val it = nodes.iterator()
                while (it.hasNext()) {
                    when (val n = it.next()) {
                        is CatalogNode.Instrument -> {
                            if (n.symbol.trim().uppercase(Locale.US) !in obsSet) {
                                it.remove()
                                removedCount++
                            }
                        }
                        is CatalogNode.Category -> pruneMissing(n.children)
                    }
                }
            }
            pruneMissing(wl.children)
        }

        val existingSet = wl.flattenInstruments().map { it.symbol.trim().uppercase(Locale.US) }.toMutableSet()
        var addedCount = 0

        fun insertRelative(nodes: MutableList<CatalogNode>, anchorSym: String, newInst: CatalogNode.Instrument, after: Boolean): Boolean {
            for (i in nodes.indices) {
                when (val n = nodes[i]) {
                    is CatalogNode.Instrument -> {
                        if (n.symbol.trim().uppercase(Locale.US) == anchorSym) {
                            nodes.add(if (after) i + 1 else i, newInst)
                            return true
                        }
                    }
                    is CatalogNode.Category -> {
                        if (insertRelative(n.children, anchorSym, newInst, after)) return true
                    }
                }
            }
            return false
        }

        for (i in obsNorm.indices) {
            val sym = obsNorm[i]
            if (sym in existingSet) continue
            val newInst = CatalogNode.Instrument(symbol = sym)
            val prevAnchor = (i - 1 downTo 0).firstOrNull { obsNorm[it] in existingSet }?.let { obsNorm[it] }
            val nextAnchor = (i + 1 until obsNorm.size).firstOrNull { obsNorm[it] in existingSet }?.let { obsNorm[it] }

            val inserted = when {
                prevAnchor != null && insertRelative(wl.children, prevAnchor, newInst, after = true) -> true
                nextAnchor != null && insertRelative(wl.children, nextAnchor, newInst, after = false) -> true
                else -> {
                    val lastCat = wl.children.lastOrNull { it is CatalogNode.Category } as? CatalogNode.Category
                    if (lastCat != null) lastCat.children.add(newInst) else wl.children.add(newInst)
                    true
                }
            }
            if (inserted) {
                existingSet.add(sym)
                addedCount++
            }
        }

        if (reorderByTvList) {
            val rankMap = HashMap<String, Int>()
            for ((idx, sym) in obsNorm.withIndex()) {
                rankMap.putIfAbsent(sym, idx)
            }

            fun minRankOf(node: CatalogNode): Int {
                return when (node) {
                    is CatalogNode.Instrument -> rankMap[node.symbol.trim().uppercase(Locale.US)] ?: Int.MAX_VALUE
                    is CatalogNode.Category -> {
                        var best = Int.MAX_VALUE
                        for (c in node.children) {
                            val r = minRankOf(c)
                            if (r < best) best = r
                        }
                        best
                    }
                }
            }

            fun sortNodesByTvOrder(nodes: MutableList<CatalogNode>) {
                for (n in nodes) {
                    if (n is CatalogNode.Category) {
                        sortNodesByTvOrder(n.children)
                    }
                }
                val indexed = nodes.mapIndexed { origIdx, n -> Triple(minRankOf(n), origIdx, n) }
                val sorted = indexed.sortedWith(compareBy<Triple<Int, Int, CatalogNode>> { it.first }.thenBy { it.second })
                nodes.clear()
                for (t in sorted) {
                    nodes.add(t.third)
                }
            }

            sortNodesByTvOrder(wl.children)
        }

        saveLocked()
        notifyListeners()
        val sortTag = if (reorderByTvList) "，已按TV列表顺序重排" else ""
        val rmTag = if (removeMissingInTv) "，清理 $removedCount 个" else ""
        return "校准[${wl.name}]完成：新增 $addedCount 个$rmTag$sortTag（保留原中文名/数据源/分类）"
    }

    @Synchronized
    fun identifyWatchlistByVisibleSymbols(visibleSymbols: List<String>): CatalogWatchlist? {
        if (visibleSymbols.isEmpty() || watchlists.isEmpty()) return null
        val scoreByWlId = HashMap<String, Int>()
        for (rawSym in visibleSymbols) {
            val sym = rawSym.trim().uppercase(Locale.US)
            val locs = findLocations(sym)
            if (locs.isEmpty()) continue
            val uniqueWls = locs.map { it.watchlistId }.toSet()
            val weight = if (uniqueWls.size == 1) 3 else 1
            for (wlId in uniqueWls) {
                scoreByWlId[wlId] = (scoreByWlId[wlId] ?: 0) + weight
            }
        }
        val bestEntry = scoreByWlId.maxByOrNull { it.value } ?: return null
        if (bestEntry.value <= 0) return null
        return getWatchlistById(bestEntry.key)
    }

    @Synchronized
    fun getSymbolOrdersInWatchlist(watchlistId: String): Map<String, List<Int>> {
        val wl = getWatchlistById(watchlistId) ?: return emptyMap()
        val flat = wl.flattenInstruments()
        val map = HashMap<String, MutableList<Int>>()
        for ((idx, inst) in flat.withIndex()) {
            val key = inst.symbol.trim().uppercase(Locale.US)
            map.getOrPut(key) { ArrayList() }.add(idx)
        }
        return map
    }

    private fun editDistanceAtMostOne(a: String, b: String): Boolean {
        val la = a.length
        val lb = b.length
        if (abs(la - lb) > 1) return false
        var i = 0
        var j = 0
        var diffs = 0
        while (i < la && j < lb) {
            if (a[i] == b[j]) {
                i++; j++
            } else {
                diffs++
                if (diffs > 1) return false
                when {
                    la > lb -> i++
                    lb > la -> j++
                    else -> { i++; j++ }
                }
            }
        }
        if (i < la || j < lb) diffs++
        return diffs <= 1
    }


    private fun applyNonDestructiveMigrationsLocked() {
        val typoFixes = mapOf(
            "CNH50" to "CHN50",
            "HEATIOGOIL" to "HEATINGOIL",
            "BEKR" to "BEKE"
        )
        fun walkFix(nodes: MutableList<CatalogNode>) {
            for (n in nodes) {
                when (n) {
                    is CatalogNode.Instrument -> {
                        val fixed = typoFixes[n.symbol.trim().uppercase(Locale.US)]
                        if (fixed != null) n.symbol = fixed
                    }
                    is CatalogNode.Category -> walkFix(n.children)
                }
            }
        }
        for (wl in watchlists) {
            walkFix(wl.children)
        }
    }

    /**
     * 获取某品种在指定列表内所属的所有细分类别名称（用于精准识别并自动展开被折叠的板块）
     */

    /**
     * 为“探索快切列表”动态解析目标列表及首个品种代码：
     * - categoryHint == null：直接返回该列表下的第 1 个品种
     * - categoryHint != null（如 美中概 / 中一 / 德股 / 法股 / 美日概 / 日股）：
     *   在列表内匹配对应细分类别并返回该类别下的第 1 个品种
     */

    @Synchronized
    fun findWatchlistForQuickJump(watchlistId: String, watchlistName: String): CatalogWatchlist? {
        if (watchlistId.isNotBlank()) {
            getWatchlistById(watchlistId)?.let { return it }
        }
        if (watchlistName.isNotBlank()) {
            getWatchlistByName(watchlistName)?.let { return it }
        }
        return null
    }

    /**
     * 获取某列表内全部细分类别（用于快切配置页的联动下拉选择）
     * 返回 List<Pair<原始类别名, 带缩进展示名>>
     */
    @Synchronized
    fun listCategoriesInWatchlist(watchlistId: String): List<Pair<String, String>> {
        val wl = getWatchlistById(watchlistId) ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        fun walk(nodes: List<CatalogNode>, depth: Int) {
            for (n in nodes) {
                if (n is CatalogNode.Category) {
                    val indent = if (depth > 0) "　".repeat(depth) + "↳ " else ""
                    out.add(n.name to "$indent${n.name}")
                    walk(n.children, depth + 1)
                }
            }
        }
        walk(wl.children, 0)
        return out
    }

    /**
     * 获取某列表（或指定细分类别下）的全部品种列表（用于快切配置页的品种联动下拉选择）
     */
    @Synchronized
    fun listInstrumentsInWatchlistOrCategory(
        watchlistId: String,
        categoryHint: String?
    ): List<CatalogNode.Instrument> {
        val wl = getWatchlistById(watchlistId) ?: return emptyList()
        if (categoryHint.isNullOrBlank()) {
            return wl.flattenInstruments()
        }
        val cleanHint = categoryHint.trim()
        fun cleanCatName(raw: String): String {
            return raw.trim()
                .trimStart('★', '△', '▲', '●', '■', '◆', '〓', '▪', '▸', '◇', '○', '【', ' ')
                .trimEnd('】', ' ')
        }
        fun findCat(nodes: List<CatalogNode>, exactRaw: Boolean, exactClean: Boolean): CatalogNode.Category? {
            for (n in nodes) {
                if (n is CatalogNode.Category) {
                    val matched = when {
                        exactRaw -> n.name.trim() == cleanHint
                        exactClean -> cleanCatName(n.name) == cleanCatName(cleanHint)
                        else -> cleanCatName(n.name).contains(cleanCatName(cleanHint))
                    }
                    if (matched) return n
                    findCat(n.children, exactRaw, exactClean)?.let { return it }
                }
            }
            return null
        }
        val cat = findCat(wl.children, exactRaw = true, exactClean = false)
            ?: findCat(wl.children, exactRaw = false, exactClean = true)
            ?: findCat(wl.children, exactRaw = false, exactClean = false)
        return cat?.flattenInstruments() ?: wl.flattenInstruments()
    }

    @Synchronized
    fun findFirstSymbolForQuickJumpByIdOrName(
        watchlistId: String,
        watchlistName: String,
        categoryHint: String?
    ): Pair<CatalogWatchlist?, String?> {
        val wl = findWatchlistForQuickJump(watchlistId, watchlistName) ?: return null to null
        val insts = listInstrumentsInWatchlistOrCategory(wl.id, categoryHint)
        return wl to (insts.firstOrNull()?.symbol ?: wl.flattenInstruments().firstOrNull()?.symbol)
    }

    @Synchronized
    fun findFirstSymbolForQuickJump(
        watchlistName: String,
        categoryHint: String?
    ): Pair<CatalogWatchlist?, String?> {
        val wl = getWatchlistByName(watchlistName) ?: return null to null
        if (categoryHint.isNullOrBlank()) {
            return wl to wl.flattenInstruments().firstOrNull()?.symbol
        }
        val cleanHint = categoryHint.trim()
        fun cleanCatName(raw: String): String {
            return raw.trim()
                .trimStart('★', '△', '▲', '●', '■', '◆', '〓', '▪', '▸', '◇', '○', '【', ' ')
                .trimEnd('】', ' ')
        }
        fun findCatFirst(nodes: List<CatalogNode>, exactOnly: Boolean): String? {
            for (n in nodes) {
                if (n is CatalogNode.Category) {
                    val c = cleanCatName(n.name)
                    val matched = if (exactOnly) (c == cleanHint) else c.contains(cleanHint)
                    if (matched) {
                        val first = n.flattenInstruments().firstOrNull()?.symbol
                        if (first != null) return first
                    }
                    findCatFirst(n.children, exactOnly)?.let { return it }
                }
            }
            return null
        }
        val sym = findCatFirst(wl.children, exactOnly = true)
            ?: findCatFirst(wl.children, exactOnly = false)
            ?: wl.flattenInstruments().firstOrNull()?.symbol
        return wl to sym
    }

    @Synchronized
    fun findCategoryHintsForSymbol(watchlistId: String, symbol: String): List<String> {
        val wl = getWatchlistById(watchlistId) ?: return emptyList()
        val target = symbol.trim().uppercase(Locale.US)
        val hints = ArrayList<String>()
        fun walk(nodes: List<CatalogNode>, path: List<String>) {
            for (n in nodes) {
                when (n) {
                    is CatalogNode.Category -> walk(n.children, path + n.name)
                    is CatalogNode.Instrument -> {
                        if (n.symbol.trim().uppercase(Locale.US) == target) {
                            hints.addAll(path)
                            if (n.cnName.isNotBlank()) hints.add(n.cnName)
                        }
                    }
                }
            }
        }
        walk(wl.children, emptyList())
        return hints.distinct()
    }

    private fun saveLocked() {
        rebuildIndexesLocked()
        val ctx = appContext ?: return
        val jsonSnapshot = toJson(watchlists)
        ioExecutor.execute {
            try {
                val file = File(ctx.filesDir, FILE_NAME)
                file.writeText(jsonSnapshot, Charsets.UTF_8)
            } catch (_: Exception) {
            }
        }
    }

    private fun rebuildIndexesLocked() {
        symbolToLocations.clear()
        compactToCanonical.clear()
        val uniqueSet = LinkedHashSet<String>()
        for ((wlIdx, wl) in watchlists.withIndex()) {
            val flat = wl.flattenInstruments()
            for ((ordIdx, inst) in flat.withIndex()) {
                val key = inst.symbol.trim().uppercase(Locale.US)
                if (key.isEmpty()) continue
                uniqueSet.add(key)
                compactToCanonical.putIfAbsent(key.replace(" ", ""), key)
                symbolToLocations.getOrPut(key) { ArrayList() }.add(
                    CatalogInstrumentLocation(
                        watchlistIndex = wlIdx,
                        watchlistId = wl.id,
                        watchlistName = wl.name,
                        orderInWatchlist = ordIdx,
                        instrument = inst
                    )
                )
            }
        }
        allSymbolsOrdered.clear()
        allSymbolsOrdered.addAll(uniqueSet)
    }

    fun normalizeListName(raw: String): String {
        return raw.trim()
            .replace(" ", "")
            .replace("　", "")
            .replace("❶", "1").replace("①", "1")
            .replace("❷", "2").replace("②", "2")
            .replace("❸", "3").replace("③", "3")
            .replace("❹", "4").replace("④", "4")
            .replace("❺", "5").replace("⑤", "5")
            .replace("❻", "6").replace("⑥", "6")
            .replace("❼", "7").replace("⑦", "7")
            .replace("❽", "8").replace("⑧", "8")
            .replace("❾", "9").replace("⑨", "9")
            .replace("❿", "10").replace("⑩", "10")
            .lowercase(Locale.US)
    }

    // ---------- 文本解析器（100% 精准支持 (●—●)、★△▲●■、〓二级分类、▰、——、—、空格及无形空格清洗） ----------

    private fun stripInvisible(s: String): String {
        return s.replace(Regex("""[\u200b\u200c\u200d\ufeff\r]"""), "").trim()
    }

    fun parseRawText(raw: String): MutableList<CatalogWatchlist> {
        val result = ArrayList<CatalogWatchlist>()
        var currentWl: CatalogWatchlist? = null
        var currentL1: CatalogNode.Category? = null
        var currentL2: CatalogNode.Category? = null

        val listMarkerRegex = Regex("""^[（(]?●[—\-–_~]+●[)）]?\s*(.+)$""")
        val l1Prefixes = setOf('★', '△', '▲', '●', '■', '◆')
        val l2Prefixes = setOf('〓', '▪', '▸', '◇', '○')

        for (rawLine in raw.lineSequence()) {
            val line = stripInvisible(rawLine)
            if (line.isEmpty()) continue

            // 1) 列表名称：(●—●)xxx
            val listMatch = listMarkerRegex.matchEntire(line)
            if (listMatch != null) {
                val wlName = listMatch.groupValues[1].trim()
                if (wlName.isNotEmpty()) {
                    val wl = CatalogWatchlist(name = wlName)
                    result.add(wl)
                    currentWl = wl
                    currentL1 = null
                    currentL2 = null
                }
                continue
            }

            val activeWl = currentWl ?: CatalogWatchlist(name = "默认列表").also {
                currentWl = it
                result.add(it)
            }

            // 2) 明确的二级细分类别（如 〓医药健康、〓【科技】）
            if (line[0] in l2Prefixes) {
                val cat = CatalogNode.Category(name = line)
                val parentL1 = currentL1
                if (parentL1 != null) {
                    parentL1.children.add(cat)
                } else {
                    activeWl.children.add(cat)
                }
                currentL2 = cat
                continue
            }

            // 3) 明确的一级细分类别（如 ★外金、△美股、▲美一、●美英概、■德股）
            if (line[0] in l1Prefixes) {
                val cat = CatalogNode.Category(name = line)
                activeWl.children.add(cat)
                currentL1 = cat
                currentL2 = null
                continue
            }

            // 4) 尝试解析为品种行
            val parsedInst = tryParseInstrumentLine(line)
            if (parsedInst != null) {
                val targetList = currentL2?.children ?: currentL1?.children ?: activeWl.children
                targetList.add(parsedInst)
                continue
            }

            // 5) 兜底作为普通细分类别
            val cat = CatalogNode.Category(name = line)
            activeWl.children.add(cat)
            currentL1 = cat
            currentL2 = null
        }
        return result
    }

    private fun tryParseInstrumentLine(line: String): CatalogNode.Instrument? {
        if (line.startsWith("=") || line.startsWith("---") || line.startsWith("——")) {
            return null
        }

        // 形态 A：▰ 分隔（如 U.UN▰ 实物铀-伦、IKO▰韩股-澳）
        if (line.contains('▰')) {
            val parts = line.split('▰').map { stripInvisible(it) }.filter { it.isNotEmpty() }
            if (parts.isNotEmpty()) {
                val sym = cleanCatalogSymbol(parts[0], allowInnerSpace = true)
                if (sym != null) {
                    if (parts.size >= 3) {
                        return CatalogNode.Instrument(symbol = sym, cnName = parts[1], source = parts.drop(2).joinToString(" "))
                    }
                    val (cn, src) = splitCnAndSource(parts.getOrNull(1).orEmpty())
                    return CatalogNode.Instrument(symbol = sym, cnName = cn, source = src)
                }
            }
        }

        // 形态 B：—— 分隔（如 RUSSELL——罗素2000—IG、TFM1! D——欧洲大陆天然气—ICEENDEX）
        val dashIdx = line.indexOf("——")
        if (dashIdx > 0) {
            val sym = cleanCatalogSymbol(line.substring(0, dashIdx), allowInnerSpace = true)
            if (sym != null) {
                val (cn, src) = splitCnAndSource(line.substring(dashIdx + 2))
                return CatalogNode.Instrument(symbol = sym, cnName = cn, source = src)
            }
        }

        // 形态 C：单个全角长破折号 — / 竖线 | / Tab（如 AAPL—苹果、MAERSK B—马士基、FANG—纽交所FANG+指数—IG）
        val sepMatch = Regex("""^([^\s—|\t][^—|\t]{0,21}?)\s*[—|\t]\s*(.+)$""").matchEntire(line)
        if (sepMatch != null) {
            val sym = cleanCatalogSymbol(sepMatch.groupValues[1], allowInnerSpace = true)
            if (sym != null) {
                val (cn, src) = splitCnAndSource(sepMatch.groupValues[2])
                return CatalogNode.Instrument(symbol = sym, cnName = cn, source = src)
            }
        }

        // 形态 D：纯代码行（无中文名无数据源，如 BTCUSD、USDOLLAR、USDTHB）
        val pureSym = cleanCatalogSymbol(line, allowInnerSpace = false)
        if (pureSym != null) {
            return CatalogNode.Instrument(symbol = pureSym)
        }

        // 形态 E：代码 + 空格 + 中文名（如 700 腾讯控股、1 长和、USWHEAT 美小麦、100 MINIMAX）
        val spaceMatch = Regex("""^(\S+)\s+(.+)$""").matchEntire(line)
        if (spaceMatch != null) {
            val sym = cleanCatalogSymbol(spaceMatch.groupValues[1], allowInnerSpace = false)
            if (sym != null && !sym.endsWith(".")) {
                val (cn, src) = splitCnAndSource(spaceMatch.groupValues[2])
                return CatalogNode.Instrument(symbol = sym, cnName = cn, source = src)
            }
        }

        return null
    }

    private fun cleanCatalogSymbol(raw: String, allowInnerSpace: Boolean): String? {
        var s = stripInvisible(raw)
        // 剥离尾部延迟行情标记（如 "TFM1! D"、"NYFANG - D"）
        s = s.replace(Regex("""[\s\-—·~]+D$"""), "").trim()
        if (s.isEmpty() || s.length > 22) return null
        if (s.any { it.code > 127 }) return null
        if (s.any { it in 'a'..'z' }) return null
        val pat = if (allowInnerSpace) {
            Regex("""^[A-Z0-9][A-Z0-9._!:/ _-]{0,21}$""")
        } else {
            Regex("""^[A-Z0-9][A-Z0-9._!:/_-]{0,21}$""")
        }
        return if (pat.matches(s)) s else null
    }

    private fun splitCnAndSource(restRaw: String): Pair<String, String> {
        val rest = stripInvisible(restRaw)
        if (rest.isBlank()) return "" to ""
        for (sep in listOf("——", "—", "|", "▰")) {
            val idx = rest.lastIndexOf(sep)
            if (idx > 0 && idx < rest.length - sep.length) {
                val left = rest.substring(0, idx).trim()
                val right = rest.substring(idx + sep.length).trim()
                if (left.isNotEmpty() && right.isNotEmpty()) {
                    return left to right
                }
            }
        }
        return rest to ""
    }

    // ---------- JSON 序列化 ----------

    private fun toJson(list: List<CatalogWatchlist>): String {
        val root = JSONObject()
        val arr = JSONArray()
        for (wl in list) {
            val obj = JSONObject()
            obj.put("id", wl.id)
            obj.put("name", wl.name)
            obj.put("children", nodesToJson(wl.children))
            arr.put(obj)
        }
        root.put("watchlists", arr)
        return root.toString()
    }

    private fun nodesToJson(nodes: List<CatalogNode>): JSONArray {
        val arr = JSONArray()
        for (n in nodes) {
            val obj = JSONObject()
            obj.put("id", n.id)
            when (n) {
                is CatalogNode.Category -> {
                    obj.put("type", "category")
                    obj.put("name", n.name)
                    obj.put("children", nodesToJson(n.children))
                }
                is CatalogNode.Instrument -> {
                    obj.put("type", "instrument")
                    obj.put("symbol", n.symbol)
                    obj.put("cnName", n.cnName)
                    obj.put("source", n.source)
                }
            }
            arr.put(obj)
        }
        return arr
    }

    private fun fromJson(jsonStr: String): MutableList<CatalogWatchlist> {
        val out = ArrayList<CatalogWatchlist>()
        val root = JSONObject(jsonStr)
        val arr = root.optJSONArray("watchlists") ?: return out
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val wl = CatalogWatchlist(
                id = obj.optString("id", UUID.randomUUID().toString()),
                name = obj.optString("name", "未命名列表"),
                children = jsonToNodes(obj.optJSONArray("children"))
            )
            out.add(wl)
        }
        return out
    }

    private fun jsonToNodes(arr: JSONArray?): MutableList<CatalogNode> {
        val out = ArrayList<CatalogNode>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("id", UUID.randomUUID().toString())
            when (obj.optString("type")) {
                "category" -> out.add(
                    CatalogNode.Category(
                        id = id,
                        name = obj.optString("name", "未命名类别"),
                        children = jsonToNodes(obj.optJSONArray("children"))
                    )
                )
                "instrument" -> out.add(
                    CatalogNode.Instrument(
                        id = id,
                        symbol = obj.optString("symbol", "").uppercase(Locale.US),
                        cnName = obj.optString("cnName", ""),
                        source = obj.optString("source", "")
                    )
                )
            }
        }
        return out
    }
}
