package com.tvhelper.color

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * 第三个功能的独立下拉状态栏快捷开关：专控“图表滚轮上下切图按钮(▲/▼)”，与前两个功能完全隔离
 */
class WheelPadTileService : TileService() {

    companion object {
        fun requestTileSync(context: Context) {
            try {
                requestListeningState(
                    context.applicationContext,
                    ComponentName(context.applicationContext, WheelPadTileService::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }

    override fun onTileAdded() {
        super.onTileAdded()
        AppStore.init(this)
        updateTileAppearance()
    }

    override fun onStartListening() {
        super.onStartListening()
        AppStore.init(this)
        updateTileAppearance()
    }

    override fun onClick() {
        super.onClick()
        AppStore.init(this)
        val nextEnabled = !AppStore.isWheelPadEnabled()
        AppStore.setWheelPadEnabled(this, nextEnabled, source = "状态栏滚轮切图开关")
        updateTileAppearance()
    }

    private fun updateTileAppearance() {
        val tile = qsTile ?: return
        val enabled = AppStore.isWheelPadEnabled()
        tile.label = getString(R.string.wheel_tile_label)
        tile.subtitle = if (enabled) "已开启" else "已关闭"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_wheel)
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
