package com.tvhelper.color

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

object QuickJumpCatalog {
    fun resolveTypeface(style: JumpFontStyle): Typeface {
        return when (style) {
            JumpFontStyle.NORMAL -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            JumpFontStyle.BOLD -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            JumpFontStyle.LIGHT -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            JumpFontStyle.ITALIC -> Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            JumpFontStyle.BOLD_ITALIC -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC)
            JumpFontStyle.MONOSPACE -> Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            JumpFontStyle.SERIF -> Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }
    }

    fun computeMonochromeColors(): Triple<Int, Int, Int> {
        val gray = (AppStore.getJumpFontGrayPct() * 255 / 100).coerceIn(0, 255)
        val textAlpha = (AppStore.getJumpFontOpacityPct() * 255 / 100).coerceIn(25, 255)
        val bgAlpha = (AppStore.getJumpBgOpacityPct() * 255 / 100).coerceIn(0, 255)
        val textColor = Color.argb(textAlpha, gray, gray, gray)
        val cardBgColor = Color.argb(bgAlpha, 12, 12, 12)
        val borderAlpha = maxOf(55, (textAlpha * 0.36f).toInt())
        val borderColor = Color.argb(borderAlpha, gray, gray, gray)
        return Triple(textColor, cardBgColor, borderColor)
    }

    fun describeTarget(entry: QuickJumpEntry): String {
        return if (entry.targetType == QuickJumpTargetType.COLOR_SLOT) {
            "顶部最左侧第 ${entry.colorSlotIndex} 个颜色列表 → 首位品种"
        } else {
            val (wl, autoSym) = CatalogRepository.findFirstSymbolForQuickJumpByIdOrName(
                entry.watchlistId,
                entry.watchlistName,
                entry.categoryName
            )
            val wlText = wl?.name ?: entry.watchlistName.ifBlank { "未指定列表" }
            val catText = if (entry.categoryName.isNotBlank()) " → ${entry.categoryName}" else ""
            val symText = if (entry.targetSymbol.isNotBlank()) {
                " → 指定品种(${entry.targetSymbol})"
            } else {
                val resolved = autoSym ?: entry.fallbackSymbol.ifBlank { "首品种" }
                " → 首位($resolved)"
            }
            "$wlText$catText$symText"
        }
    }
}

/**
 * 独立的“探索栏快切列表”悬浮层控制器：
 * 1) 透明“探索”热区拦截器：仅当 TV 底部探索栏可见时贴合其精确坐标，点击瞬间 0ms 弹出列表页而不进原探索页
 * 2) 单页 3 列黑白极简列表选择页：实时读取用户在 APP 内自定义的排序、增删、改名与目标配置
 */
class ExploreQuickJumpOverlay(
    private val context: Context,
    private val onEntrySelected: (QuickJumpEntry) -> Unit,
    private val onPassThroughExploreTap: (Float, Float) -> Unit,
    private val onPickerDismissed: () -> Unit
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    // 1. 底部“探索”按钮透明拦截热区
    private var interceptorView: View? = null
    private var interceptorParams: WindowManager.LayoutParams? = null
    private var isInterceptorAttached = false
    private var lastInterceptorRect: Rect? = null
    @Volatile
    private var passThroughUntilMs = 0L

    // 2. 自定义单页列表选择弹窗
    private var pickerRoot: FrameLayout? = null
    @Volatile
    private var pickerAttached = false
    @Volatile
    private var pickerPreviewMode = false

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    fun isInterceptorVisible(): Boolean = isInterceptorAttached

    fun isPickerShowing(): Boolean = pickerAttached

    fun isPreviewShowing(): Boolean = pickerAttached && pickerPreviewMode

    fun showExploreInterceptor(rect: Rect) {
        if (System.currentTimeMillis() < passThroughUntilMs) {
            hideExploreInterceptor()
            return
        }
        val copyRect = Rect(rect)
        mainHandler.post {
            if (pickerAttached || System.currentTimeMillis() < passThroughUntilMs) return@post
            ensureInterceptorCreated(copyRect)
            val view = interceptorView ?: return@post
            val params = interceptorParams ?: return@post
            val changed = lastInterceptorRect != copyRect
            if (changed) {
                params.x = copyRect.left
                params.y = copyRect.top
                params.width = copyRect.width().coerceAtLeast(dp(44))
                params.height = copyRect.height().coerceAtLeast(dp(36))
                lastInterceptorRect = Rect(copyRect)
            }
            if (!isInterceptorAttached && !view.isAttachedToWindow) {
                try {
                    wm.addView(view, params)
                    isInterceptorAttached = true
                } catch (_: Exception) {
                }
            } else if (changed) {
                try {
                    wm.updateViewLayout(view, params)
                } catch (_: Exception) {
                }
            }
        }
    }

    fun hideExploreInterceptor() {
        mainHandler.post {
            val view = interceptorView ?: return@post
            if (isInterceptorAttached || view.isAttachedToWindow) {
                try {
                    wm.removeViewImmediate(view)
                } catch (_: Exception) {
                    try { wm.removeView(view) } catch (_: Exception) {}
                }
            }
            isInterceptorAttached = false
        }
    }

    private fun ensureInterceptorCreated(rect: Rect) {
        if (interceptorView != null) return
        val v = View(context).apply {
            // 1/255 极微透明底色：肉眼完全不可见，但确保 vivo OriginOS 输入分发器 100% 命中拦截，不透传给底层“探索”按钮！
            setBackgroundColor(Color.argb(1, 0, 0, 0))
            isClickable = true
        }
        var downX = 0f
        var downY = 0f
        var moved = false
        var longPressed = false
        val longPressRunnable = Runnable {
            longPressed = true
            passThroughUntilMs = System.currentTimeMillis() + 2500L
            hideExploreInterceptor()
            val cx = (lastInterceptorRect?.centerX() ?: rect.centerX()).toFloat()
            val cy = (lastInterceptorRect?.centerY() ?: rect.centerY()).toFloat()
            mainHandler.postDelayed({ onPassThroughExploreTap(cx, cy) }, 35L)
        }

        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    moved = false
                    longPressed = false
                    mainHandler.removeCallbacks(longPressRunnable)
                    mainHandler.postDelayed(longPressRunnable, 520L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(ev.rawX - downX) > touchSlop || abs(ev.rawY - downY) > touchSlop) {
                        moved = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (!moved && !longPressed && AppStore.isExploreJumpEnabled()) {
                        showPicker(previewMode = false)
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    true
                }
                else -> false
            }
        }

        val params = WindowManager.LayoutParams(
            rect.width().coerceAtLeast(dp(44)),
            rect.height().coerceAtLeast(dp(36)),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // 关键修复：Android 11+ 必须置 fitInsetsTypes = 0，否则 WindowManager 会按状态栏/导航栏安全区把热区顶偏，导致点穿进原探索页！
            fitInsetsTypes = 0
            x = rect.left
            y = rect.top
        }

        interceptorView = v
        interceptorParams = params
        lastInterceptorRect = Rect(rect)
    }

    /**
     * 瞬间弹出单页 3 列列表选择浮层（支持返回提示文案，如“未找到第二颜色列表”）
     */
    fun showPicker(previewMode: Boolean = false, statusHint: String? = null) {
        mainHandler.post {
            hidePickerInternal()
            hideExploreInterceptor()
            pickerPreviewMode = previewMode

            val entries = AppStore.getQuickJumpEntries()
            val (textColor, cardBgColor, borderColor) = QuickJumpCatalog.computeMonochromeColors()
            val fontSizeSp = AppStore.getJumpFontSizeSp().toFloat()
            val tf = QuickJumpCatalog.resolveTypeface(AppStore.getJumpFontStyle())
            val bgAlpha = (AppStore.getJumpBgOpacityPct() * 255 / 100).coerceIn(0, 255)
            val gray = (AppStore.getJumpFontGrayPct() * 255 / 100).coerceIn(0, 255)

            val cellBgColor = Color.argb((bgAlpha * 0.72f).toInt(), 26, 26, 26)
            val backdropAlpha = (bgAlpha * 0.42f).toInt()

            val backdrop = object : FrameLayout(context) {
                override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
                    if (event?.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                        hidePickerInternal()
                        onPickerDismissed()
                        return true
                    }
                    return super.dispatchKeyEvent(event)
                }
            }.apply {
                setBackgroundColor(Color.argb(backdropAlpha, 0, 0, 0))
                isFocusableInTouchMode = true
                setOnClickListener { hidePickerInternal(); onPickerDismissed() }
            }

            val card = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(11), dp(10), dp(11), dp(11))
                background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(cardBgColor)
                    setStroke(dp(1), borderColor)
                }
                setOnClickListener { }
            }

            val header = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), 0, dp(2), dp(7))
            }
            val titleTv = TextView(context).apply {
                text = when {
                    !statusHint.isNullOrBlank() -> statusHint
                    previewMode -> "预览：共 ${entries.size} 项（点外部关闭）"
                    else -> "选择列表直达图表"
                }
                setTextColor(Color.argb(maxOf(100, (Color.alpha(textColor) * 0.78f).toInt()), gray, gray, gray))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val closeTv = TextView(context).apply {
                text = "✕"
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(12), dp(2), dp(6), dp(2))
                setOnClickListener { hidePickerInternal(); onPickerDismissed() }
            }
            header.addView(titleTv)
            header.addView(closeTv)
            card.addView(header)

            val gridCol = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
            }
            val cols = 3
            val rowsCount = (entries.size + cols - 1) / cols
            val cellMinHeight = dp((fontSizeSp * 2.25f + 14f).toInt().coerceIn(44, 80))

            for (r in 0 until rowsCount) {
                val rowLayout = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        if (r > 0) topMargin = dp(7)
                    }
                }
                for (c in 0 until cols) {
                    val idx = r * cols + c
                    if (idx >= entries.size) {
                        rowLayout.addView(View(context).apply {
                            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                        })
                        continue
                    }
                    val entry = entries[idx]
                    val cell = TextView(context).apply {
                        text = entry.displayName
                        setTextColor(textColor)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSp)
                        typeface = tf
                        gravity = Gravity.CENTER
                        maxLines = 1
                        minHeight = cellMinHeight
                        setPadding(dp(3), dp(6), dp(3), dp(6))
                        background = GradientDrawable().apply {
                            cornerRadius = dp(9).toFloat()
                            setColor(cellBgColor)
                            setStroke(dp(1), borderColor)
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            1f
                        ).apply {
                            if (c > 0) marginStart = dp(7)
                        }
                        setOnClickListener {
                            hidePickerInternal()
                            if (previewMode) {
                                Toast.makeText(
                                    context,
                                    "预览：${entry.displayName} → ${QuickJumpCatalog.describeTarget(entry)}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                onEntrySelected(entry)
                            }
                        }
                    }
                    rowLayout.addView(cell)
                }
                gridCol.addView(rowLayout)
            }

            val scrollWrap = ScrollView(context).apply {
                isVerticalScrollBarEnabled = false
                addView(gridCol)
            }
            card.addView(scrollWrap)

            val cardParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
                topMargin = dp(24)
                bottomMargin = dp(36)
            }
            backdrop.addView(card, cardParams)

            val winParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                fitInsetsTypes = 0
            }

            try {
                wm.addView(backdrop, winParams)
                backdrop.requestFocus()
                pickerRoot = backdrop
                pickerAttached = true
            } catch (_: Exception) {
            }
        }
    }

    fun hidePicker() {
        mainHandler.post { hidePickerInternal() }
    }

    private fun hidePickerInternal() {
        val v = pickerRoot ?: return
        if (pickerAttached || v.isAttachedToWindow) {
            try {
                wm.removeViewImmediate(v)
            } catch (_: Exception) {
                try { wm.removeView(v) } catch (_: Exception) {}
            }
        }
        pickerRoot = null
        pickerAttached = false
        pickerPreviewMode = false
    }

    fun destroy() {
        mainHandler.removeCallbacksAndMessages(null)
        hidePicker()
        hideExploreInterceptor()
    }
}
