package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

class TvAccessibilityService : AccessibilityService() {

    companion object {
        const val TV_PACKAGE = "com.tradingview.tradingviewapp"
        private const val NOTIF_CHANNEL_ID = "tv_color_missed_channel"
        private val notifIdCounter = AtomicInteger(1000)

        @Volatile
        var instance: TvAccessibilityService? = null
            private set
    }

    private enum class PageState { CHART, WATCHLIST, OTHER }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val workerExecutor = Executors.newSingleThreadExecutor()
    private val vision = VisionEngine()
    private lateinit var overlay: OverlayController

    @Volatile
    private var currentPage = PageState.OTHER
    @Volatile
    private var lastChartSymbol: String? = null
    @Volatile
    private var lastScreenshotAtMs = 0L
    @Volatile
    private var batchDoneForCurrentWatchlistVisit = false

    private val isBatchRunning = AtomicBoolean(false)
    private val abortBatchRequested = AtomicBoolean(false)
    private val isReadingChartTap = AtomicBoolean(false)

    private val screenCheckRunnable = Runnable { evaluateCurrentScreen() }
    private val litPollRunnable = object : Runnable {
        override fun run() {
            if (currentPage != PageState.CHART || overlay.getLitColor() == null) return
            if (!isReadingChartTap.get() && !isBatchRunning.get()) {
                workerExecutor.execute { pollChartSymbolForAutoOff() }
            }
            mainHandler.postDelayed(this, 1150L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppStore.init(this)
        createNotificationChannel()
        overlay = OverlayController(this) { color -> handleColorButtonTap(color) }
        AppStore.log("无障碍服务已连接")
        scheduleScreenCheck(100L)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        abortBatchRequested.set(true)
        mainHandler.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) {
            overlay.destroy()
        }
        vision.close()
        workerExecutor.shutdownNow()
    }

    override fun onInterrupt() {
        abortBatchRequested.set(true)
    }

    fun refreshOverlaySettings() {
        if (::overlay.isInitialized) {
            overlay.rebuildButtons()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()
        if (pkg == packageName) return

        val delay = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 60L
            else -> 180L
        }
        scheduleScreenCheck(delay)
    }

    private fun scheduleScreenCheck(delayMs: Long) {
        mainHandler.removeCallbacks(screenCheckRunnable)
        mainHandler.postDelayed(screenCheckRunnable, delayMs)
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        return b.width() to b.height()
    }

    private fun evaluateCurrentScreen() {
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()

        if (pkg != TV_PACKAGE) {
            if (currentPage != PageState.OTHER) {
                currentPage = PageState.OTHER
                lastChartSymbol = null
                batchDoneForCurrentWatchlistVisit = false
                stopLitPolling()
                overlay.hideButtons()
                if (isBatchRunning.get()) {
                    abortBatchRequested.set(true)
                    AppStore.log("检测到离开TradingView，中止批处理")
                }
            }
            return
        }

        val detected = detectTradingViewPage(root)

        if (detected != currentPage) {
            val prev = currentPage
            currentPage = detected
            AppStore.log("页面切换：$prev -> $detected")

            when (detected) {
                PageState.CHART -> {
                    batchDoneForCurrentWatchlistVisit = false
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                    overlay.showButtons()
                    syncChartLightFromNodes(root)
                }

                PageState.WATCHLIST -> {
                    stopLitPolling()
                    overlay.hideButtons()
                    if (AppStore.hasPendingItems() &&
                        !isBatchRunning.get() &&
                        !batchDoneForCurrentWatchlistVisit
                    ) {
                        startWatchlistBatch()
                    }
                }

                PageState.OTHER -> {
                    stopLitPolling()
                    overlay.hideButtons()
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                }
            }
        } else if (detected == PageState.CHART) {
            overlay.showButtons()
            syncChartLightFromNodes(root)
        } else if (detected == PageState.WATCHLIST) {
            overlay.hideButtons()
            if (AppStore.hasPendingItems() &&
                !isBatchRunning.get() &&
                !batchDoneForCurrentWatchlistVisit
            ) {
                startWatchlistBatch()
            }
        }
    }

    private fun detectTradingViewPage(root: AccessibilityNodeInfo): PageState {
        val (_, sh) = getScreenDimensions()
        val navTopThreshold = (sh * 0.90f).toInt()

        var watchlistNav: AccessibilityNodeInfo? = null
        var chartNav: AccessibilityNodeInfo? = null
        var hasTopSearchOrWatchlistHeader = false
        var hasChartBottomToolbar = false

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 480) {
            val node = stack.removeLast()
            visited++
            val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim().orEmpty()
            node.getBoundsInScreen(rect)

            if (rect.bottom >= navTopThreshold && text.isNotEmpty()) {
                when (text) {
                    "自选表", "Watchlist" -> watchlistNav = node
                    "图表", "Chart" -> chartNav = node
                }
            } else if (rect.top < sh * 0.14f &&
                (text == "搜索" || text == "Search" || text.startsWith("-1") || text.startsWith("-2") || text.startsWith("-3"))
            ) {
                hasTopSearchOrWatchlistHeader = true
            } else if (rect.top in (sh * 0.90f).toInt()..(sh * 0.955f).toInt() &&
                (text.contains("周") || text.contains("日") || text.contains("小时") || text.contains("分") ||
                    text.equals("1D", true) || text.equals("1W", true))
            ) {
                hasChartBottomToolbar = true
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                stack.add(child)
            }
        }

        if (isBatchRunning.get() && watchlistNav == null && chartNav == null) {
            return PageState.WATCHLIST
        }

        if (watchlistNav == null && chartNav == null) {
            return PageState.OTHER
        }

        val isChartSelected = isNodeOrAncestorSelected(chartNav)
        val isWatchlistSelected = isNodeOrAncestorSelected(watchlistNav)

        return when {
            isChartSelected && !isWatchlistSelected -> PageState.CHART
            isWatchlistSelected && !isChartSelected -> PageState.WATCHLIST
            hasChartBottomToolbar && !hasTopSearchOrWatchlistHeader -> PageState.CHART
            hasTopSearchOrWatchlistHeader && !hasChartBottomToolbar -> PageState.WATCHLIST
            else -> PageState.OTHER
        }
    }

    private fun isNodeOrAncestorSelected(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isSelected || cur.isChecked) return true
            val desc = cur.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("已选") || desc.contains("selected")) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    private fun syncChartLightFromNodes(root: AccessibilityNodeInfo) {
        val sym = extractChartSymbolFromNodes(root) ?: return
        if (sym != lastChartSymbol) {
            lastChartSymbol = sym
            val queuedColor = AppStore.getSymbolColor(sym)
            overlay.setLitColor(queuedColor)
            if (queuedColor == null) {
                stopLitPolling()
            } else {
                startLitPolling()
            }
        }
    }

    private fun extractChartSymbolFromNodes(root: AccessibilityNodeInfo): String? {
        val (sw, sh) = getScreenDimensions()
        val targetCenterY = (sh * 0.937f).toInt()
        val minY = (sh * 0.915f).toInt()
        val maxY = (sh * 0.955f).toInt()
        val maxX = (sw * 0.34f).toInt()

        var bestSym: String? = null
        var bestDist = Int.MAX_VALUE

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 420) {
            val node = stack.removeLast()
            visited++
            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                node.getBoundsInScreen(rect)
                val cy = rect.centerY()
                if (cy in minY..maxY && rect.left in 0..maxX) {
                    val normalized = vision.normalizeTickerCandidate(raw)
                    if (normalized != null) {
                        val dist = kotlin.math.abs(cy - targetCenterY)
                        if (dist < bestDist) {
                            bestDist = dist
                            bestSym = normalized
                        }
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return bestSym
    }

    private fun startLitPolling() {
        mainHandler.removeCallbacks(litPollRunnable)
        mainHandler.postDelayed(litPollRunnable, 1150L)
    }

    private fun stopLitPolling() {
        mainHandler.removeCallbacks(litPollRunnable)
    }

    private fun pollChartSymbolForAutoOff() {
        if (currentPage != PageState.CHART || overlay.getLitColor() == null) return
        val root = rootInActiveWindow
        val fromNode = root?.let { extractChartSymbolFromNodes(it) }
        val sym = fromNode ?: captureScreenBitmap(maxRetries = 1)?.let { bmp ->
            try {
                vision.readChartSymbolFromBitmap(bmp)
            } finally {
                bmp.recycle()
            }
        } ?: return

        if (sym != lastChartSymbol) {
            lastChartSymbol = sym
            val queued = AppStore.getSymbolColor(sym)
            overlay.setLitColor(queued)
            if (queued == null) {
                stopLitPolling()
            }
        }
    }

    private fun handleColorButtonTap(color: MarkColor) {
        if (currentPage != PageState.CHART) return
        if (!isReadingChartTap.compareAndSet(false, true)) return

        workerExecutor.execute {
            try {
                val root = rootInActiveWindow
                var symbol = root?.let { extractChartSymbolFromNodes(it) }
                var source = "节点"

                if (symbol == null) {
                    val bmp = captureScreenBitmap(maxRetries = 3)
                    if (bmp != null) {
                        try {
                            symbol = vision.readChartSymbolFromBitmap(bmp)
                            source = "OCR"
                        } finally {
                            bmp.recycle()
                        }
                    }
                }

                if (symbol != null) {
                    lastChartSymbol = symbol
                    AppStore.putSymbol(symbol, color)
                    AppStore.log("图表识别成功($source)：$symbol -> ${color.label}")
                    overlay.setLitColor(color)
                    startLitPolling()
                } else {
                    AppStore.log("图表未读到品种代码，忽略本次${color.label}色点击（不亮灯）")
                }
            } finally {
                isReadingChartTap.set(false)
            }
        }
    }

    private fun startWatchlistBatch() {
        if (!isBatchRunning.compareAndSet(false, true)) return
        abortBatchRequested.set(false)

        workerExecutor.execute {
            try {
                runWatchlistBatchLoop()
            } catch (e: Exception) {
                AppStore.log("批处理异常：${e.message}")
            } finally {
                isBatchRunning.set(false)
            }
        }
    }

    private fun runWatchlistBatchLoop() {
        val tasks = AppStore.snapshotQueue()
        if (tasks.isEmpty()) return

        sleepSafe(450L)
        if (shouldAbortBatch()) return

        val firstBmp = captureScreenBitmap(maxRetries = 4)
        if (firstBmp == null) {
            AppStore.log("批处理启动失败：无法截屏")
            return
        }

        val listName = vision.readActiveWatchlistName(firstBmp) ?: "当前列表"
        val markAllDuplicates = AppStore.isMarkAllDuplicates()
        AppStore.log("开始批处理｜列表=$listName｜同名全添加=$markAllDuplicates｜待办=${tasks.entries.joinToString { "${it.key}:${it.value.label}" }}")

        val foundSymbols = HashSet<String>()
        val menuFailedSymbols = HashSet<String>()

        fun shouldStopEarly(): Boolean {
            return !markAllDuplicates && foundSymbols.containsAll(tasks.keys)
        }

        fun processScreen(bmp: Bitmap): Pair<List<String>, IntArray> {
            val fp = vision.computeListFingerprint(bmp)
            val rows = vision.scanWatchlistSymbols(bmp)
            val visibleNames = rows.map { it.symbol }
            AppStore.log("当前屏识别(${rows.size}个)：${visibleNames.joinToString(",")}")

            val matchedRows = rows.filter { tasks.containsKey(it.symbol) }
            for (row in matchedRows) {
                if (shouldAbortBatch()) break
                val targetColor = tasks[row.symbol] ?: continue

                if (row.existingFlag == targetColor) {
                    AppStore.log("${row.symbol} 已有${targetColor.label}标，跳过防误取消")
                    foundSymbols.add(row.symbol)
                    continue
                }

                val ok = longPressAndSelectColor(row, targetColor, listName)
                if (ok) {
                    foundSymbols.add(row.symbol)
                    menuFailedSymbols.remove(row.symbol)
                } else {
                    menuFailedSymbols.add(row.symbol)
                }
            }
            return visibleNames to fp
        }

        var prevSymbols: List<String>
        var prevFp: IntArray
        try {
            val res = processScreen(firstBmp)
            prevSymbols = res.first
            prevFp = res.second
        } finally {
            firstBmp.recycle()
        }

        var downScrolls = 0
        var sameDownCount = 0
        while (!shouldAbortBatch() && !shouldStopEarly() && downScrolls < 45) {
            performControlledScroll(scrollDown = true)
            sleepSafe(380L)
            if (shouldAbortBatch()) break

            val bmp = captureScreenBitmap(maxRetries = 4) ?: continue
            val (currSymbols, currFp) = try {
                processScreen(bmp)
            } finally {
                bmp.recycle()
            }

            if (currSymbols == prevSymbols && vision.isSameFrame(prevFp, currFp)) {
                sameDownCount++
                if (sameDownCount >= 2) {
                    AppStore.log("已滑到列表底部（向下共翻 $downScrolls 屏）")
                    break
                }
            } else {
                sameDownCount = 0
                downScrolls++
            }
            prevSymbols = currSymbols
            prevFp = currFp
        }

        if (!shouldAbortBatch() && !shouldStopEarly()) {
            val fastReturnSteps = (downScrolls - 1).coerceAtLeast(0)
            if (fastReturnSteps > 0) {
                AppStore.log("掉头快速返回起点上方（回退 $fastReturnSteps 屏）")
                for (i in 0 until fastReturnSteps) {
                    if (shouldAbortBatch()) break
                    performFastScroll(scrollDown = false)
                    sleepSafe(260L)
                }
                sleepSafe(320L)
            } else {
                // 原本就在底部，先向上翻一屏再开始扫
                performControlledScroll(scrollDown = false)
                sleepSafe(380L)
            }

            var upScrolls = 0
            var sameUpCount = 0
            prevSymbols = emptyList()
            prevFp = IntArray(0)

            while (!shouldAbortBatch() && !shouldStopEarly() && upScrolls < 45) {
                val bmp = captureScreenBitmap(maxRetries = 4) ?: break
                val (currSymbols, currFp) = try {
                    processScreen(bmp)
                } finally {
                    bmp.recycle()
                }

                if (currSymbols == prevSymbols && vision.isSameFrame(prevFp, currFp)) {
                    sameUpCount++
                    if (sameUpCount >= 2) {
                        AppStore.log("已滑到列表顶部（向上共翻 $upScrolls 屏）")
                        break
                    }
                } else {
                    sameUpCount = 0
                    upScrolls++
                }
                prevSymbols = currSymbols
                prevFp = currFp

                if (!shouldStopEarly() && !shouldAbortBatch()) {
                    performControlledScroll(scrollDown = false)
                    sleepSafe(380L)
                }
            }
        }

        if (shouldAbortBatch()) {
            AppStore.log("批处理被手动打断，未完成队列已保留")
            return
        }

        for ((sym, color) in tasks) {
            if (sym in foundSymbols) {
                AppStore.removeSymbol(sym)
            } else if (sym in menuFailedSymbols) {
                val msg = "$listName｜未找到 $sym 的颜色菜单，待办已保留。"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                sendMissedNotification(msg)
            } else {
                val msg = "待添加 $sym 到 ${color.label}色列表，但是该品种在 $listName 列表内没有找到"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                sendMissedNotification(msg)
                AppStore.removeSymbol(sym)
            }
        }

        batchDoneForCurrentWatchlistVisit = true
        AppStore.log("批处理完成｜成功=${foundSymbols.size}/${tasks.size}")
        overlay.showDoneBanner()
    }

    private fun longPressAndSelectColor(
        row: WatchlistRow,
        color: MarkColor,
        listName: String
    ): Boolean {
        val attempts = listOf(
            Triple(row.centerX, row.centerY, 650L),
            Triple(row.centerX + 18, row.centerY, 780L)
        )

        for ((idx, attempt) in attempts.withIndex()) {
            if (shouldAbortBatch()) return false
            val (lx, ly, dur) = attempt
            AppStore.log("长按 ${row.symbol}（第${idx + 1}次）坐标=($lx,$ly) 时长=${dur}ms")

            val pressed = dispatchLongPress(lx.toFloat(), ly.toFloat(), dur)
            if (!pressed) {
                AppStore.log("长按手势被系统取消，重试")
                sleepSafe(300L)
                continue
            }

            sleepSafe(420L)

            var menuDots: ColorMenuDots? = null
            for (scanTry in 0 until 2) {
                val menuBmp = captureScreenBitmap(maxRetries = 3)
                if (menuBmp != null) {
                    try {
                        menuDots = vision.findColorMenu(menuBmp)
                    } finally {
                        menuBmp.recycle()
                    }
                }
                if (menuDots != null) break
                sleepSafe(350L)
            }

            if (menuDots != null) {
                val tapX = if (color == MarkColor.RED) menuDots.redX else menuDots.blueX
                val tapY = if (color == MarkColor.RED) menuDots.redY else menuDots.blueY
                AppStore.log(
                    "识别到颜色菜单 红(${menuDots.redX},${menuDots.redY}) 蓝(${menuDots.blueX},${menuDots.blueY}) -> 点击${color.label}($tapX,$tapY)"
                )
                dispatchTap(tapX.toFloat(), tapY.toFloat())
                sleepSafe(420L)
                return true
            } else {
                AppStore.log("$listName｜第${idx + 1}次长按 ${row.symbol} 未扫到红蓝绿黄四连色点")
            }
        }
        return false
    }

    private fun captureScreenBitmap(maxRetries: Int): Bitmap? {
        for (attempt in 0 until maxRetries) {
            val elapsed = System.currentTimeMillis() - lastScreenshotAtMs
            if (elapsed < 380L) {
                sleepSafe(380L - elapsed)
            }

            val latch = CountDownLatch(1)
            val resultRef = AtomicReference<Bitmap?>(null)
            val errRef = AtomicInteger(0)

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        lastScreenshotAtMs = System.currentTimeMillis()
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            if (hw != null) {
                                try {
                                    resultRef.set(hw.copy(Bitmap.Config.ARGB_8888, false))
                                } finally {
                                    hw.recycle()
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            try {
                                screenshot.hardwareBuffer.close()
                            } catch (_: Exception) {
                            }
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        errRef.set(errorCode)
                        latch.countDown()
                    }
                }
            )

            latch.await(3, TimeUnit.SECONDS)
            val bmp = resultRef.get()
            if (bmp != null) return bmp

            val err = errRef.get()
            if (err == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                sleepSafe(500L)
            } else {
                AppStore.log("截屏失败 errorCode=$err（第${attempt + 1}次）")
                sleepSafe(350L)
            }
        }
        return null
    }

    private fun dispatchLongPress(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGestureSync(gesture)
    }

    private fun dispatchTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGestureSync(gesture)
    }

    private fun performControlledScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.54f
        val y1 = if (scrollDown) sh * 0.76f else sh * 0.26f
        val y2 = if (scrollDown) sh * 0.26f else sh * 0.76f

        val dragPath = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, 360L, true)
        val latch = CountDownLatch(1)

        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke1).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    val holdPath = Path().apply {
                        moveTo(x, y2)
                        lineTo(x, y2)
                    }
                    val stroke2 = stroke1.continueStroke(holdPath, 0L, 110L, false)
                    dispatchGesture(
                        GestureDescription.Builder().addStroke(stroke2).build(),
                        object : GestureResultCallback() {
                            override fun onCompleted(g: GestureDescription?) { latch.countDown() }
                            override fun onCancelled(g: GestureDescription?) { latch.countDown() }
                        },
                        null
                    )
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        latch.await(2, TimeUnit.SECONDS)
    }

    private fun performFastScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.54f
        val y1 = if (scrollDown) sh * 0.78f else sh * 0.24f
        val y2 = if (scrollDown) sh * 0.24f else sh * 0.78f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 220L)
        dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchGestureSync(gesture: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok.set(true)
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    ok.set(false)
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok.get()
    }

    private fun shouldAbortBatch(): Boolean {
        return abortBatchRequested.get() || currentPage == PageState.OTHER
    }

    private fun sleepSafe(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(
            NOTIF_CHANNEL_ID,
            "未找到品种提醒",
            NotificationManager.IMPORTANCE_HIGH
        )
        nm.createNotificationChannel(ch)
    }

    private fun sendMissedNotification(message: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TV红蓝标记提醒")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(notifIdCounter.incrementAndGet(), notif)
        } catch (_: Exception) {
        }
    }
}
