package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class TvAccessibilityService : AccessibilityService() {

    companion object {
        const val TV_PACKAGE = "com.tradingview.tradingviewapp"
        private const val NOTIF_CHANNEL_ID = "tv_color_missed_channel"
        private val notifIdCounter = AtomicInteger(1000)

        @Volatile
        var instance: TvAccessibilityService? = null
            private set
    }

    private enum class PageState { CHART, WATCHLIST, OTHER }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val workerExecutor = Executors.newSingleThreadExecutor()
    private val vision = VisionEngine()
    private lateinit var overlay: OverlayController

    @Volatile
    private var currentPage = PageState.OTHER
    @Volatile
    private var lastChartSymbol: String? = null
    @Volatile
    private var cachedChartSymbol: String? = null
    @Volatile
    private var cachedChartAtMs = 0L
    @Volatile
    private var lastLitTickerPatch: IntArray? = null
    @Volatile
    private var lastScreenshotAtMs = 0L
    @Volatile
    private var batchDoneForCurrentWatchlistVisit = false
    @Volatile
    private var ownAppInForeground = false

    // 未完活时保留的右侧提示列表（双击后清空）
    @Volatile
    private var unfinishedInfoItems: List<Pair<String, MarkColor>>? = null

    private val isBatchRunning = AtomicBoolean(false)
    private val abortBatchRequested = AtomicBoolean(false)
    private val tapSeq = AtomicLong(0L)

    private val screenCheckRunnable = Runnable { evaluateCurrentScreen() }
    private val litPollRunnable = object : Runnable {
        override fun run() {
            if (currentPage != PageState.CHART || overlay.getLitColor() == null) return
            if (!isBatchRunning.get()) {
                workerExecutor.execute { pollChartSymbolForAutoOff() }
            }
            mainHandler.postDelayed(this, 360L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppStore.init(this)
        createNotificationChannel()
        overlay = OverlayController(
            context = this,
            onColorTap = { color -> handleColorButtonTap(color) },
            onInfoPanelDoubleTapDismiss = { unfinishedInfoItems = null }
        )
        AppStore.log("无障碍服务已连接")
        scheduleScreenCheck(40L)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        abortBatchRequested.set(true)
        mainHandler.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) {
            overlay.destroy()
        }
        vision.close()
        workerExecutor.shutdownNow()
    }

    override fun onInterrupt() {
        abortBatchRequested.set(true)
    }

    fun onOwnAppForegroundChanged(inForeground: Boolean) {
        ownAppInForeground = inForeground
        if (::overlay.isInitialized) {
            if (inForeground) {
                currentPage = PageState.OTHER
                stopLitPolling()
                overlay.hideButtons()
                overlay.hideInfoPanel()
            } else if (unfinishedInfoItems == null) {
                overlay.hideInfoPanel()
            }
        }
    }

    fun refreshButtonSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            overlay.refreshButtonsInPlace(resetPosition)
        }
    }

    fun refreshInfoPanelSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            overlay.refreshInfoPanelInPlace(resetPosition)
        }
    }

    fun previewDoneBanner() {
        if (::overlay.isInitialized) {
            overlay.showDoneBanner(previewMode = true)
        }
    }

    fun previewInfoPanel() {
        if (::overlay.isInitialized) {
            val q = AppStore.snapshotQueue()
            val sample = if (q.isNotEmpty()) {
                q.entries.map { it.key to it.value }
            } else {
                listOf("SAP" to MarkColor.RED, "AZN" to MarkColor.BLUE)
            }
            overlay.showInfoPanel(sample)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()
        if (pkg == packageName) return

        // 如果用户在图表页滚动了左下角品种切换滚轮，立刻灭灯（0ms响应）
        if (currentPage == PageState.CHART &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            overlay.getLitColor() != null
        ) {
            val src = event.source
            if (src != null) {
                val (sw, sh) = getScreenDimensions()
                val rect = Rect()
                src.getBoundsInScreen(rect)
                if (rect.bottom >= (sh * 0.88f).toInt() && rect.left <= (sw * 0.36f).toInt()) {
                    resetChartLightImmediately("检测到滚动切换品种")
                }
            }
        }

        val delay = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 25L
            AccessibilityEvent.TYPE_VIEW_SCROLLED, AccessibilityEvent.TYPE_VIEW_CLICKED -> 35L
            else -> 65L
        }
        scheduleScreenCheck(delay)
    }

    private fun scheduleScreenCheck(delayMs: Long) {
        mainHandler.removeCallbacks(screenCheckRunnable)
        mainHandler.postDelayed(screenCheckRunnable, delayMs)
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        return b.width() to b.height()
    }

    private fun resetChartLightImmediately(reason: String? = null) {
        lastChartSymbol = null
        cachedChartSymbol = null
        cachedChartAtMs = 0L
        lastLitTickerPatch = null
        stopLitPolling()
        if (overlay.getLitColor() != null) {
            overlay.setLitColor(null)
            if (reason != null) AppStore.log("灭灯：$reason")
        }
    }

    private fun evaluateCurrentScreen() {
        if (ownAppInForeground) return

        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()

        if (pkg != TV_PACKAGE) {
            if (currentPage != PageState.OTHER) {
                currentPage = PageState.OTHER
                resetChartLightImmediately()
                batchDoneForCurrentWatchlistVisit = false
                overlay.hideButtons()
                overlay.hideInfoPanel()
                if (isBatchRunning.get()) {
                    abortBatchRequested.set(true)
                    AppStore.log("检测到离开TradingView，中止批处理")
                }
            }
            return
        }

        val detected = detectTradingViewPage(root)

        if (detected != currentPage) {
            val prev = currentPage
            currentPage = detected
            AppStore.log("页面切换：$prev -> $detected")

            when (detected) {
                PageState.CHART -> {
                    batchDoneForCurrentWatchlistVisit = false
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                    overlay.hideInfoPanel()
                    // 进入图表立刻先置为未选中状态，不墨迹
                    resetChartLightImmediately()
                    overlay.showButtons()
                    syncChartLightFast(root, triggerPreRead = true)
                }

                PageState.WATCHLIST -> {
                    stopLitPolling()
                    overlay.hideButtons()
                    if (AppStore.hasPendingItems() &&
                        !isBatchRunning.get() &&
                        !batchDoneForCurrentWatchlistVisit
                    ) {
                        startWatchlistBatch()
                    } else if (unfinishedInfoItems != null && !isBatchRunning.get()) {
                        unfinishedInfoItems?.let { overlay.showInfoPanel(it) }
                    }
                }

                PageState.OTHER -> {
                    resetChartLightImmediately()
                    overlay.hideButtons()
                    overlay.hideInfoPanel()
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                }
            }
        } else if (detected == PageState.CHART) {
            overlay.showButtons()
            syncChartLightFast(root, triggerPreRead = false)
        } else if (detected == PageState.WATCHLIST) {
            overlay.hideButtons()
            if (AppStore.hasPendingItems() &&
                !isBatchRunning.get() &&
                !batchDoneForCurrentWatchlistVisit
            ) {
                startWatchlistBatch()
            }
        }
    }

    private fun detectTradingViewPage(root: AccessibilityNodeInfo): PageState {
        val (_, sh) = getScreenDimensions()
        val navTopThreshold = (sh * 0.90f).toInt()

        var watchlistNav: AccessibilityNodeInfo? = null
        var chartNav: AccessibilityNodeInfo? = null
        var hasTopWatchlistHeader = false
        var hasChartBottomToolbar = false

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 460) {
            val node = stack.removeLast()
            visited++
            val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim().orEmpty()
            node.getBoundsInScreen(rect)

            if (rect.bottom >= navTopThreshold && text.isNotEmpty()) {
                when (text) {
                    "自选表", "Watchlist" -> watchlistNav = node
                    "图表", "Chart" -> chartNav = node
                }
            } else if (rect.top < sh * 0.14f &&
                (text == "搜索" || text == "Search" || text.startsWith("-1") || text.startsWith("-2") || text.startsWith("-3") || text.startsWith("-4"))
            ) {
                hasTopWatchlistHeader = true
            } else if (rect.top in (sh * 0.90f).toInt()..(sh * 0.955f).toInt() &&
                (text.contains("周") || text.contains("日") || text.contains("小时") || text.contains("分") ||
                    text.equals("1D", true) || text.equals("1W", true))
            ) {
                hasChartBottomToolbar = true
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                stack.add(child)
            }
        }

        // 批处理长按弹出颜色菜单期间保持 WATCHLIST
        if (isBatchRunning.get() && watchlistNav == null && chartNav == null) {
            return PageState.WATCHLIST
        }
        if (watchlistNav == null && chartNav == null) {
            return PageState.OTHER
        }

        val isChartSelected = isNodeOrAncestorSelected(chartNav)
        val isWatchlistSelected = isNodeOrAncestorSelected(watchlistNav)

        return when {
            isChartSelected && !isWatchlistSelected -> PageState.CHART
            isWatchlistSelected && !isChartSelected -> PageState.WATCHLIST
            hasChartBottomToolbar && !hasTopWatchlistHeader -> PageState.CHART
            hasTopWatchlistHeader && !hasChartBottomToolbar -> PageState.WATCHLIST
            else -> PageState.OTHER
        }
    }

    private fun isNodeOrAncestorSelected(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isSelected || cur.isChecked) return true
            val desc = cur.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("已选") || desc.contains("selected")) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    /**
     * 快速同步图表品种并更新亮灯/灭灯状态；节点读不到时支持后台预读缓存
     */
    private fun syncChartLightFast(root: AccessibilityNodeInfo, triggerPreRead: Boolean) {
        val sym = extractChartSymbolFromNodes(root)
        if (sym != null) {
            cachedChartSymbol = sym
            cachedChartAtMs = System.currentTimeMillis()
            if (sym != lastChartSymbol) {
                lastChartSymbol = sym
                val queuedColor = AppStore.getSymbolColor(sym)
                overlay.setLitColor(queuedColor)
                if (queuedColor == null) {
                    stopLitPolling()
                } else {
                    startLitPolling()
                }
            }
        } else if (triggerPreRead) {
            // 后台预读一次图表代码，点红/蓝球时可瞬间命中缓存
            workerExecutor.execute {
                sleepSafe(90L)
                if (currentPage != PageState.CHART || isBatchRunning.get()) return@execute
                val bmp = captureScreenBitmap(maxRetries = 1) ?: return@execute
                try {
                    val patch = vision.computeChartTickerPatchHash(bmp)
                    val ocrSym = vision.readChartSymbolFromBitmap(bmp)
                    if (ocrSym != null && currentPage == PageState.CHART) {
                        cachedChartSymbol = ocrSym
                        cachedChartAtMs = System.currentTimeMillis()
                        lastChartSymbol = ocrSym
                        val queued = AppStore.getSymbolColor(ocrSym)
                        if (queued != null) {
                            lastLitTickerPatch = patch
                            overlay.setLitColor(queued)
                            startLitPolling()
                        } else {
                            overlay.setLitColor(null)
                        }
                    }
                } finally {
                    bmp.recycle()
                }
            }
        }
    }

    private fun extractChartSymbolFromNodes(root: AccessibilityNodeInfo): String? {
        val (sw, sh) = getScreenDimensions()
        val targetCenterY = (sh * 0.938f).toInt()
        val minY = (sh * 0.915f).toInt()
        val maxY = (sh * 0.955f).toInt()
        val maxX = (sw * 0.34f).toInt()

        var bestSym: String? = null
        var bestDist = Int.MAX_VALUE

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 420) {
            val node = stack.removeLast()
            visited++
            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                node.getBoundsInScreen(rect)
                val cy = rect.centerY()
                if (cy in minY..maxY && rect.left in 0..maxX) {
                    val normalized = vision.normalizeTickerCandidate(raw)
                    if (normalized != null) {
                        val dist = kotlin.math.abs(cy - targetCenterY)
                        if (dist < bestDist) {
                            bestDist = dist
                            bestSym = normalized
                        }
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return bestSym
    }

    private fun startLitPolling() {
        mainHandler.removeCallbacks(litPollRunnable)
        mainHandler.postDelayed(litPollRunnable, 360L)
    }

    private fun stopLitPolling() {
        mainHandler.removeCallbacks(litPollRunnable)
    }

    /**
     * 亮灯期间极速监控是否切换了新品种：节点优先（2ms），其次像素指纹比对（0.2ms），变化立即灭灯
     */
    private fun pollChartSymbolForAutoOff() {
        if (currentPage != PageState.CHART || overlay.getLitColor() == null) return
        val root = rootInActiveWindow
        val fromNode = root?.let { extractChartSymbolFromNodes(it) }
        if (fromNode != null) {
            cachedChartSymbol = fromNode
            cachedChartAtMs = System.currentTimeMillis()
            if (fromNode != lastChartSymbol) {
                lastChartSymbol = fromNode
                val queued = AppStore.getSymbolColor(fromNode)
                overlay.setLitColor(queued)
                if (queued == null) stopLitPolling()
            }
            return
        }

        val bmp = captureScreenBitmap(maxRetries = 1) ?: return
        try {
            val currPatch = vision.computeChartTickerPatchHash(bmp)
            if (lastLitTickerPatch != null && vision.isChartPatchChanged(lastLitTickerPatch, currPatch)) {
                // 底部左下角代码像素已变，先瞬间灭灯再更新缓存
                overlay.setLitColor(null)
                stopLitPolling()
                lastLitTickerPatch = null
                val newSym = vision.readChartSymbolFromBitmap(bmp)
                lastChartSymbol = newSym
                cachedChartSymbol = newSym
                cachedChartAtMs = System.currentTimeMillis()
                if (newSym != null) {
                    val queued = AppStore.getSymbolColor(newSym)
                    if (queued != null) {
                        lastLitTickerPatch = currPatch
                        overlay.setLitColor(queued)
                        startLitPolling()
                    }
                }
            } else if (lastLitTickerPatch == null) {
                lastLitTickerPatch = currPatch
            }
        } finally {
            bmp.recycle()
        }
    }

    /**
     * 点击悬浮红/蓝按钮：0ms 瞬间亮灯，随后极速写入队列（若实在未读到代码才灭灯回退）
     */
    private fun handleColorButtonTap(color: MarkColor) {
        if (currentPage != PageState.CHART) return
        val seq = tapSeq.incrementAndGet()

        // 瞬间点亮，零延迟反馈
        overlay.setLitColor(color)

        workerExecutor.execute {
            val root = rootInActiveWindow
            var symbol = root?.let { extractChartSymbolFromNodes(it) }
            var source = "节点"
            var patchForAutoOff: IntArray? = null

            if (symbol == null) {
                val bmp = captureScreenBitmap(maxRetries = 2)
                if (bmp != null) {
                    try {
                        patchForAutoOff = vision.computeChartTickerPatchHash(bmp)
                        symbol = vision.readChartSymbolFromBitmap(bmp)
                        source = "OCR"
                    } finally {
                        bmp.recycle()
                    }
                }
            }

            // 兜底：若本次截屏偶发受限，但有 2 秒内的预读缓存则直接用
            if (symbol == null && cachedChartSymbol != null && System.currentTimeMillis() - cachedChartAtMs <= 2000L) {
                symbol = cachedChartSymbol
                source = "预读缓存"
            }

            if (symbol != null) {
                lastChartSymbol = symbol
                cachedChartSymbol = symbol
                cachedChartAtMs = System.currentTimeMillis()
                if (patchForAutoOff != null) {
                    lastLitTickerPatch = patchForAutoOff
                }
                AppStore.putSymbol(symbol, color)
                AppStore.log("图表极速识别($source)：$symbol -> ${color.label}")
                if (tapSeq.get() == seq && currentPage == PageState.CHART) {
                    overlay.setLitColor(color)
                    startLitPolling()
                }
            } else {
                AppStore.log("图表未读到品种代码，自动灭灯回退")
                if (tapSeq.get() == seq) {
                    overlay.setLitColor(null)
                }
            }
        }
    }

    // =========================================================================
    // 自选表极速批处理引擎
    // =========================================================================

    private fun startWatchlistBatch() {
        if (!isBatchRunning.compareAndSet(false, true)) return
        abortBatchRequested.set(false)

        val initialTasks = AppStore.snapshotQueue()
        if (initialTasks.isEmpty()) {
            isBatchRunning.set(false)
            return
        }

        // 进入列表瞬间立即在右侧竖排显示本次标记清单
        val displayList = initialTasks.entries.map { it.key to it.value }
        unfinishedInfoItems = displayList
        overlay.showInfoPanel(displayList)

        workerExecutor.execute {
            try {
                runWatchlistBatchLoop(initialTasks)
            } catch (e: Exception) {
                AppStore.log("批处理异常：${e.message}")
            } finally {
                isBatchRunning.set(false)
            }
        }
    }

    /**
     * 尝试通过无障碍节点极速读取当前自选表屏幕上的品种代码（耗时 ~3ms）
     */
    private fun scanWatchlistSymbolsFromNodes(): List<WatchlistRow> {
        val root = rootInActiveWindow ?: return emptyList()
        val (sw, sh) = getScreenDimensions()
        val leftMin = (sw * 0.092f).toInt()
        val leftMax = (sw * 0.185f).toInt()
        val topMin = (sh * 0.125f).toInt()
        val bottomMax = (sh * 0.942f).toInt()

        val rows = ArrayList<WatchlistRow>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 550) {
            val node = stack.removeLast()
            visited++
            val raw = node.text?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                node.getBoundsInScreen(rect)
                if (rect.left in leftMin..leftMax &&
                    rect.top >= topMin &&
                    rect.bottom <= bottomMax &&
                    rect.height() in 14..(sh * 0.06f).toInt()
                ) {
                    val sym = vision.extractWatchlistSymbol(raw)
                    if (sym != null) {
                        val cx = ((rect.left + minOf(rect.right, (sw * 0.42f).toInt())) / 2)
                            .coerceIn((sw * 0.12f).toInt(), (sw * 0.42f).toInt())
                        rows.add(
                            WatchlistRow(
                                symbol = sym,
                                centerX = cx,
                                centerY = rect.centerY(),
                                topY = rect.top,
                                bottomY = rect.bottom,
                                hasAnyFlag = false
                            )
                        )
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || kotlin.math.abs(r.centerY - deduped.last().centerY) > (sh * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    private fun runWatchlistBatchLoop(tasks: LinkedHashMap<String, MarkColor>) {
        // 极短稳定等待
        sleepSafe(120L)
        if (shouldAbortBatch()) return

        AppStore.log("极速批处理启动｜待办=${tasks.entries.joinToString { "${it.key}:${it.value.label}" }}")

        val handledSymbols = HashSet<String>()
        val menuFailedSymbols = HashSet<String>()
        var cachedListName: String? = null

        fun getLazyListName(fallbackBmp: Bitmap? = null): String {
            cachedListName?.let { return it }
            val bmp = fallbackBmp ?: captureScreenBitmap(maxRetries = 2)
            val name = if (bmp != null) {
                try {
                    vision.readActiveWatchlistName(bmp)
                } finally {
                    if (fallbackBmp == null) bmp.recycle()
                }
            } else null
            cachedListName = name ?: "当前列表"
            return cachedListName!!
        }

        fun allTasksDone(): Boolean = handledSymbols.containsAll(tasks.keys)

        // 处理当前屏：节点优先极速扫描，命中目标时截屏验证是否已有任意颜色标志；同名品种在当前屏全部处理
        fun scanAndProcessCurrentScreen(): Pair<List<String>, IntArray?> {
            val remainingKeys = tasks.keys - handledSymbols
            if (remainingKeys.isEmpty()) return emptyList<String>() to null

            val (_, screenH) = getScreenDimensions()
            val nodeRows = scanWatchlistSymbolsFromNodes()
            var bmpForScreen: Bitmap? = null
            val finalRows: List<WatchlistRow>
            val nodeScanReliable = nodeRows.size >= 5 ||
                (nodeRows.size >= 2 && nodeRows.last().bottomY >= (screenH * 0.65f).toInt())

            if (nodeScanReliable) {
                val hasMatch = nodeRows.any { it.symbol in remainingKeys }
                if (!hasMatch) {
                    val names = nodeRows.map { it.symbol }
                    AppStore.log("节点快扫(${names.size}个/无命中)：${names.joinToString(",")}")
                    return names to null
                }
                // 命中目标，截 1 张图精准核验左边缘是否已有红/绿/蓝等颜色小旗
                bmpForScreen = captureScreenBitmap(maxRetries = 3)
                finalRows = if (bmpForScreen != null) {
                    nodeRows.map { r ->
                        if (r.symbol in remainingKeys) {
                            r.copy(hasAnyFlag = vision.hasAnyLeftEdgeFlag(bmpForScreen, r.topY, r.bottomY))
                        } else r
                    }
                } else {
                    nodeRows
                }
            } else {
                bmpForScreen = captureScreenBitmap(maxRetries = 3)
                if (bmpForScreen == null) {
                    return emptyList<String>() to null
                }
                finalRows = vision.scanWatchlistSymbols(bmpForScreen)
            }

            val fp = bmpForScreen?.let { vision.computeListFingerprint(it) }
            val visibleNames = finalRows.map { it.symbol }
            AppStore.log("当前屏(${finalRows.size}个)：${visibleNames.joinToString(",")}")

            // 找出当前屏所有匹配未完成任务的品种（包含同名重复行，全部处理）
            val matchedRows = finalRows.filter { it.symbol in remainingKeys }
            bmpForScreen?.recycle()

            for ((idx, row) in matchedRows.withIndex()) {
                if (shouldAbortBatch()) break
                val targetColor = tasks[row.symbol] ?: continue

                if (row.hasAnyFlag) {
                    AppStore.log("${row.symbol} 前方已有颜色标记，直接无视跳过")
                    handledSymbols.add(row.symbol)
                    continue
                }

                val isLastOperation = (idx == matchedRows.lastIndex) &&
                    (handledSymbols.size + 1 >= tasks.size)

                val ok = longPressAndSelectColor(row, targetColor, isLastOperation)
                if (ok) {
                    handledSymbols.add(row.symbol)
                    menuFailedSymbols.remove(row.symbol)
                } else {
                    menuFailedSymbols.add(row.symbol)
                }
            }

            return visibleNames to fp
        }

        // 第1阶段：处理当前屏
        var (prevSymbols, prevFp) = scanAndProcessCurrentScreen()

        // 只要全部品种处理完毕，立即停止，绝不继续往下拉
        if (!shouldAbortBatch() && !allTasksDone()) {
            // 第2阶段：极速向下扫描
            var downScrolls = 0
            var sameDownCount = 0
            while (!shouldAbortBatch() && !allTasksDone() && downScrolls < 45) {
                performControlledScroll(scrollDown = true)
                sleepSafe(120L)
                if (shouldAbortBatch()) break

                val (currSymbols, currFp) = scanAndProcessCurrentScreen()
                if (allTasksDone()) break

                val sameNames = currSymbols.isNotEmpty() && currSymbols == prevSymbols
                val sameFrame = (currFp != null && prevFp != null && vision.isSameFrame(prevFp, currFp))
                if (sameNames || sameFrame) {
                    sameDownCount++
                    if (sameDownCount >= 2 || (sameNames && currSymbols.size >= 4)) {
                        AppStore.log("已达底部（下翻 $downScrolls 屏）")
                        break
                    }
                } else {
                    sameDownCount = 0
                    downScrolls++
                }
                prevSymbols = currSymbols
                prevFp = currFp
            }

            // 第3阶段：仍有未找到的品种，掉头向上扫描到顶部
            if (!shouldAbortBatch() && !allTasksDone()) {
                val fastReturnSteps = (downScrolls - 1).coerceAtLeast(0)
                if (fastReturnSteps > 0) {
                    AppStore.log("未全找到，极速回退 $fastReturnSteps 屏向上搜")
                    for (i in 0 until fastReturnSteps) {
                        if (shouldAbortBatch()) break
                        performFastScroll(scrollDown = false)
                        sleepSafe(100L)
                    }
                    sleepSafe(140L)
                } else {
                    performControlledScroll(scrollDown = false)
                    sleepSafe(120L)
                }

                var upScrolls = 0
                var sameUpCount = 0
                prevSymbols = emptyList()
                prevFp = null

                while (!shouldAbortBatch() && !allTasksDone() && upScrolls < 45) {
                    val (currSymbols, currFp) = scanAndProcessCurrentScreen()
                    if (allTasksDone()) break

                    val sameNames = currSymbols.isNotEmpty() && currSymbols == prevSymbols
                    val sameFrame = (currFp != null && prevFp != null && vision.isSameFrame(prevFp, currFp))
                    if (sameNames || sameFrame) {
                        sameUpCount++
                        if (sameUpCount >= 2 || (sameNames && currSymbols.size >= 4)) {
                            AppStore.log("已达顶部（上翻 $upScrolls 屏）")
                            break
                        }
                    } else {
                        sameUpCount = 0
                        upScrolls++
                    }
                    prevSymbols = currSymbols
                    prevFp = currFp

                    if (!allTasksDone() && !shouldAbortBatch()) {
                        performControlledScroll(scrollDown = false)
                        sleepSafe(120L)
                    }
                }
            }
        }

        if (shouldAbortBatch()) {
            AppStore.log("批处理被手动打断，未完成队列已保留")
            return
        }

        // 收尾判定
        var hasUnfinished = false
        for ((sym, color) in tasks) {
            if (sym in handledSymbols) {
                AppStore.removeSymbol(sym)
            } else if (sym in menuFailedSymbols) {
                hasUnfinished = true
                val listName = getLazyListName()
                val msg = "$listName｜未找到 $sym 的颜色菜单，待办已保留。"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                sendMissedNotification(msg)
            } else {
                hasUnfinished = true
                val listName = getLazyListName()
                val msg = "待添加 $sym 到 ${color.label}色列表，但是该品种在 $listName 列表内没有找到"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                sendMissedNotification(msg)
                AppStore.removeSymbol(sym)
            }
        }

        batchDoneForCurrentWatchlistVisit = true
        if (!hasUnfinished) {
            AppStore.log("全部完活（${handledSymbols.size}/${tasks.size}）")
            // 完活一出现，右侧信息提示立即消失
            unfinishedInfoItems = null
            overlay.hideInfoPanel()
            overlay.showDoneBanner(previewMode = false)
        } else {
            AppStore.log("存在未完成项（成功 ${handledSymbols.size}/${tasks.size}），右侧信息持续保留直至双击关闭")
        }
    }

    private fun longPressAndSelectColor(
        row: WatchlistRow,
        color: MarkColor,
        isLastOperation: Boolean
    ): Boolean {
        val attempts = listOf(
            Triple(row.centerX, row.centerY, 490L),
            Triple(row.centerX + 16, row.centerY, 640L)
        )

        for ((idx, attempt) in attempts.withIndex()) {
            if (shouldAbortBatch()) return false
            val (lx, ly, dur) = attempt
            AppStore.log("长按 ${row.symbol}（第${idx + 1}次）($lx,$ly) ${dur}ms")

            if (!dispatchLongPress(lx.toFloat(), ly.toFloat(), dur)) {
                AppStore.log("长按手势取消，重试")
                sleepSafe(120L)
                continue
            }

            sleepSafe(150L)

            var menuDots: ColorMenuDots? = null
            val retryDelays = longArrayOf(0L, 160L, 220L)
            for (d in retryDelays) {
                if (d > 0L) sleepSafe(d)
                val menuBmp = captureScreenBitmap(maxRetries = 2)
                if (menuBmp != null) {
                    try {
                        menuDots = vision.findColorMenu(menuBmp)
                    } finally {
                        menuBmp.recycle()
                    }
                }
                if (menuDots != null) break
            }

            if (menuDots != null) {
                val tapX = if (color == MarkColor.RED) menuDots.redX else menuDots.blueX
                val tapY = if (color == MarkColor.RED) menuDots.redY else menuDots.blueY
                AppStore.log("命中颜色栏 -> 点${color.label}($tapX,$tapY)")
                dispatchTap(tapX.toFloat(), tapY.toFloat())
                sleepSafe(if (isLastOperation) 60L else 155L)
                return true
            } else {
                AppStore.log("第${idx + 1}次长按 ${row.symbol} 未扫到四连色点")
            }
        }
        return false
    }

    /**
     * 极速安全截屏：最小节流 170ms，遇系统频控再退避 260ms
     */
    private fun captureScreenBitmap(maxRetries: Int): Bitmap? {
        for (attempt in 0 until maxRetries) {
            val elapsed = System.currentTimeMillis() - lastScreenshotAtMs
            if (elapsed < 170L) {
                sleepSafe(170L - elapsed)
            }

            val latch = CountDownLatch(1)
            val resultRef = AtomicReference<Bitmap?>(null)
            val errRef = AtomicInteger(0)

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        lastScreenshotAtMs = System.currentTimeMillis()
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            if (hw != null) {
                                try {
                                    resultRef.set(hw.copy(Bitmap.Config.ARGB_8888, false))
                                } finally {
                                    hw.recycle()
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            try {
                                screenshot.hardwareBuffer.close()
                            } catch (_: Exception) {
                            }
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        errRef.set(errorCode)
                        latch.countDown()
                    }
                }
            )

            latch.await(2, TimeUnit.SECONDS)
            val bmp = resultRef.get()
            if (bmp != null) return bmp

            val err = errRef.get()
            if (err == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                sleepSafe(260L)
            } else {
                AppStore.log("截屏失败 err=$err（第${attempt + 1}次）")
                sleepSafe(180L)
            }
        }
        return null
    }

    private fun dispatchLongPress(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 45L)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    /**
     * 极速无惯性翻屏：在屏幕偏中左（X=45%，避开右侧信息栏）快速滑动并短停消惯性
     */
    private fun performControlledScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.45f
        val y1 = if (scrollDown) sh * 0.82f else sh * 0.20f
        val y2 = if (scrollDown) sh * 0.20f else sh * 0.82f

        val dragPath = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, 190L, true)
        val latch = CountDownLatch(1)

        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke1).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    val holdPath = Path().apply {
                        moveTo(x, y2)
                        lineTo(x, y2)
                    }
                    val stroke2 = stroke1.continueStroke(holdPath, 0L, 65L, false)
                    dispatchGesture(
                        GestureDescription.Builder().addStroke(stroke2).build(),
                        object : GestureResultCallback() {
                            override fun onCompleted(g: GestureDescription?) { latch.countDown() }
                            override fun onCancelled(g: GestureDescription?) { latch.countDown() }
                        },
                        null
                    )
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        latch.await(2, TimeUnit.SECONDS)
    }

    private fun performFastScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.45f
        val y1 = if (scrollDown) sh * 0.82f else sh * 0.20f
        val y2 = if (scrollDown) sh * 0.20f else sh * 0.82f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 140L)
        dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchGestureSync(gesture: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok.set(true)
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    ok.set(false)
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(2, TimeUnit.SECONDS)
        return ok.get()
    }

    private fun shouldAbortBatch(): Boolean {
        return abortBatchRequested.get() || currentPage == PageState.OTHER
    }

    private fun sleepSafe(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(
            NOTIF_CHANNEL_ID,
            "未找到品种提醒",
            NotificationManager.IMPORTANCE_HIGH
        )
        nm.createNotificationChannel(ch)
    }

    private fun sendMissedNotification(message: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TV红蓝标记提醒")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(notifIdCounter.incrementAndGet(), notif)
        } catch (_: Exception) {
        }
    }
}
