package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.roundToInt

private data class TopTabNodeCandidate(
    val info: WatchlistTabInfo,
    val node: AccessibilityNodeInfo?,
    val matchedCatalogIdx: Int
)

class TvAccessibilityService : AccessibilityService() {

    companion object {
        const val TV_PACKAGE = "com.tradingview.tradingviewapp"
        // 新通道 ID + IMPORTANCE_DEFAULT：不弹出顶部悬浮横幅遮挡列表栏，静默留在通知栏
        private const val NOTIF_CHANNEL_ID = "tv_color_missed_quiet_v2"
        private val notifIdCounter = AtomicInteger(2000)
        private val MENU_DOT_X_FRACS = floatArrayOf(0.088f, 0.226f, 0.358f, 0.496f, 0.633f, 0.765f, 0.903f)
        private val PRICE_REGEX = Regex("""^[+-]?\d[\d,.]*%?$""")

        @Volatile
        var instance: TvAccessibilityService? = null
            private set
    }

    private enum class PageState { CHART, WATCHLIST, OTHER }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val chartExecutor = Executors.newSingleThreadExecutor()
    private val batchExecutor = Executors.newSingleThreadExecutor()
    private val vision = VisionEngine()
    private lateinit var overlay: OverlayController

    @Volatile
    private var currentPage = PageState.OTHER
    @Volatile
    private var lastChartSymbol: String? = null
    @Volatile
    private var cachedChartSymbol: String? = null
    @Volatile
    private var cachedChartAtMs = 0L
    @Volatile
    private var lastChartReadUsedOcr = false
    @Volatile
    private var lastKnownWatchlistId: String? = null
    @Volatile
    private var lastScreenshotAtMs = 0L
    @Volatile
    private var ownAppInForeground = false

    // 用户手动操作优先权控制
    private val ownActionDepth = AtomicInteger(0)
    @Volatile
    private var lastOwnActionEndMs = 0L
    @Volatile
    private var userManualYieldUntilMs = 0L
    private val userIntervenedFlag = AtomicBoolean(false)

    private val isBatchRunning = AtomicBoolean(false)
    private val abortBatchRequested = AtomicBoolean(false)
    private val tapSeq = AtomicLong(0L)

    private val screenCheckRunnable = Runnable { evaluateCurrentScreen() }
    private val fastChartSyncRunnable = Runnable {
        if (!AppStore.isWorkEnabled() || currentPage != PageState.CHART || isBatchRunning.get()) return@Runnable
        val root = findTradingViewRoot() ?: return@Runnable
        syncChartLightFast(root)
    }
    private val litNodePollRunnable = object : Runnable {
        override fun run() {
            if (!AppStore.isWorkEnabled() || currentPage != PageState.CHART || overlay.getLitColor() == null) return
            if (!isBatchRunning.get()) {
                val root = findTradingViewRoot()
                val fromNode = root?.let { extractChartSymbolFromNodes(it) }
                if (fromNode != null) {
                    val resolved = CatalogRepository.resolveChartSymbolInCatalog(fromNode, lastKnownWatchlistId) ?: fromNode
                    if (resolved != lastChartSymbol) {
                        lastChartSymbol = resolved
                        cachedChartSymbol = resolved
                        cachedChartAtMs = System.currentTimeMillis()
                        lastChartReadUsedOcr = false
                        val queued = AppStore.getSymbolColor(resolved)
                        overlay.setLitColor(queued)
                        AppStore.log("切图同步：$resolved -> ${queued?.label ?: "灭灯"}")
                        if (queued == null) return
                    }
                }
            }
            mainHandler.postDelayed(this, 120L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppStore.init(this)
        createNotificationChannel()
        overlay = OverlayController(
            context = this,
            onColorDownPreRead = { preReadChartSymbolAsync() },
            onColorTap = { color -> handleColorButtonTap(color) },
            onRequestPauseService = { reason -> pauseServiceAtAppLevel(reason) }
        )
        WorkTileService.requestTileSync(this)
        AppStore.log("无障碍服务已连接（APP开关=${if (AppStore.isWorkEnabled()) "开" else "关"}）")
        chartExecutor.execute { vision.warmUp() }
        scheduleScreenCheck(20L)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        abortBatchRequested.set(true)
        mainHandler.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) {
            overlay.destroy()
        }
        vision.close()
        chartExecutor.shutdownNow()
        batchExecutor.shutdownNow()
    }

    override fun onInterrupt() {
        abortBatchRequested.set(true)
    }

    private fun pauseServiceAtAppLevel(reason: String) {
        tapSeq.incrementAndGet()
        AppStore.setWorkEnabled(this, false, source = reason)
    }

    fun onWorkEnabledChanged(enabled: Boolean) {
        if (!::overlay.isInitialized) return
        if (!enabled) {
            abortBatchRequested.set(true)
            stopLitNodePolling()
            currentPage = PageState.OTHER
            overlay.hideButtons()
            overlay.hideDoneBanner()
        } else {
            abortBatchRequested.set(false)
            currentPage = PageState.OTHER
            scheduleScreenCheck(20L)
        }
    }

    fun onOwnAppForegroundChanged(inForeground: Boolean) {
        ownAppInForeground = inForeground
        if (::overlay.isInitialized) {
            if (inForeground) {
                currentPage = PageState.OTHER
                abortBatchRequested.set(true)
                stopLitNodePolling()
                overlay.hideButtons()
            } else if (AppStore.isWorkEnabled()) {
                scheduleScreenCheck(25L)
            }
        }
    }

    fun refreshButtonSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            overlay.refreshButtonsInPlace(resetPosition)
        }
    }

    fun previewDoneBanner() {
        if (::overlay.isInitialized) {
            overlay.showDoneBanner(previewMode = true)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!AppStore.isWorkEnabled()) return
        val pkg = event.packageName?.toString()
        if (pkg == packageName) return

        // 精准用户手动优先权检测：过滤掉本服务切列表/长按/翻屏/弹窗引发的 TV 自带动画事件
        if (isBatchRunning.get() &&
            pkg == TV_PACKAGE &&
            (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED || event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED)
        ) {
            val now = SystemClock.uptimeMillis()
            val sinceOwn = now - lastOwnActionEndMs
            val isBottomWatchlistClick = event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
                ((event.text?.joinToString("") ?: "") + (event.contentDescription?.toString() ?: "")).let {
                    it.contains("自选表") || it.contains("Watchlist", ignoreCase = true)
                }
            // TV 切列表/关弹窗后会延迟约 0.8~1.2s 发自带滚动事件，拉高滚动屏蔽窗彻底杜绝误判自己！
            val graceMs = if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) 1350L else 550L
            val isHumanAction = !isBottomWatchlistClick && ownActionDepth.get() == 0 && sinceOwn > graceMs
            if (isHumanAction) {
                val yieldMs = if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) 520L else 420L
                val wasYielding = now < userManualYieldUntilMs
                userManualYieldUntilMs = now + yieldMs
                userIntervenedFlag.set(true)
                if (!wasYielding) {
                    AppStore.log("检测到你正在手动操作，短暂停礼让")
                }
            }
        }

        // 图表页滚轮切换品种 -> 0ms 瞬间灭灯（兼容 source 为空及各种滚轮容器）
        if (currentPage == PageState.CHART && pkg == TV_PACKAGE && overlay.getLitColor() != null) {
            if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
                val src = event.source
                if (src == null || lastChartReadUsedOcr) {
                    resetChartLightImmediately("滚轮滚动")
                } else {
                    val (sw, sh) = getScreenDimensions()
                    val rect = Rect()
                    src.getBoundsInScreen(rect)
                    if (rect.isEmpty || (rect.bottom >= (sh * 0.85f).toInt() && rect.left <= (sw * 0.45f).toInt())) {
                        resetChartLightImmediately("滚轮切换品种")
                    }
                }
                mainHandler.removeCallbacks(fastChartSyncRunnable)
                mainHandler.postDelayed(fastChartSyncRunnable, 60L)
            } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED
            ) {
                mainHandler.removeCallbacks(fastChartSyncRunnable)
                mainHandler.postDelayed(fastChartSyncRunnable, 30L)
            }
        }

        if (currentPage == PageState.CHART &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            AppStore.hasPendingItems()
        ) {
            val clickedText = (event.text?.joinToString("") ?: "") + (event.contentDescription?.toString() ?: "")
            if (clickedText.contains("自选表") || clickedText.contains("Watchlist", ignoreCase = true)) {
                mainHandler.removeCallbacks(screenCheckRunnable)
                mainHandler.postDelayed(screenCheckRunnable, 12L)
                return
            }
        }

        val delay = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 10L
            AccessibilityEvent.TYPE_VIEW_CLICKED -> 15L
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> 20L
            else -> 35L
        }
        scheduleScreenCheck(delay)
    }

    private fun scheduleScreenCheck(delayMs: Long) {
        mainHandler.removeCallbacks(screenCheckRunnable)
        mainHandler.postDelayed(screenCheckRunnable, delayMs)
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        return b.width() to b.height()
    }

    private fun resetChartLightImmediately(reason: String? = null) {
        lastChartSymbol = null
        cachedChartSymbol = null
        cachedChartAtMs = 0L
        stopLitNodePolling()
        if (overlay.getLitColor() != null) {
            overlay.setLitColor(null)
            if (reason != null) AppStore.log("灭灯：$reason")
        }
    }

    private fun findTradingViewRoot(): AccessibilityNodeInfo? {
        val active = rootInActiveWindow
        if (active != null && active.packageName?.toString() == TV_PACKAGE) {
            return active
        }
        // 即使顶部弹出微信等其它软件悬浮通知，也能在 windows 里找到 TradingView 主窗
        try {
            val winList = windows
            if (winList != null) {
                var bestRoot: AccessibilityNodeInfo? = null
                var bestArea = -1L
                val r = Rect()
                for (w in winList) {
                    val root = w.root ?: continue
                    if (root.packageName?.toString() == TV_PACKAGE) {
                        w.getBoundsInScreen(r)
                        val area = r.width().toLong() * r.height().toLong()
                        if (area > bestArea) {
                            bestArea = area
                            bestRoot = root
                        }
                    }
                }
                if (bestRoot != null) return bestRoot
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun evaluateCurrentScreen() {
        if (ownAppInForeground) return
        if (!AppStore.isWorkEnabled()) {
            overlay.hideButtons()
            return
        }

        val activeRoot = rootInActiveWindow
        val activePkg = activeRoot?.packageName?.toString()
        // 忽略系统状态栏/通知弹窗本身抢焦点的瞬间
        val isTransientSystemUi = activePkg == "com.android.systemui"
        val tvRoot = if (activePkg == TV_PACKAGE) activeRoot else if (isTransientSystemUi) findTradingViewRoot() else null

        if (tvRoot == null) {
            if (currentPage != PageState.OTHER) {
                currentPage = PageState.OTHER
                resetChartLightImmediately()
                overlay.hideButtons()
                if (isBatchRunning.get()) {
                    abortBatchRequested.set(true)
                    AppStore.log("切离TradingView，暂停批处理（待办池已保留）")
                }
            }
            return
        }

        val detected = detectTradingViewPage(tvRoot)

        if (detected != currentPage) {
            val prev = currentPage
            currentPage = detected
            AppStore.log("页面切换：$prev -> $detected")

            when (detected) {
                PageState.CHART -> {
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                    resetChartLightImmediately()
                    overlay.showButtons()
                    syncChartLightFast(tvRoot)
                }

                PageState.WATCHLIST -> {
                    stopLitNodePolling()
                    overlay.hideButtons()
                    if (AppStore.hasPendingItems() && !isBatchRunning.get()) {
                        startWatchlistBatch()
                    }
                }

                PageState.OTHER -> {
                    resetChartLightImmediately()
                    overlay.hideButtons()
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                }
            }
        } else if (detected == PageState.CHART) {
            overlay.showButtons()
            syncChartLightFast(tvRoot)
        } else if (detected == PageState.WATCHLIST) {
            overlay.hideButtons()
            if (AppStore.hasPendingItems() && !isBatchRunning.get()) {
                startWatchlistBatch()
            }
        }
    }

    private fun detectTradingViewPage(root: AccessibilityNodeInfo): PageState {
        val (_, sh) = getScreenDimensions()
        val navTopThreshold = (sh * 0.90f).toInt()

        var watchlistNav: AccessibilityNodeInfo? = null
        var chartNav: AccessibilityNodeInfo? = null
        var hasTopWatchlistHeader = false
        var hasChartBottomToolbar = false

        val topBound = (sh * 0.145f).toInt()
        val botBound = (sh * 0.890f).toInt()
        // 反向深度优先（栈）：Android 布局里底部导航栏和工具栏是最后的子节点，反向DFS约15步(<1ms)直达！
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 650) {
            val node = stack.removeLast()
            visited++
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && rect.top > topBound && rect.bottom < botBound) {
                continue
            }
            val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim().orEmpty()

            if (rect.bottom >= navTopThreshold && text.isNotEmpty()) {
                when (text) {
                    "自选表", "Watchlist" -> watchlistNav = node
                    "图表", "Chart" -> chartNav = node
                }
            } else if (rect.top < sh * 0.14f &&
                (text == "搜索" || text == "Search" || text.startsWith("-1") || text.startsWith("-2") || text.startsWith("-3") || text.startsWith("-4"))
            ) {
                hasTopWatchlistHeader = true
            } else if (rect.top in (sh * 0.90f).toInt()..(sh * 0.955f).toInt() &&
                (text.contains("周") || text.contains("日") || text.contains("小时") || text.contains("分") ||
                    text.equals("1D", true) || text.equals("1W", true))
            ) {
                hasChartBottomToolbar = true
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                stack.add(child)
            }
        }

        if (isBatchRunning.get() && watchlistNav == null && chartNav == null) {
            return PageState.WATCHLIST
        }
        if (watchlistNav == null && chartNav == null) {
            return PageState.OTHER
        }

        val isChartSelected = isNodeOrAncestorSelected(chartNav)
        val isWatchlistSelected = isNodeOrAncestorSelected(watchlistNav)

        return when {
            isChartSelected && !isWatchlistSelected -> PageState.CHART
            isWatchlistSelected && !isChartSelected -> PageState.WATCHLIST
            hasChartBottomToolbar && !hasTopWatchlistHeader -> PageState.CHART
            hasTopWatchlistHeader && !hasChartBottomToolbar -> PageState.WATCHLIST
            else -> PageState.OTHER
        }
    }

    private fun isNodeOrAncestorSelected(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isSelected || cur.isChecked) return true
            val desc = cur.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("已选") || desc.contains("selected")) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    private fun syncChartLightFast(root: AccessibilityNodeInfo) {
        val rawSym = extractChartSymbolFromNodes(root) ?: return
        val sym = CatalogRepository.resolveChartSymbolInCatalog(rawSym, lastKnownWatchlistId) ?: rawSym
        cachedChartSymbol = sym
        cachedChartAtMs = System.currentTimeMillis()
        if (sym != lastChartSymbol) {
            lastChartSymbol = sym
            val queuedColor = AppStore.getSymbolColor(sym)
            overlay.setLitColor(queuedColor)
            if (queuedColor == null) stopLitNodePolling() else startLitNodePolling()
        }
    }

    private fun extractChartSymbolFromNodes(root: AccessibilityNodeInfo): String? {
        val (sw, sh) = getScreenDimensions()
        val targetCenterY = (sh * 0.938f).toInt()
        val minY = (sh * 0.915f).toInt()
        val maxY = (sh * 0.955f).toInt()
        val maxX = (sw * 0.34f).toInt()

        var bestSym: String? = null
        var bestDist = Int.MAX_VALUE

        // 反向深度优先（栈）：优先钻入底部栏（最后子节点），跳过中间加载中的图表WebView，<1ms直达左下角滚轮！
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 800) {
            val node = stack.removeLast()
            visited++
            node.getBoundsInScreen(rect)
            // 仅对明确有范围且完全在左下角滚轮区域之外的分支剪枝
            if (!rect.isEmpty && (rect.bottom < minY - 50 || rect.top > maxY + 50 || rect.left > maxX + 60)) {
                continue
            }
            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                val cy = rect.centerY()
                if (cy in minY..maxY && rect.left in 0..maxX) {
                    val normalized = vision.normalizeTickerCandidate(raw)
                    if (normalized != null) {
                        val dist = abs(cy - targetCenterY)
                        if (dist < bestDist) {
                            bestDist = dist
                            bestSym = normalized
                            // 距离滚轮中心极近（<18px）说明已精准命中当前高亮品种，提前结束遍历！
                            if (dist <= 18) break
                        }
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return bestSym
    }

    private fun startLitNodePolling() {
        mainHandler.removeCallbacks(litNodePollRunnable)
        mainHandler.postDelayed(litNodePollRunnable, 120L)
    }

    private fun stopLitNodePolling() {
        mainHandler.removeCallbacks(litNodePollRunnable)
    }

    @Volatile
    private var preReadRawSymbol: String? = null
    @Volatile
    private var preReadAtMs = 0L

    /**
     * 手指刚碰到圆球(ACTION_DOWN)就在后台预读左下角滚轮，松手时 0ms 直接命中内存缓存，绝不卡主线程！
     */
    private fun preReadChartSymbolAsync() {
        if (!AppStore.isWorkEnabled()) return
        chartExecutor.execute {
            val raw = findTradingViewRoot()?.let { extractChartSymbolFromNodes(it) } ?: return@execute
            preReadRawSymbol = raw
            preReadAtMs = SystemClock.uptimeMillis()
        }
    }

    private fun handleColorButtonTap(color: MarkColor) {
        if (!AppStore.isWorkEnabled()) return
        val seq = tapSeq.incrementAndGet()

        // 优先使用 ACTION_DOWN 预读到的新鲜滚轮代码（0ms 纯内存读取，主线程零阻塞！）
        val freshPreRead = if (SystemClock.uptimeMillis() - preReadAtMs <= 600L) preReadRawSymbol else null
        val preCanonical = freshPreRead?.let { CatalogRepository.resolveChartSymbolInCatalog(it, lastKnownWatchlistId) ?: it }
        val isSameSymbolAsLit = (preCanonical == null) || (preCanonical == lastChartSymbol)

        if (overlay.getLitColor() == color && isSameSymbolAsLit) {
            // 0ms 瞬间干脆灭灯取消勾选
            overlay.setLitColor(null)
            stopLitNodePolling()

            val targetToRemove = preCanonical ?: lastChartSymbol ?: cachedChartSymbol
            if (targetToRemove != null) {
                if (AppStore.removeSymbol(targetToRemove)) {
                    AppStore.log("取消勾选：$targetToRemove（已移出待添加池）")
                }
                return
            }

            chartExecutor.execute {
                if (tapSeq.get() != seq) return@execute
                val rawSym = resolveCurrentChartSymbolQuick().first ?: return@execute
                val canonical = CatalogRepository.resolveChartSymbolInCatalog(rawSym, lastKnownWatchlistId) ?: rawSym
                if (tapSeq.get() == seq && AppStore.removeSymbol(canonical)) {
                    AppStore.log("取消勾选：$canonical（已移出待添加池）")
                }
            }
            return
        }

        // 0ms 瞬间干脆亮灯（主线程绝不做任何 Binder 阻塞调用）
        overlay.setLitColor(color)

        if (freshPreRead != null) {
            val canonical = CatalogRepository.resolveChartSymbolInCatalog(freshPreRead, lastKnownWatchlistId)
            if (canonical == null) {
                val msg = "品种 $freshPreRead（${color.label}色）不在《品种大全》内，已忽略（可在《品种大全》添加后一键重加）"
                AppStore.log(msg)
                AppStore.addUnaddedItem(freshPreRead, color, msg)
                overlay.setLitColor(null)
                return
            }
            lastChartSymbol = canonical
            cachedChartSymbol = canonical
            cachedChartAtMs = System.currentTimeMillis()
            lastChartReadUsedOcr = false
            AppStore.putSymbol(canonical, color)
            AppStore.log("图表秒选(预读)：$freshPreRead -> $canonical -> ${color.label}")
            startLitNodePolling()
            return
        }

        chartExecutor.execute {
            if (tapSeq.get() != seq) return@execute
            val (rawSym, source) = resolveCurrentChartSymbolQuick()
            if (tapSeq.get() != seq || !AppStore.isWorkEnabled()) return@execute

            if (rawSym == null) {
                AppStore.log("图表未读到品种代码，自动灭灯回退")
                if (tapSeq.get() == seq) overlay.setLitColor(null)
                return@execute
            }

            val canonical = CatalogRepository.resolveChartSymbolInCatalog(rawSym, lastKnownWatchlistId)
            if (canonical == null) {
                val msg = "品种 $rawSym（${color.label}色）不在《品种大全》内，已忽略（可在《品种大全》添加后一键重加）"
                AppStore.log(msg)
                AppStore.addUnaddedItem(rawSym, color, msg)
                if (tapSeq.get() == seq) overlay.setLitColor(null)
                return@execute
            }

            lastChartSymbol = canonical
            cachedChartSymbol = canonical
            cachedChartAtMs = System.currentTimeMillis()
            lastChartReadUsedOcr = (source == "OCR")
            AppStore.putSymbol(canonical, color)
            AppStore.log("图表识别($source)：$rawSym -> $canonical -> ${color.label}")
            if (tapSeq.get() == seq && currentPage == PageState.CHART) {
                overlay.setLitColor(color)
                startLitNodePolling()
            }
        }
    }

    private fun resolveCurrentChartSymbolQuick(): Pair<String?, String> {
        val root = findTradingViewRoot()
        val nodeSym = root?.let { extractChartSymbolFromNodes(it) }
        if (nodeSym != null) {
            return nodeSym to "节点"
        }

        val bmp = captureScreenBitmap(maxRetries = 2)
        if (bmp != null) {
            try {
                val ocrSym = vision.readChartSymbolFromBitmap(bmp)
                if (ocrSym != null) {
                    return ocrSym to "OCR"
                }
            } finally {
                bmp.recycle()
            }
        }

        if (cachedChartSymbol != null && System.currentTimeMillis() - cachedChartAtMs <= 2500L) {
            return cachedChartSymbol to "缓存"
        }
        return null to "无"
    }

    // =========================================================================
    // 《品种大全》驱动：全局统筹、动态顶栏、手动优先礼让、绝不漏找极速引擎
    // =========================================================================

    private fun startWatchlistBatch() {
        if (!AppStore.isWorkEnabled() || !AppStore.hasPendingItems()) return
        if (!isBatchRunning.compareAndSet(false, true)) return
        abortBatchRequested.set(false)
        userIntervenedFlag.set(false)
        userManualYieldUntilMs = 0L
        lastOwnActionEndMs = SystemClock.uptimeMillis()

        batchExecutor.execute {
            try {
                runCrossWatchlistEngine()
            } catch (e: Exception) {
                AppStore.log("批处理异常：${e.message}")
            } finally {
                isBatchRunning.set(false)
                // 如果刚刚因为快速进出页面导致中断，但此刻用户已回到列表页且池里还有待办，立刻续跑！
                if (AppStore.isWorkEnabled() && AppStore.hasPendingItems() && currentPage == PageState.WATCHLIST) {
                    mainHandler.postDelayed({ evaluateCurrentScreen() }, 60L)
                }
            }
        }
    }

    /**
     * 若用户正在手动点击或滑动，立刻暂停礼让，等用户停手后再继续
     * 返回 true 表示期间发生了用户手动操作（外层应重新审视当前列表和屏幕位置）
     */
    private fun yieldForUserIfNeeded(): Boolean {
        var yielded = userIntervenedFlag.getAndSet(false)
        while (!shouldAbortBatch()) {
            val remain = userManualYieldUntilMs - SystemClock.uptimeMillis()
            if (remain <= 0L) break
            yielded = true
            sleepSafe(minOf(remain, 120L))
        }
        if (userIntervenedFlag.getAndSet(false)) {
            yielded = true
        }
        return yielded
    }

    private fun runCrossWatchlistEngine() {
        sleepSafe(15L)
        if (shouldAbortBatch()) return

        val savedLp = AppStore.getLearnedLongPressMs()
        var preferredLongPressMs = if (savedLp in 720L..780L) savedLp else 740L

        val visitedWatchlistIds = HashSet<String>()
        val failedSwitchWatchlistIds = HashSet<String>()
        var anyActionSucceeded = false
        var hadAnyMissedOrError = false
        val unaddedNotices = ArrayList<String>()

        var outerLoops = 0
        while (!shouldAbortBatch() && AppStore.hasPendingItems() && outerLoops < 22) {
            outerLoops++
            yieldForUserIfNeeded()
            if (shouldAbortBatch()) break

            val (firstRows, firstFp, firstBmpForTabFallback) = scanScreenRows(waitForFreshNodes = true)
            if (shouldAbortBatch()) {
                firstBmpForTabFallback?.recycle()
                break
            }

            // 识别当前列表：0ms 品种反推 -> 顶部节点选中项 -> 兜底 OCR
            val currentWl: CatalogWatchlist? = CatalogRepository.identifyWatchlistByVisibleSymbols(firstRows.map { it.symbol })
                ?: detectActiveWatchlistFromTopNodes()
                ?: firstBmpForTabFallback?.let { bmp ->
                    vision.readActiveWatchlistName(bmp)?.let { CatalogRepository.getWatchlistByName(it) }
                }
            firstBmpForTabFallback?.recycle()

            if (currentWl != null) {
                lastKnownWatchlistId = currentWl.id
            }

            val wlNameLog = currentWl?.name ?: "未识别列表"
            AppStore.log("统筹#$outerLoops｜当前=$wlNameLog｜池内=${AppStore.snapshotQueue().size}个")

            // 第1优先：立刻标掉当前屏上已经看得见的待添加品种！
            val intervenedDuringFirst = processVisibleMatches(
                rows = firstRows,
                currentWl = currentWl,
                preferredLongPressMsRef = { preferredLongPressMs },
                onLearnDuration = { d ->
                    preferredLongPressMs = d
                    AppStore.setLearnedLongPressMs(d)
                },
                onSucceeded = { anyActionSucceeded = true },
                onFailedMenu = { sym, col, msg ->
                    hadAnyMissedOrError = true
                    unaddedNotices.add(msg)
                    AppStore.addUnaddedItem(sym, col, msg)
                }
            )
            if (shouldAbortBatch()) break
            if (intervenedDuringFirst || yieldForUserIfNeeded()) {
                continue
            }

            // 第2优先：当前列表内还有待办 -> 统筹规划最优方向（先近后远），彻底搜完才判未找到！
            var pendingInCurrentWl = getPendingSymbolsForWatchlist(currentWl)
            if (currentWl != null && pendingInCurrentWl.isNotEmpty() && !shouldAbortBatch()) {
                val symbolOrders = CatalogRepository.getSymbolOrdersInWatchlist(currentWl.id)
                val visibleIndices = firstRows.flatMap { symbolOrders[it.symbol].orEmpty() }
                val visMin = visibleIndices.minOrNull()
                val visMax = visibleIndices.maxOrNull()

                val targetIndices = pendingInCurrentWl.flatMap { symbolOrders[it].orEmpty() }
                val hasBelow = if (visMax == null || targetIndices.isEmpty()) true else targetIndices.any { it > visMax }
                val hasAbove = if (visMin == null || targetIndices.isEmpty()) true else targetIndices.any { it < visMin }

                // 如果目标序号夹在当前屏首尾之间（如中间板块被折叠或滚屏轻微偏移），直接跳过耗时OCR复核，立刻向下/向上快搜！
                val fallsInsideCurrentSpan = !hasBelow && !hasAbove

                // 决定最优查找方向（保证 directions 绝不为空！）
                val minDownDist = if (visMax != null) targetIndices.filter { it > visMax }.minOfOrNull { it - visMax } ?: Int.MAX_VALUE else 0
                val minUpDist = if (visMin != null) targetIndices.filter { it < visMin }.minOfOrNull { visMin - it } ?: Int.MAX_VALUE else Int.MAX_VALUE

                val directions = ArrayList<Boolean>() // true=向下翻, false=向上翻
                when {
                    fallsInsideCurrentSpan || (hasBelow && hasAbove) -> {
                        if (minDownDist <= minUpDist) {
                            directions.add(true); directions.add(false)
                        } else {
                            directions.add(false); directions.add(true)
                        }
                    }
                    hasBelow -> {
                        directions.add(true)
                        directions.add(false) // 兜底防列表顺序微调漏找（本列表一清空就会立刻跳出，不会多拉）
                    }
                    else -> {
                        directions.add(false)
                        directions.add(true)
                    }
                }

                AppStore.log("列表[${currentWl.name}] 剩余${pendingInCurrentWl.size}个｜优先方向=${if (directions[0]) "下" else "上"}")

                var interruptedByUserOrSwitch = false
                var stepsTakenFirstDir = 0

                for ((dirIdx, goDown) in directions.withIndex()) {
                    if (shouldAbortBatch() || getPendingSymbolsForWatchlist(currentWl).isEmpty()) break
                    if (yieldForUserIfNeeded()) {
                        interruptedByUserOrSwitch = true
                        break
                    }

                    if (dirIdx == 1 && stepsTakenFirstDir > 1) {
                        val backSteps = (stepsTakenFirstDir - 1).coerceAtLeast(1)
                        for (b in 0 until backSteps) {
                            if (shouldAbortBatch()) break
                            if (yieldForUserIfNeeded()) {
                                interruptedByUserOrSwitch = true
                                break
                            }
                            performFastScroll(scrollDown = goDown)
                            sleepSafe(45L)
                        }
                        if (interruptedByUserOrSwitch || shouldAbortBatch()) break
                        sleepSafe(55L)
                    }

                    // 第二个方向起点必须清空旧帧对照，防止回退正好落回首屏立刻误判到达尽头！
                    var prevNames = if (dirIdx == 0) firstRows.map { it.symbol } else emptyList()
                    var prevFp = if (dirIdx == 0) firstFp else null
                    var scrolls = 0
                    var sameCount = 0

                    while (!shouldAbortBatch() && getPendingSymbolsForWatchlist(currentWl).isNotEmpty() && scrolls < 55) {
                        if (yieldForUserIfNeeded()) {
                            interruptedByUserOrSwitch = true
                            break
                        }

                        val scrollOk = performControlledScroll(scrollDown = goDown, stronger = (sameCount > 0))
                        if (!scrollOk) {
                            interruptedByUserOrSwitch = true
                            break
                        }
                        sleepSafe(45L)
                        if (shouldAbortBatch()) break

                        var (rows, fp, bmpExtra) = scanScreenRows(waitForFreshNodes = false)
                        bmpExtra?.recycle()
                        if (shouldAbortBatch()) break

                        var names = rows.map { it.symbol }
                        // 如果刚翻完屏节点树尚未刷新（与上帧一模一样），等 65ms 复查一次，绝不因单帧延迟误判到底！
                        if (names.isNotEmpty() && names == prevNames) {
                            sleepSafe(65L)
                            if (shouldAbortBatch()) break
                            val retry = scanScreenRows(waitForFreshNodes = false)
                            retry.third?.recycle()
                            rows = retry.first
                            fp = retry.second
                            names = rows.map { it.symbol }
                        }

                        val detectedWlNow = CatalogRepository.identifyWatchlistByVisibleSymbols(names)
                        if (detectedWlNow != null && detectedWlNow.id != currentWl.id) {
                            AppStore.log("检测到你切到了[${detectedWlNow.name}]，立刻转战新列表")
                            interruptedByUserOrSwitch = true
                            break
                        }

                        val unchanged = (names.isNotEmpty() && names == prevNames) ||
                            (fp != null && prevFp != null && vision.isSameFrame(prevFp, fp))
                        if (unchanged) {
                            sameCount++
                            if (sameCount >= 2) {
                                AppStore.log("[${currentWl.name}]确认已达${if (goDown) "底部" else "顶部"}（翻 $scrolls 屏）")
                                break
                            }
                            continue
                        }
                        sameCount = 0
                        scrolls++
                        if (dirIdx == 0) stepsTakenFirstDir++
                        prevNames = names
                        prevFp = fp

                        val userIntervened = processVisibleMatches(
                            rows = rows,
                            currentWl = currentWl,
                            preferredLongPressMsRef = { preferredLongPressMs },
                            onLearnDuration = { d ->
                                preferredLongPressMs = d
                                AppStore.setLearnedLongPressMs(d)
                            },
                            onSucceeded = { anyActionSucceeded = true },
                            onFailedMenu = { sym, col, msg ->
                                hadAnyMissedOrError = true
                                unaddedNotices.add(msg)
                                AppStore.addUnaddedItem(sym, col, msg)
                            }
                        )
                        if (userIntervened) {
                            interruptedByUserOrSwitch = true
                            break
                        }

                        // 本列表待办一清空立即停手！
                        if (getPendingSymbolsForWatchlist(currentWl).isEmpty()) {
                            break
                        }
                    }

                    if (interruptedByUserOrSwitch || shouldAbortBatch()) break
                }

                // 关键修复：如果是被切页或用户手动打断，绝不判定“未找到”，直接保留待办池！
                if (shouldAbortBatch()) break
                if (interruptedByUserOrSwitch) continue

                // 只有真真切切上下完整扫遍当前列表仍未找到，才记录“未找到”并移出待办池
                visitedWatchlistIds.add(currentWl.id)
                val stillMissingHere = getPendingSymbolsForWatchlist(currentWl)
                for (sym in stillMissingHere) {
                    val allLocs = CatalogRepository.findLocations(sym)
                    val hasOtherUnvisitedWl = allLocs.any { it.watchlistId !in visitedWatchlistIds && it.watchlistId !in failedSwitchWatchlistIds }
                    if (!hasOtherUnvisitedWl) {
                        val color = AppStore.getSymbolColor(sym) ?: MarkColor.RED
                        val msg = "未添加：$sym（${color.label}色），在 ${currentWl.name} 完整搜遍后未找到"
                        AppStore.log(msg)
                        AppStore.addUnaddedItem(sym, color, msg)
                        unaddedNotices.add(msg)
                        AppStore.removeSymbol(sym)
                        hadAnyMissedOrError = true
                    }
                }
            }

            if (shouldAbortBatch() || !AppStore.hasPendingItems()) break
            if (yieldForUserIfNeeded()) continue

            // 第3优先：按全局最短路径统筹切往下一个列表
            val nextTargetWl = planNextOptimalWatchlist(currentWl, visitedWatchlistIds, failedSwitchWatchlistIds)
            if (nextTargetWl == null) {
                val leftover = AppStore.snapshotQueue()
                for ((sym, color) in leftover) {
                    val locs = CatalogRepository.findLocations(sym)
                    val targetNames = locs.map { it.watchlistName }.distinct().joinToString("/")
                    val msg = if (targetNames.isNotEmpty()) {
                        "未添加：$sym（${color.label}色，属于 $targetNames），未能自动切至该列表"
                    } else {
                        "未添加：$sym 不在《品种大全》内"
                    }
                    AppStore.log(msg)
                    AppStore.addUnaddedItem(sym, color, msg)
                    unaddedNotices.add(msg)
                    AppStore.removeSymbol(sym)
                    hadAnyMissedOrError = true
                }
                break
            }

            AppStore.log("统筹跨列表切换：${currentWl?.name ?: "当前"} -> ${nextTargetWl.name}")
            val prevSymbolsSig = firstRows.map { it.symbol }
            val switchOutcome = switchToWatchlistTab(currentWl, nextTargetWl, prevSymbolsSig)
            if (shouldAbortBatch()) break
            if (switchOutcome == -1) {
                // 用户手动打断 -> 礼让并重新统筹
                continue
            } else if (switchOutcome == 0) {
                AppStore.log("切至[${nextTargetWl.name}]失败，记录跳过")
                failedSwitchWatchlistIds.add(nextTargetWl.id)
                hadAnyMissedOrError = true
            }
        }

        if (shouldAbortBatch()) {
            AppStore.log("批处理暂停（剩余待办 ${AppStore.snapshotQueue().size} 个，回到列表页自动继续）")
            return
        }

        if (unaddedNotices.isNotEmpty()) {
            sendMissedNotification(unaddedNotices.joinToString("\n"))
        }
        if (!AppStore.hasPendingItems()) {
            if (!hadAnyMissedOrError && anyActionSucceeded) {
                AppStore.log("全部完活！")
                overlay.showDoneBanner(previewMode = false)
            } else if (!hadAnyMissedOrError) {
                AppStore.log("待办已全部处理/跳过")
                overlay.showDoneBanner(previewMode = false)
            } else {
                AppStore.log("本轮处理结束（有未添加项，可在APP一键重新加入待添加池）")
            }
        }
    }

    private fun getPendingSymbolsForWatchlist(wl: CatalogWatchlist?): List<String> {
        if (wl == null) return emptyList()
        val pool = AppStore.snapshotQueue()
        return pool.keys.filter { CatalogRepository.isSymbolInWatchlist(it, wl.id) }
    }

    /**
     * 全局 1D 最短路径统筹规划：
     * 已知 12 个列表顺序固定，若左右两边都有待办列表，先清掉总跨度更短的一侧，再单向横扫另一侧，彻底消除折返跑！
     */
    private fun planNextOptimalWatchlist(
        currentWl: CatalogWatchlist?,
        visitedIds: Set<String>,
        failedSwitchIds: Set<String>
    ): CatalogWatchlist? {
        val pool = AppStore.snapshotQueue()
        if (pool.isEmpty()) return null
        val allWls = CatalogRepository.getWatchlists()
        val currIdx = currentWl?.let { CatalogRepository.getWatchlistIndexById(it.id) } ?: 0

        val candidateIndices = LinkedHashSet<Int>()
        for (sym in pool.keys) {
            for (loc in CatalogRepository.findLocations(sym)) {
                if (loc.watchlistId !in visitedIds && loc.watchlistId !in failedSwitchIds) {
                    val idx = allWls.indexOfFirst { it.id == loc.watchlistId }
                    if (idx >= 0) candidateIndices.add(idx)
                }
            }
        }
        if (candidateIndices.isEmpty()) return null

        val leftSide = candidateIndices.filter { it < currIdx }.sortedDescending() // 由近到远
        val rightSide = candidateIndices.filter { it > currIdx }.sorted()          // 由近到远

        val bestIdx = when {
            leftSide.isEmpty() -> rightSide.first()
            rightSide.isEmpty() -> leftSide.first()
            else -> {
                val leftSpan = currIdx - leftSide.last()
                val rightSpan = rightSide.last() - currIdx
                if (leftSpan <= rightSpan) leftSide.first() else rightSide.first()
            }
        }
        return allWls.getOrNull(bestIdx)
    }

    /**
     * 动态高度顶部列表栏切换：
     * - 兼容收起(5.9%) / 半收起(7.3%) / 展开(9.5%) 三种高度，绝不再错扫下方 BABA / DXY 行
     * - 点击优先走无障碍节点 ACTION_CLICK（即使被外部弹窗遮挡也能穿透点击！）
     * - 绝不往右滑进后方垃圾列表区
     * 返回值：1=切换成功，0=失败，-1=被用户手动打断需礼让重算
     */
    private fun switchToWatchlistTab(
        currentWl: CatalogWatchlist?,
        targetWl: CatalogWatchlist,
        prevRowSymbols: List<String>
    ): Int {
        val totalWls = CatalogRepository.getWatchlists().size
        val lastCatalogIdx = (totalWls - 1).coerceAtLeast(0)
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)
        val currIdx = currentWl?.let { CatalogRepository.getWatchlistIndexById(it.id) } ?: -1

        val (sw, sh) = getScreenDimensions()
        val safeLeftX = (sw * 0.13f).toInt()
        val safeRightX = (sw * 0.93f).toInt()

        fun scanTopTabsDynamic(): Pair<List<TopTabNodeCandidate>, Int> {
            val (nodeTabs, nodeY) = findTopTabRowFromNodes()
            if (nodeTabs.isNotEmpty() && nodeTabs.any { it.matchedCatalogIdx >= 0 }) {
                return nodeTabs to nodeY
            }
            val bmp = captureScreenBitmap(maxRetries = 2)
                ?: return nodeTabs to (if (nodeY > 0) nodeY else (sh * 0.095f).toInt())
            return try {
                val dynY = vision.detectTabBarCenterY(bmp)
                val ocrTabs = vision.scanTopWatchlistTabs(bmp).map { t ->
                    TopTabNodeCandidate(t, null, CatalogRepository.matchWatchlistIndexByTabText(t.name))
                }
                ocrTabs to dynY
            } finally {
                bmp.recycle()
            }
        }

        /**
         * 无惯性可控横滑顶部列表栏：
         * 拖动结束后末端停顿 45ms 彻底消除惯性飞甩，绝不再一甩飞进后方几十个垃圾列表！
         * distanceFrac: 0.28f(轻调) / 0.48f(约3个列表) / 0.68f(约4.5个列表)
         */
        fun swipeTabBarAt(tabY: Int, swipeFingerRightToLeft: Boolean, distanceFrac: Float): Boolean {
            val y = tabY.toFloat().coerceIn(sh * 0.045f, sh * 0.125f)
            val span = distanceFrac.coerceIn(0.24f, 0.70f)
            val x1: Float
            val x2: Float
            if (swipeFingerRightToLeft) {
                x1 = sw * 0.86f
                x2 = (sw * (0.86f - span)).coerceAtLeast(sw * 0.15f)
            } else {
                x1 = sw * 0.18f
                x2 = (sw * (0.18f + span)).coerceAtMost(sw * 0.88f)
            }

            val dragPath = Path().apply {
                moveTo(x1, y)
                lineTo(x2, y)
            }
            val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, 145L, true)
            val latch = CountDownLatch(1)
            val ok = AtomicBoolean(false)

            ownActionDepth.incrementAndGet()
            try {
                val accepted = dispatchGesture(
                    GestureDescription.Builder().addStroke(stroke1).build(),
                    object : GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) {
                            val holdPath = Path().apply {
                                moveTo(x2, y)
                                lineTo(x2, y)
                            }
                            val stroke2 = stroke1.continueStroke(holdPath, 0L, 45L, false)
                            dispatchGesture(
                                GestureDescription.Builder().addStroke(stroke2).build(),
                                object : GestureResultCallback() {
                                    override fun onCompleted(g: GestureDescription?) {
                                        ok.set(true)
                                        latch.countDown()
                                    }
                                    override fun onCancelled(g: GestureDescription?) {
                                        ok.set(false)
                                        userManualYieldUntilMs = SystemClock.uptimeMillis() + 850L
                                        userIntervenedFlag.set(true)
                                        latch.countDown()
                                    }
                                },
                                null
                            )
                        }

                        override fun onCancelled(gestureDescription: GestureDescription?) {
                            ok.set(false)
                            userManualYieldUntilMs = SystemClock.uptimeMillis() + 850L
                            userIntervenedFlag.set(true)
                            latch.countDown()
                        }
                    },
                    null
                )
                if (accepted) {
                    latch.await(2, TimeUnit.SECONDS)
                }
            } finally {
                lastOwnActionEndMs = SystemClock.uptimeMillis()
                ownActionDepth.decrementAndGet()
            }
            if (ok.get()) sleepSafe(45L)
            return ok.get()
        }

        fun waitForTabSwitchEffect() {
            // 极速轮询节点等待新列表内容渲染完毕（通常 80~140ms 即完成，免去死等！）
            for (i in 0 until 12) {
                sleepSafe(25L)
                if (shouldAbortBatch() || userIntervenedFlag.get()) return
                val nowRows = scanWatchlistSymbolsFromNodes()
                if (nowRows.size >= 2 && nowRows.map { it.symbol } != prevRowSymbols) {
                    return
                }
            }
        }

        /**
         * 原生无障碍滚动顶部列表栏（~15ms，完全不受收起高度 Y=143 / 状态栏 / 弹窗影响，零惯性！）
         */
        fun tryNativeScrollTabBar(cands: List<TopTabNodeCandidate>, goForwardRight: Boolean): Boolean {
            val anchorNode = cands.firstOrNull { it.node != null }?.node ?: return false
            val action = if (goForwardRight) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            var cur: AccessibilityNodeInfo? = anchorNode.parent
            var depth = 0
            while (cur != null && depth < 5) {
                val hasAct = cur.actionList.any { it.id == action }
                if (cur.isScrollable || hasAct) {
                    ownActionDepth.incrementAndGet()
                    val ok = try {
                        cur.performAction(action)
                    } catch (_: Exception) {
                        false
                    } finally {
                        lastOwnActionEndMs = SystemClock.uptimeMillis()
                        ownActionDepth.decrementAndGet()
                    }
                    if (ok) {
                        sleepSafe(55L)
                        return true
                    }
                }
                cur = cur.parent
                depth++
            }
            return false
        }

        var prevSignature = ""
        var stuckCount = 0

        for (step in 0 until 12) {
            if (shouldAbortBatch()) return 0
            if (yieldForUserIfNeeded()) return -1

            val (candidates, tabY) = scanTopTabsDynamic()
            if (shouldAbortBatch()) return 0
            if (yieldForUserIfNeeded()) return -1
            val sig = candidates.joinToString("|") { "${it.info.name}:${it.matchedCatalogIdx}" }
            AppStore.log("顶部栏#$step(Y=$tabY)：$sig")

            val targetHit = candidates.firstOrNull { it.matchedCatalogIdx == targetIdx }
            if (targetHit != null) {
                if (targetHit.node != null && clickNodeOrParent(targetHit.node)) {
                    AppStore.log("节点直点列表[${targetWl.name}]")
                    waitForTabSwitchEffect()
                    lastOwnActionEndMs = SystemClock.uptimeMillis()
                    return 1
                }

                if (targetHit.info.centerX < safeLeftX && step < 11) {
                    if (!swipeTabBarAt(tabY, swipeFingerRightToLeft = false, distanceFrac = 0.30f)) return -1
                    continue
                }
                if (targetHit.info.centerX > safeRightX && step < 11) {
                    if (!swipeTabBarAt(tabY, swipeFingerRightToLeft = true, distanceFrac = 0.30f)) return -1
                    continue
                }
                val clickX = targetHit.info.centerX.coerceIn(safeLeftX, safeRightX)
                AppStore.log("坐标点击列表[${targetWl.name}] ($clickX,$tabY)")
                if (!dispatchTap(clickX.toFloat(), tabY.toFloat())) return -1
                waitForTabSwitchEffect()
                lastOwnActionEndMs = SystemClock.uptimeMillis()
                return 1
            }

            if (sig == prevSignature && sig.isNotEmpty()) {
                stuckCount++
                if (stuckCount >= 3) {
                    AppStore.log("顶部栏已确认滑到尽头，停止滑动")
                    return 0
                }
            } else {
                stuckCount = 0
                prevSignature = sig
            }

            val knownIndices = candidates.map { it.matchedCatalogIdx }.filter { it >= 0 }
            val hasGarbage = candidates.any { it.matchedCatalogIdx < 0 }
            val seesLastCatalog = knownIndices.any { it >= lastCatalogIdx }

            val goRightToLeft: Boolean = when {
                knownIndices.isEmpty() -> {
                    if (candidates.isNotEmpty()) false
                    else if (currIdx >= 0 && targetIdx >= 0) (targetIdx > currIdx) else false
                }
                seesLastCatalog && targetIdx < lastCatalogIdx -> false
                hasGarbage && knownIndices.max() >= lastCatalogIdx - 1 && targetIdx < knownIndices.min() -> false
                knownIndices.min() > targetIdx -> false
                knownIndices.max() < targetIdx -> true
                else -> (targetIdx > knownIndices.average())
            }

            // 第1优先：如果上次没卡住，尝试 15ms 原生容器滚动（彻底绕开 Y=143 收起顶栏划不动的问题！）
            if (stuckCount == 0 && tryNativeScrollTabBar(candidates, goForwardRight = goRightToLeft)) {
                AppStore.log("顶部栏原生快滚(${if (goRightToLeft) "往后" else "往前"})")
                continue
            }

            // 如果顶栏收起在极高位置(Y<180)且卡住了一次，先小幅下拉列表区把顶栏展开到 Y=230，再横滑 100% 成功！
            if (stuckCount == 1 && tabY < (sh * 0.075f).toInt()) {
                AppStore.log("顶栏收起卡住(Y=$tabY)，先轻拉展开顶栏")
                val pullPath = Path().apply {
                    moveTo(sw * 0.50f, sh * 0.35f)
                    lineTo(sw * 0.50f, sh * 0.52f)
                }
                dispatchGestureSync(
                    GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(pullPath, 0L, 120L))
                        .build()
                )
                sleepSafe(70L)
                continue
            }

            // 第2优先：自适应无惯性横滑（若上次卡住则自动加大滑动幅度并微调 Y）
            val baseFrac = when {
                knownIndices.isEmpty() -> 0.68f
                else -> {
                    val nearest = knownIndices.minByOrNull { abs(it - targetIdx) } ?: targetIdx
                    val gap = abs(targetIdx - nearest)
                    when {
                        gap <= 2 -> 0.45f
                        gap <= 4 -> 0.58f
                        else -> 0.68f
                    }
                }
            }
            val distFrac = if (stuckCount > 0) 0.68f else baseFrac
            val effectiveY = if (stuckCount > 0 && tabY < (sh * 0.08f).toInt()) tabY + 14 else tabY

            AppStore.log("顶部栏(Y=$effectiveY)横滑：${if (goRightToLeft) "往后(右→左)" else "往前(左→右)"} 幅度=${(distFrac * 100).toInt()}%")
            if (!swipeTabBarAt(effectiveY, swipeFingerRightToLeft = goRightToLeft, distanceFrac = distFrac)) {
                return -1
            }
        }
        return 0
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isClickable) {
                ownActionDepth.incrementAndGet()
                return try {
                    cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                } catch (_: Exception) {
                    false
                } finally {
                    lastOwnActionEndMs = SystemClock.uptimeMillis()
                    ownActionDepth.decrementAndGet()
                }
            }
            cur = cur.parent
            depth++
        }
        return false
    }

    /**
     * 精准识别当前激活的顶部标签（0ms 节点）
     */
    private fun detectActiveWatchlistFromTopNodes(): CatalogWatchlist? {
        val (tabs, _) = findTopTabRowFromNodes()
        for (t in tabs) {
            if (t.matchedCatalogIdx >= 0 && t.node != null && isNodeOrAncestorSelected(t.node)) {
                return CatalogRepository.getWatchlists().getOrNull(t.matchedCatalogIdx)
            }
        }
        return null
    }

    /**
     * 动态高度顶栏节点扫描（覆盖展开 9.5% / 半收起 7.3% / 全收起 5.9%）：
     * - 过滤掉价格数字（83.52 / 103.722）、已知品种名（BABA / DXY）和板块分割线
     * - 按 centerY 聚合成水平行，选出真正的顶部标签栏并返回其精确 Y 坐标
     */
    private fun findTopTabRowFromNodes(): Pair<List<TopTabNodeCandidate>, Int> {
        val root = findTradingViewRoot() ?: return emptyList<TopTabNodeCandidate>() to 0
        val (sw, sh) = getScreenDimensions()
        val topMin = (sh * 0.036f).toInt()
        val botMax = (sh * 0.130f).toInt()
        val minX = (sw * 0.080f).toInt()

        val rawCandidates = ArrayList<TopTabNodeCandidate>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 550) {
            val n = queue.removeFirst()
            visited++
            n.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.top > botMax + 30 || rect.bottom < topMin - 30)) {
                continue
            }

            val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (txt.isNotEmpty() &&
                rect.centerY() in topMin..botMax &&
                rect.right > minX &&
                rect.left < sw &&
                rect.width() in 24..(sw * 0.44f).toInt() &&
                rect.height() in 18..(sh * 0.068f).toInt()
            ) {
                // 剔除价格/涨跌幅、板块线、已知股票代码（如 BABA / DXY），绝不把品种行当列表栏！
                val isPrice = PRICE_REGEX.matches(txt)
                val isSection = txt.startsWith("---") || txt.startsWith("—") || txt.startsWith("✓") || txt.startsWith("▼") || txt.contains("——")
                val isKnownTicker = CatalogRepository.findLocations(txt).isNotEmpty()
                if (!isPrice && !isSection && !isKnownTicker) {
                    val matchedIdx = CatalogRepository.matchWatchlistIndexByTabText(txt)
                    val info = WatchlistTabInfo(txt, rect.left, rect.right, rect.centerX(), rect.centerY())
                    rawCandidates.add(TopTabNodeCandidate(info, n, matchedIdx))
                }
            }

            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                queue.add(c)
            }
        }

        if (rawCandidates.isEmpty()) return emptyList<TopTabNodeCandidate>() to 0

        // 按 centerY 聚类成若干水平行（容差 ±24px）
        val rowGroups = ArrayList<MutableList<TopTabNodeCandidate>>()
        for (cand in rawCandidates.sortedBy { it.info.centerY }) {
            val group = rowGroups.firstOrNull { abs(it.first().info.centerY - cand.info.centerY) <= 24 }
            if (group != null) {
                group.add(cand)
            } else {
                rowGroups.add(mutableListOf(cand))
            }
        }

        // 选出得分最高的水平行作为真正的列表栏（含匹配《品种大全》标签的权重最高）
        val bestGroup = rowGroups.maxByOrNull { grp ->
            val catalogHits = grp.count { it.matchedCatalogIdx >= 0 }
            val dashHits = grp.count { it.info.name.startsWith("-") || it.info.name.contains("000") }
            val avgY = grp.map { it.info.centerY }.average()
            catalogHits * 20 + dashHits * 4 + grp.size * 2 - (avgY / sh * 3.0).toInt()
        } ?: return emptyList<TopTabNodeCandidate>() to 0

        // 按 X 排序并去重重叠子节点
        val sorted = bestGroup.sortedBy { it.info.centerX }
        val deduped = ArrayList<TopTabNodeCandidate>()
        for (c in sorted) {
            if (deduped.isEmpty() || abs(c.info.centerX - deduped.last().info.centerX) > (sw * 0.04f).toInt()) {
                deduped.add(c)
            }
        }
        val avgY = deduped.map { it.info.centerY }.average().roundToInt()
        return deduped to avgY
    }

    private fun scanScreenRows(waitForFreshNodes: Boolean): Triple<List<WatchlistRow>, IntArray?, Bitmap?> {
        val poolKeys = AppStore.snapshotQueue().keys
        val (_, screenH) = getScreenDimensions()

        var nodeRows = scanWatchlistSymbolsFromNodes()
        // 刚进页面或刚切列表时，极速轮询节点最多 120ms（避免落入 1.2s 截屏+OCR 慢路径！）
        if (waitForFreshNodes && nodeRows.size < 3) {
            for (tryIdx in 0 until 3) {
                sleepSafe(35L)
                if (shouldAbortBatch()) return Triple(emptyList(), null, null)
                nodeRows = scanWatchlistSymbolsFromNodes()
                if (nodeRows.size >= 3) break
            }
        }

        val nodeReliable = nodeRows.size >= 4 ||
            (nodeRows.size >= 2 && nodeRows.last().bottomY >= (screenH * 0.60f).toInt())

        if (nodeReliable) {
            val hasMatch = nodeRows.any { vision.findMatchingTaskKey(it.symbol, poolKeys) != null }
            if (!hasMatch) {
                return Triple(nodeRows, null, null)
            }
            val captured = captureScreenBitmap(maxRetries = 3)
            if (captured != null) {
                val rowsWithFlags = nodeRows.map { r ->
                    if (vision.findMatchingTaskKey(r.symbol, poolKeys) != null) {
                        r.copy(hasAnyFlag = vision.hasAnyLeftEdgeFlag(captured, r.topY, r.bottomY))
                    } else r
                }
                val fp = vision.computeListFingerprint(captured)
                return Triple(rowsWithFlags, fp, captured)
            }
            return Triple(nodeRows, null, null)
        }

        var captured = captureScreenBitmap(maxRetries = 3) ?: return Triple(emptyList(), null, null)
        var rows = vision.scanWatchlistSymbols(captured)
        if (waitForFreshNodes && rows.isEmpty() && !shouldAbortBatch()) {
            captured.recycle()
            sleepSafe(55L)
            captured = captureScreenBitmap(maxRetries = 2) ?: return Triple(emptyList(), null, null)
            rows = vision.scanWatchlistSymbols(captured)
        }
        val fp = vision.computeListFingerprint(captured)
        return Triple(rows, fp, captured)
    }

    /**
     * 返回 true 表示过程中发生了用户手动打断/礼让
     */
    private fun processVisibleMatches(
        rows: List<WatchlistRow>,
        currentWl: CatalogWatchlist?,
        preferredLongPressMsRef: () -> Long,
        onLearnDuration: (Long) -> Unit,
        onSucceeded: () -> Unit,
        onFailedMenu: (String, MarkColor, String) -> Unit
    ): Boolean {
        val pool = AppStore.snapshotQueue()
        if (pool.isEmpty() || rows.isEmpty()) return false

        val matchedPairs = ArrayList<Pair<WatchlistRow, String>>()
        for (row in rows) {
            val taskKey = vision.findMatchingTaskKey(row.symbol, pool.keys) ?: continue
            matchedPairs.add(row to taskKey)
        }
        if (matchedPairs.isEmpty()) return false

        val symbolOrdersInWl = currentWl?.let { CatalogRepository.getSymbolOrdersInWatchlist(it.id) } ?: emptyMap()
        val visibleOrderBounds = rows.flatMap { symbolOrdersInWl[it.symbol].orEmpty() }
        val visMinOrder = visibleOrderBounds.minOrNull()
        val visMaxOrder = visibleOrderBounds.maxOrNull()

        for ((idx, pair) in matchedPairs.withIndex()) {
            if (shouldAbortBatch()) return false
            if (yieldForUserIfNeeded()) return true

            val (row, taskKey) = pair
            val targetColor = AppStore.getSymbolColor(taskKey) ?: continue

            val hasMoreSameOnScreen = matchedPairs.drop(idx + 1).any { it.second == taskKey }
            val allOrdersHere = symbolOrdersInWl[taskKey].orEmpty()
            val hasMoreDuplicateOutsideScreen = if (visMinOrder != null && visMaxOrder != null && allOrdersHere.size > 1) {
                allOrdersHere.any { it < visMinOrder || it > visMaxOrder }
            } else {
                false
            }

            if (row.hasAnyFlag) {
                AppStore.log("${row.symbol} 已有颜色标记，无视跳过")
                onSucceeded()
                if (!hasMoreSameOnScreen && !hasMoreDuplicateOutsideScreen) {
                    AppStore.removeSymbol(taskKey)
                }
                continue
            }

            val isLastOpOverall = !hasMoreSameOnScreen && !hasMoreDuplicateOutsideScreen &&
                (idx == matchedPairs.lastIndex) && (AppStore.snapshotQueue().size <= 1)

            val usedDur = longPressAndSelectColor(
                row = row,
                color = targetColor,
                firstDurationMs = preferredLongPressMsRef(),
                isLastOperation = isLastOpOverall
            )
            if (usedDur == -2L) {
                // 被用户触屏取消手势 -> 绝不移出待办池，立即礼让！
                return true
            } else if (usedDur > 0L) {
                onLearnDuration(usedDur)
                onSucceeded()
                if (!hasMoreSameOnScreen && !hasMoreDuplicateOutsideScreen) {
                    AppStore.removeSymbol(taskKey)
                }
            } else if (!shouldAbortBatch()) {
                val wlLabel = currentWl?.name ?: "当前列表"
                val msg = "未添加：$taskKey（${targetColor.label}色），在 $wlLabel 未弹出颜色菜单"
                AppStore.log(msg)
                onFailedMenu(taskKey, targetColor, msg)
                AppStore.removeSymbol(taskKey)
            }
        }
        return false
    }

    private fun scanWatchlistSymbolsFromNodes(): List<WatchlistRow> {
        val root = findTradingViewRoot() ?: return emptyList()
        val (sw, sh) = getScreenDimensions()
        val leftMax = (sw * 0.220f).toInt()
        // 兼容收起顶栏(7.3%)，避免漏扫顶部第一行品种
        val topMin = (sh * 0.075f).toInt()
        val bottomMax = (sh * 0.944f).toInt()

        val rows = ArrayList<WatchlistRow>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val rect = Rect()

        while (queue.isNotEmpty() && visited < 720) {
            val node = queue.removeFirst()
            visited++
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && (rect.bottom < topMin || rect.top > bottomMax || rect.left > sw * 0.55f)) {
                continue
            }

            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty() &&
                rect.left in 0..leftMax &&
                rect.top >= topMin &&
                rect.bottom <= bottomMax &&
                rect.height() in 14..(sh * 0.085f).toInt()
            ) {
                // 排除顶部列表名自身
                if (CatalogRepository.matchWatchlistIndexByTabText(raw) >= 0) continue

                val sym = vision.extractWatchlistSymbol(raw)
                if (sym != null) {
                    val cx = if (rect.left >= (sw * 0.08f).toInt()) {
                        ((rect.left + minOf(rect.right, (sw * 0.40f).toInt())) / 2)
                            .coerceIn((sw * 0.14f).toInt(), (sw * 0.36f).toInt())
                    } else {
                        (sw * 0.24f).toInt()
                    }
                    rows.add(
                        WatchlistRow(
                            symbol = sym,
                            centerX = cx,
                            centerY = rect.centerY(),
                            topY = rect.top,
                            bottomY = rect.bottom,
                            hasAnyFlag = false
                        )
                    )
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                queue.add(c)
            }
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || abs(r.centerY - deduped.last().centerY) > (sh * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    private fun getTvWindowRootsOrderedBySmallFirst(): List<Pair<AccessibilityNodeInfo, Rect>> {
        val roots = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()
        val winRect = Rect()
        try {
            val winList = windows
            if (winList != null) {
                for (w in winList) {
                    val r = w.root ?: continue
                    if (r.packageName?.toString() != TV_PACKAGE) continue
                    w.getBoundsInScreen(winRect)
                    roots.add(r to Rect(winRect))
                }
            }
        } catch (_: Exception) {
        }
        if (roots.isEmpty()) {
            val active = rootInActiveWindow
            if (active != null && active.packageName?.toString() == TV_PACKAGE) {
                active.getBoundsInScreen(winRect)
                roots.add(active to Rect(winRect))
            }
        }
        // PopupWindow 宽度明显小于全屏主窗口，排在最前优先秒查！
        roots.sortBy { it.second.width() }
        return roots
    }

    /**
     * 2ms 极速判定长按菜单是否仍在屏幕上（单次原生 findAccessibilityNodeInfosByText，告别 600 次 Binder 扫描！）
     */
    private fun isColorMenuStillOpenFast(): Boolean {
        for ((r, _) in getTvWindowRootsOrderedBySmallFirst()) {
            val hits = try {
                r.findAccessibilityNodeInfosByText("移至底部")
            } catch (_: Exception) {
                null
            }
            if (!hits.isNullOrEmpty()) return true
        }
        return false
    }

    /**
     * 5ms 极速定位 7 色菜单圆点（原生文本直查 + 仅遍历 25 个菜单子节点，速度提升 20 倍！）
     */
    private fun findColorMenuFromAccessibilityWindows(): Pair<ColorMenuDots, String>? {
        val (sw, sh) = getScreenDimensions()
        val roots = getTvWindowRootsOrderedBySmallFirst()

        for ((rootNode, wBounds) in roots) {
            val mbNodes = try {
                rootNode.findAccessibilityNodeInfosByText("移至底部")
                    ?.takeIf { it.isNotEmpty() }
                    ?: rootNode.findAccessibilityNodeInfosByText("Move to bottom")
            } catch (_: Exception) {
                null
            }
            if (mbNodes.isNullOrEmpty()) continue

            val aaNodes = try {
                rootNode.findAccessibilityNodeInfosByText("添加警报")
                    ?.takeIf { it.isNotEmpty() }
                    ?: rootNode.findAccessibilityNodeInfosByText("Add alert")
            } catch (_: Exception) {
                null
            }
            if (aaNodes.isNullOrEmpty()) continue

            val mbNode = mbNodes[0]
            val mbRect = Rect().also { mbNode.getBoundsInScreen(it) }
            val aaRect = Rect().also { aaNodes[0].getBoundsInScreen(it) }
            if (aaRect.centerY() <= mbRect.centerY() + 25) continue

            // 只在弹窗菜单的局部父容器内找 7 颗圆点（~25 个节点，耗时 ~4ms！）
            val bandTop = mbRect.bottom - 12
            val bandBottom = aaRect.top + 12
            var searchRoot: AccessibilityNodeInfo = rootNode
            if (wBounds.width() > (sw * 0.72f).toInt()) {
                var cur = mbNode.parent
                var depth = 0
                val pRect = Rect()
                while (cur != null && depth < 5) {
                    cur.getBoundsInScreen(pRect)
                    if (pRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt() && pRect.height() > (sh * 0.22f).toInt()) {
                        searchRoot = cur
                        break
                    }
                    cur = cur.parent
                    depth++
                }
            }

            val dotCandidates = ArrayList<Rect>()
            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(searchRoot)
            var visited = 0
            val rect = Rect()
            while (stack.isNotEmpty() && visited < 120) {
                val n = stack.removeLast()
                visited++
                n.getBoundsInScreen(rect)
                if (!rect.isEmpty && (rect.bottom < bandTop - 20 || rect.top > bandBottom + 20)) {
                    continue
                }
                if (rect.width() in 16..(sw * 0.14f).toInt() &&
                    rect.height() in 16..(sw * 0.14f).toInt() &&
                    rect.centerY() in bandTop..bandBottom &&
                    rect.left >= 0 && rect.right <= (sw * 0.65f).toInt() &&
                    n.text.isNullOrEmpty() &&
                    (n.isClickable || n.childCount == 0)
                ) {
                    dotCandidates.add(Rect(rect))
                }
                for (i in 0 until n.childCount) {
                    val c = n.getChild(i) ?: continue
                    stack.add(c)
                }
            }

            dotCandidates.sortBy { it.centerX() }
            val distinctDots = ArrayList<Rect>()
            for (r in dotCandidates) {
                if (distinctDots.isEmpty() || abs(r.centerX() - distinctDots.last().centerX()) > (sw * 0.03f).toInt()) {
                    distinctDots.add(r)
                }
            }

            if (distinctDots.size == 7) {
                val xs = IntArray(7) { distinctDots[it].centerX() }
                val avgY = distinctDots.map { it.centerY() }.average().roundToInt()
                if (avgY in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) {
                    return ColorMenuDots(xs, avgY) to "节点直取7点"
                }
            }

            // 锚点几何推算兜底（~1ms）
            val dotY = (mbRect.centerY() + (aaRect.centerY() - mbRect.centerY()) * 0.412f).roundToInt()
            if (dotY !in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) continue

            val srRect = Rect().also { searchRoot.getBoundsInScreen(it) }
            val menuLeft = if (srRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) srRect.left else (sw * 0.026f).toInt()
            val menuRight = if (srRect.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) srRect.right else (sw * 0.519f).toInt()
            val menuW = (menuRight - menuLeft).coerceAtLeast((sw * 0.40f).toInt())
            val xs = IntArray(7) { idx ->
                (menuLeft + menuW * MENU_DOT_X_FRACS[idx]).roundToInt().coerceIn(4, sw - 4)
            }
            return ColorMenuDots(xs, dotY) to "锚点零截屏"
        }
        return null
    }

    /**
     * 返回 >0L 表示成功所用时长；-1L 表示未弹出菜单；-2L 表示被用户触屏打断（礼让，不判失败！）
     */
    private fun longPressAndSelectColor(
        row: WatchlistRow,
        color: MarkColor,
        firstDurationMs: Long,
        isLastOperation: Boolean
    ): Long {
        val (_, sh) = getScreenDimensions()
        val rowMidY = (row.centerY + (sh * 0.006f).toInt()).coerceAtMost((sh * 0.935f).toInt())
        val secondDurationMs = maxOf(firstDurationMs + 115L, 830L)
        val attempts = listOf(
            Triple(row.centerX, rowMidY, firstDurationMs),
            Triple(row.centerX + 20, row.centerY, secondDurationMs)
        )

        for ((idx, attempt) in attempts.withIndex()) {
            if (shouldAbortBatch()) return -2L
            val (lx, ly, dur) = attempt
            AppStore.log("长按 ${row.symbol} 第${idx + 1}次 ($lx,$ly) ${dur}ms")

            if (!dispatchLongPress(lx.toFloat(), ly.toFloat(), dur)) {
                userManualYieldUntilMs = SystemClock.uptimeMillis() + 650L
                userIntervenedFlag.set(true)
                AppStore.log("检测到触屏中断长按，短礼让用户（待办已保留）")
                return -2L
            }

            // 核心提速：长按 740ms 结束时弹窗通常已展开，0ms 立即查一次(5ms)，未出再 20ms 步进极速轮询！
            var found: Pair<ColorMenuDots, String>? = findColorMenuFromAccessibilityWindows()
            if (found == null) {
                val nodePollSteps = longArrayOf(20L, 25L, 30L, 35L, 40L, 45L)
                for (stepWait in nodePollSteps) {
                    sleepSafe(stepWait)
                    if (shouldAbortBatch()) return -2L
                    found = findColorMenuFromAccessibilityWindows()
                    if (found != null) break
                }
            }

            // 仅在 250ms 内节点未出现时，才降级截屏像素扫描兜底
            if (found == null) {
                val retryDelays = longArrayOf(0L, 90L)
                for (d in retryDelays) {
                    if (d > 0L) sleepSafe(d)
                    if (shouldAbortBatch()) return -2L
                    found = findColorMenuFromAccessibilityWindows()
                    if (found != null) break

                    val menuBmp = captureScreenBitmap(maxRetries = 1)
                    if (menuBmp != null) {
                        try {
                            val dots = vision.findColorMenu(menuBmp)
                            if (dots != null) {
                                found = dots to "截屏像素"
                            }
                        } finally {
                            menuBmp.recycle()
                        }
                    }
                    if (found != null) break
                }
            }

            if (found != null) {
                val (menuDots, method) = found
                val (tapX, tapY) = menuDots.pointFor(color)
                AppStore.log("命中7色栏($method) -> 点${color.label}($tapX,$tapY)")
                dispatchTap(tapX.toFloat(), tapY.toFloat())
                if (!isLastOperation) {
                    // 2ms 极速轮询等待菜单关闭（总耗时 ~60~80ms），告别原来 1 秒的卡顿间隙！
                    for (w in 0 until 8) {
                        sleepSafe(18L)
                        if (!isColorMenuStillOpenFast()) break
                    }
                    sleepSafe(15L)
                    lastOwnActionEndMs = SystemClock.uptimeMillis()
                }
                // 只有首次成功才学习时长，避免偶发二次重试永久拉慢后续所有长按
                return if (idx == 0) dur else firstDurationMs
            } else {
                AppStore.log("第${idx + 1}次长按 ${row.symbol} 未找到7色栏")
            }
        }
        return -1L
    }

    private fun captureScreenBitmap(maxRetries: Int): Bitmap? {
        for (attempt in 0 until maxRetries) {
            val elapsed = System.currentTimeMillis() - lastScreenshotAtMs
            if (elapsed < 70L) {
                sleepSafe(70L - elapsed)
            }

            val latch = CountDownLatch(1)
            val resultRef = AtomicReference<Bitmap?>(null)
            val errRef = AtomicInteger(0)

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        lastScreenshotAtMs = System.currentTimeMillis()
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            if (hw != null) {
                                try {
                                    resultRef.set(hw.copy(Bitmap.Config.ARGB_8888, false))
                                } finally {
                                    hw.recycle()
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            try {
                                screenshot.hardwareBuffer.close()
                            } catch (_: Exception) {
                            }
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        errRef.set(errorCode)
                        latch.countDown()
                    }
                }
            )

            latch.await(2, TimeUnit.SECONDS)
            val bmp = resultRef.get()
            if (bmp != null) return bmp

            val err = errRef.get()
            if (err == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                sleepSafe(95L)
            } else {
                AppStore.log("截屏失败 err=$err（第${attempt + 1}次）")
                sleepSafe(95L)
            }
        }
        return null
    }

    private fun dispatchLongPress(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 24L)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    /**
     * 52% 零惯性重叠翻屏（保障相邻两屏有 ~35% 重叠区，绝不飞过任何品种！stronger=true 时 60% 破卡）
     */
    private fun performControlledScroll(scrollDown: Boolean, stronger: Boolean = false): Boolean {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.46f
        val y1 = if (scrollDown) (if (stronger) sh * 0.80f else sh * 0.76f) else (if (stronger) sh * 0.20f else sh * 0.24f)
        val y2 = if (scrollDown) (if (stronger) sh * 0.20f else sh * 0.24f) else (if (stronger) sh * 0.80f else sh * 0.76f)

        val dragPath = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, 145L, true)
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)

        ownActionDepth.incrementAndGet()
        try {
            val accepted = dispatchGesture(
                GestureDescription.Builder().addStroke(stroke1).build(),
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        val holdPath = Path().apply {
                            moveTo(x, y2)
                            lineTo(x, y2)
                        }
                        val stroke2 = stroke1.continueStroke(holdPath, 0L, 48L, false)
                        dispatchGesture(
                            GestureDescription.Builder().addStroke(stroke2).build(),
                            object : GestureResultCallback() {
                                override fun onCompleted(g: GestureDescription?) {
                                    ok.set(true)
                                    latch.countDown()
                                }
                                override fun onCancelled(g: GestureDescription?) {
                                    ok.set(false)
                                    userManualYieldUntilMs = SystemClock.uptimeMillis() + 1100L
                                    userIntervenedFlag.set(true)
                                    latch.countDown()
                                }
                            },
                            null
                        )
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        ok.set(false)
                        userManualYieldUntilMs = SystemClock.uptimeMillis() + 1100L
                        userIntervenedFlag.set(true)
                        latch.countDown()
                    }
                },
                null
            )
            if (accepted) {
                latch.await(2, TimeUnit.SECONDS)
            }
        } finally {
            lastOwnActionEndMs = SystemClock.uptimeMillis()
            ownActionDepth.decrementAndGet()
        }
        return ok.get()
    }

    private fun performFastScroll(scrollDown: Boolean): Boolean {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.44f
        val y1 = if (scrollDown) sh * 0.83f else sh * 0.19f
        val y2 = if (scrollDown) sh * 0.19f else sh * 0.83f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 95L)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchGestureSync(gesture: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        ownActionDepth.incrementAndGet()
        try {
            val accepted = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        ok.set(true)
                        latch.countDown()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        ok.set(false)
                        latch.countDown()
                    }
                },
                null
            )
            if (!accepted) return false
            latch.await(2, TimeUnit.SECONDS)
        } finally {
            lastOwnActionEndMs = SystemClock.uptimeMillis()
            ownActionDepth.decrementAndGet()
        }
        return ok.get()
    }

    private fun shouldAbortBatch(): Boolean {
        return !AppStore.isWorkEnabled() || abortBatchRequested.get() || currentPage != PageState.WATCHLIST
    }

    private fun sleepSafe(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(
            NOTIF_CHANNEL_ID,
            "未添加品种提醒（不遮挡屏幕）",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            setSound(null, null)
            enableVibration(false)
        }
        nm.createNotificationChannel(ch)
    }

    private fun sendMissedNotification(message: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TV颜色标记：有未添加品种（进APP可一键重试）")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setSilent(true)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(notifIdCounter.incrementAndGet(), notif)
        } catch (_: Exception) {
        }
    }
}
