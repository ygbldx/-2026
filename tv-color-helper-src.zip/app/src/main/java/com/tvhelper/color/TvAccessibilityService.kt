package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.roundToInt

class TvAccessibilityService : AccessibilityService() {

    companion object {
        const val TV_PACKAGE = "com.tradingview.tradingviewapp"
        private const val NOTIF_CHANNEL_ID = "tv_color_missed_channel"
        private val notifIdCounter = AtomicInteger(1000)
        private val MENU_DOT_X_FRACS = floatArrayOf(0.088f, 0.226f, 0.358f, 0.496f, 0.633f, 0.765f, 0.903f)

        @Volatile
        var instance: TvAccessibilityService? = null
            private set
    }

    private enum class PageState { CHART, WATCHLIST, OTHER }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val chartExecutor = Executors.newSingleThreadExecutor()
    private val batchExecutor = Executors.newSingleThreadExecutor()
    private val vision = VisionEngine()
    private lateinit var overlay: OverlayController

    @Volatile
    private var currentPage = PageState.OTHER
    @Volatile
    private var lastChartSymbol: String? = null
    @Volatile
    private var cachedChartSymbol: String? = null
    @Volatile
    private var cachedChartAtMs = 0L
    @Volatile
    private var lastKnownWatchlistId: String? = null
    @Volatile
    private var lastScreenshotAtMs = 0L
    @Volatile
    private var ownAppInForeground = false
    @Volatile
    private var learnedLongPressMs = 0L
    @Volatile
    private var infoDismissedByUser = false

    private val isBatchRunning = AtomicBoolean(false)
    private val abortBatchRequested = AtomicBoolean(false)
    private val tapSeq = AtomicLong(0L)

    private val screenCheckRunnable = Runnable { evaluateCurrentScreen() }
    private val litNodePollRunnable = object : Runnable {
        override fun run() {
            if (!AppStore.isWorkEnabled() || currentPage != PageState.CHART || overlay.getLitColor() == null) return
            if (!isBatchRunning.get()) {
                val root = rootInActiveWindow
                val fromNode = root?.let { extractChartSymbolFromNodes(it) }
                if (fromNode != null) {
                    val resolved = CatalogRepository.resolveChartSymbolInCatalog(fromNode, lastKnownWatchlistId) ?: fromNode
                    if (resolved != lastChartSymbol) {
                        lastChartSymbol = resolved
                        cachedChartSymbol = resolved
                        cachedChartAtMs = System.currentTimeMillis()
                        val queued = AppStore.getSymbolColor(resolved)
                        overlay.setLitColor(queued)
                        if (queued == null) return
                    }
                }
            }
            mainHandler.postDelayed(this, 260L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppStore.init(this)
        createNotificationChannel()
        overlay = OverlayController(
            context = this,
            onColorTap = { color -> handleColorButtonTap(color) },
            onRequestPauseService = { reason -> pauseServiceAtAppLevel(reason) },
            onInfoPanelDismissed = { infoDismissedByUser = true }
        )
        WorkTileService.requestTileSync(this)
        AppStore.log("无障碍服务已连接（APP开关=${if (AppStore.isWorkEnabled()) "开" else "关"}）")
        chartExecutor.execute { vision.warmUp() }
        scheduleScreenCheck(20L)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        abortBatchRequested.set(true)
        mainHandler.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) {
            overlay.destroy()
        }
        vision.close()
        chartExecutor.shutdownNow()
        batchExecutor.shutdownNow()
    }

    override fun onInterrupt() {
        abortBatchRequested.set(true)
    }

    private fun pauseServiceAtAppLevel(reason: String) {
        tapSeq.incrementAndGet()
        AppStore.setWorkEnabled(this, false, source = reason)
    }

    fun onWorkEnabledChanged(enabled: Boolean) {
        if (!::overlay.isInitialized) return
        if (!enabled) {
            abortBatchRequested.set(true)
            stopLitNodePolling()
            currentPage = PageState.OTHER
            infoDismissedByUser = false
            overlay.hideButtons()
            overlay.hideInfoPanel()
            overlay.hideDoneBanner()
        } else {
            abortBatchRequested.set(false)
            infoDismissedByUser = false
            currentPage = PageState.OTHER
            scheduleScreenCheck(20L)
        }
    }

    fun onOwnAppForegroundChanged(inForeground: Boolean) {
        ownAppInForeground = inForeground
        if (::overlay.isInitialized) {
            if (inForeground) {
                currentPage = PageState.OTHER
                abortBatchRequested.set(true)
                stopLitNodePolling()
                overlay.hideButtons()
                overlay.hideInfoPanel()
            } else {
                overlay.hideInfoPanel()
                if (AppStore.isWorkEnabled()) {
                    scheduleScreenCheck(25L)
                }
            }
        }
    }

    fun refreshButtonSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            overlay.refreshButtonsInPlace(resetPosition)
        }
    }

    fun refreshInfoPanelSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            if (!AppStore.isInfoPanelEnabled()) {
                overlay.hideInfoPanel()
            } else {
                overlay.refreshInfoPanelInPlace(resetPosition)
            }
        }
    }

    fun previewDoneBanner() {
        if (::overlay.isInitialized) {
            overlay.showDoneBanner(previewMode = true)
        }
    }

    fun previewInfoPanel() {
        if (::overlay.isInitialized) {
            val q = AppStore.snapshotQueue()
            val sample = if (q.isNotEmpty()) {
                q.entries.map { (sym, col) ->
                    val inst = CatalogRepository.findInstrumentInfo(sym)
                    InfoDisplayItem(sym, inst?.cnName.orEmpty(), inst?.source.orEmpty(), col)
                }
            } else {
                listOf(
                    InfoDisplayItem("RUSSELL", "罗素2000", "IG", MarkColor.RED),
                    InfoDisplayItem("IKO", "韩股-澳", "", MarkColor.BLUE),
                    InfoDisplayItem("LLY", "礼来", "", MarkColor.GREEN)
                )
            }
            overlay.showInfoPanel(sample, forcePreview = true)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!AppStore.isWorkEnabled()) return
        val pkg = event.packageName?.toString()
        if (pkg == packageName) return

        if (currentPage == PageState.CHART &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            overlay.getLitColor() != null
        ) {
            val src = event.source
            if (src != null) {
                val (sw, sh) = getScreenDimensions()
                val rect = Rect()
                src.getBoundsInScreen(rect)
                if (rect.bottom >= (sh * 0.88f).toInt() && rect.left <= (sw * 0.36f).toInt()) {
                    resetChartLightImmediately("检测到滚动切换品种")
                }
            }
        }

        // 0ms 抢跑：点击底部“自选表”标签立刻切入判断
        if (currentPage == PageState.CHART &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            AppStore.hasPendingItems()
        ) {
            val clickedText = (event.text?.joinToString("") ?: "") + (event.contentDescription?.toString() ?: "")
            if (clickedText.contains("自选表") || clickedText.contains("Watchlist", ignoreCase = true)) {
                mainHandler.removeCallbacks(screenCheckRunnable)
                mainHandler.postDelayed(screenCheckRunnable, 10L)
                return
            }
        }

        val delay = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 10L
            AccessibilityEvent.TYPE_VIEW_CLICKED -> 15L
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> 20L
            else -> 35L
        }
        scheduleScreenCheck(delay)
    }

    private fun scheduleScreenCheck(delayMs: Long) {
        mainHandler.removeCallbacks(screenCheckRunnable)
        mainHandler.postDelayed(screenCheckRunnable, delayMs)
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        return b.width() to b.height()
    }

    private fun resetChartLightImmediately(reason: String? = null) {
        lastChartSymbol = null
        cachedChartSymbol = null
        cachedChartAtMs = 0L
        stopLitNodePolling()
        if (overlay.getLitColor() != null) {
            overlay.setLitColor(null)
            if (reason != null) AppStore.log("灭灯：$reason")
        }
    }

    private fun evaluateCurrentScreen() {
        if (ownAppInForeground) return
        if (!AppStore.isWorkEnabled()) {
            overlay.hideButtons()
            overlay.hideInfoPanel()
            return
        }

        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()

        // 切到手机其它任何页面：立即暂停工作并隐藏一切悬浮窗（保留待添加品种池！）
        if (pkg != TV_PACKAGE) {
            if (currentPage != PageState.OTHER) {
                currentPage = PageState.OTHER
                resetChartLightImmediately()
                overlay.hideButtons()
                overlay.hideInfoPanel()
                if (isBatchRunning.get()) {
                    abortBatchRequested.set(true)
                    AppStore.log("切离TradingView，暂停批处理（待办池已保留）")
                }
            }
            return
        }

        val detected = detectTradingViewPage(root)

        if (detected != currentPage) {
            val prev = currentPage
            currentPage = detected
            AppStore.log("页面切换：$prev -> $detected")

            when (detected) {
                PageState.CHART -> {
                    // 切到图表页：暂时停止列表添加，隐藏右侧清单，显示圆球继续选色
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                    overlay.hideInfoPanel()
                    resetChartLightImmediately()
                    overlay.showButtons()
                    syncChartLightFast(root)
                }

                PageState.WATCHLIST -> {
                    stopLitNodePolling()
                    overlay.hideButtons()
                    infoDismissedByUser = false
                    // 只要待添加品种池不为空，回到列表页立即开工！
                    if (AppStore.hasPendingItems() && !isBatchRunning.get()) {
                        startWatchlistBatch()
                    } else if (!AppStore.hasPendingItems()) {
                        overlay.hideInfoPanel()
                    }
                }

                PageState.OTHER -> {
                    resetChartLightImmediately()
                    overlay.hideButtons()
                    overlay.hideInfoPanel()
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                }
            }
        } else if (detected == PageState.CHART) {
            overlay.hideInfoPanel()
            overlay.showButtons()
            syncChartLightFast(root)
        } else if (detected == PageState.WATCHLIST) {
            overlay.hideButtons()
            if (AppStore.hasPendingItems() && !isBatchRunning.get()) {
                startWatchlistBatch()
            }
        }
    }

    private fun detectTradingViewPage(root: AccessibilityNodeInfo): PageState {
        val (_, sh) = getScreenDimensions()
        val navTopThreshold = (sh * 0.90f).toInt()

        var watchlistNav: AccessibilityNodeInfo? = null
        var chartNav: AccessibilityNodeInfo? = null
        var hasTopWatchlistHeader = false
        var hasChartBottomToolbar = false

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 460) {
            val node = stack.removeLast()
            visited++
            val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim().orEmpty()
            node.getBoundsInScreen(rect)

            if (rect.bottom >= navTopThreshold && text.isNotEmpty()) {
                when (text) {
                    "自选表", "Watchlist" -> watchlistNav = node
                    "图表", "Chart" -> chartNav = node
                }
            } else if (rect.top < sh * 0.14f &&
                (text == "搜索" || text == "Search" || text.startsWith("-1") || text.startsWith("-2") || text.startsWith("-3") || text.startsWith("-4"))
            ) {
                hasTopWatchlistHeader = true
            } else if (rect.top in (sh * 0.90f).toInt()..(sh * 0.955f).toInt() &&
                (text.contains("周") || text.contains("日") || text.contains("小时") || text.contains("分") ||
                    text.equals("1D", true) || text.equals("1W", true))
            ) {
                hasChartBottomToolbar = true
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                stack.add(child)
            }
        }

        if (isBatchRunning.get() && watchlistNav == null && chartNav == null) {
            return PageState.WATCHLIST
        }
        if (watchlistNav == null && chartNav == null) {
            return PageState.OTHER
        }

        val isChartSelected = isNodeOrAncestorSelected(chartNav)
        val isWatchlistSelected = isNodeOrAncestorSelected(watchlistNav)

        return when {
            isChartSelected && !isWatchlistSelected -> PageState.CHART
            isWatchlistSelected && !isChartSelected -> PageState.WATCHLIST
            hasChartBottomToolbar && !hasTopWatchlistHeader -> PageState.CHART
            hasTopWatchlistHeader && !hasChartBottomToolbar -> PageState.WATCHLIST
            else -> PageState.OTHER
        }
    }

    private fun isNodeOrAncestorSelected(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isSelected || cur.isChecked) return true
            val desc = cur.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("已选") || desc.contains("selected")) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    private fun syncChartLightFast(root: AccessibilityNodeInfo) {
        val rawSym = extractChartSymbolFromNodes(root) ?: return
        val sym = CatalogRepository.resolveChartSymbolInCatalog(rawSym, lastKnownWatchlistId) ?: rawSym
        cachedChartSymbol = sym
        cachedChartAtMs = System.currentTimeMillis()
        if (sym != lastChartSymbol) {
            lastChartSymbol = sym
            val queuedColor = AppStore.getSymbolColor(sym)
            overlay.setLitColor(queuedColor)
            if (queuedColor == null) stopLitNodePolling() else startLitNodePolling()
        }
    }

    private fun extractChartSymbolFromNodes(root: AccessibilityNodeInfo): String? {
        val (sw, sh) = getScreenDimensions()
        val targetCenterY = (sh * 0.938f).toInt()
        val minY = (sh * 0.915f).toInt()
        val maxY = (sh * 0.955f).toInt()
        val maxX = (sw * 0.34f).toInt()

        var bestSym: String? = null
        var bestDist = Int.MAX_VALUE

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 420) {
            val node = stack.removeLast()
            visited++
            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                node.getBoundsInScreen(rect)
                val cy = rect.centerY()
                if (cy in minY..maxY && rect.left in 0..maxX) {
                    val normalized = vision.normalizeTickerCandidate(raw)
                    if (normalized != null) {
                        val dist = abs(cy - targetCenterY)
                        if (dist < bestDist) {
                            bestDist = dist
                            bestSym = normalized
                        }
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return bestSym
    }

    private fun startLitNodePolling() {
        mainHandler.removeCallbacks(litNodePollRunnable)
        mainHandler.postDelayed(litNodePollRunnable, 260L)
    }

    private fun stopLitNodePolling() {
        mainHandler.removeCallbacks(litNodePollRunnable)
    }

    /**
     * 点击悬浮颜色球：
     * - 再点当前选中颜色 -> 0ms 取消勾选并移出待添加品种池
     * - 选中颜色 -> 用《品种大全》精准校准规范名；若不在《品种大全》内则不入池、灭灯并在APP内发消息提示
     */
    private fun handleColorButtonTap(color: MarkColor) {
        if (!AppStore.isWorkEnabled() || currentPage != PageState.CHART) return
        val seq = tapSeq.incrementAndGet()

        if (overlay.getLitColor() == color) {
            overlay.setLitColor(null)
            stopLitNodePolling()

            val knownSym = lastChartSymbol ?: cachedChartSymbol
            if (knownSym != null) {
                if (AppStore.removeSymbol(knownSym)) {
                    AppStore.log("取消勾选：$knownSym（已移出待添加池）")
                }
                return
            }

            chartExecutor.execute {
                if (tapSeq.get() != seq) return@execute
                val rawSym = resolveCurrentChartSymbolQuick().first ?: return@execute
                val canonical = CatalogRepository.resolveChartSymbolInCatalog(rawSym, lastKnownWatchlistId) ?: rawSym
                if (tapSeq.get() == seq && AppStore.removeSymbol(canonical)) {
                    AppStore.log("取消勾选：$canonical（已移出待添加池）")
                }
            }
            return
        }

        // 0ms 瞬间亮灯反馈
        overlay.setLitColor(color)

        chartExecutor.execute {
            if (tapSeq.get() != seq) return@execute
            val (rawSym, source) = resolveCurrentChartSymbolQuick()
            if (tapSeq.get() != seq || !AppStore.isWorkEnabled()) return@execute

            if (rawSym == null) {
                AppStore.log("图表未读到品种代码，自动灭灯回退")
                if (tapSeq.get() == seq) overlay.setLitColor(null)
                return@execute
            }

            // 去《品种大全》查表校验（自动修复滚轮截断，如 BTCUS/BTCUSI -> BTCUSD）
            val canonical = CatalogRepository.resolveChartSymbolInCatalog(rawSym, lastKnownWatchlistId)
            if (canonical == null) {
                val msg = "品种 $rawSym 不在《品种大全》内，已忽略（可在APP《品种大全》里手动添加）"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                if (tapSeq.get() == seq) overlay.setLitColor(null)
                return@execute
            }

            lastChartSymbol = canonical
            cachedChartSymbol = canonical
            cachedChartAtMs = System.currentTimeMillis()
            AppStore.putSymbol(canonical, color)
            AppStore.log("图表识别($source)：$rawSym -> 规范名 $canonical -> ${color.label}")
            if (tapSeq.get() == seq && currentPage == PageState.CHART) {
                overlay.setLitColor(color)
                startLitNodePolling()
            }
        }
    }

    private fun resolveCurrentChartSymbolQuick(): Pair<String?, String> {
        val root = rootInActiveWindow
        val nodeSym = root?.let { extractChartSymbolFromNodes(it) }
        if (nodeSym != null) {
            return nodeSym to "节点"
        }

        val bmp = captureScreenBitmap(maxRetries = 2)
        if (bmp != null) {
            try {
                val ocrSym = vision.readChartSymbolFromBitmap(bmp)
                if (ocrSym != null) {
                    return ocrSym to "OCR"
                }
            } finally {
                bmp.recycle()
            }
        }

        if (cachedChartSymbol != null && System.currentTimeMillis() - cachedChartAtMs <= 2500L) {
            return cachedChartSymbol to "缓存"
        }
        return null to "无"
    }

    // =========================================================================
    // 《品种大全》驱动：跨列表、方向感知、优先添加、极致高速引擎
    // =========================================================================

    private fun startWatchlistBatch() {
        if (!AppStore.isWorkEnabled()) return
        if (!AppStore.hasPendingItems()) return
        if (!isBatchRunning.compareAndSet(false, true)) return
        abortBatchRequested.set(false)

        // 添加优先级绝对高于右侧显示：立刻进入 batchExecutor 开工，绝不先画悬浮窗拖延！
        batchExecutor.execute {
            try {
                runCrossWatchlistEngine()
            } catch (e: Exception) {
                AppStore.log("批处理异常：${e.message}")
            } finally {
                isBatchRunning.set(false)
            }
        }
    }

    /**
     * 更新右侧清单悬浮窗：只在列表页显示，且严格只显示“当前所在列表内”尚未完成的待添加品种
     */
    private fun updateRightInfoPanelForWatchlist(currentWl: CatalogWatchlist?, visibleRows: List<WatchlistRow>) {
        if (currentPage != PageState.WATCHLIST || !AppStore.isWorkEnabled() || !AppStore.isInfoPanelEnabled() || infoDismissedByUser) {
            overlay.hideInfoPanel()
            return
        }
        val pool = AppStore.snapshotQueue()
        if (pool.isEmpty()) {
            overlay.hideInfoPanel()
            return
        }

        val visibleSet = visibleRows.map { it.symbol }.toSet()
        val displayItems = ArrayList<InfoDisplayItem>()
        for ((sym, color) in pool) {
            val belongsHere = if (currentWl != null) {
                CatalogRepository.isSymbolInWatchlist(sym, currentWl.id) || (sym in visibleSet)
            } else {
                sym in visibleSet
            }
            if (belongsHere) {
                val inst = CatalogRepository.findInstrumentInfo(sym, currentWl?.id)
                displayItems.add(
                    InfoDisplayItem(
                        symbol = sym,
                        cnName = inst?.cnName.orEmpty(),
                        source = inst?.source.orEmpty(),
                        color = color
                    )
                )
            }
        }

        if (displayItems.isEmpty()) {
            overlay.hideInfoPanel()
        } else {
            overlay.showInfoPanel(displayItems)
        }
    }

    private fun runCrossWatchlistEngine() {
        sleepSafe(15L)
        if (shouldAbortBatch()) return

        val sysLpMs = ViewConfiguration.getLongPressTimeout().toLong().coerceIn(400L, 900L)
        var preferredLongPressMs = if (learnedLongPressMs > 0L) learnedLongPressMs else maxOf(sysLpMs + 110L, 580L)

        // 记录本次列表会话中，每个 (watchlistId, symbol) 已经扫完/处理过的集合，防止死磕
        val visitedWatchlistIds = HashSet<String>()
        val failedSwitchWatchlistIds = HashSet<String>()
        var anyActionSucceeded = false
        var hadAnyMissedOrError = false

        // 外层跨列表循环：直到待添加池清空，或被用户切走/关闭服务，或所有相关列表均已处理完毕
        var outerLoops = 0
        while (!shouldAbortBatch() && AppStore.hasPendingItems() && outerLoops < 20) {
            outerLoops++

            // 1) 立刻扫描当前屏品种
            val (firstRows, firstFp, firstBmpForTabFallback) = scanScreenRows(isFirstCheck = (outerLoops == 1))
            if (shouldAbortBatch()) {
                firstBmpForTabFallback?.recycle()
                break
            }

            // 2) 识别当前所在列表（0ms 通过品种集合反推，兜底读顶部灰底胶囊）
            val currentWl: CatalogWatchlist? = CatalogRepository.identifyWatchlistByVisibleSymbols(firstRows.map { it.symbol })
                ?: firstBmpForTabFallback?.let { bmp ->
                    vision.readActiveWatchlistName(bmp)?.let { CatalogRepository.getWatchlistByName(it) }
                }
            firstBmpForTabFallback?.recycle()

            if (currentWl != null) {
                lastKnownWatchlistId = currentWl.id
            }

            val wlNameLog = currentWl?.name ?: "未识别列表"
            AppStore.log("批处理周期#$outerLoops｜当前列表=$wlNameLog｜待办池=${AppStore.snapshotQueue().size}个")

            // 3) 第一优先：先把当前屏上已经看得见的待添加品种立刻全部标完！（连右侧清单都排在它后面或同步异步刷）
            var pendingInCurrentWl = getPendingSymbolsForWatchlist(currentWl)
            // 先处理当前屏命中的（即便它属于其它列表或正好出现在当前屏，看见就顺手标掉！）
            val screenMatched = processVisibleMatches(
                rows = firstRows,
                currentWl = currentWl,
                preferredLongPressMsRef = { preferredLongPressMs },
                onLearnDuration = { d ->
                    if (d > preferredLongPressMs || learnedLongPressMs == 0L) {
                        preferredLongPressMs = d
                        learnedLongPressMs = d
                    }
                },
                onSucceeded = { anyActionSucceeded = true },
                onFailedMenu = { hadAnyMissedOrError = true }
            )
            if (shouldAbortBatch()) break

            // 标完首屏可见项后（若有剩余），异步刷新右侧清单，只显示当前列表有的品种
            updateRightInfoPanelForWatchlist(currentWl, firstRows)

            // 4) 重新检查当前列表是否还有剩余待办
            pendingInCurrentWl = getPendingSymbolsForWatchlist(currentWl)
            if (currentWl != null && pendingInCurrentWl.isNotEmpty() && !shouldAbortBatch()) {
                // 使用《品种大全》的固定先后顺序，决定精确滑动方向！
                val symbolOrders = CatalogRepository.getSymbolOrdersInWatchlist(currentWl.id)
                val visibleIndices = firstRows.flatMap { symbolOrders[it.symbol].orEmpty() }
                val visMin = visibleIndices.minOrNull()
                val visMax = visibleIndices.maxOrNull()

                val targetIndices = pendingInCurrentWl.flatMap { symbolOrders[it].orEmpty() }
                val needDown = if (visMax == null || targetIndices.isEmpty()) true else targetIndices.any { it > visMax }
                val needUp = if (visMin == null || targetIndices.isEmpty()) true else targetIndices.any { it < visMin }

                // 算哪边更近先去哪边
                val minDownDist = if (visMax != null) targetIndices.filter { it > visMax }.minOfOrNull { it - visMax } ?: Int.MAX_VALUE else 0
                val minUpDist = if (visMin != null) targetIndices.filter { it < visMin }.minOfOrNull { visMin - it } ?: Int.MAX_VALUE else Int.MAX_VALUE

                val directions = ArrayList<Boolean>() // true = scrollDown, false = scrollUp
                if (needDown && needUp) {
                    if (minDownDist <= minUpDist) {
                        directions.add(true); directions.add(false)
                    } else {
                        directions.add(false); directions.add(true)
                    }
                } else if (needDown) {
                    directions.add(true)
                } else if (needUp) {
                    directions.add(false)
                }

                AppStore.log("列表[${currentWl.name}] 剩余${pendingInCurrentWl.size}个｜方向计划=${directions.joinToString("->") { if (it) "向下" else "向上" }}")

                var userSwitchedListMidWay = false
                var stepsTakenFirstDir = 0

                for ((dirIdx, goDown) in directions.withIndex()) {
                    if (shouldAbortBatch() || getPendingSymbolsForWatchlist(currentWl).isEmpty()) break

                    // 若第二个方向启动且刚才单向滑了很多屏，先快速回退跳过已扫区域
                    if (dirIdx == 1 && stepsTakenFirstDir > 1) {
                        val backSteps = (stepsTakenFirstDir - 1).coerceAtLeast(1)
                        AppStore.log("快速越过已扫区域（回退 $backSteps 屏）")
                        for (b in 0 until backSteps) {
                            if (shouldAbortBatch()) break
                            performFastScroll(scrollDown = goDown)
                            sleepSafe(50L)
                        }
                        sleepSafe(65L)
                    }

                    var prevNames = firstRows.map { it.symbol }
                    var prevFp = firstFp
                    var scrolls = 0
                    var sameCount = 0

                    while (!shouldAbortBatch() && getPendingSymbolsForWatchlist(currentWl).isNotEmpty() && scrolls < 45) {
                        performControlledScroll(scrollDown = goDown)
                        sleepSafe(40L)
                        if (shouldAbortBatch()) break

                        val (rows, fp, bmpExtra) = scanScreenRows(isFirstCheck = false)
                        bmpExtra?.recycle()
                        if (shouldAbortBatch()) break

                        val names = rows.map { it.symbol }

                        // 检测用户是否手动切到了别的列表！如果切走了立刻跳出，直接转战新列表！
                        val detectedWlNow = CatalogRepository.identifyWatchlistByVisibleSymbols(names)
                        if (detectedWlNow != null && detectedWlNow.id != currentWl.id) {
                            AppStore.log("检测到你手动切换到列表[${detectedWlNow.name}]，立即转为处理新列表")
                            userSwitchedListMidWay = true
                            break
                        }

                        val unchanged = (names.isNotEmpty() && names == prevNames) ||
                            (fp != null && prevFp != null && vision.isSameFrame(prevFp, fp))
                        if (unchanged) {
                            sameCount++
                            if (sameCount >= 2 || names.size >= 4) {
                                AppStore.log("列表[${currentWl.name}]已达${if (goDown) "底部" else "顶部"}（翻 $scrolls 屏）")
                                break
                            }
                            continue
                        }
                        sameCount = 0
                        scrolls++
                        if (dirIdx == 0) stepsTakenFirstDir++
                        prevNames = names
                        prevFp = fp

                        // 处理本屏命中项
                        processVisibleMatches(
                            rows = rows,
                            currentWl = currentWl,
                            preferredLongPressMsRef = { preferredLongPressMs },
                            onLearnDuration = { d ->
                                if (d > preferredLongPressMs || learnedLongPressMs == 0L) {
                                    preferredLongPressMs = d
                                    learnedLongPressMs = d
                                }
                            },
                            onSucceeded = { anyActionSucceeded = true },
                            onFailedMenu = { hadAnyMissedOrError = true }
                        )

                        // 如果本列表已全部清空，立刻停手不再拉！
                        val stillLeftHere = getPendingSymbolsForWatchlist(currentWl)
                        if (stillLeftHere.isEmpty()) {
                            AppStore.log("列表[${currentWl.name}]内待办已全部完成，立即停止滑动")
                            break
                        }

                        // 若本方向已经越过本列表内该方向上最远目标品种的索引，提前停手不再拉到底！
                        val currIndices = rows.flatMap { symbolOrders[it.symbol].orEmpty() }
                        val remIndices = stillLeftHere.flatMap { symbolOrders[it].orEmpty() }
                        if (currIndices.isNotEmpty() && remIndices.isNotEmpty()) {
                            if (goDown && currIndices.min() > remIndices.max() + 2) {
                                AppStore.log("已越过列表[${currentWl.name}]下方最远目标，提前停手")
                                break
                            }
                            if (!goDown && currIndices.max() < remIndices.min() - 2) {
                                AppStore.log("已越过列表[${currentWl.name}]上方最远目标，提前停手")
                                break
                            }
                        }

                        updateRightInfoPanelForWatchlist(currentWl, rows)
                    }

                    if (userSwitchedListMidWay) break
                }

                if (userSwitchedListMidWay) {
                    continue
                }

                // 整个列表扫描完成后，如果还有归属此列表（且无其它未扫归属列表）的品种没找到 -> 报告消息并移出待办池不死磕
                visitedWatchlistIds.add(currentWl.id)
                val stillMissingHere = getPendingSymbolsForWatchlist(currentWl)
                for (sym in stillMissingHere) {
                    val allLocs = CatalogRepository.findLocations(sym)
                    val hasOtherUnvisitedWl = allLocs.any { it.watchlistId !in visitedWatchlistIds && it.watchlistId !in failedSwitchWatchlistIds }
                    if (!hasOtherUnvisitedWl) {
                        val color = AppStore.getSymbolColor(sym) ?: MarkColor.RED
                        val msg = "待添加 $sym 到 ${color.label}色列表，但在 ${currentWl.name} 列表内没有找到（已移出待办池）"
                        AppStore.log(msg)
                        AppStore.addMissedRecord(msg)
                        sendMissedNotification(msg)
                        AppStore.removeSymbol(sym)
                        hadAnyMissedOrError = true
                    }
                }
                updateRightInfoPanelForWatchlist(currentWl, emptyList())
            }

            if (shouldAbortBatch() || !AppStore.hasPendingItems()) break

            // 5) 跨列表自动切换：查找待办池里下一个尚未处理的品种所属列表
            val nextTargetWl = findNextTargetWatchlist(currentWl, visitedWatchlistIds, failedSwitchWatchlistIds)
            if (nextTargetWl == null) {
                // 剩余品种找不到可切换的所属列表，全部输出消息并移出待办池防止死循环
                val leftover = AppStore.snapshotQueue()
                for ((sym, color) in leftover) {
                    val locs = CatalogRepository.findLocations(sym)
                    val targetNames = locs.map { it.watchlistName }.distinct().joinToString("/")
                    val msg = if (targetNames.isNotEmpty()) {
                        "待添加 $sym 到 ${color.label}色列表（属于 $targetNames），未能自动切换至该列表"
                    } else {
                        "品种 $sym 不在《品种大全》内，已忽略"
                    }
                    AppStore.log(msg)
                    AppStore.addMissedRecord(msg)
                    sendMissedNotification(msg)
                    AppStore.removeSymbol(sym)
                    hadAnyMissedOrError = true
                }
                break
            }

            // 执行自动切换列表（按《品种大全》列表前后顺序精准决定顶部标签栏向左滑还是向右滑！）
            AppStore.log("跨列表切换：${currentWl?.name ?: "当前"} -> ${nextTargetWl.name}")
            overlay.hideInfoPanel()
            val switched = switchToWatchlistTab(currentWl, nextTargetWl)
            if (!switched) {
                AppStore.log("自动切换到列表[${nextTargetWl.name}]失败，记录跳过")
                failedSwitchWatchlistIds.add(nextTargetWl.id)
                hadAnyMissedOrError = true
            } else {
                sleepSafe(120L)
            }
        }

        if (shouldAbortBatch()) {
            overlay.hideInfoPanel()
            AppStore.log("批处理暂停（剩余待办 ${AppStore.snapshotQueue().size} 个，回到列表页自动继续）")
            return
        }

        // 收尾：待办池已清空
        if (!AppStore.hasPendingItems()) {
            overlay.hideInfoPanel()
            if (!hadAnyMissedOrError && anyActionSucceeded) {
                AppStore.log("全部跨列表待办已完活！")
                overlay.showDoneBanner(previewMode = false)
            } else if (!hadAnyMissedOrError) {
                AppStore.log("待办已全部跳过/完活")
                overlay.showDoneBanner(previewMode = false)
            } else {
                AppStore.log("本轮处理结束（含未找到项，详见APP消息记录）")
            }
        }
    }

    private fun getPendingSymbolsForWatchlist(wl: CatalogWatchlist?): List<String> {
        if (wl == null) return emptyList()
        val pool = AppStore.snapshotQueue()
        return pool.keys.filter { CatalogRepository.isSymbolInWatchlist(it, wl.id) }
    }

    private fun findNextTargetWatchlist(
        currentWl: CatalogWatchlist?,
        visitedIds: Set<String>,
        failedSwitchIds: Set<String>
    ): CatalogWatchlist? {
        val pool = AppStore.snapshotQueue()
        if (pool.isEmpty()) return null
        val allWls = CatalogRepository.getWatchlists()
        val currIdx = currentWl?.let { CatalogRepository.getWatchlistIndexById(it.id) } ?: 0

        val candidateWls = LinkedHashSet<CatalogWatchlist>()
        for (sym in pool.keys) {
            for (loc in CatalogRepository.findLocations(sym)) {
                if (loc.watchlistId !in visitedIds && loc.watchlistId !in failedSwitchIds) {
                    CatalogRepository.getWatchlistById(loc.watchlistId)?.let { candidateWls.add(it) }
                }
            }
        }
        if (candidateWls.isEmpty()) return null

        // 优先切到离当前列表顺序最近的下一个列表，省去顶部标签栏大幅来回滑动！
        return candidateWls.minByOrNull { wl ->
            val idx = allWls.indexOfFirst { it.id == wl.id }.coerceAtLeast(0)
            abs(idx - currIdx)
        }
    }

    /**
     * 顶部列表栏自动切换至目标列表：
     * 1) 节点查找 -> 2) OCR 顶部标签栏 -> 3) 按《品种大全》列表前后顺序精准向目标方向滑动顶部栏再点击
     */
    private fun switchToWatchlistTab(currentWl: CatalogWatchlist?, targetWl: CatalogWatchlist): Boolean {
        val targetNorm = CatalogRepository.normalizeListName(targetWl.name)
        val currIdx = currentWl?.let { CatalogRepository.getWatchlistIndexById(it.id) } ?: -1
        val targetIdx = CatalogRepository.getWatchlistIndexById(targetWl.id)
        // target 在当前列表右边 -> 顶部栏向左滑（手指从右往左）；反之手指从左往右
        val swipeRightToLeftFirst = if (currIdx >= 0 && targetIdx >= 0) (targetIdx > currIdx) else true

        val (sw, sh) = getScreenDimensions()
        val tabBarY = sh * 0.097f

        fun tryTapTabOnScreen(): Boolean {
            // 先查无障碍节点（2ms）
            val nodePoint = findTopTabPointFromNodes(targetNorm)
            if (nodePoint != null) {
                AppStore.log("顶部节点命中[${targetWl.name}] (${nodePoint.first},${nodePoint.second})")
                dispatchTap(nodePoint.first.toFloat(), nodePoint.second.toFloat())
                return true
            }
            // 再 OCR 顶部标签栏
            val bmp = captureScreenBitmap(maxRetries = 2) ?: return false
            val tabs = try {
                vision.scanTopWatchlistTabs(bmp)
            } finally {
                bmp.recycle()
            }
            val matched = tabs.firstOrNull { tab ->
                val n = CatalogRepository.normalizeListName(tab.name)
                n == targetNorm || (n.length >= 2 && targetNorm.length >= 2 && (n.contains(targetNorm) || targetNorm.contains(n)))
            }
            if (matched != null) {
                AppStore.log("顶部OCR命中[${targetWl.name}] (${matched.centerX},${matched.centerY})")
                dispatchTap(matched.centerX.toFloat(), matched.centerY.toFloat())
                return true
            }
            return false
        }

        if (tryTapTabOnScreen()) return true

        // 优先按顺序方向滑动最多 5 次，若还没找到再反方向滑 5 次兜底
        val dirs = listOf(swipeRightToLeftFirst, !swipeRightToLeftFirst)
        for (rtl in dirs) {
            for (step in 0 until 5) {
                if (shouldAbortBatch()) return false
                val x1 = if (rtl) sw * 0.86f else sw * 0.24f
                val x2 = if (rtl) sw * 0.24f else sw * 0.86f
                val path = Path().apply {
                    moveTo(x1, tabBarY)
                    lineTo(x2, tabBarY)
                }
                dispatchGestureSync(
                    GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(path, 0L, 140L))
                        .build()
                )
                sleepSafe(90L)
                if (tryTapTabOnScreen()) return true
            }
        }
        return false
    }

    private fun findTopTabPointFromNodes(targetNorm: String): Pair<Int, Int>? {
        val root = rootInActiveWindow ?: return null
        val (sw, sh) = getScreenDimensions()
        val topMin = (sh * 0.068f).toInt()
        val botMax = (sh * 0.128f).toInt()
        val minX = (sw * 0.14f).toInt()

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 220) {
            val n = stack.removeLast()
            visited++
            val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (txt.isNotEmpty()) {
                n.getBoundsInScreen(rect)
                if (rect.centerY() in topMin..botMax && rect.centerX() >= minX && rect.right <= sw) {
                    val norm = CatalogRepository.normalizeListName(txt)
                    if (norm == targetNorm || (norm.length >= 2 && targetNorm.length >= 2 && (norm.contains(targetNorm) || targetNorm.contains(norm)))) {
                        return rect.centerX() to rect.centerY()
                    }
                }
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return null
    }

    /**
     * 扫描当前屏幕品种行（节点优先，命中目标时截屏验证已标色旗帜；否则 0.55x 亮白直滤极速 OCR）
     * 返回：行列表、屏幕指纹、可选保留用于列表名兜底的 Bitmap（调用方负责 recycle）
     */
    private fun scanScreenRows(isFirstCheck: Boolean): Triple<List<WatchlistRow>, IntArray?, Bitmap?> {
        val poolKeys = AppStore.snapshotQueue().keys
        val (_, screenH) = getScreenDimensions()
        val nodeRows = scanWatchlistSymbolsFromNodes()
        val nodeReliable = nodeRows.size >= 4 ||
            (nodeRows.size >= 2 && nodeRows.last().bottomY >= (screenH * 0.65f).toInt())

        if (nodeReliable) {
            val hasMatch = nodeRows.any { vision.findMatchingTaskKey(it.symbol, poolKeys) != null }
            if (!hasMatch) {
                return Triple(nodeRows, null, null)
            }
            val captured = captureScreenBitmap(maxRetries = 3)
            if (captured != null) {
                val rowsWithFlags = nodeRows.map { r ->
                    if (vision.findMatchingTaskKey(r.symbol, poolKeys) != null) {
                        r.copy(hasAnyFlag = vision.hasAnyLeftEdgeFlag(captured, r.topY, r.bottomY))
                    } else r
                }
                val fp = vision.computeListFingerprint(captured)
                return Triple(rowsWithFlags, fp, captured)
            }
            return Triple(nodeRows, null, null)
        }

        var captured = captureScreenBitmap(maxRetries = 3) ?: return Triple(emptyList(), null, null)
        var rows = vision.scanWatchlistSymbols(captured)
        if (isFirstCheck && rows.isEmpty() && !shouldAbortBatch()) {
            captured.recycle()
            sleepSafe(55L)
            captured = captureScreenBitmap(maxRetries = 2) ?: return Triple(emptyList(), null, null)
            rows = vision.scanWatchlistSymbols(captured)
        }
        val fp = vision.computeListFingerprint(captured)
        return Triple(rows, fp, captured)
    }

    /**
     * 对当前屏所有命中待添加品种池的行执行长按标色（同屏同名全部添加，已有颜色标记直接无视跳过）
     */
    private fun processVisibleMatches(
        rows: List<WatchlistRow>,
        currentWl: CatalogWatchlist?,
        preferredLongPressMsRef: () -> Long,
        onLearnDuration: (Long) -> Unit,
        onSucceeded: () -> Unit,
        onFailedMenu: () -> Unit
    ): Int {
        val pool = AppStore.snapshotQueue()
        if (pool.isEmpty() || rows.isEmpty()) return 0

        val matchedPairs = ArrayList<Pair<WatchlistRow, String>>()
        for (row in rows) {
            val taskKey = vision.findMatchingTaskKey(row.symbol, pool.keys) ?: continue
            matchedPairs.add(row to taskKey)
        }
        if (matchedPairs.isEmpty()) return 0

        val symbolOrdersInWl = currentWl?.let { CatalogRepository.getSymbolOrdersInWatchlist(it.id) } ?: emptyMap()
        val visibleOrderBounds = rows.flatMap { symbolOrdersInWl[it.symbol].orEmpty() }
        val visMinOrder = visibleOrderBounds.minOrNull()
        val visMaxOrder = visibleOrderBounds.maxOrNull()

        var processedCount = 0
        for ((idx, pair) in matchedPairs.withIndex()) {
            if (shouldAbortBatch()) break
            val (row, taskKey) = pair
            val targetColor = AppStore.getSymbolColor(taskKey) ?: continue

            val hasMoreSameOnScreen = matchedPairs.drop(idx + 1).any { it.second == taskKey }
            // 检查《品种大全》里此列表在当前屏之外是否还有同名行需要继续找
            val allOrdersHere = symbolOrdersInWl[taskKey].orEmpty()
            val hasMoreDuplicateOutsideScreen = if (visMinOrder != null && visMaxOrder != null && allOrdersHere.size > 1) {
                allOrdersHere.any { it < visMinOrder || it > visMaxOrder }
            } else {
                false
            }

            if (row.hasAnyFlag) {
                AppStore.log("${row.symbol} 前方已有颜色标记，无视跳过")
                processedCount++
                onSucceeded()
                if (!hasMoreSameOnScreen && !hasMoreDuplicateOutsideScreen) {
                    AppStore.removeSymbol(taskKey)
                }
                continue
            }

            val isLastOpOverall = !hasMoreSameOnScreen && !hasMoreDuplicateOutsideScreen &&
                (idx == matchedPairs.lastIndex) && (AppStore.snapshotQueue().size <= 1)

            val usedDur = longPressAndSelectColor(
                row = row,
                taskKey = taskKey,
                color = targetColor,
                firstDurationMs = preferredLongPressMsRef(),
                isLastOperation = isLastOpOverall
            )
            if (usedDur > 0L) {
                onLearnDuration(usedDur)
                processedCount++
                onSucceeded()
                if (!hasMoreSameOnScreen && !hasMoreDuplicateOutsideScreen) {
                    AppStore.removeSymbol(taskKey)
                }
            } else {
                onFailedMenu()
                val wlLabel = currentWl?.name ?: "当前列表"
                val msg = "$wlLabel｜未找到 $taskKey 的颜色菜单，已跳过并移出待办池"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                AppStore.removeSymbol(taskKey)
            }
        }
        return processedCount
    }

    private fun scanWatchlistSymbolsFromNodes(): List<WatchlistRow> {
        val root = rootInActiveWindow ?: return emptyList()
        val (sw, sh) = getScreenDimensions()
        val leftMax = (sw * 0.220f).toInt()
        val topMin = (sh * 0.124f).toInt()
        val bottomMax = (sh * 0.944f).toInt()

        val rows = ArrayList<WatchlistRow>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 550) {
            val node = stack.removeLast()
            visited++
            val raw = node.text?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                node.getBoundsInScreen(rect)
                if (rect.left in 0..leftMax &&
                    rect.top >= topMin &&
                    rect.bottom <= bottomMax &&
                    rect.height() in 14..(sh * 0.085f).toInt()
                ) {
                    val sym = vision.extractWatchlistSymbol(raw)
                    if (sym != null) {
                        val cx = if (rect.left >= (sw * 0.08f).toInt()) {
                            ((rect.left + minOf(rect.right, (sw * 0.40f).toInt())) / 2)
                                .coerceIn((sw * 0.14f).toInt(), (sw * 0.36f).toInt())
                        } else {
                            (sw * 0.24f).toInt()
                        }
                        rows.add(
                            WatchlistRow(
                                symbol = sym,
                                centerX = cx,
                                centerY = rect.centerY(),
                                topY = rect.top,
                                bottomY = rect.bottom,
                                hasAnyFlag = false
                            )
                        )
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || abs(r.centerY - deduped.last().centerY) > (sh * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    private fun findColorMenuFromAccessibilityWindows(): Pair<ColorMenuDots, String>? {
        val (sw, sh) = getScreenDimensions()
        val roots = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()
        val winRect = Rect()

        try {
            val winList = windows
            if (winList != null) {
                for (w in winList) {
                    val r = w.root ?: continue
                    if (r.packageName?.toString() != TV_PACKAGE) continue
                    w.getBoundsInScreen(winRect)
                    roots.add(r to Rect(winRect))
                }
            }
        } catch (_: Exception) {
        }

        val activeRoot = rootInActiveWindow
        if (activeRoot != null && activeRoot.packageName?.toString() == TV_PACKAGE) {
            activeRoot.getBoundsInScreen(winRect)
            roots.add(activeRoot to Rect(winRect))
        }

        for ((rootNode, wBounds) in roots) {
            var moveBottomNode: AccessibilityNodeInfo? = null
            var moveBottomRect: Rect? = null
            var addAlertRect: Rect? = null
            var hasMenuConfirmText = false
            val allNodes = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()

            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(rootNode)
            var visited = 0
            val rect = Rect()

            while (stack.isNotEmpty() && visited < 300) {
                val n = stack.removeLast()
                visited++
                n.getBoundsInScreen(rect)
                val copyRect = Rect(rect)
                allNodes.add(n to copyRect)

                val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
                if (txt.isNotEmpty()) {
                    when {
                        txt == "移至底部" || txt.equals("Move to bottom", ignoreCase = true) -> {
                            moveBottomNode = n
                            moveBottomRect = copyRect
                            hasMenuConfirmText = true
                        }
                        txt == "添加警报" || txt.equals("Add alert", ignoreCase = true) -> {
                            addAlertRect = copyRect
                            hasMenuConfirmText = true
                        }
                        txt == "在上方添加板块" || txt == "移至顶部" || txt == "移除" -> {
                            hasMenuConfirmText = true
                        }
                    }
                }
                for (i in 0 until n.childCount) {
                    val c = n.getChild(i) ?: continue
                    stack.add(c)
                }
            }

            val mbRect = moveBottomRect
            val aaRect = addAlertRect
            if (!hasMenuConfirmText || mbRect == null || aaRect == null) continue
            if (aaRect.centerY() <= mbRect.centerY() + 25) continue

            val bandTop = mbRect.bottom - 12
            val bandBottom = aaRect.top + 12
            val dotCandidates = allNodes.filter { (node, r) ->
                r.width() in 16..(sw * 0.14f).toInt() &&
                    r.height() in 16..(sw * 0.14f).toInt() &&
                    r.centerY() in bandTop..bandBottom &&
                    r.left >= 0 && r.right <= (sw * 0.65f).toInt() &&
                    node.text.isNullOrEmpty() &&
                    (node.isClickable || node.childCount == 0)
            }.sortedBy { it.second.centerX() }

            val distinctDots = ArrayList<Rect>()
            for ((_, r) in dotCandidates) {
                if (distinctDots.isEmpty() || abs(r.centerX() - distinctDots.last().centerX()) > (sw * 0.03f).toInt()) {
                    distinctDots.add(r)
                }
            }

            if (distinctDots.size == 7) {
                val xs = IntArray(7) { distinctDots[it].centerX() }
                val avgY = distinctDots.map { it.centerY() }.average().roundToInt()
                if (avgY in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) {
                    return ColorMenuDots(xs, avgY) to "节点直取7点"
                }
            }

            val dotY = (mbRect.centerY() + (aaRect.centerY() - mbRect.centerY()) * 0.412f).roundToInt()
            if (dotY !in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) continue

            var menuLeft = (sw * 0.026f).toInt()
            var menuRight = (sw * 0.519f).toInt()
            if (wBounds.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) {
                menuLeft = wBounds.left
                menuRight = wBounds.right
            } else {
                var cur = moveBottomNode?.parent
                var depth = 0
                val pRect = Rect()
                while (cur != null && depth < 6) {
                    cur.getBoundsInScreen(pRect)
                    if (pRect.width() in (sw * 0.36f).toInt()..(sw * 0.66f).toInt() && pRect.height() > (sh * 0.25f).toInt()) {
                        menuLeft = pRect.left
                        menuRight = pRect.right
                        break
                    }
                    cur = cur.parent
                    depth++
                }
            }

            val menuW = (menuRight - menuLeft).coerceAtLeast((sw * 0.40f).toInt())
            val xs = IntArray(7) { idx ->
                (menuLeft + menuW * MENU_DOT_X_FRACS[idx]).roundToInt().coerceIn(4, sw - 4)
            }
            return ColorMenuDots(xs, dotY) to "锚点零截屏"
        }
        return null
    }

    private fun longPressAndSelectColor(
        row: WatchlistRow,
        taskKey: String,
        color: MarkColor,
        firstDurationMs: Long,
        isLastOperation: Boolean
    ): Long {
        val (_, sh) = getScreenDimensions()
        val rowMidY = (row.centerY + (sh * 0.006f).toInt()).coerceAtMost((sh * 0.935f).toInt())
        val secondDurationMs = maxOf(firstDurationMs + 240L, 840L)
        val attempts = listOf(
            Triple(row.centerX, rowMidY, firstDurationMs),
            Triple(row.centerX + 22, row.centerY, secondDurationMs)
        )

        for ((idx, attempt) in attempts.withIndex()) {
            if (shouldAbortBatch()) return -1L
            val (lx, ly, dur) = attempt
            AppStore.log("长按 ${row.symbol} 第${idx + 1}次 ($lx,$ly) ${dur}ms")

            if (!dispatchLongPress(lx.toFloat(), ly.toFloat(), dur)) {
                AppStore.log("长按手势取消，重试")
                sleepSafe(80L)
                continue
            }

            sleepSafe(35L)
            var found: Pair<ColorMenuDots, String>? = findColorMenuFromAccessibilityWindows()
            if (found == null) {
                sleepSafe(75L)
                found = findColorMenuFromAccessibilityWindows()
            }

            if (found == null) {
                val retryDelays = longArrayOf(0L, 95L, 140L)
                for (d in retryDelays) {
                    if (d > 0L) sleepSafe(d)
                    found = findColorMenuFromAccessibilityWindows()
                    if (found != null) break

                    val menuBmp = captureScreenBitmap(maxRetries = 2)
                    if (menuBmp != null) {
                        try {
                            val dots = vision.findColorMenu(menuBmp)
                            if (dots != null) {
                                found = dots to "截屏像素"
                            }
                        } finally {
                            menuBmp.recycle()
                        }
                    }
                    if (found != null) break
                }
            }

            if (found != null) {
                val (menuDots, method) = found
                val (tapX, tapY) = menuDots.pointFor(color)
                AppStore.log("命中7色栏($method) -> 点${color.label}($tapX,$tapY)")
                dispatchTap(tapX.toFloat(), tapY.toFloat())
                sleepSafe(if (isLastOperation) 20L else 55L)
                return dur
            } else {
                AppStore.log("第${idx + 1}次长按 ${row.symbol} 未找到7色栏")
            }
        }
        return -1L
    }

    private fun captureScreenBitmap(maxRetries: Int): Bitmap? {
        for (attempt in 0 until maxRetries) {
            val elapsed = System.currentTimeMillis() - lastScreenshotAtMs
            if (elapsed < 85L) {
                sleepSafe(85L - elapsed)
            }

            val latch = CountDownLatch(1)
            val resultRef = AtomicReference<Bitmap?>(null)
            val errRef = AtomicInteger(0)

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        lastScreenshotAtMs = System.currentTimeMillis()
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            if (hw != null) {
                                try {
                                    resultRef.set(hw.copy(Bitmap.Config.ARGB_8888, false))
                                } finally {
                                    hw.recycle()
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            try {
                                screenshot.hardwareBuffer.close()
                            } catch (_: Exception) {
                            }
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        errRef.set(errorCode)
                        latch.countDown()
                    }
                }
            )

            latch.await(2, TimeUnit.SECONDS)
            val bmp = resultRef.get()
            if (bmp != null) return bmp

            val err = errRef.get()
            if (err == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                sleepSafe(110L)
            } else {
                AppStore.log("截屏失败 err=$err（第${attempt + 1}次）")
                sleepSafe(110L)
            }
        }
        return null
    }

    private fun dispatchLongPress(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 35L)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun performControlledScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.44f
        val y1 = if (scrollDown) sh * 0.83f else sh * 0.19f
        val y2 = if (scrollDown) sh * 0.19f else sh * 0.83f

        val dragPath = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, 145L, true)
        val latch = CountDownLatch(1)

        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke1).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    val holdPath = Path().apply {
                        moveTo(x, y2)
                        lineTo(x, y2)
                    }
                    val stroke2 = stroke1.continueStroke(holdPath, 0L, 40L, false)
                    dispatchGesture(
                        GestureDescription.Builder().addStroke(stroke2).build(),
                        object : GestureResultCallback() {
                            override fun onCompleted(g: GestureDescription?) { latch.countDown() }
                            override fun onCancelled(g: GestureDescription?) { latch.countDown() }
                        },
                        null
                    )
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        latch.await(2, TimeUnit.SECONDS)
    }

    private fun performFastScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.44f
        val y1 = if (scrollDown) sh * 0.83f else sh * 0.19f
        val y2 = if (scrollDown) sh * 0.19f else sh * 0.83f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 110L)
        dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchGestureSync(gesture: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok.set(true)
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    ok.set(false)
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(2, TimeUnit.SECONDS)
        return ok.get()
    }

    private fun shouldAbortBatch(): Boolean {
        return !AppStore.isWorkEnabled() || abortBatchRequested.get() || currentPage != PageState.WATCHLIST
    }

    private fun sleepSafe(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(
            NOTIF_CHANNEL_ID,
            "未找到品种提醒",
            NotificationManager.IMPORTANCE_HIGH
        )
        nm.createNotificationChannel(ch)
    }

    private fun sendMissedNotification(message: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TV颜色标记提醒")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(notifIdCounter.incrementAndGet(), notif)
        } catch (_: Exception) {
        }
    }
}
