package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * 极简省电总控服务（v6.4.3）：
 * - 零录屏权限、零启动 OCR 预加载、仅 2 个轻量后台线程
 * - 离开 TV 零事件处理；TV 图表静置 4 秒完全休眠（0Hz 空转），仅由真实点击/滚轮/切页瞬间唤醒
 */
class TvAccessibilityService : AccessibilityService() {

    companion object {
        const val TV_PACKAGE = NodeInspector.TV_PACKAGE
        private const val NOTIF_CHANNEL_ID = "tv_color_missed_quiet_v2"
        private val notifIdCounter = AtomicInteger(2000)

        @Volatile
        var instance: TvAccessibilityService? = null
            private set
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    // 4 线程精简为 2 线程：ioExecutor（页面检测/图表识别）+ batchExecutor（自选表批处理）
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val batchExecutor = Executors.newSingleThreadExecutor()

    private val vision = VisionEngine()
    private lateinit var inspector: NodeInspector
    private lateinit var gesture: GestureDriver
    private lateinit var executor: WatchlistExecutor
    private lateinit var overlay: OverlayController

    @Volatile
    private var currentPage = TvPageState.OTHER
    @Volatile
    private var lastChartSymbol: String? = null
    @Volatile
    private var cachedChartSymbol: String? = null
    @Volatile
    private var cachedChartAtMs = 0L
    @Volatile
    private var preReadRawSymbol: String? = null
    @Volatile
    private var preReadAtMs = 0L
    @Volatile
    private var lastChartReadUsedOcr = false
    @Volatile
    private var lastChartScrollMs = 0L
    @Volatile
    private var lastUserTapMs = 0L
    @Volatile
    private var lastKnownWatchlistId: String? = null
    @Volatile
    private var inferredChartWatchlistId: String? = null
    @Volatile
    private var lastChartActivityMs = 0L
    @Volatile
    private var lastContentCheckMs = 0L
    @Volatile
    private var lastScreenshotAtMs = 0L
    @Volatile
    private var ownAppInForeground = false

    private val tapInFlightCount = AtomicInteger(0)
    private val chartOtherMissCount = AtomicInteger(0)
    private val screenCheckPending = AtomicBoolean(false)
    private val contentTrailPending = AtomicBoolean(false)
    private val fastChartSyncPending = AtomicBoolean(false)
    private val isBatchRunning = AtomicBoolean(false)
    private val abortBatchRequested = AtomicBoolean(false)
    private val tapSeq = AtomicLong(0L)

    private val queueBadgeListener: (Int) -> Unit = { count ->
        if (::overlay.isInitialized) {
            overlay.updatePendingBadge(count)
        }
    }

    private fun isTapProtectionActive(): Boolean {
        return tapInFlightCount.get() > 0 || (SystemClock.uptimeMillis() - lastUserTapMs) < 420L
    }

    private val screenCheckRunnable = Runnable {
        if (screenCheckPending.compareAndSet(false, true)) {
            ioExecutor.execute {
                try {
                    evaluateCurrentScreen()
                } catch (_: Exception) {
                } finally {
                    screenCheckPending.set(false)
                }
            }
        }
    }

    private val contentTrailRunnable = Runnable {
        contentTrailPending.set(false)
        lastContentCheckMs = SystemClock.uptimeMillis()
        scheduleScreenCheck(15L)
    }

    private val fastChartSyncRunnable = Runnable {
        if (!AppStore.isWorkEnabled() || currentPage != TvPageState.CHART || isBatchRunning.get()) return@Runnable
        if (fastChartSyncPending.compareAndSet(false, true)) {
            ioExecutor.execute {
                try {
                    if (currentPage == TvPageState.CHART && !isBatchRunning.get()) {
                        val root = inspector.findTradingViewRoot() ?: return@execute
                        syncChartLightFast(root)
                    }
                } catch (_: Exception) {
                } finally {
                    fastChartSyncPending.set(false)
                }
            }
        }
    }

    private val wheelSettleSyncRunnable = Runnable { fastChartSyncRunnable.run() }

    private fun effectiveChartWatchlistId(): String? {
        return inferredChartWatchlistId ?: lastKnownWatchlistId
    }

    /**
     * 仅由真实交互（滚轮滚动 / 点击 / 切页）唤醒短时同步，绝不被实时行情跳动唤醒！
     */
    private fun wakeChartPolling() {
        lastChartActivityMs = SystemClock.uptimeMillis()
        if (currentPage == TvPageState.CHART && AppStore.isWorkEnabled()) {
            mainHandler.removeCallbacks(litNodePollRunnable)
            mainHandler.postDelayed(litNodePollRunnable, 150L)
        }
    }

    /**
     * 智能零空转同步器：
     * - 灯亮着时（刚标完准备切下一张）：持续按 240ms 做 <1ms 左下角滚轮核对，保证切品种 100% 必灭灯，绝不卡亮！
     * - 灯灭着时：静置满 3.5 秒彻底休眠（0Hz），零后台耗电！
     */
    private val litNodePollRunnable = object : Runnable {
        override fun run() {
            if (!AppStore.isWorkEnabled() || currentPage != TvPageState.CHART) return
            val isLit = overlay.getLitColor() != null
            val idleMs = SystemClock.uptimeMillis() - lastChartActivityMs
            if (!isLit && idleMs > 3_500L) {
                return
            }
            if (!isBatchRunning.get() && !isTapProtectionActive()) {
                ioExecutor.execute {
                    if (currentPage != TvPageState.CHART || isBatchRunning.get() || isTapProtectionActive()) return@execute
                    val root = inspector.findTradingViewRoot() ?: return@execute
                    val ctx = inspector.extractChartWheelContext(root)
                    val fromNode = ctx.currentSymbol ?: return@execute
                    preReadRawSymbol = fromNode
                    preReadAtMs = SystemClock.uptimeMillis()
                    CatalogRepository.inferWatchlistIdFromWheelContext(ctx.prevSymbol, fromNode, ctx.nextSymbol)?.let {
                        inferredChartWatchlistId = it
                    }
                    val wlId = effectiveChartWatchlistId()
                    val resolved = CatalogRepository.resolveChartSymbolInCatalog(fromNode, wlId) ?: fromNode
                    if (resolved != lastChartSymbol && !isTapProtectionActive()) {
                        lastChartSymbol = resolved
                        cachedChartSymbol = resolved
                        cachedChartAtMs = System.currentTimeMillis()
                        lastChartReadUsedOcr = false
                        val queued = AppStore.getTaskColorForChart(resolved, wlId)
                        if (overlay.getLitColor() != queued) {
                            overlay.setLitColor(queued)
                            AppStore.log("切图同步：$resolved -> ${queued?.label ?: "灭灯"}")
                        }
                        overlay.updateSessionMarkedBadge(AppStore.getSessionMarkedColor(resolved, wlId))
                    }
                }
            }
            val nextDelay = when {
                idleMs < 1_500L -> 150L
                isLit -> 240L
                else -> 450L
            }
            mainHandler.postDelayed(this, nextDelay)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppStore.init(this)
        createNotificationChannel()

        inspector = NodeInspector(this, vision) { getScreenDimensions() }
        gesture = GestureDriver(this) { getScreenDimensions() }
        overlay = OverlayController(
            context = this,
            onColorDownPreRead = { preReadChartSymbolAsync() },
            onColorTap = { color -> handleColorButtonTap(color) },
            onRequestPauseService = { reason -> pauseServiceAtAppLevel(reason) }
        )
        executor = WatchlistExecutor(
            service = this,
            vision = vision,
            inspector = inspector,
            gesture = gesture,
            screenSizeProvider = { getScreenDimensions() },
            captureScreen = { maxRetries -> captureScreenBitmap(maxRetries) },
            shouldAbort = { shouldAbortBatch() },
            onWatchlistIdentified = { wlId -> lastKnownWatchlistId = wlId },
            onSendNotification = { msg -> sendMissedNotification(msg) },
            onShowDoneBanner = { overlay.showDoneBanner(previewMode = false) },
            onShowCustomBanner = { txt -> overlay.showCustomBanner(txt) }
        )

        AppStore.addQueueCountListener(queueBadgeListener)
        overlay.updatePendingBadge(AppStore.pendingCount())
        WorkTileService.requestTileSync(this)
        AppStore.log("无障碍服务已连接（v6.4.3 极简省电版｜APP开关=${if (AppStore.isWorkEnabled()) "开" else "关"}）")
        // 不再预加载 ML Kit OCR 模型，完全按需懒加载，常驻内存直降 ~100MB！
        scheduleScreenCheck(25L)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        AppStore.removeQueueCountListener(queueBadgeListener)
        abortBatchRequested.set(true)
        mainHandler.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) {
            overlay.destroy()
        }
        vision.close()
        ioExecutor.shutdownNow()
        batchExecutor.shutdownNow()
    }

    override fun onInterrupt() {
        abortBatchRequested.set(true)
    }

    private fun pauseServiceAtAppLevel(reason: String) {
        tapSeq.incrementAndGet()
        AppStore.setWorkEnabled(this, false, source = reason)
    }

    fun onWorkEnabledChanged(enabled: Boolean) {
        if (!::overlay.isInitialized) return
        if (!enabled) {
            abortBatchRequested.set(true)
            stopLitNodePolling()
            currentPage = TvPageState.OTHER
            overlay.hideButtons()
            overlay.hideDoneBanner()
        } else {
            abortBatchRequested.set(false)
            currentPage = TvPageState.OTHER
            scheduleScreenCheck(20L)
        }
    }

    fun onOwnAppForegroundChanged(inForeground: Boolean) {
        ownAppInForeground = inForeground
        if (::overlay.isInitialized) {
            if (inForeground) {
                currentPage = TvPageState.OTHER
                abortBatchRequested.set(true)
                stopLitNodePolling()
                overlay.hideButtons()
            } else if (AppStore.isWorkEnabled()) {
                scheduleScreenCheck(25L)
            }
        }
    }

    fun refreshButtonSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            overlay.refreshButtonsInPlace(resetPosition)
        }
    }

    fun previewDoneBanner() {
        if (::overlay.isInitialized) {
            overlay.showDoneBanner(previewMode = true)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !AppStore.isWorkEnabled()) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val evType = event.eventType

        // 1) 非 TradingView 应用：直接第一行拦截，微信/桌面/浏览器里后台算力消耗 = 0%！
        if (pkg != TV_PACKAGE) {
            if (currentPage == TvPageState.OTHER) return
            if (evType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                scheduleScreenCheck(25L)
            }
            return
        }

        // 2) 批处理运行中：仅将点击/滚动交给礼让器，且仅在窗口切换/点击时复核页面，避免内部事件风暴
        if (isBatchRunning.get()) {
            gesture.onExternalTvEvent(event)
            if (evType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || evType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                scheduleScreenCheck(20L)
            }
            return
        }

        // 3) TV 内内容更新“前缘+尾缘”合并节流（200ms）：
        //    既把 60Hz 报价刷屏压到 ~4次/秒，又保证周末休市/安静图表切换品种的最后一帧 100% 必被扫到，绝不丢尾事件！
        if (evType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            val changeTypes = event.contentChangeTypes
            val isPaneTransition = (changeTypes and (
                AccessibilityEvent.CONTENT_CHANGE_TYPE_PANE_APPEARED or
                    AccessibilityEvent.CONTENT_CHANGE_TYPE_PANE_DISAPPEARED or
                    AccessibilityEvent.CONTENT_CHANGE_TYPE_PANE_TITLE
                )) != 0
            val now = SystemClock.uptimeMillis()
            if (isPaneTransition) {
                contentTrailPending.set(false)
                mainHandler.removeCallbacks(contentTrailRunnable)
                lastContentCheckMs = now
                scheduleScreenCheck(25L)
            } else if (now - lastContentCheckMs >= 200L) {
                contentTrailPending.set(false)
                mainHandler.removeCallbacks(contentTrailRunnable)
                lastContentCheckMs = now
                scheduleScreenCheck(30L)
            } else if (contentTrailPending.compareAndSet(false, true)) {
                val remain = (lastContentCheckMs + 200L - now).coerceAtLeast(45L)
                mainHandler.postDelayed(contentTrailRunnable, remain)
            }
            return
        }

        // 4) 真实用户操作即时响应
        if (currentPage == TvPageState.CHART) {
            if (evType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
                lastChartScrollMs = SystemClock.uptimeMillis()
                preReadRawSymbol = null
                if (overlay.getLitColor() != null) {
                    val src = event.source
                    if (src == null || lastChartReadUsedOcr) {
                        resetChartLightImmediately("滚轮滚动", keepWatcher = true)
                    } else {
                        val (sw, sh) = getScreenDimensions()
                        val rect = Rect()
                        src.getBoundsInScreen(rect)
                        if (rect.isEmpty || (rect.bottom >= (sh * 0.85f).toInt() && rect.left <= (sw * 0.45f).toInt())) {
                            resetChartLightImmediately("滚轮切换品种", keepWatcher = true)
                        }
                    }
                }
                wakeChartPolling()
                mainHandler.removeCallbacks(fastChartSyncRunnable)
                mainHandler.removeCallbacks(wheelSettleSyncRunnable)
                mainHandler.postDelayed(fastChartSyncRunnable, 55L)
                mainHandler.postDelayed(wheelSettleSyncRunnable, 190L)
                return
            } else if (evType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                val clickedText = (event.text?.joinToString("") ?: "") + (event.contentDescription?.toString() ?: "")
                var isWatchlistTabClick = clickedText.contains("自选表") || clickedText.contains("Watchlist", ignoreCase = true)
                if (!isWatchlistTabClick) {
                    val src = event.source
                    if (src != null) {
                        val (sw, sh) = getScreenDimensions()
                        val rect = Rect()
                        src.getBoundsInScreen(rect)
                        if (!rect.isEmpty && rect.bottom >= (sh * 0.93f).toInt() && rect.centerX() <= (sw * 0.22f).toInt()) {
                            isWatchlistTabClick = true
                        }
                    }
                }
                if (isWatchlistTabClick) {
                    // 0ms 瞬间隐藏圆球，绝不在列表页残留哪怕半秒！（不管待办池是否为空）
                    overlay.hideButtons()
                    mainHandler.removeCallbacks(screenCheckRunnable)
                    mainHandler.postDelayed(screenCheckRunnable, 10L)
                    return
                }
                wakeChartPolling()
                mainHandler.removeCallbacks(fastChartSyncRunnable)
                mainHandler.postDelayed(fastChartSyncRunnable, 40L)
                scheduleScreenCheck(15L)
                return
            }
        }

        val delay = when {
            evType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 8L
            evType == AccessibilityEvent.TYPE_VIEW_CLICKED && currentPage == TvPageState.WATCHLIST -> 6L
            evType == AccessibilityEvent.TYPE_VIEW_CLICKED -> 14L
            else -> 30L
        }
        scheduleScreenCheck(delay)
    }

    private fun scheduleScreenCheck(delayMs: Long) {
        mainHandler.removeCallbacks(screenCheckRunnable)
        mainHandler.postDelayed(screenCheckRunnable, delayMs)
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        return b.width() to b.height()
    }

    private fun resetChartLightImmediately(reason: String? = null, keepWatcher: Boolean = false) {
        lastChartSymbol = null
        cachedChartSymbol = null
        cachedChartAtMs = 0L
        if (!keepWatcher) preReadRawSymbol = null
        if (!keepWatcher) stopLitNodePolling()
        overlay.updateSessionMarkedBadge(null)
        if (overlay.getLitColor() != null) {
            overlay.setLitColor(null)
            if (reason != null) AppStore.log("灭灯：$reason")
        }
    }

    private fun stopLitNodePolling() {
        mainHandler.removeCallbacks(litNodePollRunnable)
    }

    private fun evaluateCurrentScreen() {
        if (ownAppInForeground) return
        if (!AppStore.isWorkEnabled()) {
            overlay.hideButtons()
            return
        }

        val activeRoot = rootInActiveWindow
        val activePkg = activeRoot?.packageName?.toString()
        val tvRoot: AccessibilityNodeInfo? = when {
            activePkg == TV_PACKAGE -> activeRoot
            activePkg == null || activePkg == "com.android.systemui" || activePkg == packageName -> inspector.findTradingViewRoot()
            else -> {
                val activeRect = Rect().also { activeRoot.getBoundsInScreen(it) }
                val (sw, sh) = getScreenDimensions()
                val isSmallFloatingOverlay = !activeRect.isEmpty &&
                    (activeRect.width() < (sw * 0.85f).toInt() || activeRect.height() < (sh * 0.72f).toInt())
                if (isSmallFloatingOverlay) inspector.findTradingViewRoot() else null
            }
        }

        if (tvRoot == null) {
            if (currentPage != TvPageState.OTHER) {
                currentPage = TvPageState.OTHER
                resetChartLightImmediately()
                overlay.hideButtons()
                if (isBatchRunning.get()) {
                    abortBatchRequested.set(true)
                    AppStore.log("切离TradingView，暂停批处理（待办池已保留）")
                }
            }
            return
        }

        var detectedWheelCtx: ChartWheelContext? = null
        val detected = inspector.detectTradingViewPage(
            root = tvRoot,
            isBatchRunning = isBatchRunning.get(),
            onWheelContextFound = { ctx ->
                detectedWheelCtx = ctx
                ctx.currentSymbol?.let { sym ->
                    preReadRawSymbol = sym
                    preReadAtMs = SystemClock.uptimeMillis()
                    CatalogRepository.inferWatchlistIdFromWheelContext(ctx.prevSymbol, sym, ctx.nextSymbol)?.let {
                        inferredChartWatchlistId = it
                    }
                }
            }
        )

        if (detected != currentPage) {
            val prev = currentPage
            currentPage = detected
            AppStore.log("页面切换：$prev -> $detected")

            when (detected) {
                TvPageState.CHART -> {
                    chartOtherMissCount.set(0)
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                    resetChartLightImmediately()
                    // 优先立刻显示预构建的圆球（<1ms），再同步亮灯状态，不再重复扫两遍节点树！
                    overlay.showButtons()
                    val reusedCtx = detectedWheelCtx
                    if (reusedCtx?.currentSymbol != null) {
                        applyChartWheelContext(reusedCtx)
                    } else {
                        syncChartLightFast(tvRoot)
                    }
                    wakeChartPolling()
                }

                TvPageState.WATCHLIST -> {
                    chartOtherMissCount.set(0)
                    stopLitNodePolling()
                    overlay.hideButtons()
                    if (!isBatchRunning.get()) {
                        inspector.detectActiveWatchlistFromTopNodes()?.let { lastKnownWatchlistId = it.id }
                    }
                    if ((AppStore.isCalibrationArmed() || AppStore.hasPendingItems()) && !isBatchRunning.get()) {
                        startWatchlistBatch()
                    }
                }

                TvPageState.OTHER -> {
                    if (prev == TvPageState.CHART && activePkg == TV_PACKAGE) {
                        val misses = chartOtherMissCount.incrementAndGet()
                        if (misses < 2) {
                            currentPage = TvPageState.CHART
                            scheduleScreenCheck(140L)
                            return
                        }
                    }
                    chartOtherMissCount.set(0)
                    resetChartLightImmediately()
                    overlay.hideButtons()
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                }
            }
        } else if (detected == TvPageState.CHART) {
            chartOtherMissCount.set(0)
            overlay.showButtons()
            syncChartLightFast(tvRoot)
        } else if (detected == TvPageState.WATCHLIST) {
            overlay.hideButtons()
            if (!isBatchRunning.get()) {
                inspector.detectActiveWatchlistFromTopNodes()?.let { lastKnownWatchlistId = it.id }
            }
            if ((AppStore.isCalibrationArmed() || AppStore.hasPendingItems()) && !isBatchRunning.get()) {
                startWatchlistBatch()
            }
        }
    }

    private fun applyChartWheelContext(ctx: ChartWheelContext) {
        val rawSym = ctx.currentSymbol ?: return
        preReadRawSymbol = rawSym
        preReadAtMs = SystemClock.uptimeMillis()
        CatalogRepository.inferWatchlistIdFromWheelContext(ctx.prevSymbol, rawSym, ctx.nextSymbol)?.let {
            inferredChartWatchlistId = it
        }
        val wlId = effectiveChartWatchlistId()
        val sym = CatalogRepository.resolveChartSymbolInCatalog(rawSym, wlId) ?: rawSym
        cachedChartSymbol = sym
        cachedChartAtMs = System.currentTimeMillis()
        if (isTapProtectionActive()) return
        val queuedColor = AppStore.getTaskColorForChart(sym, wlId)
        if (sym != lastChartSymbol || overlay.getLitColor() != queuedColor) {
            val prevColor = overlay.getLitColor()
            lastChartSymbol = sym
            overlay.setLitColor(queuedColor)
            if (prevColor != queuedColor) {
                AppStore.log("切图同步：$sym -> ${queuedColor?.label ?: "灭灯"}")
            }
            if (queuedColor != null) wakeChartPolling()
        }
        overlay.updateSessionMarkedBadge(AppStore.getSessionMarkedColor(sym, wlId))
    }

    private fun syncChartLightFast(root: AccessibilityNodeInfo) {
        applyChartWheelContext(inspector.extractChartWheelContext(root))
    }

    private fun preReadChartSymbolAsync() {
        if (!AppStore.isWorkEnabled()) return
        val now = SystemClock.uptimeMillis()
        if (preReadRawSymbol != null && preReadAtMs >= lastChartScrollMs && (now - preReadAtMs) < 250L) {
            return
        }
        ioExecutor.execute {
            val ctx = inspector.findTradingViewRoot()?.let { inspector.extractChartWheelContext(it) } ?: return@execute
            val raw = ctx.currentSymbol ?: return@execute
            preReadRawSymbol = raw
            preReadAtMs = SystemClock.uptimeMillis()
            CatalogRepository.inferWatchlistIdFromWheelContext(ctx.prevSymbol, raw, ctx.nextSymbol)?.let {
                inferredChartWatchlistId = it
            }
        }
    }

    /**
     * 0ms 瞬时亮灭反馈 + 2ms 实时读屏核对（彻底杜绝读到旧品种缓存张冠李戴！）
     */
    private fun handleColorButtonTap(color: MarkColor) {
        if (!AppStore.isWorkEnabled()) return
        val seq = tapSeq.incrementAndGet()
        val now = SystemClock.uptimeMillis()
        lastUserTapMs = now
        wakeChartPolling()

        val prevLitColor = overlay.getLitColor()
        val prevLitSymbol = lastChartSymbol

        // 0ms 即时视觉响应（若点的是已亮同色先暂灭，后台2ms核对若已换新品种则立刻亮起并标新品种）
        if (prevLitColor == color) {
            overlay.setLitColor(null)
        } else {
            overlay.setLitColor(color)
        }

        // 仅当 ACTION_DOWN 刚刚(<350ms内)实时预读到新鲜结果，直接走 0ms 快通道
        val superFreshPre = if (preReadRawSymbol != null && preReadAtMs >= lastChartScrollMs && (now - preReadAtMs) <= 350L) {
            preReadRawSymbol
        } else null

        if (superFreshPre != null) {
            applyVerifiedTap(seq, superFreshPre, "秒选", color, prevLitColor, prevLitSymbol)
            return
        }

        tapInFlightCount.incrementAndGet()
        ioExecutor.execute {
            try {
                if (tapSeq.get() != seq) return@execute
                val (rawSym, source) = resolveCurrentChartSymbolQuick()
                if (tapSeq.get() != seq || !AppStore.isWorkEnabled() || currentPage != TvPageState.CHART) return@execute

                if (rawSym == null) {
                    AppStore.log("图表未读到品种代码，自动灭灯回退")
                    if (tapSeq.get() == seq) overlay.setLitColor(null)
                    return@execute
                }
                preReadRawSymbol = rawSym
                preReadAtMs = SystemClock.uptimeMillis()
                applyVerifiedTap(seq, rawSym, source, color, prevLitColor, prevLitSymbol)
            } finally {
                tapInFlightCount.decrementAndGet()
            }
        }
    }

    private fun applyVerifiedTap(
        seq: Long,
        rawSym: String,
        source: String,
        tappedColor: MarkColor,
        prevLitColor: MarkColor?,
        prevLitSymbol: String?
    ) {
        if (tapSeq.get() != seq || currentPage != TvPageState.CHART) return
        val curWlId = effectiveChartWatchlistId()
        val resolved = CatalogRepository.resolveChartSymbolInCatalog(rawSym, curWlId)
        val targetSym = resolved ?: rawSym

        // 只有真实当前品种 == 之前亮灯的品种，且点了相同颜色，才执行取消勾选！
        if (prevLitColor == tappedColor && prevLitSymbol != null && targetSym == prevLitSymbol) {
            overlay.setLitColor(null)
            if (AppStore.removeTaskForChart(targetSym, curWlId)) {
                AppStore.log("取消勾选：$targetSym（已移出待添加池）")
            }
            return
        }

        if (resolved == null) {
            AppStore.recordUnknownSymbol(targetSym)
            AppStore.log("提示：$targetSym 不在《品种大全》内，已照常加入待添加池")
        }
        lastChartSymbol = targetSym
        cachedChartSymbol = targetSym
        cachedChartAtMs = System.currentTimeMillis()
        lastChartReadUsedOcr = (source == "OCR")
        AppStore.putTask(targetSym, tappedColor, curWlId)
        AppStore.log("图表$source：$rawSym -> $targetSym -> ${tappedColor.label}")
        if (tapSeq.get() == seq && currentPage == TvPageState.CHART) {
            overlay.setLitColor(tappedColor)
        }
    }

    private fun resolveCurrentChartSymbolQuick(): Pair<String?, String> {
        for (tryIdx in 0 until 2) {
            val root = inspector.findTradingViewRoot()
            val ctx = root?.let { inspector.extractChartWheelContext(it) }
            if (ctx?.currentSymbol != null) {
                CatalogRepository.inferWatchlistIdFromWheelContext(ctx.prevSymbol, ctx.currentSymbol, ctx.nextSymbol)?.let {
                    inferredChartWatchlistId = it
                }
                return ctx.currentSymbol to "节点"
            }
            if (tryIdx == 0) gesture.sleepSafe(55L)
        }

        val bmp = captureScreenBitmap(maxRetries = 2)
        if (bmp != null) {
            try {
                val ocrSym = vision.readChartSymbolFromBitmap(bmp)
                if (ocrSym != null) return ocrSym to "OCR"
            } finally {
                bmp.recycle()
            }
        }
        if (cachedChartSymbol != null && System.currentTimeMillis() - cachedChartAtMs <= 2500L) {
            return cachedChartSymbol to "缓存"
        }
        return null to "无"
    }

    private fun startWatchlistBatch() {
        val runCalibration = AppStore.isCalibrationArmed()
        if (!AppStore.isWorkEnabled() || (!runCalibration && !AppStore.hasPendingItems())) return
        if (!isBatchRunning.compareAndSet(false, true)) return
        abortBatchRequested.set(false)
        gesture.resetYieldOnBatchStart()

        batchExecutor.execute {
            try {
                if (runCalibration) {
                    executor.runWatchlistCalibration()
                } else {
                    executor.runBatch()
                }
            } catch (e: Exception) {
                AppStore.log("批处理异常：${e.message}")
            } finally {
                isBatchRunning.set(false)
                if (AppStore.isWorkEnabled() && (AppStore.isCalibrationArmed() || AppStore.hasPendingItems()) && currentPage == TvPageState.WATCHLIST) {
                    scheduleScreenCheck(45L)
                }
            }
        }
    }

    private fun shouldAbortBatch(): Boolean {
        return !AppStore.isWorkEnabled() || abortBatchRequested.get() || currentPage != TvPageState.WATCHLIST
    }

    /**
     * 按需单次无障碍截屏（零常驻录屏）：
     * 回调仅在主线程做 0.01ms 引用传递，实际像素拷贝在当前后台线程执行，零死锁、零阻塞主线程！
     */
    private fun captureScreenBitmap(maxRetries: Int): Bitmap? {
        for (attempt in 0 until maxRetries) {
            val elapsed = System.currentTimeMillis() - lastScreenshotAtMs
            if (elapsed < 40L) {
                gesture.sleepSafe(40L - elapsed)
            }

            val latch = CountDownLatch(1)
            val rawShotRef = AtomicReference<ScreenshotResult?>(null)
            val errRef = AtomicInteger(0)

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        lastScreenshotAtMs = System.currentTimeMillis()
                        rawShotRef.set(screenshot)
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) {
                        errRef.set(errorCode)
                        latch.countDown()
                    }
                }
            )

            latch.await(2, TimeUnit.SECONDS)
            val shot = rawShotRef.get()
            if (shot != null) {
                val bmp = try {
                    val hw = Bitmap.wrapHardwareBuffer(shot.hardwareBuffer, shot.colorSpace)
                    if (hw != null) {
                        try {
                            hw.copy(Bitmap.Config.ARGB_8888, false)
                        } finally {
                            hw.recycle()
                        }
                    } else null
                } catch (_: Exception) {
                    null
                } finally {
                    try { shot.hardwareBuffer.close() } catch (_: Exception) {}
                }
                if (bmp != null) return bmp
            }

            val err = errRef.get()
            if (err == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                gesture.sleepSafe(95L)
            } else {
                AppStore.log("截屏失败 err=$err（第${attempt + 1}次）")
                gesture.sleepSafe(95L)
            }
        }
        return null
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(
            NOTIF_CHANNEL_ID,
            "未添加品种提醒（不遮挡屏幕）",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            setSound(null, null)
            enableVibration(false)
        }
        nm.createNotificationChannel(ch)
    }

    private fun sendMissedNotification(message: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TV颜色标记：有未添加品种（进APP可一键重试）")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setSilent(true)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(notifIdCounter.incrementAndGet(), notif)
        } catch (_: Exception) {
        }
    }
}
