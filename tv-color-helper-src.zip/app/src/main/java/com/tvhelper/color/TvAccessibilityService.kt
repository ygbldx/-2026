package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.roundToInt

class TvAccessibilityService : AccessibilityService() {

    companion object {
        const val TV_PACKAGE = "com.tradingview.tradingviewapp"
        private const val NOTIF_CHANNEL_ID = "tv_color_missed_channel"
        private val notifIdCounter = AtomicInteger(1000)

        // TradingView 长按菜单内 7 颗颜色圆点相对菜单宽度的精确水平比例（红->粉）
        private val MENU_DOT_X_FRACS = floatArrayOf(0.088f, 0.226f, 0.358f, 0.496f, 0.633f, 0.765f, 0.903f)

        @Volatile
        var instance: TvAccessibilityService? = null
            private set
    }

    private enum class PageState { CHART, WATCHLIST, OTHER }

    private val mainHandler = Handler(Looper.getMainLooper())
    // 独立双线程池：图表识别与列表批处理互不排队阻塞
    private val chartExecutor = Executors.newSingleThreadExecutor()
    private val batchExecutor = Executors.newSingleThreadExecutor()
    private val vision = VisionEngine()
    private lateinit var overlay: OverlayController

    @Volatile
    private var currentPage = PageState.OTHER
    @Volatile
    private var lastChartSymbol: String? = null
    @Volatile
    private var cachedChartSymbol: String? = null
    @Volatile
    private var cachedChartAtMs = 0L
    @Volatile
    private var lastScreenshotAtMs = 0L
    @Volatile
    private var batchDoneForCurrentWatchlistVisit = false
    @Volatile
    private var ownAppInForeground = false
    @Volatile
    private var learnedLongPressMs = 0L

    @Volatile
    private var unfinishedInfoItems: List<Pair<String, MarkColor>>? = null

    private val isBatchRunning = AtomicBoolean(false)
    private val abortBatchRequested = AtomicBoolean(false)
    private val tapSeq = AtomicLong(0L)

    private val screenCheckRunnable = Runnable { evaluateCurrentScreen() }
    // 仅做 0 截屏的无障碍节点轻检测，绝不占用系统截屏冷却
    private val litNodePollRunnable = object : Runnable {
        override fun run() {
            if (!AppStore.isWorkEnabled() || currentPage != PageState.CHART || overlay.getLitColor() == null) return
            if (!isBatchRunning.get()) {
                val root = rootInActiveWindow
                val fromNode = root?.let { extractChartSymbolFromNodes(it) }
                if (fromNode != null && fromNode != lastChartSymbol) {
                    lastChartSymbol = fromNode
                    cachedChartSymbol = fromNode
                    cachedChartAtMs = System.currentTimeMillis()
                    val queued = AppStore.getSymbolColor(fromNode)
                    overlay.setLitColor(queued)
                    if (queued == null) return
                }
            }
            mainHandler.postDelayed(this, 260L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppStore.init(this)
        createNotificationChannel()
        overlay = OverlayController(
            context = this,
            onColorTap = { color -> handleColorButtonTap(color) },
            onRequestPauseService = { reason -> pauseServiceAtAppLevel(reason) },
            onInfoPanelDismissed = { unfinishedInfoItems = null }
        )
        WorkTileService.requestTileSync(this)
        AppStore.log("无障碍服务已连接（APP开关=${if (AppStore.isWorkEnabled()) "开" else "关"}）")
        chartExecutor.execute { vision.warmUp() }
        scheduleScreenCheck(20L)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        abortBatchRequested.set(true)
        mainHandler.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) {
            overlay.destroy()
        }
        vision.close()
        chartExecutor.shutdownNow()
        batchExecutor.shutdownNow()
    }

    override fun onInterrupt() {
        abortBatchRequested.set(true)
    }

    /**
     * 图表页手势关闭服务：仅关闭 APP 层面总开关（并同步状态栏快捷开关与 APP 大开关），绝不关闭系统无障碍！
     */
    private fun pauseServiceAtAppLevel(reason: String) {
        tapSeq.incrementAndGet()
        AppStore.setWorkEnabled(this, false, source = reason)
    }

    /**
     * 响应 APP 大开关 / 状态栏快捷开关 / 图表手势 的开关切换
     */
    fun onWorkEnabledChanged(enabled: Boolean) {
        if (!::overlay.isInitialized) return
        if (!enabled) {
            abortBatchRequested.set(true)
            stopLitNodePolling()
            currentPage = PageState.OTHER
            batchDoneForCurrentWatchlistVisit = false
            unfinishedInfoItems = null
            overlay.hideButtons()
            overlay.hideInfoPanel()
            overlay.hideDoneBanner()
        } else {
            abortBatchRequested.set(false)
            batchDoneForCurrentWatchlistVisit = false
            currentPage = PageState.OTHER
            scheduleScreenCheck(20L)
        }
    }

    fun onOwnAppForegroundChanged(inForeground: Boolean) {
        ownAppInForeground = inForeground
        if (::overlay.isInitialized) {
            if (inForeground) {
                currentPage = PageState.OTHER
                stopLitNodePolling()
                overlay.hideButtons()
                overlay.hideInfoPanel()
            } else {
                if (unfinishedInfoItems == null) {
                    overlay.hideInfoPanel()
                }
                if (AppStore.isWorkEnabled()) {
                    scheduleScreenCheck(30L)
                }
            }
        }
    }

    fun refreshButtonSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            overlay.refreshButtonsInPlace(resetPosition)
        }
    }

    fun refreshInfoPanelSettings(resetPosition: Boolean = false) {
        if (::overlay.isInitialized) {
            if (!AppStore.isInfoPanelEnabled()) {
                overlay.hideInfoPanel()
            } else {
                overlay.refreshInfoPanelInPlace(resetPosition)
            }
        }
    }

    fun previewDoneBanner() {
        if (::overlay.isInitialized) {
            overlay.showDoneBanner(previewMode = true)
        }
    }

    fun previewInfoPanel() {
        if (::overlay.isInitialized) {
            val q = AppStore.snapshotQueue()
            val sample = if (q.isNotEmpty()) {
                q.entries.map { it.key to it.value }
            } else {
                listOf(
                    "SAP" to MarkColor.RED,
                    "AZN" to MarkColor.BLUE,
                    "LLY" to MarkColor.GREEN
                )
            }
            overlay.showInfoPanel(sample, forcePreview = true)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!AppStore.isWorkEnabled()) return
        val pkg = event.packageName?.toString()
        if (pkg == packageName) return

        // 图表页滚动左下角滚轮，0ms 瞬间灭灯
        if (currentPage == PageState.CHART &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            overlay.getLitColor() != null
        ) {
            val src = event.source
            if (src != null) {
                val (sw, sh) = getScreenDimensions()
                val rect = Rect()
                src.getBoundsInScreen(rect)
                if (rect.bottom >= (sh * 0.88f).toInt() && rect.left <= (sw * 0.36f).toInt()) {
                    resetChartLightImmediately("检测到滚动切换品种")
                }
            }
        }

        // 0ms 抢跑：在图表页点底部“自选表”标签，立刻触发切换不防抖
        if (currentPage == PageState.CHART &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            AppStore.hasPendingItems()
        ) {
            val clickedText = (event.text?.joinToString("") ?: "") + (event.contentDescription?.toString() ?: "")
            if (clickedText.contains("自选表") || clickedText.contains("Watchlist", ignoreCase = true)) {
                mainHandler.removeCallbacks(screenCheckRunnable)
                mainHandler.postDelayed(screenCheckRunnable, 10L)
                return
            }
        }

        val delay = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 10L
            AccessibilityEvent.TYPE_VIEW_CLICKED -> 15L
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> 20L
            else -> 35L
        }
        scheduleScreenCheck(delay)
    }

    private fun scheduleScreenCheck(delayMs: Long) {
        mainHandler.removeCallbacks(screenCheckRunnable)
        mainHandler.postDelayed(screenCheckRunnable, delayMs)
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        return b.width() to b.height()
    }

    private fun resetChartLightImmediately(reason: String? = null) {
        lastChartSymbol = null
        cachedChartSymbol = null
        cachedChartAtMs = 0L
        stopLitNodePolling()
        if (overlay.getLitColor() != null) {
            overlay.setLitColor(null)
            if (reason != null) AppStore.log("灭灯：$reason")
        }
    }

    private fun evaluateCurrentScreen() {
        if (ownAppInForeground) return
        if (!AppStore.isWorkEnabled()) {
            overlay.hideButtons()
            overlay.hideInfoPanel()
            return
        }

        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()

        if (pkg != TV_PACKAGE) {
            if (currentPage != PageState.OTHER) {
                currentPage = PageState.OTHER
                resetChartLightImmediately()
                batchDoneForCurrentWatchlistVisit = false
                overlay.hideButtons()
                overlay.hideInfoPanel()
                if (isBatchRunning.get()) {
                    abortBatchRequested.set(true)
                    AppStore.log("检测到离开TradingView，中止批处理")
                }
            }
            return
        }

        val detected = detectTradingViewPage(root)

        if (detected != currentPage) {
            val prev = currentPage
            currentPage = detected
            AppStore.log("页面切换：$prev -> $detected")

            when (detected) {
                PageState.CHART -> {
                    batchDoneForCurrentWatchlistVisit = false
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                    overlay.hideInfoPanel()
                    resetChartLightImmediately()
                    overlay.showButtons()
                    syncChartLightFast(root)
                }

                PageState.WATCHLIST -> {
                    stopLitNodePolling()
                    overlay.hideButtons()
                    if (AppStore.hasPendingItems() &&
                        !isBatchRunning.get() &&
                        !batchDoneForCurrentWatchlistVisit
                    ) {
                        startWatchlistBatch()
                    } else if (unfinishedInfoItems != null && !isBatchRunning.get()) {
                        unfinishedInfoItems?.let { overlay.showInfoPanel(it) }
                    }
                }

                PageState.OTHER -> {
                    resetChartLightImmediately()
                    overlay.hideButtons()
                    overlay.hideInfoPanel()
                    if (isBatchRunning.get()) {
                        abortBatchRequested.set(true)
                    }
                }
            }
        } else if (detected == PageState.CHART) {
            overlay.showButtons()
            syncChartLightFast(root)
        } else if (detected == PageState.WATCHLIST) {
            overlay.hideButtons()
            if (AppStore.hasPendingItems() &&
                !isBatchRunning.get() &&
                !batchDoneForCurrentWatchlistVisit
            ) {
                startWatchlistBatch()
            }
        }
    }

    private fun detectTradingViewPage(root: AccessibilityNodeInfo): PageState {
        val (_, sh) = getScreenDimensions()
        val navTopThreshold = (sh * 0.90f).toInt()

        var watchlistNav: AccessibilityNodeInfo? = null
        var chartNav: AccessibilityNodeInfo? = null
        var hasTopWatchlistHeader = false
        var hasChartBottomToolbar = false

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 460) {
            val node = stack.removeLast()
            visited++
            val text = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim().orEmpty()
            node.getBoundsInScreen(rect)

            if (rect.bottom >= navTopThreshold && text.isNotEmpty()) {
                when (text) {
                    "自选表", "Watchlist" -> watchlistNav = node
                    "图表", "Chart" -> chartNav = node
                }
            } else if (rect.top < sh * 0.14f &&
                (text == "搜索" || text == "Search" || text.startsWith("-1") || text.startsWith("-2") || text.startsWith("-3") || text.startsWith("-4"))
            ) {
                hasTopWatchlistHeader = true
            } else if (rect.top in (sh * 0.90f).toInt()..(sh * 0.955f).toInt() &&
                (text.contains("周") || text.contains("日") || text.contains("小时") || text.contains("分") ||
                    text.equals("1D", true) || text.equals("1W", true))
            ) {
                hasChartBottomToolbar = true
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                stack.add(child)
            }
        }

        if (isBatchRunning.get() && watchlistNav == null && chartNav == null) {
            return PageState.WATCHLIST
        }
        if (watchlistNav == null && chartNav == null) {
            return PageState.OTHER
        }

        val isChartSelected = isNodeOrAncestorSelected(chartNav)
        val isWatchlistSelected = isNodeOrAncestorSelected(watchlistNav)

        return when {
            isChartSelected && !isWatchlistSelected -> PageState.CHART
            isWatchlistSelected && !isChartSelected -> PageState.WATCHLIST
            hasChartBottomToolbar && !hasTopWatchlistHeader -> PageState.CHART
            hasTopWatchlistHeader && !hasChartBottomToolbar -> PageState.WATCHLIST
            else -> PageState.OTHER
        }
    }

    private fun isNodeOrAncestorSelected(node: AccessibilityNodeInfo?): Boolean {
        var cur = node
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isSelected || cur.isChecked) return true
            val desc = cur.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("已选") || desc.contains("selected")) return true
            cur = cur.parent
            depth++
        }
        return false
    }

    /**
     * 纯节点 0 截屏快速同步图表亮灯状态（避免触发系统截屏冷却拖慢后续自选表）
     */
    private fun syncChartLightFast(root: AccessibilityNodeInfo) {
        val sym = extractChartSymbolFromNodes(root) ?: return
        cachedChartSymbol = sym
        cachedChartAtMs = System.currentTimeMillis()
        if (sym != lastChartSymbol) {
            lastChartSymbol = sym
            val queuedColor = AppStore.getSymbolColor(sym)
            overlay.setLitColor(queuedColor)
            if (queuedColor == null) stopLitNodePolling() else startLitNodePolling()
        }
    }

    private fun extractChartSymbolFromNodes(root: AccessibilityNodeInfo): String? {
        val (sw, sh) = getScreenDimensions()
        val targetCenterY = (sh * 0.938f).toInt()
        val minY = (sh * 0.915f).toInt()
        val maxY = (sh * 0.955f).toInt()
        val maxX = (sw * 0.34f).toInt()

        var bestSym: String? = null
        var bestDist = Int.MAX_VALUE

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 420) {
            val node = stack.removeLast()
            visited++
            val raw = node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: node.contentDescription?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                node.getBoundsInScreen(rect)
                val cy = rect.centerY()
                if (cy in minY..maxY && rect.left in 0..maxX) {
                    val normalized = vision.normalizeTickerCandidate(raw)
                    if (normalized != null) {
                        val dist = abs(cy - targetCenterY)
                        if (dist < bestDist) {
                            bestDist = dist
                            bestSym = normalized
                        }
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }
        return bestSym
    }

    private fun startLitNodePolling() {
        mainHandler.removeCallbacks(litNodePollRunnable)
        mainHandler.postDelayed(litNodePollRunnable, 260L)
    }

    private fun stopLitNodePolling() {
        mainHandler.removeCallbacks(litNodePollRunnable)
    }

    /**
     * 点击悬浮颜色球：
     * - 再点一下当前已选中的颜色 -> 0ms 取消勾选并移出待办队列
     * - 点其他颜色 -> 0ms 瞬间点亮并异步写入队列
     */
    private fun handleColorButtonTap(color: MarkColor) {
        if (!AppStore.isWorkEnabled() || currentPage != PageState.CHART) return
        val seq = tapSeq.incrementAndGet()

        if (overlay.getLitColor() == color) {
            overlay.setLitColor(null)
            stopLitNodePolling()

            val knownSym = lastChartSymbol ?: cachedChartSymbol
            if (knownSym != null) {
                if (AppStore.removeSymbol(knownSym)) {
                    AppStore.log("取消勾选：$knownSym（已移出待办队列）")
                }
                return
            }

            chartExecutor.execute {
                if (tapSeq.get() != seq) return@execute
                val sym = resolveCurrentChartSymbolQuick().first
                if (sym != null && tapSeq.get() == seq) {
                    if (AppStore.removeSymbol(sym)) {
                        AppStore.log("取消勾选：$sym（已移出待办队列）")
                    }
                }
            }
            return
        }

        // 0ms 瞬间亮灯
        overlay.setLitColor(color)

        chartExecutor.execute {
            if (tapSeq.get() != seq) return@execute
            val (symbol, source) = resolveCurrentChartSymbolQuick()
            if (tapSeq.get() != seq || !AppStore.isWorkEnabled()) return@execute

            if (symbol != null) {
                lastChartSymbol = symbol
                cachedChartSymbol = symbol
                cachedChartAtMs = System.currentTimeMillis()
                AppStore.putSymbol(symbol, color)
                AppStore.log("图表识别($source)：$symbol -> ${color.label}")
                if (tapSeq.get() == seq && currentPage == PageState.CHART) {
                    overlay.setLitColor(color)
                    startLitNodePolling()
                }
            } else {
                AppStore.log("图表未读到品种代码，自动灭灯回退")
                if (tapSeq.get() == seq) {
                    overlay.setLitColor(null)
                }
            }
        }
    }

    private fun resolveCurrentChartSymbolQuick(): Pair<String?, String> {
        val root = rootInActiveWindow
        val nodeSym = root?.let { extractChartSymbolFromNodes(it) }
        if (nodeSym != null) {
            return nodeSym to "节点"
        }

        val bmp = captureScreenBitmap(maxRetries = 2)
        if (bmp != null) {
            try {
                val ocrSym = vision.readChartSymbolFromBitmap(bmp)
                if (ocrSym != null) {
                    return ocrSym to "OCR"
                }
            } finally {
                bmp.recycle()
            }
        }

        if (cachedChartSymbol != null && System.currentTimeMillis() - cachedChartAtMs <= 2500L) {
            return cachedChartSymbol to "缓存"
        }
        return null to "无"
    }

    // =========================================================================
    // 自选表极速批处理引擎（0截屏优先弹窗定位 + 独立线程零排队）
    // =========================================================================

    private fun startWatchlistBatch() {
        if (!AppStore.isWorkEnabled()) return
        if (!isBatchRunning.compareAndSet(false, true)) return
        abortBatchRequested.set(false)

        val initialTasks = AppStore.snapshotQueue()
        if (initialTasks.isEmpty()) {
            isBatchRunning.set(false)
            return
        }

        val displayList = initialTasks.entries.map { it.key to it.value }
        unfinishedInfoItems = displayList
        overlay.showInfoPanel(displayList)

        batchExecutor.execute {
            try {
                runWatchlistBatchLoop(initialTasks)
            } catch (e: Exception) {
                AppStore.log("批处理异常：${e.message}")
            } finally {
                isBatchRunning.set(false)
            }
        }
    }

    private fun scanWatchlistSymbolsFromNodes(): List<WatchlistRow> {
        val root = rootInActiveWindow ?: return emptyList()
        val (sw, sh) = getScreenDimensions()
        val leftMax = (sw * 0.220f).toInt()
        val topMin = (sh * 0.124f).toInt()
        val bottomMax = (sh * 0.944f).toInt()

        val rows = ArrayList<WatchlistRow>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        val rect = Rect()

        while (stack.isNotEmpty() && visited < 550) {
            val node = stack.removeLast()
            visited++
            val raw = node.text?.toString()?.trim()
            if (!raw.isNullOrEmpty()) {
                node.getBoundsInScreen(rect)
                if (rect.left in 0..leftMax &&
                    rect.top >= topMin &&
                    rect.bottom <= bottomMax &&
                    rect.height() in 14..(sh * 0.085f).toInt()
                ) {
                    val sym = vision.extractWatchlistSymbol(raw)
                    if (sym != null) {
                        val cx = if (rect.left >= (sw * 0.08f).toInt()) {
                            ((rect.left + minOf(rect.right, (sw * 0.40f).toInt())) / 2)
                                .coerceIn((sw * 0.14f).toInt(), (sw * 0.36f).toInt())
                        } else {
                            (sw * 0.24f).toInt()
                        }
                        rows.add(
                            WatchlistRow(
                                symbol = sym,
                                centerX = cx,
                                centerY = rect.centerY(),
                                topY = rect.top,
                                bottomY = rect.bottom,
                                hasAnyFlag = false
                            )
                        )
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                stack.add(c)
            }
        }

        rows.sortBy { it.centerY }
        val deduped = ArrayList<WatchlistRow>()
        for (r in rows) {
            if (deduped.isEmpty() || abs(r.centerY - deduped.last().centerY) > (sh * 0.015f)) {
                deduped.add(r)
            }
        }
        return deduped
    }

    /**
     * 核心极速突破：2ms 零截屏读取 TradingView 长按弹出的 7 色菜单坐标！
     * 避开 Android 系统 1 秒截屏频控，连续标记多个品种完全无需等待！
     */
    private fun findColorMenuFromAccessibilityWindows(): Pair<ColorMenuDots, String>? {
        val (sw, sh) = getScreenDimensions()
        val roots = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()
        val winRect = Rect()

        try {
            val winList = windows
            if (winList != null) {
                for (w in winList) {
                    val r = w.root ?: continue
                    if (r.packageName?.toString() != TV_PACKAGE) continue
                    w.getBoundsInScreen(winRect)
                    roots.add(r to Rect(winRect))
                }
            }
        } catch (_: Exception) {
        }

        val activeRoot = rootInActiveWindow
        if (activeRoot != null && activeRoot.packageName?.toString() == TV_PACKAGE) {
            activeRoot.getBoundsInScreen(winRect)
            roots.add(activeRoot to Rect(winRect))
        }

        for ((rootNode, wBounds) in roots) {
            var moveBottomNode: AccessibilityNodeInfo? = null
            var moveBottomRect: Rect? = null
            var addAlertRect: Rect? = null
            var hasMenuConfirmText = false
            val allNodes = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()

            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(rootNode)
            var visited = 0
            val rect = Rect()

            while (stack.isNotEmpty() && visited < 300) {
                val n = stack.removeLast()
                visited++
                n.getBoundsInScreen(rect)
                val copyRect = Rect(rect)
                allNodes.add(n to copyRect)

                val txt = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
                if (txt.isNotEmpty()) {
                    when {
                        txt == "移至底部" || txt.equals("Move to bottom", ignoreCase = true) -> {
                            moveBottomNode = n
                            moveBottomRect = copyRect
                            hasMenuConfirmText = true
                        }
                        txt == "添加警报" || txt.equals("Add alert", ignoreCase = true) -> {
                            addAlertRect = copyRect
                            hasMenuConfirmText = true
                        }
                        txt == "在上方添加板块" || txt == "移至顶部" || txt == "移除" -> {
                            hasMenuConfirmText = true
                        }
                    }
                }
                for (i in 0 until n.childCount) {
                    val c = n.getChild(i) ?: continue
                    stack.add(c)
                }
            }

            if (!hasMenuConfirmText || moveBottomRect == null || addAlertRect == null) continue
            if (addAlertRect.centerY() <= moveBottomRect.centerY() + 25) continue

            // 方式 A1：直接查找“移至底部”和“添加警报”之间横向排列的 7 个圆点节点
            val bandTop = moveBottomRect.bottom - 12
            val bandBottom = addAlertRect.top + 12
            val dotCandidates = allNodes.filter { (node, r) ->
                r.width() in 16..(sw * 0.14f).toInt() &&
                    r.height() in 16..(sw * 0.14f).toInt() &&
                    r.centerY() in bandTop..bandBottom &&
                    r.left >= 0 && r.right <= (sw * 0.65f).toInt() &&
                    node.text.isNullOrEmpty() &&
                    (node.isClickable || node.childCount == 0)
            }.sortedBy { it.second.centerX() }

            // 合并中心点几乎重合的嵌套节点
            val distinctDots = ArrayList<Rect>()
            for ((_, r) in dotCandidates) {
                if (distinctDots.isEmpty() || abs(r.centerX() - distinctDots.last().centerX()) > (sw * 0.03f).toInt()) {
                    distinctDots.add(r)
                }
            }

            if (distinctDots.size == 7) {
                val xs = IntArray(7) { distinctDots[it].centerX() }
                val avgY = distinctDots.map { it.centerY() }.average().roundToInt()
                if (avgY in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) {
                    return ColorMenuDots(xs, avgY) to "节点直取7点"
                }
            }

            // 方式 A2：用“移至底部”与“添加警报”的精确几何比例（0.412）和菜单窗宽直接推算 7 颗圆点
            val dotY = (moveBottomRect.centerY() + (addAlertRect.centerY() - moveBottomRect.centerY()) * 0.412f).roundToInt()
            if (dotY !in (sh * 0.12f).toInt()..(sh * 0.94f).toInt()) continue

            var menuLeft = (sw * 0.026f).toInt()
            var menuRight = (sw * 0.519f).toInt()
            if (wBounds.width() in (sw * 0.34f).toInt()..(sw * 0.68f).toInt()) {
                menuLeft = wBounds.left
                menuRight = wBounds.right
            } else {
                var cur = moveBottomNode?.parent
                var depth = 0
                val pRect = Rect()
                while (cur != null && depth < 6) {
                    cur.getBoundsInScreen(pRect)
                    if (pRect.width() in (sw * 0.36f).toInt()..(sw * 0.66f).toInt() && pRect.height() > (sh * 0.25f).toInt()) {
                        menuLeft = pRect.left
                        menuRight = pRect.right
                        break
                    }
                    cur = cur.parent
                    depth++
                }
            }

            val menuW = (menuRight - menuLeft).coerceAtLeast((sw * 0.40f).toInt())
            val xs = IntArray(7) { idx ->
                (menuLeft + menuW * MENU_DOT_X_FRACS[idx]).roundToInt().coerceIn(4, sw - 4)
            }
            return ColorMenuDots(xs, dotY) to "锚点零截屏"
        }
        return null
    }

    private fun runWatchlistBatchLoop(tasks: LinkedHashMap<String, MarkColor>) {
        // 切进列表后仅等 15ms 立即开干
        sleepSafe(15L)
        if (shouldAbortBatch()) return

        val sysLpMs = ViewConfiguration.getLongPressTimeout().toLong().coerceIn(400L, 900L)
        var preferredLongPressMs = if (learnedLongPressMs > 0L) {
            learnedLongPressMs
        } else {
            maxOf(sysLpMs + 110L, 580L)
        }
        AppStore.log("极速批处理启动(首按=${preferredLongPressMs}ms)｜待办=${tasks.entries.joinToString { "${it.key}:${it.value.label}" }}")

        val handledKeys = HashSet<String>()
        val menuFailedKeys = HashSet<String>()
        val failedOnThisVisitKeys = HashSet<String>()
        var cachedListName: String? = null

        fun getLazyListName(fallbackBmp: Bitmap? = null): String {
            cachedListName?.let { return it }
            val bmp = fallbackBmp ?: captureScreenBitmap(maxRetries = 2)
            val name = if (bmp != null) {
                try {
                    vision.readActiveWatchlistName(bmp)
                } finally {
                    if (fallbackBmp == null) bmp.recycle()
                }
            } else null
            cachedListName = name ?: "当前列表"
            return cachedListName!!
        }

        fun allTasksDone(): Boolean = handledKeys.containsAll(tasks.keys)
        fun hasActionableRemaining(): Boolean = (tasks.keys - handledKeys - failedOnThisVisitKeys).isNotEmpty()

        fun scanAndProcessCurrentScreen(
            prevNames: List<String>,
            prevFingerprint: IntArray?,
            isFirstScreen: Boolean
        ): Triple<List<String>, IntArray?, Boolean> {
            val remainingKeys = (tasks.keys - handledKeys)
            if (remainingKeys.isEmpty()) return Triple(emptyList(), null, false)

            val (_, screenH) = getScreenDimensions()
            val nodeRows = scanWatchlistSymbolsFromNodes()
            var bmpForScreen: Bitmap? = null
            var finalRows: List<WatchlistRow>
            val nodeScanReliable = nodeRows.size >= 4 ||
                (nodeRows.size >= 2 && nodeRows.last().bottomY >= (screenH * 0.65f).toInt())

            if (nodeScanReliable) {
                val hasMatch = nodeRows.any { vision.findMatchingTaskKey(it.symbol, remainingKeys) != null }
                if (!hasMatch) {
                    val names = nodeRows.map { it.symbol }
                    val unchanged = names.isNotEmpty() && names == prevNames
                    AppStore.log("节点快扫(${names.size}个/无命中)：${names.joinToString(",")}")
                    return Triple(names, null, unchanged)
                }
                val captured = captureScreenBitmap(maxRetries = 3)
                bmpForScreen = captured
                finalRows = if (captured != null) {
                    nodeRows.map { r ->
                        if (vision.findMatchingTaskKey(r.symbol, remainingKeys) != null) {
                            r.copy(hasAnyFlag = vision.hasAnyLeftEdgeFlag(captured, r.topY, r.bottomY))
                        } else r
                    }
                } else {
                    nodeRows
                }
            } else {
                var captured = captureScreenBitmap(maxRetries = 3)
                    ?: return Triple(emptyList(), null, false)
                finalRows = vision.scanWatchlistSymbols(captured)
                // 首屏如果刚切换动画还没完全落位导致 0 行，等 65ms 补扫一次
                if (isFirstScreen && finalRows.isEmpty() && !shouldAbortBatch()) {
                    captured.recycle()
                    sleepSafe(65L)
                    captured = captureScreenBitmap(maxRetries = 2)
                        ?: return Triple(emptyList(), null, false)
                    finalRows = vision.scanWatchlistSymbols(captured)
                }
                bmpForScreen = captured
            }

            val fp = bmpForScreen?.let { vision.computeListFingerprint(it) }
            val visibleNames = finalRows.map { it.symbol }
            val unchanged = (visibleNames.isNotEmpty() && visibleNames == prevNames) ||
                (fp != null && prevFingerprint != null && vision.isSameFrame(prevFingerprint, fp))

            bmpForScreen?.recycle()

            if (unchanged) {
                return Triple(visibleNames, fp, true)
            }

            AppStore.log("当前屏(${finalRows.size}个)：${visibleNames.joinToString(",")}")

            val matchedPairs = ArrayList<Pair<WatchlistRow, String>>()
            for (row in finalRows) {
                val matchedKey = vision.findMatchingTaskKey(row.symbol, remainingKeys) ?: continue
                if (matchedKey in failedOnThisVisitKeys) continue
                matchedPairs.add(row to matchedKey)
            }

            for ((idx, pair) in matchedPairs.withIndex()) {
                if (shouldAbortBatch()) break
                val (row, taskKey) = pair
                val targetColor = tasks[taskKey] ?: continue

                if (row.hasAnyFlag) {
                    AppStore.log("${row.symbol} 前方已有颜色标记，无视跳过")
                    handledKeys.add(taskKey)
                    continue
                }

                val hasMoreSameKeyOnScreen = matchedPairs.drop(idx + 1).any { it.second == taskKey }
                val isLastOperation = !hasMoreSameKeyOnScreen &&
                    (idx == matchedPairs.lastIndex) &&
                    (handledKeys.size + 1 >= tasks.size)

                val usedDur = longPressAndSelectColor(row, taskKey, targetColor, preferredLongPressMs, isLastOperation)
                if (usedDur > 0L) {
                    if (usedDur > preferredLongPressMs) {
                        preferredLongPressMs = usedDur
                        learnedLongPressMs = usedDur
                    } else if (learnedLongPressMs == 0L) {
                        learnedLongPressMs = usedDur
                    }
                    if (!hasMoreSameKeyOnScreen) {
                        handledKeys.add(taskKey)
                    }
                    menuFailedKeys.remove(taskKey)
                } else {
                    menuFailedKeys.add(taskKey)
                    failedOnThisVisitKeys.add(taskKey)
                }
            }

            return Triple(visibleNames, fp, false)
        }

        // 第1阶段：处理当前屏
        var (prevSymbols, prevFp, _) = scanAndProcessCurrentScreen(emptyList(), null, isFirstScreen = true)

        // 只要全部选完立即停手，绝不再继续往下拉
        if (!shouldAbortBatch() && !allTasksDone() && hasActionableRemaining()) {
            // 第2阶段：极速向下扫描
            var downScrolls = 0
            var sameDownCount = 0
            while (!shouldAbortBatch() && !allTasksDone() && hasActionableRemaining() && downScrolls < 45) {
                performControlledScroll(scrollDown = true)
                sleepSafe(45L)
                if (shouldAbortBatch()) break

                val (currSymbols, currFp, unchanged) = scanAndProcessCurrentScreen(prevSymbols, prevFp, isFirstScreen = false)
                if (allTasksDone() || !hasActionableRemaining()) break

                if (unchanged) {
                    sameDownCount++
                    if (sameDownCount >= 2 || currSymbols.size >= 4) {
                        AppStore.log("已达底部（下翻 $downScrolls 屏）")
                        break
                    }
                } else {
                    sameDownCount = 0
                    downScrolls++
                }
                prevSymbols = currSymbols
                prevFp = currFp
            }

            // 第3阶段：仍有未找到的品种，掉头向上扫描到顶部
            if (!shouldAbortBatch() && !allTasksDone() && hasActionableRemaining()) {
                val fastReturnSteps = (downScrolls - 1).coerceAtLeast(0)
                if (fastReturnSteps > 0) {
                    AppStore.log("极速回退 $fastReturnSteps 屏向上搜")
                    for (i in 0 until fastReturnSteps) {
                        if (shouldAbortBatch()) break
                        performFastScroll(scrollDown = false)
                        sleepSafe(55L)
                    }
                    sleepSafe(70L)
                } else {
                    performControlledScroll(scrollDown = false)
                    sleepSafe(45L)
                }

                var upScrolls = 0
                var sameUpCount = 0
                prevSymbols = emptyList()
                prevFp = null

                while (!shouldAbortBatch() && !allTasksDone() && hasActionableRemaining() && upScrolls < 45) {
                    val (currSymbols, currFp, unchanged) = scanAndProcessCurrentScreen(prevSymbols, prevFp, isFirstScreen = false)
                    if (allTasksDone() || !hasActionableRemaining()) break

                    if (unchanged) {
                        sameUpCount++
                        if (sameUpCount >= 2 || currSymbols.size >= 4) {
                            AppStore.log("已达顶部（上翻 $upScrolls 屏）")
                            break
                        }
                    } else {
                        sameUpCount = 0
                        upScrolls++
                    }
                    prevSymbols = currSymbols
                    prevFp = currFp

                    if (!allTasksDone() && hasActionableRemaining() && !shouldAbortBatch()) {
                        performControlledScroll(scrollDown = false)
                        sleepSafe(45L)
                    }
                }
            }
        }

        if (shouldAbortBatch()) {
            AppStore.log("批处理被中止，未完成队列已保留")
            return
        }

        var hasUnfinished = false
        for ((sym, color) in tasks) {
            if (sym in handledKeys) {
                AppStore.removeSymbol(sym)
            } else if (sym in menuFailedKeys) {
                hasUnfinished = true
                val listName = getLazyListName()
                val msg = "$listName｜未找到 $sym 的颜色菜单，待办已保留。"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                sendMissedNotification(msg)
            } else {
                hasUnfinished = true
                val listName = getLazyListName()
                val msg = "待添加 $sym 到 ${color.label}色列表，但是该品种在 $listName 列表内没有找到"
                AppStore.log(msg)
                AppStore.addMissedRecord(msg)
                sendMissedNotification(msg)
                AppStore.removeSymbol(sym)
            }
        }

        batchDoneForCurrentWatchlistVisit = true
        if (!hasUnfinished) {
            AppStore.log("全部完活（${handledKeys.size}/${tasks.size}）")
            unfinishedInfoItems = null
            overlay.hideInfoPanel()
            overlay.showDoneBanner(previewMode = false)
        } else {
            AppStore.log("存在未完成项（成功 ${handledKeys.size}/${tasks.size}），右侧清单保留直至手动关闭")
        }
    }

    private fun longPressAndSelectColor(
        row: WatchlistRow,
        taskKey: String,
        color: MarkColor,
        firstDurationMs: Long,
        isLastOperation: Boolean
    ): Long {
        val (_, sh) = getScreenDimensions()
        val rowMidY = (row.centerY + (sh * 0.006f).toInt()).coerceAtMost((sh * 0.935f).toInt())
        val secondDurationMs = maxOf(firstDurationMs + 240L, 840L)
        val attempts = listOf(
            Triple(row.centerX, rowMidY, firstDurationMs),
            Triple(row.centerX + 22, row.centerY, secondDurationMs)
        )

        for ((idx, attempt) in attempts.withIndex()) {
            if (shouldAbortBatch()) return -1L
            val (lx, ly, dur) = attempt
            AppStore.log("长按 ${row.symbol} 第${idx + 1}次 ($lx,$ly) ${dur}ms")

            if (!dispatchLongPress(lx.toFloat(), ly.toFloat(), dur)) {
                AppStore.log("长按手势取消，重试")
                sleepSafe(80L)
                continue
            }

            // 1) 优先 0 截屏检测无障碍弹窗窗口（2ms 极速，完全不受系统 1 秒截屏限制！）
            sleepSafe(35L)
            var found: Pair<ColorMenuDots, String>? = findColorMenuFromAccessibilityWindows()
            if (found == null) {
                sleepSafe(75L)
                found = findColorMenuFromAccessibilityWindows()
            }

            // 2) 若无障碍未暴露弹窗节点，立刻无缝降级截屏扫描 7 色栏
            if (found == null) {
                val retryDelays = longArrayOf(0L, 95L, 140L)
                for (d in retryDelays) {
                    if (d > 0L) sleepSafe(d)
                    // 每次等完顺带再扫一次零截屏节点
                    found = findColorMenuFromAccessibilityWindows()
                    if (found != null) break

                    val menuBmp = captureScreenBitmap(maxRetries = 2)
                    if (menuBmp != null) {
                        try {
                            val dots = vision.findColorMenu(menuBmp)
                            if (dots != null) {
                                found = dots to "截屏像素"
                            }
                        } finally {
                            menuBmp.recycle()
                        }
                    }
                    if (found != null) break
                }
            }

            if (found != null) {
                val (menuDots, method) = found
                val (tapX, tapY) = menuDots.pointFor(color)
                AppStore.log("命中7色栏($method) -> 点${color.label}($tapX,$tapY)")
                dispatchTap(tapX.toFloat(), tapY.toFloat())
                // 点击颜色点后弹窗同步自动关闭，仅短停 55ms 立即进入下一个品种
                sleepSafe(if (isLastOperation) 20L else 55L)
                return dur
            } else {
                AppStore.log("第${idx + 1}次长按 ${row.symbol} 未找到7色栏")
            }
        }
        return -1L
    }

    private fun captureScreenBitmap(maxRetries: Int): Bitmap? {
        for (attempt in 0 until maxRetries) {
            val elapsed = System.currentTimeMillis() - lastScreenshotAtMs
            if (elapsed < 85L) {
                sleepSafe(85L - elapsed)
            }

            val latch = CountDownLatch(1)
            val resultRef = AtomicReference<Bitmap?>(null)
            val errRef = AtomicInteger(0)

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        lastScreenshotAtMs = System.currentTimeMillis()
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            if (hw != null) {
                                try {
                                    resultRef.set(hw.copy(Bitmap.Config.ARGB_8888, false))
                                } finally {
                                    hw.recycle()
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            try {
                                screenshot.hardwareBuffer.close()
                            } catch (_: Exception) {
                            }
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        errRef.set(errorCode)
                        latch.countDown()
                    }
                }
            )

            latch.await(2, TimeUnit.SECONDS)
            val bmp = resultRef.get()
            if (bmp != null) return bmp

            val err = errRef.get()
            if (err == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                sleepSafe(110L)
            } else {
                AppStore.log("截屏失败 err=$err（第${attempt + 1}次）")
                sleepSafe(110L)
            }
        }
        return null
    }

    private fun dispatchLongPress(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 35L)
        return dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun performControlledScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.44f
        val y1 = if (scrollDown) sh * 0.83f else sh * 0.19f
        val y2 = if (scrollDown) sh * 0.19f else sh * 0.83f

        val dragPath = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke1 = GestureDescription.StrokeDescription(dragPath, 0L, 145L, true)
        val latch = CountDownLatch(1)

        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke1).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    val holdPath = Path().apply {
                        moveTo(x, y2)
                        lineTo(x, y2)
                    }
                    val stroke2 = stroke1.continueStroke(holdPath, 0L, 40L, false)
                    dispatchGesture(
                        GestureDescription.Builder().addStroke(stroke2).build(),
                        object : GestureResultCallback() {
                            override fun onCompleted(g: GestureDescription?) { latch.countDown() }
                            override fun onCancelled(g: GestureDescription?) { latch.countDown() }
                        },
                        null
                    )
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        latch.await(2, TimeUnit.SECONDS)
    }

    private fun performFastScroll(scrollDown: Boolean) {
        val (sw, sh) = getScreenDimensions()
        val x = sw * 0.44f
        val y1 = if (scrollDown) sh * 0.83f else sh * 0.19f
        val y2 = if (scrollDown) sh * 0.19f else sh * 0.83f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 110L)
        dispatchGestureSync(GestureDescription.Builder().addStroke(stroke).build())
    }

    private fun dispatchGestureSync(gesture: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok.set(true)
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    ok.set(false)
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(2, TimeUnit.SECONDS)
        return ok.get()
    }

    private fun shouldAbortBatch(): Boolean {
        return !AppStore.isWorkEnabled() || abortBatchRequested.get() || currentPage == PageState.OTHER
    }

    private fun sleepSafe(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(
            NOTIF_CHANNEL_ID,
            "未找到品种提醒",
            NotificationManager.IMPORTANCE_HIGH
        )
        nm.createNotificationChannel(ch)
    }

    private fun sendMissedNotification(message: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TV颜色标记提醒")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(notifIdCounter.incrementAndGet(), notif)
        } catch (_: Exception) {
        }
    }
}
