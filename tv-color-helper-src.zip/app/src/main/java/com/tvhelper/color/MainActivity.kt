package com.tvhelper.color

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * 清晰 4 页多标签主界面（v7.3.0）：
 * - 页 0【总览】：三大独立功能总控开关 + 权限/品种大全入口 + 实时待办池/未知品种/未找到提醒 + 折叠日志
 * - 页 1【标色】：功能一（图表7色标色）全部设置（圆球外观/退出方式/完活提示音/高级速度策略）
 * - 页 2【快切】：功能二（探索栏列表快切）全部设置（18项列表管理/黑白弹窗样式与预览）
 * - 页 3【切图】：功能三（滚轮三角切图 ▲/▼）全部设置（圆角预览/显示模式/大小明暗不透明度间距/位置重置）
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val KEY_ACTIVE_TAB = "active_tab_idx"
    }

    private var activeTabIdx = 0
    private val tabPages = ArrayList<ScrollView>(4)
    private val tabIndicators = ArrayList<View>(4)
    private val tabLabels = ArrayList<TextView>(4)
    private val tabStatusDots = ArrayList<View>(4)

    // 顶部栏状态
    private lateinit var headerStatusTv: TextView

    // 总览页三功能快捷开关卡片
    private lateinit var hubColorSwitchTv: TextView
    private lateinit var hubJumpSwitchTv: TextView
    private lateinit var hubWheelSwitchTv: TextView

    // 三大功能专属页内的大开关
    private lateinit var colorBigToggleBtn: Button
    private lateinit var exploreJumpToggleBtn: Button
    private lateinit var manageJumpEntriesBtn: Button
    private lateinit var wheelPadToggleBtn: Button

    // 实时待办 / 未知品种 / 未找到提醒 / 日志
    private lateinit var queueListContainer: LinearLayout
    private lateinit var sessionMarkedLabel: TextView
    private lateinit var unknownCard: LinearLayout
    private lateinit var unknownListContainer: LinearLayout
    private lateinit var missedListContainer: LinearLayout
    private lateinit var requeueBtn: Button
    private lateinit var logBodyWrap: LinearLayout
    private lateinit var logFoldBtn: TextView
    private lateinit var logText: TextView
    private lateinit var logExpandBtn: TextView
    private var logPanelOpen = false
    private var logExpanded = false

    // 实时预览区
    private lateinit var previewUnselRow: LinearLayout
    private lateinit var previewSelRow: LinearLayout
    private lateinit var jumpPreviewBox: LinearLayout
    private val jumpPreviewCells = ArrayList<TextView>()
    private lateinit var wheelPreviewWrap: LinearLayout

    private val storeListener: () -> Unit = {
        runOnUiThread { refreshAllStatusAndLists() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        activeTabIdx = savedInstanceState?.getInt(KEY_ACTIVE_TAB, 0)?.coerceIn(0, 3) ?: 0
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildRootShell())
        switchTab(activeTabIdx)
        requestNotificationPermissionIfNeeded()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_ACTIVE_TAB, activeTabIdx)
    }

    override fun onResume() {
        super.onResume()
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(true)
        AppStore.addListener(storeListener)
        WorkTileService.requestTileSync(this)
        ExploreJumpTileService.requestTileSync(this)
        WheelPadTileService.requestTileSync(this)
        refreshAllStatusAndLists()
        updateButtonPreview()
        updateJumpPreview()
        updateWheelPadPreview()
    }

    override fun onPause() {
        super.onPause()
        AppStore.removeListener(storeListener)
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(false)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    // ==================== 主壳结构：固定顶栏 + 4页内容容器 + 固定底栏 ====================

    private fun buildRootShell(): LinearLayout {
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        // 1) 简洁顶部标题状态栏
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#161B22"))
            setPadding(dp(16), dp(14), dp(14), dp(12))
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = "TV 交易助手"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            paint.isFakeBoldText = true
        })
        headerStatusTv = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(2), 0, 0)
        }
        titleCol.addView(headerStatusTv)
        topBar.addView(titleCol)

        topBar.addView(makeHeaderPill("品种大全", "#8957E5") {
            startActivity(Intent(this, CatalogActivity::class.java))
        })
        topBar.addView(makeHeaderPill("无障碍", "#1F6FEB") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }.apply {
            (layoutParams as? LinearLayout.LayoutParams)?.marginStart = dp(6)
        })
        shell.addView(topBar)
        shell.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#21262D"))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        })

        // 2) 中间 4 页内容 FrameLayout（独立滚动位置互不干扰）
        val contentHost = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        tabPages.clear()
        val p0 = wrapScrollPage(buildOverviewPage())
        val p1 = wrapScrollPage(buildColorTagPage())
        val p2 = wrapScrollPage(buildQuickJumpPage())
        val p3 = wrapScrollPage(buildWheelPadPage())
        tabPages.addAll(listOf(p0, p1, p2, p3))
        for (p in tabPages) {
            contentHost.addView(p, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        shell.addView(contentHost)

        // 3) 底部 4 页固定导航栏
        shell.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#30363D"))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        })
        shell.addView(buildBottomNavBar())

        return shell
    }

    private fun wrapScrollPage(content: LinearLayout): ScrollView {
        return ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Color.parseColor("#0D1117"))
            addView(content)
        }
    }

    private fun buildBottomNavBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#161B22"))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(58)
            )
        }

        val items = listOf(
            "总览" to false,
            "标色" to true,
            "快切" to true,
            "切图" to true
        )
        tabIndicators.clear()
        tabLabels.clear()
        tabStatusDots.clear()

        for ((idx, pair) in items.withIndex()) {
            val (label, hasDot) = pair
            val tabCell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { switchTab(idx) }
            }

            val topIndicator = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(28), dp(3))
            }
            tabIndicators.add(topIndicator)
            tabCell.addView(topIndicator)

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    0,
                    1f
                )
            }
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(6), dp(6)).apply {
                    marginEnd = dp(5)
                }
                visibility = if (hasDot) View.VISIBLE else View.GONE
            }
            tabStatusDots.add(dot)
            row.addView(dot)

            val tv = TextView(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            }
            tabLabels.add(tv)
            row.addView(tv)

            tabCell.addView(row)
            bar.addView(tabCell)
        }
        return bar
    }

    private fun switchTab(idx: Int) {
        activeTabIdx = idx.coerceIn(0, tabPages.lastIndex)
        for (i in tabPages.indices) {
            val selected = (i == activeTabIdx)
            tabPages[i].visibility = if (selected) View.VISIBLE else View.GONE
            tabIndicators[i].background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(if (selected) Color.WHITE else Color.TRANSPARENT)
            }
            tabLabels[i].setTextColor(if (selected) Color.WHITE else Color.parseColor("#8B949E"))
            tabLabels[i].paint.isFakeBoldText = selected
        }
    }

    // ==================== 页面 0：总览（三大独立功能开关 + 实时队列 + 日志） ====================

    private fun buildOverviewPage(): LinearLayout {
        val page = makePageRoot()

        // 1) 三大独立功能总控台（一屏全览、各自独立开关）
        val hubCard = makeCard(topMarginDp = 0)
        hubCard.addView(makeCardTitle("三大独立功能开关（各自独立 · 互不干扰）"))
        hubCard.addView(TextView(this).apply {
            text = "三个功能在手机下拉控制中心均设有专属快捷按钮（首次需点控制中心右上角编辑拖出：TV标记开关 / 列表快切开关 / 滚轮切图开关）。"
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(2), 0, dp(10))
        })

        val (row1, sw1) = makeFeatureHubRow(
            title = "① 图表 7 色自动标色",
            desc = "图表点选圆球 · 回自选表高速批量标色",
            onToggle = {
                val next = !AppStore.isWorkEnabled()
                AppStore.setWorkEnabled(this, next, source = "APP总览开关")
                checkAccessibilityToast(next)
            },
            onSettings = { switchTab(1) }
        )
        hubColorSwitchTv = sw1
        hubCard.addView(row1)

        val (row2, sw2) = makeFeatureHubRow(
            title = "② 探索栏 · 列表快切直达",
            desc = "点底部“探索”弹出 18 项直达首品种图表",
            onToggle = {
                val next = !AppStore.isExploreJumpEnabled()
                AppStore.setExploreJumpEnabled(this, next, source = "APP总览开关")
                checkAccessibilityToast(next)
            },
            onSettings = { switchTab(2) }
        )
        hubJumpSwitchTv = sw2
        hubCard.addView(row2)

        val (row3, sw3) = makeFeatureHubRow(
            title = "③ 滚轮上下切图 ▲ / ▼",
            desc = "进图表默认显示 · 点左上角/状态栏同步显隐",
            onToggle = {
                val next = !AppStore.isWheelPadEnabled()
                AppStore.setWheelPadEnabled(this, next, source = "APP总览开关")
                checkAccessibilityToast(next)
            },
            onSettings = { switchTab(3) }
        )
        hubWheelSwitchTv = sw3
        hubCard.addView(row3)
        page.addView(hubCard)

        // 2) 实时待添加品种池
        val queueCard = makeCard()
        queueCard.addView(makeSectionHeader("待添加品种池（点单条可改色/改列表）", "清空池") {
            AppStore.clearQueue()
        })
        queueListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        queueCard.addView(queueListContainer)

        val sessRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        sessionMarkedLabel = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        sessRow.addView(sessionMarkedLabel)
        sessRow.addView(makeMiniButton("清空已标记忆") {
            AppStore.clearSessionMarked()
            Toast.makeText(this, "已清空本轮已标色记忆", Toast.LENGTH_SHORT).show()
        })
        queueCard.addView(sessRow)
        page.addView(queueCard)

        // 3) 不在《品种大全》的品种（自动观察位置 · 单独一键写入）
        unknownCard = makeCard().apply { visibility = View.GONE }
        unknownCard.addView(makeSectionHeader("不在《品种大全》的品种（一键写入）", "清空") {
            AppStore.clearUnknownCandidates()
        })
        unknownCard.addView(TextView(this).apply {
            text = "图表点选时已自动放行入池；程序进入列表页观察到它相邻品种后，点右侧绿色按钮即可一键写入《品种大全》准确位置。"
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, dp(4), 0, dp(6))
        })
        unknownListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        unknownCard.addView(unknownListContainer)
        page.addView(unknownCard)

        // 4) APP 消息 / 未找到提醒
        val missedCard = makeCard()
        missedCard.addView(makeSectionHeader("未找到提醒 / 失败重试", "清空") {
            AppStore.clearMissedRecords()
        })
        requeueBtn = Button(this).apply {
            text = "一键将未找到品种加入待添加池"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(40)
            ).apply { topMargin = dp(6) }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#238636"))
            }
            setOnClickListener {
                val added = AppStore.requeueAllUnadded()
                if (added > 0) {
                    if (!AppStore.isWorkEnabled()) {
                        AppStore.setWorkEnabled(this@MainActivity, true, source = "一键重试自动开启")
                    }
                    Toast.makeText(this@MainActivity, "已将 $added 个未添加品种重新加入待添加池", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "当前没有可重试的未添加品种", Toast.LENGTH_SHORT).show()
                }
            }
        }
        missedCard.addView(requeueBtn)
        missedListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        missedCard.addView(missedListContainer)
        page.addView(missedCard)

        // 5) 运行排错日志（默认折叠，头部可直接一键复制）
        val logCard = makeCard()
        val logHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        logFoldBtn = TextView(this).apply {
            text = "▶ 运行排错日志"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                logPanelOpen = !logPanelOpen
                logBodyWrap.visibility = if (logPanelOpen) View.VISIBLE else View.GONE
                text = if (logPanelOpen) "▼ 运行排错日志" else "▶ 运行排错日志"
                if (logPanelOpen) refreshAllStatusAndLists()
            }
        }
        logHeader.addView(logFoldBtn)
        logHeader.addView(makeMiniButton("复制日志") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TV日志", AppStore.getLogsText()))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        })
        logHeader.addView(makeMiniButton("清空") {
            AppStore.clearLogs()
        })
        logCard.addView(logHeader)

        logBodyWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(6), 0, 0)
        }
        logExpandBtn = makeMiniButton("展开全部") {
            logExpanded = !logExpanded
            refreshAllStatusAndLists()
        }
        logBodyWrap.addView(logExpandBtn)
        logText = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(6), 0, 0)
            setTextIsSelectable(true)
        }
        logBodyWrap.addView(logText)
        logCard.addView(logBodyWrap)
        page.addView(logCard)

        return page
    }

    private fun makeFeatureHubRow(
        title: String,
        desc: String,
        onToggle: () -> Unit,
        onSettings: () -> Unit
    ): Pair<LinearLayout, TextView> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(8), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
            background = GradientDrawable().apply {
                cornerRadius = dp(9).toFloat()
                setColor(Color.parseColor("#0D1117"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            setOnClickListener { onSettings() }
        }

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        info.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            paint.isFakeBoldText = true
        })
        info.addView(TextView(this).apply {
            text = desc
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(2), 0, 0)
        })
        row.addView(info)

        val swBtn = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            paint.isFakeBoldText = true
            gravity = Gravity.CENTER
            minWidth = dp(62)
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setOnClickListener { onToggle() }
        }
        row.addView(swBtn)

        row.addView(TextView(this).apply {
            text = "›"
            setTextColor(Color.parseColor("#6E7681"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setPadding(dp(8), 0, dp(2), 0)
        })

        return row to swBtn
    }

    // ==================== 页面 1：标色（功能一全套设置） ====================

    private fun buildColorTagPage(): LinearLayout {
        val page = makePageRoot()

        // 1) 功能一独立大开关
        colorBigToggleBtn = Button(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54)
            )
            setOnClickListener {
                val next = !AppStore.isWorkEnabled()
                AppStore.setWorkEnabled(this@MainActivity, next, source = "APP标色开关")
                checkAccessibilityToast(next)
            }
        }
        page.addView(colorBigToggleBtn)

        // 2) 7 色圆球显示与外观设置
        val ballCard = makeCard()
        ballCard.addView(makeCardTitle("图表颜色圆球设置（支持全7色自由搭配）"))

        val colorPickLabel = TextView(this).apply {
            text = "选择图表上要显示的颜色球（可单选或多选）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(4), 0, dp(6))
        }
        ballCard.addView(colorPickLabel)

        val enabledSet = AppStore.getEnabledColors().toSet()
        val colorCheckRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val colorCheckRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        MarkColor.values().forEachIndexed { idx, markColor ->
            val cb = CheckBox(this).apply {
                text = markColor.label
                setTextColor(Color.rgb(markColor.baseR, markColor.baseG, markColor.baseB))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                paint.isFakeBoldText = true
                isChecked = markColor in enabledSet
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { buttonView, isChecked ->
                    val ok = AppStore.setColorEnabled(markColor, isChecked)
                    if (!ok) {
                        buttonView.isChecked = true
                        Toast.makeText(this@MainActivity, "至少保留 1 种颜色球", Toast.LENGTH_SHORT).show()
                    } else {
                        updateButtonPreview()
                        TvAccessibilityService.instance?.refreshButtonSettings()
                    }
                }
            }
            if (idx < 4) colorCheckRow1.addView(cb) else colorCheckRow2.addView(cb)
        }
        colorCheckRow2.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        })
        ballCard.addView(colorCheckRow1)
        ballCard.addView(colorCheckRow2)

        val previewScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#0A0D12"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
        }
        previewUnselRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        previewSelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        previewBox.addView(previewUnselRow)
        previewBox.addView(previewSelRow)
        previewScroll.addView(previewBox)
        ballCard.addView(previewScroll)

        ballCard.addView(makeSlider(
            labelPrefix = "圆球直径（默认 60）",
            unit = "dp",
            minVal = 30,
            maxVal = 80,
            initVal = AppStore.getButtonDiameterDp()
        ) { v ->
            AppStore.setButtonDiameterDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(makeSlider(
            labelPrefix = "圆球间距（默认 12）",
            unit = "dp",
            minVal = 5,
            maxVal = 60,
            initVal = AppStore.getButtonGapDp()
        ) { v ->
            AppStore.setButtonGapDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(makeSlider(
            labelPrefix = "选中前整体明暗度（默认 60）",
            unit = "%",
            minVal = 10,
            maxVal = 100,
            initVal = AppStore.getUnselectedBrightness()
        ) { v ->
            AppStore.setUnselectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(makeSlider(
            labelPrefix = "选中后整体明暗度（默认 100）",
            unit = "%",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getSelectedBrightness()
        ) { v ->
            AppStore.setSelectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(CheckBox(this).apply {
            text = "选中后显示白色外圈"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isSelectedWhiteRingEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setSelectedWhiteRingEnabled(checked)
                updateButtonPreview()
                TvAccessibilityService.instance?.refreshButtonSettings()
            }
        })

        ballCard.addView(CheckBox(this).apply {
            text = "圆球角落显示待办数量角标（黑白小数字）"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isBallBadgeEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setBallBadgeEnabled(checked)
                TvAccessibilityService.instance?.refreshButtonSettings()
            }
        })

        ballCard.addView(TextView(this).apply {
            text = "图表页隐藏圆球并关闭本服务的方式（可多选，不关系统无障碍）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(2))
        })
        ballCard.addView(makeOptionCheckBox("双击圆球区域", AppStore.isBallExitDoubleTap()) {
            AppStore.setBallExitDoubleTap(it)
        })
        ballCard.addView(makeOptionCheckBox("从圆球区域右滑", AppStore.isBallExitSwipeRight()) {
            AppStore.setBallExitSwipeRight(it)
        })
        ballCard.addView(makeOptionCheckBox("从圆球区域上滑 / 下滑 / 左滑 / 右滑均可", AppStore.isBallExitSwipeAny()) {
            AppStore.setBallExitSwipeAny(it)
        })

        val ballBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        ballBtnRow.addView(makeActionButton("重置默认位置", "#21262D") {
            AppStore.resetOverlayPosition()
            TvAccessibilityService.instance?.refreshButtonSettings(resetPosition = true)
            Toast.makeText(this, "圆球已恢复左下角默认位置", Toast.LENGTH_SHORT).show()
        })
        ballBtnRow.addView(makeActionButton("恢复默认样式", "#30363D") {
            AppStore.resetBallAppearanceDefaults()
            TvAccessibilityService.instance?.refreshButtonSettings()
            Toast.makeText(this, "已恢复圆球默认外观（60dp/12dp/60%/100%）", Toast.LENGTH_SHORT).show()
            recreate()
        })
        ballCard.addView(ballBtnRow)
        page.addView(ballCard)

        // 3) 完成提示与提示音设置
        val doneCard = makeCard()
        doneCard.addView(makeSectionHeader("完成提示设置（纯黑白 · 3秒消失）", "预览/调位置") {
            val svc = TvAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "请先在系统无障碍中开启“TV颜色标记”", Toast.LENGTH_SHORT).show()
            } else {
                svc.previewDoneBanner()
                SoundPlayer.playDoneSoundIfEnabled()
                Toast.makeText(this, "长按文字可拖动位置，短按或点空白关闭", Toast.LENGTH_SHORT).show()
            }
        })

        doneCard.addView(TextView(this).apply {
            text = "显示文字内容："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })

        val doneInput = EditText(this).apply {
            setText(AppStore.getDoneText())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6E7681"))
            hint = "例如：完活、已完成"
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#0D1117"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    AppStore.setDoneText(s?.toString().orEmpty())
                }
            })
        }
        doneCard.addView(doneInput)

        doneCard.addView(makeSlider(
            labelPrefix = "文字大小",
            unit = "sp",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getDoneSizeSp()
        ) { v -> AppStore.setDoneSizeSp(v) })

        doneCard.addView(makeSlider(
            labelPrefix = "黑白灰度",
            unit = "%",
            minVal = 15,
            maxVal = 100,
            initVal = AppStore.getDoneGrayPct()
        ) { v -> AppStore.setDoneGrayPct(v) })

        doneCard.addView(CheckBox(this).apply {
            text = "跳出完活时播放提示音（无震动）"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isDoneSoundEnabled()
            setOnCheckedChangeListener { _, checked -> AppStore.setDoneSoundEnabled(checked) }
        })

        val soundHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        soundHeader.addView(TextView(this).apply {
            text = "选择提示音（共${SoundPreset.values().size}种）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        soundHeader.addView(makeMiniButton("试听") {
            val preset = SoundPreset.fromId(AppStore.getDoneSoundId())
            SoundPlayer.playPreset(preset, AppStore.getDoneSoundVolume().coerceAtLeast(15))
        })
        doneCard.addView(soundHeader)

        val presets = SoundPreset.values()
        val presetNames = presets.map { it.displayName }
        val spinner = Spinner(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#21262D"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        spinner.adapter = makeDarkSpinnerAdapter(presetNames)
        val initSoundIdx = presets.indexOfFirst { it.id == AppStore.getDoneSoundId() }.coerceAtLeast(0)
        spinner.setSelection(initSoundIdx, false)

        var spinnerReady = false
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosen = presets[position]
                AppStore.setDoneSoundId(chosen.id)
                if (spinnerReady) {
                    SoundPlayer.playPreset(chosen, AppStore.getDoneSoundVolume().coerceAtLeast(15))
                }
                spinnerReady = true
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        doneCard.addView(spinner)

        doneCard.addView(makeSlider(
            labelPrefix = "提示音音量",
            unit = "%",
            minVal = 0,
            maxVal = 100,
            initVal = AppStore.getDoneSoundVolume()
        ) { v -> AppStore.setDoneSoundVolume(v) })

        doneCard.addView(makeMiniButton("重置完成提示位置（居中）") {
            AppStore.resetDonePosition()
            Toast.makeText(this, "完成提示已恢复居中", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(6), 0, 0) })
        page.addView(doneCard)

        // 4) 高级速度与策略微调（默认折叠）
        val advCard = makeCard()
        var advExpanded = false
        val advBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(6), 0, 0)
        }
        val advHeaderTv = TextView(this).apply {
            text = "▶ 高级速度与策略微调（点击展开）"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            paint.isFakeBoldText = true
            setOnClickListener {
                advExpanded = !advExpanded
                advBody.visibility = if (advExpanded) View.VISIBLE else View.GONE
                text = if (advExpanded) "▼ 高级速度与策略微调（点击收起）" else "▶ 高级速度与策略微调（点击展开）"
            }
        }
        advCard.addView(advHeaderTv)

        advBody.addView(makeOptionCheckBox("跨列表优先用左上角 ≡ 抽屉直选（2次点击秒切，推荐）", AppStore.isDrawerSwitchPreferred()) {
            AppStore.setDrawerSwitchPreferred(it)
        })
        advBody.addView(makeOptionCheckBox("非颜色列表已有其它颜色时也覆盖改色（注：颜色列表内始终自动同色跳过/异色重标）", AppStore.isOverwriteDifferentColorFlag()) {
            AppStore.setOverwriteDifferentColorFlag(it)
        })
        advBody.addView(makeOptionCheckBox("跳过查小旗极速模式（0截屏省400ms · 内置本轮同色防误取消）", AppStore.isSkipFlagCheckTurbo()) {
            AppStore.setSkipFlagCheckTurbo(it)
        })
        advBody.addView(makeSlider(
            labelPrefix = "长按触发时长（默认 730）",
            unit = "ms",
            minVal = 550,
            maxVal = 950,
            initVal = AppStore.getCustomLongPressMs().toInt()
        ) { v -> AppStore.setCustomLongPressMs(v.toLong()) })

        advBody.addView(makeSlider(
            labelPrefix = "同屏连按冷却（默认 300）",
            unit = "ms",
            minVal = 200,
            maxVal = 650,
            initVal = AppStore.getPostTapCooldownMs().toInt()
        ) { v -> AppStore.setPostTapCooldownMs(v.toLong()) })

        advBody.addView(makeSlider(
            labelPrefix = "列表翻屏耗时（默认 125）",
            unit = "ms",
            minVal = 80,
            maxVal = 240,
            initVal = AppStore.getScrollDurationMs().toInt()
        ) { v -> AppStore.setScrollDurationMs(v.toLong()) })

        advBody.addView(makeMiniButton("恢复默认速度与策略参数") {
            AppStore.resetSpeedDefaults()
            Toast.makeText(this, "已恢复默认参数", Toast.LENGTH_SHORT).show()
            recreate()
        }.apply { setPadding(0, dp(6), 0, 0) })

        advCard.addView(advBody)
        page.addView(advCard)

        return page
    }

    // ==================== 页面 2：快切（功能二全套设置） ====================

    private fun buildQuickJumpPage(): LinearLayout {
        val page = makePageRoot()

        exploreJumpToggleBtn = Button(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16.5f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54)
            )
            setOnClickListener {
                val next = !AppStore.isExploreJumpEnabled()
                AppStore.setExploreJumpEnabled(this@MainActivity, next, source = "APP列表快切开关")
                checkAccessibilityToast(next)
            }
        }
        page.addView(exploreJumpToggleBtn)

        // 列表项管理卡片
        val manageCard = makeCard()
        manageCard.addView(makeCardTitle("列表项与目标定位管理"))
        manageCard.addView(TextView(this).apply {
            text = "点击 TV 最底部“探索”按钮立刻弹出单页 3 列列表选择页（长按“探索”约 0.5 秒可透传进原探索页）。默认内置第一/二/三颜色及全部 15 个分类入口。"
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, dp(2), 0, dp(10))
        })
        manageJumpEntriesBtn = Button(this).apply {
            text = "管理列表项（排序 / 新增 / 删除 / 改名 / 目标定位）"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(46)
            )
            background = GradientDrawable().apply {
                cornerRadius = dp(9).toFloat()
                setColor(Color.parseColor("#1F6FEB"))
            }
            setOnClickListener {
                startActivity(Intent(this@MainActivity, QuickJumpManageActivity::class.java))
            }
        }
        manageCard.addView(manageJumpEntriesBtn)
        page.addView(manageCard)

        // 弹窗黑白外观设置卡片
        val styleCard = makeCard()
        styleCard.addView(makeCardTitle("弹窗黑白外观自定义"))

        jumpPreviewBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(12), dp(10), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(6)
                bottomMargin = dp(8)
            }
        }
        jumpPreviewCells.clear()
        for ((idx, sampleName) in listOf("第一颜色", "第二颜色", "第三颜色").withIndex()) {
            val cell = TextView(this).apply {
                text = sampleName
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(dp(4), dp(8), dp(4), dp(8))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx > 0) marginStart = dp(8)
                }
            }
            jumpPreviewCells.add(cell)
            jumpPreviewBox.addView(cell)
        }
        styleCard.addView(jumpPreviewBox)

        styleCard.addView(makeSlider(
            labelPrefix = "列表弹窗字体大小",
            unit = "sp",
            minVal = 12,
            maxVal = 32,
            initVal = AppStore.getJumpFontSizeSp()
        ) { v ->
            AppStore.setJumpFontSizeSp(v)
            updateJumpPreview()
        })

        styleCard.addView(TextView(this).apply {
            text = "列表弹窗字体样式"
            setTextColor(Color.parseColor("#C9D1D9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })
        val styleOptions = JumpFontStyle.values()
        val styleSpinner = Spinner(this).apply {
            adapter = makeDarkSpinnerAdapter(styleOptions.map { it.label })
            setSelection(styleOptions.indexOf(AppStore.getJumpFontStyle()).coerceAtLeast(0), false)
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#21262D"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    AppStore.setJumpFontStyle(styleOptions[position])
                    updateJumpPreview()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        styleCard.addView(styleSpinner)

        styleCard.addView(makeSlider(
            labelPrefix = "字体灰度（0%黑 ↔ 100%白）",
            unit = "%",
            minVal = 0,
            maxVal = 100,
            initVal = AppStore.getJumpFontGrayPct()
        ) { v ->
            AppStore.setJumpFontGrayPct(v)
            updateJumpPreview()
        })

        styleCard.addView(makeSlider(
            labelPrefix = "字体不透明度",
            unit = "%",
            minVal = 10,
            maxVal = 100,
            initVal = AppStore.getJumpFontOpacityPct()
        ) { v ->
            AppStore.setJumpFontOpacityPct(v)
            updateJumpPreview()
        })

        styleCard.addView(makeSlider(
            labelPrefix = "背景不透明度",
            unit = "%",
            minVal = 0,
            maxVal = 100,
            initVal = AppStore.getJumpBgOpacityPct()
        ) { v ->
            AppStore.setJumpBgOpacityPct(v)
            updateJumpPreview()
        })

        val jumpBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        jumpBtnRow.addView(makeActionButton("预览全页列表弹窗", "#21262D") {
            val svc = TvAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "请先开启系统无障碍权限再预览", Toast.LENGTH_SHORT).show()
            } else {
                svc.previewExploreJumpPicker()
            }
        })
        jumpBtnRow.addView(makeActionButton("恢复默认样式", "#30363D") {
            AppStore.resetJumpStyleDefaults()
            Toast.makeText(this, "已恢复列表快切默认黑白样式", Toast.LENGTH_SHORT).show()
            recreate()
        })
        styleCard.addView(jumpBtnRow)
        page.addView(styleCard)

        return page
    }

    // ==================== 页面 3：切图（功能三全套设置） ====================

    private fun buildWheelPadPage(): LinearLayout {
        val page = makePageRoot()

        wheelPadToggleBtn = Button(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16.5f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54)
            )
            setOnClickListener {
                val next = !AppStore.isWheelPadEnabled()
                AppStore.setWheelPadEnabled(this@MainActivity, next, source = "APP滚轮切图开关")
                checkAccessibilityToast(next)
            }
        }
        page.addView(wheelPadToggleBtn)

        val wheelCard = makeCard()
        wheelCard.addView(makeCardTitle("圆角三角切图按钮 ▲ / ▼ 外观与操控"))
        wheelCard.addView(TextView(this).apply {
            text = "进入图表页默认自动显示；点 ▲ 慢划切前一个品种，点 ▼ 慢划切后一个，整个正方形区域均可点动；长按按钮可自由拖动位置。点击图表左上角、本页开关或下拉状态栏“滚轮切图开关”，三端开关自动实时同步。"
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, dp(2), 0, dp(8))
        })

        // 实时可点预览
        wheelPreviewWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#0A0D12"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }
        wheelCard.addView(wheelPreviewWrap)

        // 显示模式
        wheelCard.addView(TextView(this).apply {
            text = "显示按钮选择（可双显或仅显示其中一个）"
            setTextColor(Color.parseColor("#C9D1D9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(4), 0, dp(4))
        })
        val wheelModes = WheelPadDisplayMode.values()
        val wheelModeSpinner = Spinner(this).apply {
            adapter = makeDarkSpinnerAdapter(wheelModes.map { it.label })
            setSelection(wheelModes.indexOf(AppStore.getWheelPadDisplayMode()).coerceAtLeast(0), false)
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#21262D"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    AppStore.setWheelPadDisplayMode(wheelModes[position])
                    updateWheelPadPreview()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        wheelCard.addView(wheelModeSpinner)

        // 大小 20..100 默认 60
        wheelCard.addView(makeSlider(
            labelPrefix = "三角形按钮大小（默认 60）",
            unit = "dp",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getWheelPadSizeDp()
        ) { v ->
            AppStore.setWheelPadSizeDp(v)
            updateWheelPadPreview()
        })

        // 明暗度 默认 50
        wheelCard.addView(makeSlider(
            labelPrefix = "按钮明暗度（0%黑 ↔ 100%白 · 默认 50）",
            unit = "%",
            minVal = 0,
            maxVal = 100,
            initVal = AppStore.getWheelPadBrightnessPct()
        ) { v ->
            AppStore.setWheelPadBrightnessPct(v)
            updateWheelPadPreview()
        })

        // 不透明度 默认 40
        wheelCard.addView(makeSlider(
            labelPrefix = "按钮不透明度（默认 40）",
            unit = "%",
            minVal = 10,
            maxVal = 100,
            initVal = AppStore.getWheelPadOpacityPct()
        ) { v ->
            AppStore.setWheelPadOpacityPct(v)
            updateWheelPadPreview()
        })

        // 上下间距 默认 20
        wheelCard.addView(makeSlider(
            labelPrefix = "▲ 与 ▼ 上下相隔距离（默认 20）",
            unit = "dp",
            minVal = 4,
            maxVal = 140,
            initVal = AppStore.getWheelPadGapDp()
        ) { v ->
            AppStore.setWheelPadGapDp(v)
            updateWheelPadPreview()
        })

        // 单步慢划幅度微调
        wheelCard.addView(makeSlider(
            labelPrefix = "单步慢划幅度（默认28｜划不动调大/连跳调小）",
            unit = "‰",
            minVal = 15,
            maxVal = 52,
            initVal = AppStore.getWheelPadStepPermille()
        ) { v -> AppStore.setWheelPadStepPermille(v) })

        wheelCard.addView(makeOptionCheckBox(
            "允许点图表左上角白框区域一键显隐 ▲/▼（长按 0.5 秒透传原搜索）",
            AppStore.isWheelTopLeftTriggerEnabled()
        ) {
            AppStore.setWheelTopLeftTriggerEnabled(it)
        })

        val wheelBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        wheelBtnRow.addView(makeActionButton("重置左中部", "#21262D") {
            AppStore.saveWheelPadCenterFrac(0.08f, 0.627f)
            TvAccessibilityService.instance?.refreshWheelPadSettings()
            Toast.makeText(this, "已重置到左中部（二三幅图交界线）", Toast.LENGTH_SHORT).show()
        })
        wheelBtnRow.addView(makeActionButton("移至右中部", "#21262D") {
            AppStore.saveWheelPadCenterFrac(0.92f, 0.627f)
            TvAccessibilityService.instance?.refreshWheelPadSettings()
            Toast.makeText(this, "已移至图表右侧中部（二三幅图交界线）", Toast.LENGTH_SHORT).show()
        })
        wheelBtnRow.addView(makeActionButton("恢复默认", "#30363D") {
            AppStore.resetWheelPadDefaults(placeRightSide = false)
            Toast.makeText(this, "已恢复默认（60dp / 明暗50% / 不透明40% / 间距20dp）", Toast.LENGTH_SHORT).show()
            recreate()
        })
        wheelCard.addView(wheelBtnRow)
        page.addView(wheelCard)

        return page
    }

    // ==================== 实时状态同步与预览刷新 ====================

    private fun checkAccessibilityToast(turnedOn: Boolean) {
        if (turnedOn && TvAccessibilityService.instance == null) {
            Toast.makeText(
                this,
                "开关已开启，请先点右上角“无障碍”授权“TV颜色标记”",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun stylePillSwitch(tv: TextView, enabled: Boolean) {
        tv.text = if (enabled) "已开启" else "已关闭"
        tv.setTextColor(if (enabled) Color.WHITE else Color.parseColor("#8B949E"))
        tv.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Color.parseColor(if (enabled) "#238636" else "#21262D"))
            setStroke(dp(1), Color.parseColor(if (enabled) "#3FB950" else "#30363D"))
        }
    }

    private fun refreshAllStatusAndLists() {
        val accReady = TvAccessibilityService.instance != null
        val workOn = AppStore.isWorkEnabled()
        val jumpOn = AppStore.isExploreJumpEnabled()
        val wheelOn = AppStore.isWheelPadEnabled()

        headerStatusTv.text = if (accReady) {
            "v7.3.0 · 无障碍运行中"
        } else {
            "v7.3.0 · 无障碍未开启（请先点右上角授权）"
        }
        headerStatusTv.setTextColor(
            Color.parseColor(if (accReady) "#3FB950" else "#F85149")
        )

        // 同步底部导航状态小圆点 + 待办提示
        val dotStates = listOf(false, workOn, jumpOn, wheelOn)
        for (i in 1..3) {
            tabStatusDots[i].background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(if (dotStates[i]) "#3FB950" else "#484F58"))
            }
        }
        val pendCnt = AppStore.pendingCount()
        tabLabels[0].text = if (pendCnt > 0) "总览($pendCnt)" else "总览"

        // 同步总览页三功能开关
        if (::hubColorSwitchTv.isInitialized) stylePillSwitch(hubColorSwitchTv, workOn)
        if (::hubJumpSwitchTv.isInitialized) stylePillSwitch(hubJumpSwitchTv, jumpOn)
        if (::hubWheelSwitchTv.isInitialized) stylePillSwitch(hubWheelSwitchTv, wheelOn)

        // 同步三大功能专属页大开关
        if (::colorBigToggleBtn.isInitialized) {
            colorBigToggleBtn.text = if (workOn) "● 标色服务已开启（点此暂停）" else "○ 标色服务已暂停（点此开启）"
            colorBigToggleBtn.background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor(if (workOn) "#238636" else "#21262D"))
                setStroke(dp(1), Color.parseColor(if (workOn) "#3FB950" else "#484F58"))
            }
        }
        if (::exploreJumpToggleBtn.isInitialized) {
            exploreJumpToggleBtn.text = if (jumpOn) "● 探索列表快切已开启（点此关闭）" else "○ 探索列表快切已关闭（点此开启）"
            exploreJumpToggleBtn.background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor(if (jumpOn) "#238636" else "#21262D"))
                setStroke(dp(1), Color.parseColor(if (jumpOn) "#3FB950" else "#484F58"))
            }
        }
        if (::manageJumpEntriesBtn.isInitialized) {
            val cnt = AppStore.getQuickJumpEntries().size
            manageJumpEntriesBtn.text = "管理列表项（当前 ${cnt} 项 · 排序/增删/改名/定位）"
        }
        if (::wheelPadToggleBtn.isInitialized) {
            wheelPadToggleBtn.text = if (wheelOn) "● 滚轮三角切图已开启（点此隐藏）" else "○ 滚轮三角切图已隐藏（点此显示）"
            wheelPadToggleBtn.background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor(if (wheelOn) "#238636" else "#21262D"))
                setStroke(dp(1), Color.parseColor(if (wheelOn) "#3FB950" else "#484F58"))
            }
        }

        refreshQueueRowsUi()
        refreshUnknownCandidatesUi()
        refreshMissedRowsUi()

        if (::logText.isInitialized && logPanelOpen) {
            val fullLogs = AppStore.getLogsText()
            val lines = fullLogs.lines()
            if (!logExpanded && lines.size > 16) {
                logText.text = lines.takeLast(16).joinToString("
")
                logExpandBtn.text = "展开全部(${lines.size}条)"
            } else {
                logText.text = fullLogs.ifEmpty { "暂无日志" }
                logExpandBtn.text = if (lines.size > 16) "收起日志" else "展开全部"
            }
        }
    }

    private fun updateButtonPreview() {
        if (!::previewUnselRow.isInitialized) return
        previewUnselRow.removeAllViews()
        previewSelRow.removeAllViews()

        val colors = AppStore.getEnabledColors()
        val rawDia = AppStore.getButtonDiameterDp()
        val previewDiaPx = dp(rawDia.coerceAtMost(50))
        val previewGapPx = dp((AppStore.getButtonGapDp() * 0.7f).toInt().coerceIn(4, 24))

        fun addRowLabel(row: LinearLayout, text: String) {
            row.addView(TextView(this).apply {
                this.text = text
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                minWidth = dp(52)
            })
        }

        addRowLabel(previewUnselRow, "选中前：")
        addRowLabel(previewSelRow, "选中后：")

        for ((idx, mc) in colors.withIndex()) {
            val uDot = View(this).apply {
                background = OverlayController.makeCircleDrawable(this@MainActivity, mc, selected = false)
                layoutParams = LinearLayout.LayoutParams(previewDiaPx, previewDiaPx).apply {
                    if (idx > 0) marginStart = previewGapPx
                }
            }
            val sDot = View(this).apply {
                background = OverlayController.makeCircleDrawable(this@MainActivity, mc, selected = true)
                layoutParams = LinearLayout.LayoutParams(previewDiaPx, previewDiaPx).apply {
                    if (idx > 0) marginStart = previewGapPx
                }
            }
            previewUnselRow.addView(uDot)
            previewSelRow.addView(sDot)
        }
    }

    private fun updateJumpPreview() {
        if (!::jumpPreviewBox.isInitialized) return
        val (textColor, cardBgColor, borderColor) = QuickJumpCatalog.computeMonochromeColors()
        val fontSizeSp = AppStore.getJumpFontSizeSp().toFloat()
        val tf = QuickJumpCatalog.resolveTypeface(AppStore.getJumpFontStyle())
        val bgAlpha = (AppStore.getJumpBgOpacityPct() * 255 / 100).coerceIn(0, 255)
        val cellBgColor = Color.argb((bgAlpha * 0.72f).toInt(), 26, 26, 26)

        jumpPreviewBox.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(cardBgColor)
            setStroke(dp(1), borderColor)
        }
        val sampleNames = AppStore.getQuickJumpEntries().take(3).map { it.displayName }
        for ((idx, cell) in jumpPreviewCells.withIndex()) {
            if (idx in sampleNames.indices) cell.text = sampleNames[idx]
            cell.setTextColor(textColor)
            cell.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSp)
            cell.typeface = tf
            cell.background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(cellBgColor)
                setStroke(dp(1), borderColor)
            }
        }
    }

    private fun updateWheelPadPreview() {
        if (!::wheelPreviewWrap.isInitialized) return
        wheelPreviewWrap.removeAllViews()
        val mode = AppStore.getWheelPadDisplayMode()
        val sz = dp(AppStore.getWheelPadSizeDp().coerceAtMost(76))
        val gap = dp(AppStore.getWheelPadGapDp().coerceAtMost(64))
        val bright = AppStore.getWheelPadBrightnessPct()
        val opacity = AppStore.getWheelPadOpacityPct()

        wheelPreviewWrap.addView(TextView(this).apply {
            text = "实时预览（点圆角三角形可体验“瞬间变正方形”反馈）"
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, 0, 0, dp(8))
        })

        if (mode == WheelPadDisplayMode.BOTH || mode == WheelPadDisplayMode.UP_ONLY) {
            val u = WheelTriangleView(this, isUp = true).apply {
                applyAppearance(bright, opacity)
                layoutParams = LinearLayout.LayoutParams(sz, sz)
                setOnClickListener { triggerSquareFeedback() }
            }
            wheelPreviewWrap.addView(u)
        }

        if (mode == WheelPadDisplayMode.BOTH) {
            wheelPreviewWrap.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#30363D"))
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(1)).apply {
                    topMargin = gap / 2
                    bottomMargin = (gap - gap / 2).coerceAtLeast(0)
                }
            })
        }

        if (mode == WheelPadDisplayMode.BOTH || mode == WheelPadDisplayMode.DOWN_ONLY) {
            val d = WheelTriangleView(this, isUp = false).apply {
                applyAppearance(bright, opacity)
                layoutParams = LinearLayout.LayoutParams(sz, sz)
                setOnClickListener { triggerSquareFeedback() }
            }
            wheelPreviewWrap.addView(d)
        }
    }

    // ==================== 待办池 / 未知品种 / 未找到提醒行构建 ====================

    private fun refreshQueueRowsUi() {
        if (!::queueListContainer.isInitialized) return
        val taskList = AppStore.snapshotTasks()
        val sessCnt = AppStore.sessionMarkedCount()
        sessionMarkedLabel.text = "本轮已标色记忆：$sessCnt 个（图表圆球左上角显示 ✓色）"
        queueListContainer.removeAllViews()
        if (taskList.isEmpty()) {
            queueListContainer.addView(TextView(this).apply {
                text = "暂无待添加品种（《品种大全》共 ${CatalogRepository.getWatchlists().size} 列表 / ${CatalogRepository.totalInstrumentCount()} 品种）"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            })
            return
        }

        for ((idx, task) in taskList.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(6), dp(6), dp(6))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (idx > 0) topMargin = dp(5) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(7).toFloat()
                    setColor(Color.parseColor("#0D1117"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
            }

            val lockedWl = if (task.preferredWatchlistId.isNotEmpty()) {
                CatalogRepository.getWatchlistById(task.preferredWatchlistId)
            } else null
            val locs = CatalogRepository.findLocations(task.symbol)
            val wlName = lockedWl?.name ?: locs.map { it.watchlistName }.distinct().joinToString("/").ifBlank { "自动" }
            val inst = CatalogRepository.findInstrumentInfo(task.symbol, task.preferredWatchlistId.ifBlank { null })
            val cnPart = if (inst != null && inst.cnName.isNotBlank()) " ${inst.cnName}" else ""

            val infoCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            infoCol.addView(TextView(this).apply {
                text = "${task.symbol}$cnPart"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                paint.isFakeBoldText = true
            })
            infoCol.addView(TextView(this).apply {
                text = "目标：$wlName"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            })
            row.addView(infoCol)

            row.addView(TextView(this).apply {
                text = "${task.color.label}色"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                paint.isFakeBoldText = true
                setPadding(dp(8), dp(4), dp(8), dp(4))
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.rgb(task.color.baseR, task.color.baseG, task.color.baseB))
                }
                setOnClickListener { showPickTaskColorDialog(task) }
            })

            row.addView(TextView(this).apply {
                text = "改列表"
                setTextColor(Color.parseColor("#58A6FF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(dp(8), dp(4), dp(6), dp(4))
                setOnClickListener { showPickTaskWatchlistDialog(task) }
            })

            row.addView(TextView(this).apply {
                text = "×"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(6), dp(2), dp(4), dp(2))
                setOnClickListener { AppStore.removeTaskByKey(task.key) }
            })

            queueListContainer.addView(row)
        }
    }

    private fun showPickTaskColorDialog(task: PendingTask) {
        val colors = MarkColor.values()
        val labels = colors.map { "${it.label}色列表" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("修改 ${task.symbol} 的目标颜色")
            .setItems(labels) { _, which -> AppStore.updateTaskColor(task.key, colors[which]) }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showPickTaskWatchlistDialog(task: PendingTask) {
        val wls = CatalogRepository.getWatchlists()
        val labels = (listOf("自动匹配所属列表") + wls.map { it.name }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("指定 ${task.symbol} 的目标列表")
            .setItems(labels) { _, which ->
                val targetId = if (which == 0) "" else wls[which - 1].id
                AppStore.updateTaskWatchlist(task.key, targetId)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun refreshMissedRowsUi() {
        if (!::missedListContainer.isInitialized) return
        val retryCount = AppStore.countRetryableUnadded()
        requeueBtn.visibility = View.VISIBLE
        requeueBtn.text = if (retryCount > 0) {
            "一键将未找到的 $retryCount 个品种加入待添加池"
        } else {
            "一键将未找到品种加入待添加池（当前 0 个）"
        }
        requeueBtn.background = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Color.parseColor(if (retryCount > 0) "#1F6FEB" else "#30363D"))
        }

        val items = AppStore.getUnaddedItems()
        missedListContainer.removeAllViews()
        if (items.isEmpty()) {
            missedListContainer.addView(TextView(this).apply {
                text = "暂无未找到提醒"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            })
            return
        }

        for ((idx, item) in items.take(25).withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(6), dp(6), dp(6))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (idx > 0) topMargin = dp(5) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(7).toFloat()
                    setColor(Color.parseColor("#0D1117"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
            }

            row.addView(TextView(this).apply {
                text = "[${item.timestamp}] ${item.message}"
                setTextColor(Color.parseColor("#FFA657"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            if (item.symbol.isNotEmpty() && item.color != null) {
                row.addView(TextView(this).apply {
                    text = "重试"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    paint.isFakeBoldText = true
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(5).toFloat()
                        setColor(Color.parseColor("#1F6FEB"))
                    }
                    setOnClickListener {
                        if (AppStore.requeueSingleUnadded(idx)) {
                            if (!AppStore.isWorkEnabled()) {
                                AppStore.setWorkEnabled(this@MainActivity, true, source = "单条重试自动开启")
                            }
                            Toast.makeText(this@MainActivity, "已将 ${item.symbol} 重新加入待添加池", Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }

            row.addView(TextView(this).apply {
                text = "×"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(8), dp(2), dp(4), dp(2))
                setOnClickListener { AppStore.removeSingleUnadded(idx) }
            })
            missedListContainer.addView(row)
        }
    }

    private fun refreshUnknownCandidatesUi() {
        if (!::unknownCard.isInitialized) return
        val list = AppStore.getUnknownCandidates()
        unknownListContainer.removeAllViews()
        if (list.isEmpty()) {
            unknownCard.visibility = View.GONE
            return
        }
        unknownCard.visibility = View.VISIBLE

        for ((idx, item) in list.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(7), dp(6), dp(7))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (idx > 0) topMargin = dp(6) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(7).toFloat()
                    setColor(Color.parseColor("#0D1117"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
            }

            val posDesc = when {
                item.watchlistName.isNotEmpty() && item.prevSymbol.isNotEmpty() ->
                    "所属：${item.watchlistName}（在 ${item.prevSymbol} 后）"
                item.watchlistName.isNotEmpty() && item.nextSymbol.isNotEmpty() ->
                    "所属：${item.watchlistName}（在 ${item.nextSymbol} 前）"
                item.watchlistName.isNotEmpty() ->
                    "所属：${item.watchlistName}（列表末尾）"
                else ->
                    "切到所属列表后自动定位，或点右侧手动选列表写入"
            }

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            textCol.addView(TextView(this).apply {
                text = item.symbol
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                paint.isFakeBoldText = true
            })
            textCol.addView(TextView(this).apply {
                text = posDesc
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            })
            row.addView(textCol)

            row.addView(TextView(this).apply {
                text = "一键写入"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                paint.isFakeBoldText = true
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.parseColor("#238636"))
                }
                setOnClickListener {
                    if (item.watchlistId.isNotEmpty() && CatalogRepository.getWatchlistById(item.watchlistId) != null) {
                        val res = CatalogRepository.insertObservedInstrument(
                            symbol = item.symbol,
                            watchlistId = item.watchlistId,
                            prevSymbol = item.prevSymbol,
                            nextSymbol = item.nextSymbol
                        )
                        AppStore.removeUnknownCandidate(item.symbol)
                        Toast.makeText(this@MainActivity, res, Toast.LENGTH_LONG).show()
                    } else {
                        showPickWatchlistAndInsert(item.symbol)
                    }
                }
            })

            row.addView(TextView(this).apply {
                text = "×"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(10), dp(4), dp(4), dp(4))
                setOnClickListener { AppStore.removeUnknownCandidate(item.symbol) }
            })
            unknownListContainer.addView(row)
        }
    }

    private fun showPickWatchlistAndInsert(symbol: String) {
        val wls = CatalogRepository.getWatchlists()
        if (wls.isEmpty()) return
        val names = wls.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("将 $symbol 写入哪个列表？")
            .setItems(names) { _, which ->
                val wl = wls[which]
                val res = CatalogRepository.insertObservedInstrument(symbol, wl.id)
                AppStore.removeUnknownCandidate(symbol)
                Toast.makeText(this, res, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // ==================== 通用 UI 控件工具 ====================

    private fun makePageRoot(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(26))
        }
    }

    private fun makeHeaderPill(label: String, hexBg: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            paint.isFakeBoldText = true
            setPadding(dp(10), dp(6), dp(10), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            background = GradientDrawable().apply {
                cornerRadius = dp(7).toFloat()
                setColor(Color.parseColor(hexBg))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeDarkSpinnerAdapter(labels: List<String>): ArrayAdapter<String> {
        return object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getView(position, convertView, parent) as TextView
                tv.setTextColor(Color.WHITE)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                tv.setPadding(dp(10), dp(8), dp(10), dp(8))
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getDropDownView(position, convertView, parent) as TextView
                tv.setTextColor(Color.WHITE)
                tv.setBackgroundColor(Color.parseColor("#161B22"))
                tv.setPadding(dp(14), dp(12), dp(14), dp(12))
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                return tv
            }
        }
    }

    private fun makeOptionCheckBox(label: String, checked: Boolean, onChanged: (Boolean) -> Unit): CheckBox {
        return CheckBox(this).apply {
            text = label
            setTextColor(Color.parseColor("#E6EDF3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            isChecked = checked
            setOnCheckedChangeListener { _, isChecked -> onChanged(isChecked) }
        }
    }

    private fun makeSlider(
        labelPrefix: String,
        unit: String,
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        onChanged: (Int) -> Unit
    ): LinearLayout {
        return makeCustomLabelSlider(
            minVal = minVal,
            maxVal = maxVal,
            initVal = initVal,
            labelFormatter = { v -> "$labelPrefix：$v $unit" },
            onChanged = onChanged
        )
    }

    private fun makeCustomLabelSlider(
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        labelFormatter: (Int) -> String,
        onChanged: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(2))
        }
        val clampedInit = initVal.coerceIn(minVal, maxVal)
        val label = TextView(this).apply {
            text = labelFormatter(clampedInit)
            setTextColor(Color.parseColor("#C9D1D9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        }
        val sb = SeekBar(this).apply {
            max = (maxVal - minVal).coerceAtLeast(1)
            progress = clampedInit - minVal
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = minVal + progress
                    label.text = labelFormatter(v)
                    if (fromUser) onChanged(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(label)
        box.addView(sb)
        return box
    }

    private fun makeCard(topMarginDp: Int = 12): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(topMarginDp) }
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
        }
    }

    private fun makeCardTitle(title: String): TextView {
        return TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
            setPadding(0, 0, 0, dp(4))
        }
    }

    private fun makeSectionHeader(title: String, actionLabel: String, onAction: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                paint.isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(makeMiniButton(actionLabel, onAction))
        }
    }

    private fun makeActionButton(label: String, hexBg: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(6)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(hexBg))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeMiniButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(dp(8), dp(2), dp(2), dp(2))
            setOnClickListener { onClick() }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }
}
