package com.tvhelper.color

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var bigToggleBtn: Button
    private lateinit var statusText: TextView
    private lateinit var queueListContainer: LinearLayout
    private lateinit var sessionMarkedLabel: TextView
    private lateinit var unknownCard: LinearLayout
    private lateinit var unknownListContainer: LinearLayout
    private lateinit var missedListContainer: LinearLayout
    private lateinit var requeueBtn: Button
    private lateinit var logText: TextView
    private lateinit var logExpandBtn: TextView
    private var logExpanded = false

    private lateinit var previewUnselRow: LinearLayout
    private lateinit var previewSelRow: LinearLayout

    private val storeListener: () -> Unit = {
        runOnUiThread { refreshStatusAndLogs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildLayout())
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(true)
        AppStore.addListener(storeListener)
        WorkTileService.requestTileSync(this)
        refreshStatusAndLogs()
        updateButtonPreview()
    }

    override fun onPause() {
        super.onPause()
        AppStore.removeListener(storeListener)
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(false)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun buildLayout(): ScrollView {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(36))
        }

        // ==================== 最顶部：大大的服务总开关（与下拉状态栏严格同步） ====================
        bigToggleBtn = Button(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(66)
            )
            setOnClickListener {
                val next = !AppStore.isWorkEnabled()
                AppStore.setWorkEnabled(this@MainActivity, next, source = "APP大开关")
                refreshBigToggleUi()
                if (next && TvAccessibilityService.instance == null) {
                    Toast.makeText(
                        this@MainActivity,
                        "已开启总开关，请确认系统无障碍已授权“TV颜色标记”",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
        root.addView(bigToggleBtn)

        statusText = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(10))
        }
        root.addView(statusText)

        val topBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topBtns.addView(makeActionButton("无障碍权限（开一次）", "#1F6FEB") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        topBtns.addView(makeActionButton("《品种大全》管理", "#8957E5") {
            startActivity(Intent(this, CatalogActivity::class.java))
        })
        root.addView(topBtns)

        // ==================== 实时待添加品种池（单条可改色/改列表/删除） ====================
        val queueCard = makeCard()
        queueCard.addView(makeSectionHeader("待添加品种池（点击单条可改色/改列表）", "清空池") {
            AppStore.clearQueue()
        })
        queueListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        queueCard.addView(queueListContainer)

        val sessRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        sessionMarkedLabel = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        sessRow.addView(sessionMarkedLabel)
        sessRow.addView(makeMiniButton("清空已标记忆") {
            AppStore.clearSessionMarked()
            Toast.makeText(this, "已清空本轮已标色记忆", Toast.LENGTH_SHORT).show()
        })
        queueCard.addView(sessRow)
        root.addView(queueCard)

        // ==================== 不在《品种大全》的品种（自动观察位置 · 单独一键写入） ====================
        unknownCard = makeCard()
        val uHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        uHeader.addView(TextView(this).apply {
            text = "不在《品种大全》的新品种（可一键写入）"
            setTextColor(Color.parseColor("#79C0FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        uHeader.addView(makeMiniButton("清空") {
            AppStore.clearUnknownCandidates()
        })
        unknownCard.addView(uHeader)
        unknownListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        unknownCard.addView(unknownListContainer)
        root.addView(unknownCard)

        // ==================== APP 消息与未找到提醒（含一键重新加入待添加池） ====================
        val missedCard = makeCard()
        missedCard.addView(makeSectionHeader("APP 消息 / 未找到提醒", "清空消息") {
            AppStore.clearMissedRecords()
        })
        requeueBtn = Button(this).apply {
            text = "一键将未找到品种加入待添加池"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            paint.isFakeBoldText = true
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(40)
            ).apply { topMargin = dp(8) }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#1F6FEB"))
            }
            setOnClickListener {
                val count = AppStore.requeueAllUnadded()
                if (count > 0) {
                    if (!AppStore.isWorkEnabled()) {
                        AppStore.setWorkEnabled(this@MainActivity, true, source = "一键重试自动开启")
                    }
                    Toast.makeText(
                        this@MainActivity,
                        "已将 $count 个未找到品种重新加入待添加池，切回TV列表页自动添加",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(this@MainActivity, "当前没有未找到品种", Toast.LENGTH_SHORT).show()
                }
            }
        }
        missedCard.addView(requeueBtn)
        missedListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        missedCard.addView(missedListContainer)
        root.addView(missedCard)

        // ==================== 卡片1：7色圆球显示与外观设置 ====================
        val ballCard = makeCard()
        ballCard.addView(makeCardTitle("图表颜色圆球设置（支持全7色自由搭配）"))

        ballCard.addView(TextView(this).apply {
            text = "选择图表上要显示的颜色球（可单选或多选）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })

        val enabledSet = AppStore.getEnabledColors().toSet()
        val colorRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val colorRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        MarkColor.values().forEachIndexed { idx, markColor ->
            val cb = CheckBox(this).apply {
                text = markColor.label
                setTextColor(Color.rgb(markColor.baseR, markColor.baseG, markColor.baseB))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                paint.isFakeBoldText = true
                isChecked = markColor in enabledSet
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { buttonView, isChecked ->
                    val ok = AppStore.setColorEnabled(markColor, isChecked)
                    if (!ok) {
                        buttonView.isChecked = true
                        Toast.makeText(this@MainActivity, "至少保留 1 种颜色球", Toast.LENGTH_SHORT).show()
                    } else {
                        updateButtonPreview()
                        TvAccessibilityService.instance?.refreshButtonSettings()
                    }
                }
            }
            if (idx < 4) colorRow1.addView(cb) else colorRow2.addView(cb)
        }
        ballCard.addView(colorRow1)
        ballCard.addView(colorRow2)

        val previewScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.BLACK)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8); bottomMargin = dp(6) }
        }
        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        previewUnselRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        previewSelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        previewBox.addView(previewUnselRow)
        previewBox.addView(previewSelRow)
        previewScroll.addView(previewBox)
        ballCard.addView(previewScroll)

        ballCard.addView(makeSlider(
            labelPrefix = "圆球直径",
            unit = "dp",
            minVal = 30,
            maxVal = 80,
            initVal = AppStore.getButtonDiameterDp()
        ) { v ->
            AppStore.setButtonDiameterDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(makeSlider(
            labelPrefix = "圆球间距",
            unit = "dp",
            minVal = 5,
            maxVal = 60,
            initVal = AppStore.getButtonGapDp()
        ) { v ->
            AppStore.setButtonGapDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(makeSlider(
            labelPrefix = "选中前整体明暗度",
            unit = "%",
            minVal = 10,
            maxVal = 100,
            initVal = AppStore.getUnselectedBrightness()
        ) { v ->
            AppStore.setUnselectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(makeSlider(
            labelPrefix = "选中后整体明暗度",
            unit = "%",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getSelectedBrightness()
        ) { v ->
            AppStore.setSelectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        ballCard.addView(CheckBox(this).apply {
            text = "选中后显示白色外圈"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isSelectedWhiteRingEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setSelectedWhiteRingEnabled(checked)
                updateButtonPreview()
                TvAccessibilityService.instance?.refreshButtonSettings()
            }
        })

        ballCard.addView(CheckBox(this).apply {
            text = "圆球角落显示待办数量角标（黑白小数字）"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isBallBadgeEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setBallBadgeEnabled(checked)
                TvAccessibilityService.instance?.refreshButtonSettings()
            }
        })

        // 图表页隐藏圆球并关闭服务方式（可多选，不关无障碍）
        ballCard.addView(TextView(this).apply {
            text = "图表页隐藏圆球并关闭本服务的方式（可多选，不关系统无障碍）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(2))
        })
        ballCard.addView(makeOptionCheckBox("双击圆球区域", AppStore.isBallExitDoubleTap()) {
            AppStore.setBallExitDoubleTap(it)
        })
        ballCard.addView(makeOptionCheckBox("从圆球区域右滑", AppStore.isBallExitSwipeRight()) {
            AppStore.setBallExitSwipeRight(it)
        })
        ballCard.addView(makeOptionCheckBox("从圆球区域上滑 / 下滑 / 左滑 / 右滑均可", AppStore.isBallExitSwipeAny()) {
            AppStore.setBallExitSwipeAny(it)
        })
        ballCard.addView(makeMiniButton("重置圆球默认位置（左下角）") {
            AppStore.resetOverlayPosition()
            TvAccessibilityService.instance?.refreshButtonSettings(resetPosition = true)
            Toast.makeText(this, "圆球已恢复左下角默认位置", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(6), 0, 0) })
        root.addView(ballCard)

        // ==================== 卡片2：完活提示与提示音设置 ====================
        val doneCard = makeCard()
        doneCard.addView(makeSectionHeader("完成提示设置（纯黑白 · 3秒消失）", "预览/调位置") {
            val svc = TvAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "请先在系统无障碍中开启“TV颜色标记”", Toast.LENGTH_SHORT).show()
            } else {
                svc.previewDoneBanner()
                SoundPlayer.playDoneSoundIfEnabled()
                Toast.makeText(this, "长按文字可拖动位置，短按或点空白关闭", Toast.LENGTH_SHORT).show()
            }
        })

        doneCard.addView(TextView(this).apply {
            text = "显示文字内容："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })

        val doneInput = EditText(this).apply {
            setText(AppStore.getDoneText())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6E7681"))
            hint = "例如：完活、已完成"
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#0D1117"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    AppStore.setDoneText(s?.toString().orEmpty())
                }
            })
        }
        doneCard.addView(doneInput)

        doneCard.addView(makeSlider(
            labelPrefix = "文字大小",
            unit = "sp",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getDoneSizeSp()
        ) { v ->
            AppStore.setDoneSizeSp(v)
        })

        doneCard.addView(makeSlider(
            labelPrefix = "黑白灰度",
            unit = "%",
            minVal = 15,
            maxVal = 100,
            initVal = AppStore.getDoneGrayPct()
        ) { v ->
            AppStore.setDoneGrayPct(v)
        })

        doneCard.addView(CheckBox(this).apply {
            text = "跳出完活时播放提示音（无震动）"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isDoneSoundEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setDoneSoundEnabled(checked)
            }
        })

        val soundHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        soundHeader.addView(TextView(this).apply {
            text = "选择提示音（共${SoundPreset.values().size}种）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        soundHeader.addView(makeMiniButton("试听") {
            val preset = SoundPreset.fromId(AppStore.getDoneSoundId())
            SoundPlayer.playPreset(preset, AppStore.getDoneSoundVolume().coerceAtLeast(15))
        })
        doneCard.addView(soundHeader)

        val presets = SoundPreset.values()
        val presetNames = presets.map { it.displayName }
        val spinner = Spinner(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#21262D"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, presetNames) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getView(position, convertView, parent) as TextView
                tv.setTextColor(Color.WHITE)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getDropDownView(position, convertView, parent) as TextView
                tv.setTextColor(Color.WHITE)
                tv.setBackgroundColor(Color.parseColor("#161B22"))
                tv.setPadding(dp(14), dp(12), dp(14), dp(12))
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                return tv
            }
        }
        spinner.adapter = adapter
        val initSoundIdx = presets.indexOfFirst { it.id == AppStore.getDoneSoundId() }.coerceAtLeast(0)
        spinner.setSelection(initSoundIdx, false)

        var spinnerReady = false
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosen = presets[position]
                AppStore.setDoneSoundId(chosen.id)
                if (spinnerReady) {
                    SoundPlayer.playPreset(chosen, AppStore.getDoneSoundVolume().coerceAtLeast(15))
                }
                spinnerReady = true
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        doneCard.addView(spinner)

        doneCard.addView(makeSlider(
            labelPrefix = "提示音音量",
            unit = "%",
            minVal = 0,
            maxVal = 100,
            initVal = AppStore.getDoneSoundVolume()
        ) { v ->
            AppStore.setDoneSoundVolume(v)
        })

        doneCard.addView(makeMiniButton("重置完成提示位置（居中）") {
            AppStore.resetDonePosition()
            Toast.makeText(this, "完成提示已恢复居中", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(6), 0, 0) })
        root.addView(doneCard)

        // ==================== 卡片3：高级速度与策略微调（默认折叠，按需展开） ====================
        val advCard = makeCard()
        var advExpanded = false
        val advBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(6), 0, 0)
        }
        val advHeaderTv = TextView(this).apply {
            text = "▶ 高级速度与策略微调（点击展开）"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            paint.isFakeBoldText = true
            setOnClickListener {
                advExpanded = !advExpanded
                advBody.visibility = if (advExpanded) View.VISIBLE else View.GONE
                text = if (advExpanded) "▼ 高级速度与策略微调（点击收起）" else "▶ 高级速度与策略微调（点击展开）"
            }
        }
        advCard.addView(advHeaderTv)

        advBody.addView(makeOptionCheckBox("跨列表优先用左上角 ≡ 抽屉直选（2次点击秒切，推荐）", AppStore.isDrawerSwitchPreferred()) {
            AppStore.setDrawerSwitchPreferred(it)
        })
        advBody.addView(makeOptionCheckBox("已有其它颜色标记时覆盖改色（不勾则已有任意颜色均跳过）", AppStore.isOverwriteDifferentColorFlag()) {
            AppStore.setOverwriteDifferentColorFlag(it)
        })
        advBody.addView(makeOptionCheckBox("跳过查小旗极速模式（省去每次截屏400ms，适合全新未标板块）", AppStore.isSkipFlagCheckTurbo()) {
            AppStore.setSkipFlagCheckTurbo(it)
        })

        advBody.addView(makeSlider(
            labelPrefix = "长按触发时长（默认 740）",
            unit = "ms",
            minVal = 550,
            maxVal = 950,
            initVal = AppStore.getCustomLongPressMs().toInt()
        ) { v ->
            AppStore.setCustomLongPressMs(v.toLong())
        })

        advBody.addView(makeSlider(
            labelPrefix = "同屏连按冷却（默认 340）",
            unit = "ms",
            minVal = 200,
            maxVal = 650,
            initVal = AppStore.getPostTapCooldownMs().toInt()
        ) { v ->
            AppStore.setPostTapCooldownMs(v.toLong())
        })

        advBody.addView(makeSlider(
            labelPrefix = "列表翻屏耗时（默认 125）",
            unit = "ms",
            minVal = 80,
            maxVal = 240,
            initVal = AppStore.getScrollDurationMs().toInt()
        ) { v ->
            AppStore.setScrollDurationMs(v.toLong())
        })

        advBody.addView(makeMiniButton("恢复默认速度与策略参数") {
            AppStore.resetSpeedDefaults()
            Toast.makeText(this, "已恢复默认参数（重进本页刷新滑块）", Toast.LENGTH_SHORT).show()
            recreate()
        }.apply { setPadding(0, dp(6), 0, 0) })

        advCard.addView(advBody)
        root.addView(advCard)

        // ==================== 卡片6：运行排错日志 ====================
        val logCard = makeCard()
        val logHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        logHeader.addView(TextView(this).apply {
            text = "运行排错日志"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        logHeader.addView(makeMiniButton("复制日志") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TV日志", AppStore.getLogsText()))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        })
        logExpandBtn = makeMiniButton("展开全部") {
            logExpanded = !logExpanded
            refreshStatusAndLogs()
        }
        logHeader.addView(logExpandBtn)
        logHeader.addView(makeMiniButton("清空") {
            AppStore.clearLogs()
        })
        logCard.addView(logHeader)

        logText = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(8), 0, 0)
            setTextIsSelectable(true)
        }
        logCard.addView(logText)
        root.addView(logCard)

        scroll.addView(root)
        return scroll
    }

    private fun makeOptionCheckBox(label: String, checked: Boolean, onChanged: (Boolean) -> Unit): CheckBox {
        return CheckBox(this).apply {
            text = label
            setTextColor(Color.parseColor("#E6EDF3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            isChecked = checked
            setOnCheckedChangeListener { _, isChecked -> onChanged(isChecked) }
        }
    }

    private fun refreshBigToggleUi() {
        val enabled = AppStore.isWorkEnabled()
        bigToggleBtn.text = if (enabled) "● 服务已开启（点此暂停）" else "○ 服务已关闭（点此启动）"
        bigToggleBtn.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(
                if (enabled) Color.parseColor("#238636") else Color.parseColor("#30363D")
            )
            setStroke(
                dp(2),
                if (enabled) Color.parseColor("#3FB950") else Color.parseColor("#6E7681")
            )
        }
    }

    private fun updateButtonPreview() {
        val enabledColors = AppStore.getEnabledColors()
        val diamPx = dp(AppStore.getButtonDiameterDp())
        val gapPx = dp(AppStore.getButtonGapDp())
        val unselPct = AppStore.getUnselectedBrightness()
        val selPct = AppStore.getSelectedBrightness()
        val showWhiteRing = AppStore.isSelectedWhiteRingEnabled()

        fun populateRow(row: LinearLayout, label: String, selected: Boolean) {
            row.removeAllViews()
            row.addView(TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, 0, dp(8), 0)
            })
            enabledColors.forEachIndexed { idx, color ->
                val v = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(diamPx, diamPx).apply {
                        if (idx > 0) marginStart = gapPx
                    }
                    background = OverlayController.makeCircleDrawable(
                        context = this@MainActivity,
                        color = color,
                        selected = selected,
                        unselPct = unselPct,
                        selPct = selPct,
                        showWhiteRing = showWhiteRing
                    )
                }
                row.addView(v)
            }
        }

        populateRow(previewUnselRow, "选中前：", selected = false)
        populateRow(previewSelRow, "选中后：", selected = true)
    }

    private fun makeSlider(
        labelPrefix: String,
        unit: String,
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        onChange: (Int) -> Unit
    ): LinearLayout {
        return makeCustomLabelSlider(
            minVal = minVal,
            maxVal = maxVal,
            initVal = initVal,
            formatter = { v -> "$labelPrefix：$v $unit" },
            onChange = onChange
        )
    }

    private fun makeCustomLabelSlider(
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        formatter: (Int) -> String,
        onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(2))
        }
        val tv = TextView(this).apply {
            text = formatter(initVal)
            setTextColor(Color.parseColor("#C9D1D9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, 0, 0, dp(2))
        }
        val bar = SeekBar(this).apply {
            max = (maxVal - minVal).coerceAtLeast(1)
            progress = (initVal - minVal).coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = minVal + progress
                    tv.text = formatter(v)
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(tv)
        box.addView(bar)
        return box
    }

    private fun makeCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
        }
    }

    private fun makeCardTitle(title: String): TextView {
        return TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
        }
    }

    private fun makeSectionHeader(title: String, actionLabel: String, onAction: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                paint.isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(makeMiniButton(actionLabel, onAction))
        }
    }

    private fun makeActionButton(label: String, hexBg: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(hexBg))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeMiniButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { onClick() }
        }
    }

    private fun refreshStatusAndLogs() {
        refreshBigToggleUi()

        val accReady = TvAccessibilityService.instance != null
        val workOn = AppStore.isWorkEnabled()
        statusText.text = when {
            !accReady -> "版本 v6.0.0｜无障碍未开启（请先点下方蓝色按钮授权一次）"
            workOn -> "版本 v6.0.0｜无障碍正常｜状态栏“TV标记开关”可随时启停"
            else -> "版本 v6.0.0｜无障碍常驻｜当前已暂停，点大开关或状态栏秒启"
        }
        statusText.setTextColor(
            when {
                !accReady -> Color.parseColor("#F85149")
                workOn -> Color.parseColor("#3FB950")
                else -> Color.parseColor("#8B949E")
            }
        )

        refreshQueueRowsUi()
        sessionMarkedLabel.text = "本轮已标色记忆：${AppStore.sessionMarkedCount()} 个（图表圆球左上角自动显示 ✓色 提示）"

        refreshUnknownCandidatesUi()
        refreshMissedRowsUi()

        val fullLogs = AppStore.getLogsText()
        if (fullLogs.isBlank()) {
            logText.text = "暂无日志"
            logExpandBtn.text = "展开全部"
        } else {
            val allLines = fullLogs.lines()
            if (logExpanded || allLines.size <= 8) {
                logText.text = fullLogs
                logExpandBtn.text = if (allLines.size <= 8) "共${allLines.size}行" else "收起(${allLines.size}行)"
            } else {
                logText.text = allLines.takeLast(8).joinToString("\n")
                logExpandBtn.text = "展开全部(${allLines.size}行)"
            }
        }
    }

    private fun refreshQueueRowsUi() {
        val taskList = AppStore.snapshotTasks()
        queueListContainer.removeAllViews()
        if (taskList.isEmpty()) {
            queueListContainer.addView(TextView(this).apply {
                text = "暂无待添加品种（当前《品种大全》共 ${CatalogRepository.getWatchlists().size} 列表 / ${CatalogRepository.totalInstrumentCount()} 品种）"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            })
            return
        }

        for ((idx, task) in taskList.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(6), dp(6), dp(6))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (idx > 0) topMargin = dp(5) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(7).toFloat()
                    setColor(Color.parseColor("#0D1117"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
            }

            val lockedWl = if (task.preferredWatchlistId.isNotEmpty()) {
                CatalogRepository.getWatchlistById(task.preferredWatchlistId)
            } else null
            val locs = CatalogRepository.findLocations(task.symbol)
            val wlName = lockedWl?.name ?: locs.map { it.watchlistName }.distinct().joinToString("/").ifBlank { "自动" }
            val inst = CatalogRepository.findInstrumentInfo(task.symbol, task.preferredWatchlistId.ifBlank { null })
            val cnPart = if (inst != null && inst.cnName.isNotBlank()) " ${inst.cnName}" else ""

            val infoCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            infoCol.addView(TextView(this).apply {
                text = "${task.symbol}$cnPart"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                paint.isFakeBoldText = true
            })
            infoCol.addView(TextView(this).apply {
                text = "目标：$wlName"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            })
            row.addView(infoCol)

            // 点击色块直接改颜色
            val colorChip = TextView(this).apply {
                text = "${task.color.label}色"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                paint.isFakeBoldText = true
                setPadding(dp(8), dp(4), dp(8), dp(4))
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.rgb(task.color.baseR, task.color.baseG, task.color.baseB))
                }
                setOnClickListener { showPickTaskColorDialog(task) }
            }
            row.addView(colorChip)

            // 点击列表芯片可指定目标列表
            val listChip = TextView(this).apply {
                text = "改列表"
                setTextColor(Color.parseColor("#58A6FF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(dp(8), dp(4), dp(6), dp(4))
                setOnClickListener { showPickTaskWatchlistDialog(task) }
            }
            row.addView(listChip)

            // 单条删除
            val delBtn = TextView(this).apply {
                text = "×"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(6), dp(2), dp(4), dp(2))
                setOnClickListener { AppStore.removeTaskByKey(task.key) }
            }
            row.addView(delBtn)

            queueListContainer.addView(row)
        }
    }

    private fun showPickTaskColorDialog(task: PendingTask) {
        val colors = MarkColor.values()
        val labels = colors.map { "${it.label}色列表" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("修改 ${task.symbol} 的目标颜色")
            .setItems(labels) { _, which ->
                AppStore.updateTaskColor(task.key, colors[which])
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showPickTaskWatchlistDialog(task: PendingTask) {
        val wls = CatalogRepository.getWatchlists()
        val labels = (listOf("自动匹配所属列表") + wls.map { it.name }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("指定 ${task.symbol} 的目标列表")
            .setItems(labels) { _, which ->
                val targetId = if (which == 0) "" else wls[which - 1].id
                AppStore.updateTaskWatchlist(task.key, targetId)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun refreshMissedRowsUi() {
        val retryCount = AppStore.countRetryableUnadded()
        requeueBtn.visibility = View.VISIBLE
        requeueBtn.text = if (retryCount > 0) {
            "一键将未找到的 $retryCount 个品种加入待添加池"
        } else {
            "一键将未找到品种加入待添加池（当前 0 个）"
        }
        requeueBtn.background = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Color.parseColor(if (retryCount > 0) "#1F6FEB" else "#30363D"))
        }

        val items = AppStore.getUnaddedItems()
        missedListContainer.removeAllViews()
        if (items.isEmpty()) {
            missedListContainer.addView(TextView(this).apply {
                text = "暂无未找到提醒"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            })
            return
        }

        for ((idx, item) in items.take(25).withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(6), dp(6), dp(6))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (idx > 0) topMargin = dp(5) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(7).toFloat()
                    setColor(Color.parseColor("#0D1117"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
            }

            row.addView(TextView(this).apply {
                text = "[${item.timestamp}] ${item.message}"
                setTextColor(Color.parseColor("#FFA657"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            if (item.symbol.isNotEmpty() && item.color != null) {
                row.addView(TextView(this).apply {
                    text = "重试"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    paint.isFakeBoldText = true
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(5).toFloat()
                        setColor(Color.parseColor("#1F6FEB"))
                    }
                    setOnClickListener {
                        if (AppStore.requeueSingleUnadded(idx)) {
                            if (!AppStore.isWorkEnabled()) {
                                AppStore.setWorkEnabled(this@MainActivity, true, source = "单条重试自动开启")
                            }
                            Toast.makeText(this@MainActivity, "已将 ${item.symbol} 重新加入待添加池", Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }

            row.addView(TextView(this).apply {
                text = "×"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(8), dp(2), dp(4), dp(2))
                setOnClickListener { AppStore.removeSingleUnadded(idx) }
            })

            missedListContainer.addView(row)
        }
    }

    private fun refreshUnknownCandidatesUi() {
        val list = AppStore.getUnknownCandidates()
        unknownListContainer.removeAllViews()
        if (list.isEmpty()) {
            unknownCard.visibility = View.GONE
            return
        }
        unknownCard.visibility = View.VISIBLE

        for ((idx, item) in list.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(7), dp(6), dp(7))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (idx > 0) topMargin = dp(6) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(7).toFloat()
                    setColor(Color.parseColor("#0D1117"))
                    setStroke(dp(1), Color.parseColor("#30363D"))
                }
            }

            val posDesc = when {
                item.watchlistName.isNotEmpty() && item.prevSymbol.isNotEmpty() ->
                    "所属：${item.watchlistName}（在 ${item.prevSymbol} 后）"
                item.watchlistName.isNotEmpty() && item.nextSymbol.isNotEmpty() ->
                    "所属：${item.watchlistName}（在 ${item.nextSymbol} 前）"
                item.watchlistName.isNotEmpty() ->
                    "所属：${item.watchlistName}（列表末尾）"
                else ->
                    "切到所属列表后自动定位，或点右侧手动选列表写入"
            }

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            textCol.addView(TextView(this).apply {
                text = item.symbol
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                paint.isFakeBoldText = true
            })
            textCol.addView(TextView(this).apply {
                text = posDesc
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            })
            row.addView(textCol)

            val writeBtn = TextView(this).apply {
                text = "一键写入"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                paint.isFakeBoldText = true
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.parseColor("#238636"))
                }
                setOnClickListener {
                    if (item.watchlistId.isNotEmpty() && CatalogRepository.getWatchlistById(item.watchlistId) != null) {
                        val res = CatalogRepository.insertObservedInstrument(
                            symbol = item.symbol,
                            watchlistId = item.watchlistId,
                            prevSymbol = item.prevSymbol,
                            nextSymbol = item.nextSymbol
                        )
                        AppStore.removeUnknownCandidate(item.symbol)
                        Toast.makeText(this@MainActivity, res, Toast.LENGTH_LONG).show()
                    } else {
                        showPickWatchlistAndInsert(item.symbol)
                    }
                }
            }
            row.addView(writeBtn)

            val delBtn = TextView(this).apply {
                text = "×"
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(10), dp(4), dp(4), dp(4))
                setOnClickListener {
                    AppStore.removeUnknownCandidate(item.symbol)
                }
            }
            row.addView(delBtn)

            unknownListContainer.addView(row)
        }
    }

    private fun showPickWatchlistAndInsert(symbol: String) {
        val wls = CatalogRepository.getWatchlists()
        if (wls.isEmpty()) return
        val names = wls.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("将 $symbol 写入哪个列表？")
            .setItems(names) { _, which ->
                val wl = wls[which]
                val res = CatalogRepository.insertObservedInstrument(symbol, wl.id)
                AppStore.removeUnknownCandidate(symbol)
                Toast.makeText(this, res, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }
}
