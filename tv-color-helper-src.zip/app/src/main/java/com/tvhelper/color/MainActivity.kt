package com.tvhelper.color

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var queueText: TextView
    private lateinit var missedText: TextView
    private lateinit var logText: TextView
    private lateinit var sizeLabel: TextView

    private val storeListener: () -> Unit = {
        runOnUiThread { refreshUi() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildLayout())
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        AppStore.addListener(storeListener)
        refreshUi()
    }

    override fun onPause() {
        super.onPause()
        AppStore.removeListener(storeListener)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun buildLayout(): ScrollView {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val title = TextView(this).apply {
            text = "TV 红蓝标记助手"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            paint.isFakeBoldText = true
        }
        root.addView(title)

        statusText = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(statusText)

        val btnRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        btnRow1.addView(makeActionButton("开启无障碍服务", "#1F6FEB") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        btnRow1.addView(makeActionButton("重置球位置", "#30363D") {
            AppStore.resetOverlayPosition()
            TvAccessibilityService.instance?.refreshOverlaySettings()
            Toast.makeText(this, "已恢复默认位置（左下角TV符号处）", Toast.LENGTH_SHORT).show()
        })
        root.addView(btnRow1)

        val settingsBox = makeCard()
        val dupCheck = CheckBox(this).apply {
            text = "发现同名品种全部添加（完整扫遍当前列表）"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isMarkAllDuplicates()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setMarkAllDuplicates(checked)
            }
        }
        settingsBox.addView(dupCheck)

        sizeLabel = TextView(this).apply {
            text = "红蓝圆球直径：${AppStore.getButtonDiameterDp()} dp"
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(8), 0, dp(4))
        }
        settingsBox.addView(sizeLabel)

        val sizeBar = SeekBar(this).apply {
            max = 20
            progress = (AppStore.getButtonDiameterDp() - 22).coerceIn(0, 20)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val dpVal = 22 + progress
                    sizeLabel.text = "红蓝圆球直径：$dpVal dp"
                    if (fromUser) {
                        AppStore.setButtonDiameterDp(dpVal)
                        TvAccessibilityService.instance?.refreshOverlaySettings()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        settingsBox.addView(sizeBar)
        root.addView(settingsBox)

        val queueCard = makeCard()
        val qHeader = makeSectionHeader("待添加队列", "清空队列") {
            AppStore.clearQueue()
        }
        queueCard.addView(qHeader)
        queueText = TextView(this).apply {
            setTextColor(Color.parseColor("#E6EDF3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6), 0, 0)
        }
        queueCard.addView(queueText)
        root.addView(queueCard)

        val missedCard = makeCard()
        val mHeader = makeSectionHeader("漏项/提醒记录", "清空记录") {
            AppStore.clearMissedRecords()
        }
        missedCard.addView(mHeader)
        missedText = TextView(this).apply {
            setTextColor(Color.parseColor("#FFA657"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6), 0, 0)
        }
        missedCard.addView(missedText)
        root.addView(missedCard)

        val logCard = makeCard()
        val logHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        logHeaderRow.addView(TextView(this).apply {
            text = "运行排错日志"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        logHeaderRow.addView(makeMiniButton("复制日志") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TV日志", AppStore.getLogsText()))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        })
        logHeaderRow.addView(makeMiniButton("清空") {
            AppStore.clearLogs()
        })
        logCard.addView(logHeaderRow)

        logText = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(8), 0, 0)
            setTextIsSelectable(true)
        }
        logCard.addView(logText)
        root.addView(logCard)

        scroll.addView(root)
        return scroll
    }

    private fun makeCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
        }
    }

    private fun makeSectionHeader(title: String, actionLabel: String, onAction: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                paint.isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(makeMiniButton(actionLabel, onAction))
        }
    }

    private fun makeActionButton(label: String, hexBg: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(hexBg))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeMiniButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { onClick() }
        }
    }

    private fun refreshUi() {
        val running = TvAccessibilityService.instance != null
        statusText.text = if (running) {
            "状态：无障碍服务已运行（打开 TradingView 图表页即可使用）"
        } else {
            "状态：未开启无障碍服务（请点击下方按钮开启“TV红蓝标记”）"
        }
        statusText.setTextColor(
            if (running) Color.parseColor("#3FB950") else Color.parseColor("#F85149")
        )

        val q = AppStore.snapshotQueue()
        queueText.text = if (q.isEmpty()) {
            "暂无待添加品种"
        } else {
            q.entries.joinToString("\n") { "• ${it.key}  →  ${it.value.label}色列表" }
        }

        val missed = AppStore.getMissedRecords()
        missedText.text = if (missed.isBlank()) "暂无漏项记录" else missed

        val logs = AppStore.getLogsText()
        logText.text = if (logs.isBlank()) "暂无日志" else logs
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }
}
