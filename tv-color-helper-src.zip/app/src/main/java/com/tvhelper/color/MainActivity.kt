package com.tvhelper.color

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var queueText: TextView
    private lateinit var missedText: TextView
    private lateinit var logText: TextView

    // 红蓝圆球实时预览视图
    private lateinit var previewUnselRed: View
    private lateinit var previewUnselBlue: View
    private lateinit var previewSelRed: View
    private lateinit var previewSelBlue: View

    private val storeListener: () -> Unit = {
        runOnUiThread { refreshStatusAndLogs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildLayout())
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(true)
        AppStore.addListener(storeListener)
        refreshStatusAndLogs()
        updateButtonPreview()
    }

    override fun onPause() {
        super.onPause()
        AppStore.removeListener(storeListener)
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(false)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun buildLayout(): ScrollView {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "TV 红蓝标记助手"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            paint.isFakeBoldText = true
        })

        statusText = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(statusText)

        val topBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topBtns.addView(makeActionButton("开启无障碍服务", "#1F6FEB") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        topBtns.addView(makeActionButton("重置球位置", "#30363D") {
            AppStore.resetOverlayPosition()
            TvAccessibilityService.instance?.refreshButtonSettings(resetPosition = true)
            Toast.makeText(this, "已恢复左下角默认位置", Toast.LENGTH_SHORT).show()
        })
        root.addView(topBtns)

        // ==================== 卡片1：红蓝圆球设置 ====================
        val ballCard = makeCard()
        ballCard.addView(makeCardTitle("红蓝圆球设置"))

        // 实时效果预览（选中前 vs 选中后）
        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.BLACK)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8); bottomMargin = dp(6) }
        }
        previewUnselRed = View(this)
        previewUnselBlue = View(this)
        previewSelRed = View(this)
        previewSelBlue = View(this)
        previewBox.addView(makePreviewRow("选中前：", previewUnselRed, previewUnselBlue))
        previewBox.addView(makePreviewRow("选中后：", previewSelRed, previewSelBlue).apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(8)
        })
        ballCard.addView(previewBox)

        // 1) 圆点直径 30~60dp
        ballCard.addView(makeSlider(
            labelPrefix = "圆球直径",
            unit = "dp",
            minVal = 30,
            maxVal = 60,
            initVal = AppStore.getButtonDiameterDp()
        ) { v ->
            AppStore.setButtonDiameterDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        // 2) 两圆点间距 5~60dp
        ballCard.addView(makeSlider(
            labelPrefix = "两圆球间距",
            unit = "dp",
            minVal = 5,
            maxVal = 60,
            initVal = AppStore.getButtonGapDp()
        ) { v ->
            AppStore.setButtonGapDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        // 3) 选中前明暗度 10~100%
        ballCard.addView(makeSlider(
            labelPrefix = "选中前整体明暗度",
            unit = "%",
            minVal = 10,
            maxVal = 100,
            initVal = AppStore.getUnselectedBrightness()
        ) { v ->
            AppStore.setUnselectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        // 4) 选中后明暗度 20~100%
        ballCard.addView(makeSlider(
            labelPrefix = "选中后整体明暗度",
            unit = "%",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getSelectedBrightness()
        ) { v ->
            AppStore.setSelectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })
        root.addView(ballCard)

        // ==================== 卡片2：完活提示设置 ====================
        val doneCard = makeCard()
        doneCard.addView(makeSectionHeader("完成提示设置（纯黑白 · 3秒消失）", "预览/调位置") {
            val svc = TvAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
            } else {
                svc.previewDoneBanner()
                Toast.makeText(this, "长按文字可拖动位置，短按或点空白关闭", Toast.LENGTH_SHORT).show()
            }
        })

        doneCard.addView(TextView(this).apply {
            text = "显示文字内容："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })

        val doneInput = EditText(this).apply {
            setText(AppStore.getDoneText())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6E7681"))
            hint = "例如：完活、已完成"
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#0D1117"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    AppStore.setDoneText(s?.toString().orEmpty())
                }
            })
        }
        doneCard.addView(doneInput)

        doneCard.addView(makeSlider(
            labelPrefix = "文字大小",
            unit = "sp",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getDoneSizeSp()
        ) { v ->
            AppStore.setDoneSizeSp(v)
        })

        doneCard.addView(makeSlider(
            labelPrefix = "黑白灰度",
            unit = "%",
            minVal = 15,
            maxVal = 100,
            initVal = AppStore.getDoneGrayPct()
        ) { v ->
            AppStore.setDoneGrayPct(v)
        })

        doneCard.addView(makeMiniButton("重置完成提示位置（居中）") {
            AppStore.resetDonePosition()
            Toast.makeText(this, "完成提示已恢复居中", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(6), 0, 0) })
        root.addView(doneCard)

        // ==================== 卡片3：列表右侧信息提示设置 ====================
        val infoCard = makeCard()
        infoCard.addView(makeSectionHeader("列表右侧清单提示（纯黑白 · 双击关闭）", "预览/调位置") {
            val svc = TvAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
            } else {
                svc.previewInfoPanel()
                Toast.makeText(this, "按住清单可拖动位置，双击关闭预览", Toast.LENGTH_SHORT).show()
            }
        })

        infoCard.addView(makeSlider(
            labelPrefix = "字体大小",
            unit = "sp",
            minVal = 10,
            maxVal = 40,
            initVal = AppStore.getInfoSizeSp()
        ) { v ->
            AppStore.setInfoSizeSp(v)
            TvAccessibilityService.instance?.refreshInfoPanelSettings()
        })

        infoCard.addView(makeSlider(
            labelPrefix = "黑白灰度",
            unit = "%",
            minVal = 15,
            maxVal = 100,
            initVal = AppStore.getInfoGrayPct()
        ) { v ->
            AppStore.setInfoGrayPct(v)
            TvAccessibilityService.instance?.refreshInfoPanelSettings()
        })

        infoCard.addView(makeCustomLabelSlider(
            minVal = 0,
            maxVal = 180,
            initVal = AppStore.getInfoGapDp(),
            formatter = { v -> if (v == 0) "品种与红/蓝间距：最小（1个空格）" else "品种与红/蓝间距：1空格 + ${v}dp" }
        ) { v ->
            AppStore.setInfoGapDp(v)
            TvAccessibilityService.instance?.refreshInfoPanelSettings()
        })

        infoCard.addView(makeMiniButton("重置右侧清单位置（靠右）") {
            AppStore.resetInfoPosition()
            TvAccessibilityService.instance?.refreshInfoPanelSettings(resetPosition = true)
            Toast.makeText(this, "右侧清单已恢复默认靠右位置", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(6), 0, 0) })
        root.addView(infoCard)

        // ==================== 卡片4：待办队列 ====================
        val queueCard = makeCard()
        queueCard.addView(makeSectionHeader("待添加队列", "清空队列") {
            AppStore.clearQueue()
        })
        queueText = TextView(this).apply {
            setTextColor(Color.parseColor("#E6EDF3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6), 0, 0)
        }
        queueCard.addView(queueText)
        root.addView(queueCard)

        // ==================== 卡片5：漏项提醒记录 ====================
        val missedCard = makeCard()
        missedCard.addView(makeSectionHeader("漏项/提醒记录", "清空记录") {
            AppStore.clearMissedRecords()
        })
        missedText = TextView(this).apply {
            setTextColor(Color.parseColor("#D0D7DE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6), 0, 0)
        }
        missedCard.addView(missedText)
        root.addView(missedCard)

        // ==================== 卡片6：运行排错日志 ====================
        val logCard = makeCard()
        val logHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        logHeader.addView(TextView(this).apply {
            text = "运行排错日志"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        logHeader.addView(makeMiniButton("复制日志") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TV日志", AppStore.getLogsText()))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        })
        logHeader.addView(makeMiniButton("清空") {
            AppStore.clearLogs()
        })
        logCard.addView(logHeader)

        logText = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(8), 0, 0)
            setTextIsSelectable(true)
        }
        logCard.addView(logText)
        root.addView(logCard)

        scroll.addView(root)
        return scroll
    }

    private fun makePreviewRow(label: String, vRed: View, vBlue: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, 0, dp(8), 0)
            })
            addView(vRed)
            addView(vBlue)
        }
    }

    private fun updateButtonPreview() {
        val diamPx = dp(AppStore.getButtonDiameterDp())
        val gapPx = dp(AppStore.getButtonGapDp())
        val unselPct = AppStore.getUnselectedBrightness()
        val selPct = AppStore.getSelectedBrightness()

        previewUnselRed.layoutParams = LinearLayout.LayoutParams(diamPx, diamPx)
        previewUnselBlue.layoutParams = LinearLayout.LayoutParams(diamPx, diamPx).apply { marginStart = gapPx }
        previewSelRed.layoutParams = LinearLayout.LayoutParams(diamPx, diamPx)
        previewSelBlue.layoutParams = LinearLayout.LayoutParams(diamPx, diamPx).apply { marginStart = gapPx }

        previewUnselRed.background = makeCirclePreviewDrawable(isRed = true, selected = false, pct = unselPct)
        previewUnselBlue.background = makeCirclePreviewDrawable(isRed = false, selected = false, pct = unselPct)
        previewSelRed.background = makeCirclePreviewDrawable(isRed = true, selected = true, pct = selPct)
        previewSelBlue.background = makeCirclePreviewDrawable(isRed = false, selected = true, pct = selPct)
    }

    private fun makeCirclePreviewDrawable(isRed: Boolean, selected: Boolean, pct: Int): GradientDrawable {
        val f = pct / 100f
        val baseR = if (isRed) 255 else 35
        val baseG = if (isRed) 42 else 112
        val baseB = if (isRed) 58 else 255
        val alpha = if (selected) (175 + 80 * f).toInt().coerceIn(80, 255) else (95 + 145 * f).toInt().coerceIn(45, 240)
        val rgbScale = if (selected) (0.35f + 0.65f * f) else (0.20f + 0.62f * f)
        val fillColor = Color.argb(
            alpha,
            (baseR * rgbScale).toInt().coerceIn(0, 255),
            (baseG * rgbScale).toInt().coerceIn(0, 255),
            (baseB * rgbScale).toInt().coerceIn(0, 255)
        )
        val strokeAlpha = if (selected) (190 + 65 * f).toInt().coerceIn(90, 255) else (70 + 130 * f).toInt().coerceIn(40, 200)
        val strokeGray = if (selected) (160 + 95 * f).toInt().coerceIn(100, 255) else (120 + 110 * f).toInt().coerceIn(80, 230)
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fillColor)
            setStroke(if (selected) dp(3) else dp(1), Color.argb(strokeAlpha, strokeGray, strokeGray, strokeGray))
        }
    }

    private fun makeSlider(
        labelPrefix: String,
        unit: String,
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        onChange: (Int) -> Unit
    ): LinearLayout {
        return makeCustomLabelSlider(
            minVal = minVal,
            maxVal = maxVal,
            initVal = initVal,
            formatter = { v -> "$labelPrefix：$v $unit" },
            onChange = onChange
        )
    }

    private fun makeCustomLabelSlider(
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        formatter: (Int) -> String,
        onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(2))
        }
        val tv = TextView(this).apply {
            text = formatter(initVal)
            setTextColor(Color.parseColor("#C9D1D9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, 0, 0, dp(2))
        }
        val bar = SeekBar(this).apply {
            max = (maxVal - minVal).coerceAtLeast(1)
            progress = (initVal - minVal).coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = minVal + progress
                    tv.text = formatter(v)
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(tv)
        box.addView(bar)
        return box
    }

    private fun makeCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
        }
    }

    private fun makeCardTitle(title: String): TextView {
        return TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
        }
    }

    private fun makeSectionHeader(title: String, actionLabel: String, onAction: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                paint.isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(makeMiniButton(actionLabel, onAction))
        }
    }

    private fun makeActionButton(label: String, hexBg: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(hexBg))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeMiniButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { onClick() }
        }
    }

    private fun refreshStatusAndLogs() {
        val running = TvAccessibilityService.instance != null
        statusText.text = if (running) {
            "状态：无障碍服务已运行（打开 TradingView 图表页即可使用）"
        } else {
            "状态：未开启无障碍服务（请点击下方按钮开启“TV红蓝标记”）"
        }
        statusText.setTextColor(
            if (running) Color.parseColor("#3FB950") else Color.parseColor("#F85149")
        )

        val q = AppStore.snapshotQueue()
        queueText.text = if (q.isEmpty()) {
            "暂无待添加品种"
        } else {
            q.entries.joinToString("\n") { "• ${it.key}  →  ${it.value.label}色列表" }
        }

        val missed = AppStore.getMissedRecords()
        missedText.text = if (missed.isBlank()) "暂无漏项记录" else missed

        val logs = AppStore.getLogsText()
        logText.text = if (logs.isBlank()) "暂无日志" else logs
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }
}
