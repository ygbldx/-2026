package com.tvhelper.color

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var queueText: TextView
    private lateinit var missedText: TextView
    private lateinit var logText: TextView

    private lateinit var previewUnselRow: LinearLayout
    private lateinit var previewSelRow: LinearLayout

    private val storeListener: () -> Unit = {
        runOnUiThread { refreshStatusAndLogs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppStore.init(this)
        window.statusBarColor = Color.parseColor("#0D1117")
        setContentView(buildLayout())
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(true)
        AppStore.addListener(storeListener)
        refreshStatusAndLogs()
        updateButtonPreview()
    }

    override fun onPause() {
        super.onPause()
        AppStore.removeListener(storeListener)
        TvAccessibilityService.instance?.onOwnAppForegroundChanged(false)
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun buildLayout(): ScrollView {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D1117"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(36))
        }

        root.addView(TextView(this).apply {
            text = "TV 7色标记助手"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            paint.isFakeBoldText = true
        })

        statusText = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(statusText)

        val topBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topBtns.addView(makeActionButton("开启无障碍服务", "#1F6FEB") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        topBtns.addView(makeActionButton("重置圆球位置", "#30363D") {
            AppStore.resetOverlayPosition()
            TvAccessibilityService.instance?.refreshButtonSettings(resetPosition = true)
            Toast.makeText(this, "已恢复左下角默认位置", Toast.LENGTH_SHORT).show()
        })
        root.addView(topBtns)

        // ==================== 卡片1：7色圆球显示与外观设置 ====================
        val ballCard = makeCard()
        ballCard.addView(makeCardTitle("图表颜色圆球设置（支持全7色自由搭配）"))

        ballCard.addView(TextView(this).apply {
            text = "选择图表上要显示的颜色球（可单选或多选）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })

        // 7种颜色勾选区（分两行排布，整齐不拥挤）
        val enabledSet = AppStore.getEnabledColors().toSet()
        val colorRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val colorRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        MarkColor.values().forEachIndexed { idx, markColor ->
            val cb = CheckBox(this).apply {
                text = markColor.label
                setTextColor(Color.rgb(markColor.baseR, markColor.baseG, markColor.baseB))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                paint.isFakeBoldText = true
                isChecked = markColor in enabledSet
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { buttonView, isChecked ->
                    val ok = AppStore.setColorEnabled(markColor, isChecked)
                    if (!ok) {
                        buttonView.isChecked = true
                        Toast.makeText(this@MainActivity, "至少保留 1 种颜色球", Toast.LENGTH_SHORT).show()
                    } else {
                        updateButtonPreview()
                        TvAccessibilityService.instance?.refreshButtonSettings()
                    }
                }
            }
            if (idx < 4) colorRow1.addView(cb) else colorRow2.addView(cb)
        }
        ballCard.addView(colorRow1)
        ballCard.addView(colorRow2)

        // 实时效果预览（选中前 vs 选中后，横向可滚防大尺寸撑破）
        val previewScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.BLACK)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8); bottomMargin = dp(6) }
        }
        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        previewUnselRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        previewSelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        previewBox.addView(previewUnselRow)
        previewBox.addView(previewSelRow)
        previewScroll.addView(previewBox)
        ballCard.addView(previewScroll)

        // 1) 直径 30~80dp
        ballCard.addView(makeSlider(
            labelPrefix = "圆球直径",
            unit = "dp",
            minVal = 30,
            maxVal = 80,
            initVal = AppStore.getButtonDiameterDp()
        ) { v ->
            AppStore.setButtonDiameterDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        // 2) 两球间距 5~60dp
        ballCard.addView(makeSlider(
            labelPrefix = "圆球间距",
            unit = "dp",
            minVal = 5,
            maxVal = 60,
            initVal = AppStore.getButtonGapDp()
        ) { v ->
            AppStore.setButtonGapDp(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        // 3) 选中前明暗度
        ballCard.addView(makeSlider(
            labelPrefix = "选中前整体明暗度",
            unit = "%",
            minVal = 10,
            maxVal = 100,
            initVal = AppStore.getUnselectedBrightness()
        ) { v ->
            AppStore.setUnselectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        // 4) 选中后明暗度
        ballCard.addView(makeSlider(
            labelPrefix = "选中后整体明暗度",
            unit = "%",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getSelectedBrightness()
        ) { v ->
            AppStore.setSelectedBrightness(v)
            updateButtonPreview()
            TvAccessibilityService.instance?.refreshButtonSettings()
        })

        // 5) 选中后有无白外圈
        ballCard.addView(CheckBox(this).apply {
            text = "选中后显示白色外圈"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isSelectedWhiteRingEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setSelectedWhiteRingEnabled(checked)
                updateButtonPreview()
                TvAccessibilityService.instance?.refreshButtonSettings()
            }
        })

        // 6) 圆球退出服务方式（3选1）
        ballCard.addView(TextView(this).apply {
            text = "图表页隐藏圆球并退出服务方式："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(2))
        })
        val exitGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val currExitMode = AppStore.getBallExitMode()
        for (mode in BallExitMode.values()) {
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = mode.label
                setTextColor(Color.parseColor("#E6EDF3"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                isChecked = (mode == currExitMode)
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) AppStore.setBallExitMode(mode)
                }
            }
            exitGroup.addView(rb)
        }
        ballCard.addView(exitGroup)
        root.addView(ballCard)

        // ==================== 卡片2：完活提示与提示音设置 ====================
        val doneCard = makeCard()
        doneCard.addView(makeSectionHeader("完成提示设置（纯黑白 · 3秒消失）", "预览/调位置") {
            val svc = TvAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
            } else {
                svc.previewDoneBanner()
                SoundPlayer.playDoneSoundIfEnabled()
                Toast.makeText(this, "长按文字可拖动位置，短按或点空白关闭", Toast.LENGTH_SHORT).show()
            }
        })

        doneCard.addView(TextView(this).apply {
            text = "显示文字内容："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(8), 0, dp(4))
        })

        val doneInput = EditText(this).apply {
            setText(AppStore.getDoneText())
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6E7681"))
            hint = "例如：完活、已完成"
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#0D1117"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    AppStore.setDoneText(s?.toString().orEmpty())
                }
            })
        }
        doneCard.addView(doneInput)

        doneCard.addView(makeSlider(
            labelPrefix = "文字大小",
            unit = "sp",
            minVal = 20,
            maxVal = 100,
            initVal = AppStore.getDoneSizeSp()
        ) { v ->
            AppStore.setDoneSizeSp(v)
        })

        doneCard.addView(makeSlider(
            labelPrefix = "黑白灰度",
            unit = "%",
            minVal = 15,
            maxVal = 100,
            initVal = AppStore.getDoneGrayPct()
        ) { v ->
            AppStore.setDoneGrayPct(v)
        })

        // 提示音开关 + 22种短提示音下拉选择 + 试听 + 音量拉条
        doneCard.addView(CheckBox(this).apply {
            text = "跳出完活时播放提示音（无震动）"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isDoneSoundEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setDoneSoundEnabled(checked)
            }
        })

        val soundHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        soundHeader.addView(TextView(this).apply {
            text = "选择提示音（共${SoundPreset.values().size}种）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        soundHeader.addView(makeMiniButton("试听") {
            val preset = SoundPreset.fromId(AppStore.getDoneSoundId())
            SoundPlayer.playPreset(preset, AppStore.getDoneSoundVolume().coerceAtLeast(15))
        })
        doneCard.addView(soundHeader)

        val presets = SoundPreset.values()
        val presetNames = presets.map { it.displayName }
        val spinner = Spinner(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#21262D"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, presetNames) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getView(position, convertView, parent) as TextView
                tv.setTextColor(Color.WHITE)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getDropDownView(position, convertView, parent) as TextView
                tv.setTextColor(Color.WHITE)
                tv.setBackgroundColor(Color.parseColor("#161B22"))
                tv.setPadding(dp(14), dp(12), dp(14), dp(12))
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                return tv
            }
        }
        spinner.adapter = adapter
        val initSoundIdx = presets.indexOfFirst { it.id == AppStore.getDoneSoundId() }.coerceAtLeast(0)
        spinner.setSelection(initSoundIdx, false)

        var spinnerReady = false
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val chosen = presets[position]
                AppStore.setDoneSoundId(chosen.id)
                if (spinnerReady) {
                    SoundPlayer.playPreset(chosen, AppStore.getDoneSoundVolume().coerceAtLeast(15))
                }
                spinnerReady = true
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        doneCard.addView(spinner)

        doneCard.addView(makeSlider(
            labelPrefix = "提示音音量",
            unit = "%",
            minVal = 0,
            maxVal = 100,
            initVal = AppStore.getDoneSoundVolume()
        ) { v ->
            AppStore.setDoneSoundVolume(v)
        })

        doneCard.addView(makeMiniButton("重置完成提示位置（居中）") {
            AppStore.resetDonePosition()
            Toast.makeText(this, "完成提示已恢复居中", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(6), 0, 0) })
        root.addView(doneCard)

        // ==================== 卡片3：列表右侧清单提示设置 ====================
        val infoCard = makeCard()
        infoCard.addView(makeSectionHeader("列表右侧清单提示（纯黑白）", "预览/调位置") {
            val svc = TvAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
            } else {
                svc.previewInfoPanel()
                Toast.makeText(this, "已显示预览（双击模式直接拖，滑动模式长按拖）", Toast.LENGTH_SHORT).show()
            }
        })

        infoCard.addView(CheckBox(this).apply {
            text = "进入列表页时显示右侧清单提示"
            setTextColor(Color.parseColor("#E6EDF3"))
            isChecked = AppStore.isInfoPanelEnabled()
            setOnCheckedChangeListener { _, checked ->
                AppStore.setInfoPanelEnabled(checked)
                TvAccessibilityService.instance?.refreshInfoPanelSettings()
            }
        })

        infoCard.addView(TextView(this).apply {
            text = "手动关闭清单的方式（未完活持续显示时）："
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, dp(4), 0, dp(2))
        })
        val infoCloseGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val currCloseMode = AppStore.getInfoCloseMode()
        for (mode in InfoCloseMode.values()) {
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = mode.label
                setTextColor(Color.parseColor("#E6EDF3"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                isChecked = (mode == currCloseMode)
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) AppStore.setInfoCloseMode(mode)
                }
            }
            infoCloseGroup.addView(rb)
        }
        infoCard.addView(infoCloseGroup)

        // 字体大小：20~80sp
        infoCard.addView(makeSlider(
            labelPrefix = "字体大小",
            unit = "sp",
            minVal = 20,
            maxVal = 80,
            initVal = AppStore.getInfoSizeSp()
        ) { v ->
            AppStore.setInfoSizeSp(v)
            TvAccessibilityService.instance?.refreshInfoPanelSettings()
        })

        infoCard.addView(makeSlider(
            labelPrefix = "黑白灰度",
            unit = "%",
            minVal = 15,
            maxVal = 100,
            initVal = AppStore.getInfoGrayPct()
        ) { v ->
            AppStore.setInfoGrayPct(v)
            TvAccessibilityService.instance?.refreshInfoPanelSettings()
        })

        infoCard.addView(makeCustomLabelSlider(
            minVal = 0,
            maxVal = 180,
            initVal = AppStore.getInfoGapDp(),
            formatter = { v -> if (v == 0) "品种与颜色字间距：最小（1个空格）" else "品种与颜色字间距：1空格 + ${v}dp" }
        ) { v ->
            AppStore.setInfoGapDp(v)
            TvAccessibilityService.instance?.refreshInfoPanelSettings()
        })

        infoCard.addView(makeMiniButton("重置右侧清单位置（靠右）") {
            AppStore.resetInfoPosition()
            TvAccessibilityService.instance?.refreshInfoPanelSettings(resetPosition = true)
            Toast.makeText(this, "右侧清单已恢复默认靠右位置", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(0, dp(6), 0, 0) })
        root.addView(infoCard)

        // ==================== 卡片4：待办队列 ====================
        val queueCard = makeCard()
        queueCard.addView(makeSectionHeader("待添加队列", "清空队列") {
            AppStore.clearQueue()
        })
        queueText = TextView(this).apply {
            setTextColor(Color.parseColor("#E6EDF3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6), 0, 0)
        }
        queueCard.addView(queueText)
        root.addView(queueCard)

        // ==================== 卡片5：漏项提醒记录 ====================
        val missedCard = makeCard()
        missedCard.addView(makeSectionHeader("漏项/提醒记录", "清空记录") {
            AppStore.clearMissedRecords()
        })
        missedText = TextView(this).apply {
            setTextColor(Color.parseColor("#D0D7DE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6), 0, 0)
        }
        missedCard.addView(missedText)
        root.addView(missedCard)

        // ==================== 卡片6：运行排错日志 ====================
        val logCard = makeCard()
        val logHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        logHeader.addView(TextView(this).apply {
            text = "运行排错日志"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        logHeader.addView(makeMiniButton("复制日志") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TV日志", AppStore.getLogsText()))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        })
        logHeader.addView(makeMiniButton("清空") {
            AppStore.clearLogs()
        })
        logCard.addView(logHeader)

        logText = TextView(this).apply {
            setTextColor(Color.parseColor("#8B949E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(8), 0, 0)
            setTextIsSelectable(true)
        }
        logCard.addView(logText)
        root.addView(logCard)

        scroll.addView(root)
        return scroll
    }

    private fun updateButtonPreview() {
        val enabledColors = AppStore.getEnabledColors()
        val diamPx = dp(AppStore.getButtonDiameterDp())
        val gapPx = dp(AppStore.getButtonGapDp())
        val unselPct = AppStore.getUnselectedBrightness()
        val selPct = AppStore.getSelectedBrightness()
        val showWhiteRing = AppStore.isSelectedWhiteRingEnabled()

        fun populateRow(row: LinearLayout, label: String, selected: Boolean) {
            row.removeAllViews()
            row.addView(TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#8B949E"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, 0, dp(8), 0)
            })
            enabledColors.forEachIndexed { idx, color ->
                val v = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(diamPx, diamPx).apply {
                        if (idx > 0) marginStart = gapPx
                    }
                    background = OverlayController.makeCircleDrawable(
                        context = this@MainActivity,
                        color = color,
                        selected = selected,
                        unselPct = unselPct,
                        selPct = selPct,
                        showWhiteRing = showWhiteRing
                    )
                }
                row.addView(v)
            }
        }

        populateRow(previewUnselRow, "选中前：", selected = false)
        populateRow(previewSelRow, "选中后：", selected = true)
    }

    private fun makeSlider(
        labelPrefix: String,
        unit: String,
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        onChange: (Int) -> Unit
    ): LinearLayout {
        return makeCustomLabelSlider(
            minVal = minVal,
            maxVal = maxVal,
            initVal = initVal,
            formatter = { v -> "$labelPrefix：$v $unit" },
            onChange = onChange
        )
    }

    private fun makeCustomLabelSlider(
        minVal: Int,
        maxVal: Int,
        initVal: Int,
        formatter: (Int) -> String,
        onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(2))
        }
        val tv = TextView(this).apply {
            text = formatter(initVal)
            setTextColor(Color.parseColor("#C9D1D9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(0, 0, 0, dp(2))
        }
        val bar = SeekBar(this).apply {
            max = (maxVal - minVal).coerceAtLeast(1)
            progress = (initVal - minVal).coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = minVal + progress
                    tv.text = formatter(v)
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(tv)
        box.addView(bar)
        return box
    }

    private fun makeCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
        }
    }

    private fun makeCardTitle(title: String): TextView {
        return TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            paint.isFakeBoldText = true
        }
    }

    private fun makeSectionHeader(title: String, actionLabel: String, onAction: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                paint.isFakeBoldText = true
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(makeMiniButton(actionLabel, onAction))
        }
    }

    private fun makeActionButton(label: String, hexBg: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(hexBg))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeMiniButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#58A6FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { onClick() }
        }
    }

    private fun refreshStatusAndLogs() {
        val running = TvAccessibilityService.instance != null
        statusText.text = if (running) {
            "状态：无障碍服务已运行（打开 TradingView 图表页即可使用）"
        } else {
            "状态：未开启无障碍服务（请点击下方按钮开启“TV颜色标记”）"
        }
        statusText.setTextColor(
            if (running) Color.parseColor("#3FB950") else Color.parseColor("#F85149")
        )

        val q = AppStore.snapshotQueue()
        queueText.text = if (q.isEmpty()) {
            "暂无待添加品种"
        } else {
            q.entries.joinToString("\n") { "• ${it.key}  →  ${it.value.label}色列表" }
        }

        val missed = AppStore.getMissedRecords()
        missedText.text = if (missed.isBlank()) "暂无漏项记录" else missed

        val logs = AppStore.getLogsText()
        logText.text = if (logs.isBlank()) "暂无日志" else logs
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
    }
}
