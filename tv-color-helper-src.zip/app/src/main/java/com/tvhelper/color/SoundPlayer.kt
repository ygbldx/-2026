package com.tvhelper.color

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

enum class SoundPreset(val id: String, val displayName: String) {
    WECHAT("wechat", "微信消息音（默认）"),
    WECHAT_CRISP("wechat_crisp", "微信轻脆版"),
    CRISP_DING("crisp_ding", "清脆单叮"),
    DOUBLE_DING("double_ding", "轻快双叮"),
    TRIPLE_CHIME("triple_chime", "三连风铃"),
    WATER_DROP("water_drop", "水滴落珠"),
    BUBBLE_POP("bubble_pop", "气泡啵声"),
    WOOD_KNOCK("wood_knock", "清脆木鱼"),
    CRYSTAL_BELL("crystal_bell", "水晶清铃"),
    MARIMBA_UP("marimba_up", "马林巴上扬"),
    MARIMBA_DONE("marimba_done", "马林巴双音"),
    PIANO_CHORD("piano_chord", "钢琴亮和弦"),
    GLASS_PING("glass_ping", "玻璃轻碰"),
    SOFT_BEEP("soft_beep", "柔和短嘀"),
    TECH_BLIP("tech_blip", "科技轻脉冲"),
    COIN_GET("coin_get", "游戏金币音"),
    SUCCESS_CHIME("success_chime", "轻快达成音"),
    ZEN_BOWL("zen_bowl", "禅意小铜磬"),
    KALIMBA("kalimba", "拇指琴弹拨"),
    SNAP_CLICK("snap_click", "利落咔哒"),
    WHISTLE_UP("whistle_up", "轻快短哨"),
    TINY_TICK("tiny_tick", "极简微滴");

    companion object {
        fun fromId(id: String): SoundPreset = values().firstOrNull { it.id == id } ?: WECHAT
    }
}

object SoundPlayer {
    private const val SAMPLE_RATE = 44100
    private val audioExecutor = Executors.newSingleThreadExecutor()

    fun playDoneSoundIfEnabled() {
        if (!AppStore.isDoneSoundEnabled()) return
        val preset = SoundPreset.fromId(AppStore.getDoneSoundId())
        val vol = AppStore.getDoneSoundVolume()
        if (vol <= 0) return
        playPreset(preset, vol)
    }

    fun playPreset(preset: SoundPreset, volumePct: Int) {
        val clampedVol = volumePct.coerceIn(0, 100)
        if (clampedVol <= 0) return
        audioExecutor.execute {
            try {
                val pcm = synthesize(preset, clampedVol / 100.0)
                playPcm(pcm)
            } catch (_: Exception) {
            }
        }
    }

    private fun playPcm(pcm: ShortArray) {
        val byteLen = pcm.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(byteLen)
            .build()

        try {
            track.write(pcm, 0, pcm.size)
            track.play()
            val durationMs = (pcm.size * 1000L / SAMPLE_RATE) + 60L
            Thread.sleep(durationMs)
        } finally {
            try { track.stop() } catch (_: Exception) {}
            try { track.release() } catch (_: Exception) {}
        }
    }

    private fun synthesize(preset: SoundPreset, volLinear: Double): ShortArray {
        val gain = volLinear.pow(1.35) * 0.88
        return when (preset) {
            // 经典微信提示音：极短促明亮的上升双音木琴感（A5 -> E6 泛音）
            SoundPreset.WECHAT -> renderNotes(
                totalSec = 0.24, gain = gain,
                notes = listOf(
                    Note(0.000, 0.085, 1174.66, 1174.66, 1.0, 22.0, 0.32),
                    Note(0.072, 0.165, 1567.98, 1567.98, 0.95, 16.0, 0.28)
                )
            )
            SoundPreset.WECHAT_CRISP -> renderNotes(
                totalSec = 0.20, gain = gain,
                notes = listOf(
                    Note(0.000, 0.068, 1318.51, 1318.51, 0.95, 26.0, 0.25),
                    Note(0.058, 0.140, 1760.00, 1760.00, 1.0, 18.0, 0.22)
                )
            )
            SoundPreset.CRISP_DING -> renderNotes(
                totalSec = 0.26, gain = gain,
                notes = listOf(
                    Note(0.000, 0.25, 1760.0, 1760.0, 1.0, 13.0, 0.35)
                )
            )
            SoundPreset.DOUBLE_DING -> renderNotes(
                totalSec = 0.28, gain = gain,
                notes = listOf(
                    Note(0.000, 0.11, 1567.98, 1567.98, 0.9, 18.0, 0.3),
                    Note(0.095, 0.18, 2093.00, 2093.00, 1.0, 14.0, 0.3)
                )
            )
            SoundPreset.TRIPLE_CHIME -> renderNotes(
                totalSec = 0.34, gain = gain,
                notes = listOf(
                    Note(0.000, 0.11, 1046.50, 1046.50, 0.85, 18.0, 0.25),
                    Note(0.075, 0.12, 1318.51, 1318.51, 0.90, 17.0, 0.25),
                    Note(0.150, 0.19, 1567.98, 1567.98, 1.0, 13.0, 0.25)
                )
            )
            SoundPreset.WATER_DROP -> renderNotes(
                totalSec = 0.16, gain = gain,
                notes = listOf(
                    Note(0.000, 0.15, 620.0, 1480.0, 1.0, 24.0, 0.08)
                )
            )
            SoundPreset.BUBBLE_POP -> renderNotes(
                totalSec = 0.14, gain = gain,
                notes = listOf(
                    Note(0.000, 0.12, 420.0, 1180.0, 1.0, 28.0, 0.05)
                )
            )
            SoundPreset.WOOD_KNOCK -> renderNotes(
                totalSec = 0.13, gain = gain,
                notes = listOf(
                    Note(0.000, 0.11, 840.0, 760.0, 1.0, 38.0, 0.45)
                )
            )
            SoundPreset.CRYSTAL_BELL -> renderNotes(
                totalSec = 0.36, gain = gain,
                notes = listOf(
                    Note(0.000, 0.35, 2349.32, 2349.32, 0.85, 10.0, 0.22),
                    Note(0.000, 0.30, 3520.00, 3520.00, 0.35, 14.0, 0.0)
                )
            )
            SoundPreset.MARIMBA_UP -> renderNotes(
                totalSec = 0.26, gain = gain,
                notes = listOf(
                    Note(0.000, 0.10, 659.25, 659.25, 0.95, 20.0, 0.20),
                    Note(0.070, 0.11, 880.00, 880.00, 0.95, 18.0, 0.20),
                    Note(0.140, 0.12, 1174.66, 1174.66, 1.0, 18.0, 0.20)
                )
            )
            SoundPreset.MARIMBA_DONE -> renderNotes(
                totalSec = 0.25, gain = gain,
                notes = listOf(
                    Note(0.000, 0.11, 783.99, 783.99, 0.95, 20.0, 0.22),
                    Note(0.085, 0.16, 1046.50, 1046.50, 1.0, 15.0, 0.22)
                )
            )
            SoundPreset.PIANO_CHORD -> renderNotes(
                totalSec = 0.36, gain = gain,
                notes = listOf(
                    Note(0.000, 0.35, 523.25, 523.25, 0.45, 9.0, 0.25),
                    Note(0.015, 0.33, 659.25, 659.25, 0.45, 9.0, 0.25),
                    Note(0.030, 0.32, 783.99, 783.99, 0.50, 9.0, 0.25),
                    Note(0.045, 0.31, 1046.50, 1046.50, 0.55, 10.0, 0.20)
                )
            )
            SoundPreset.GLASS_PING -> renderNotes(
                totalSec = 0.30, gain = gain,
                notes = listOf(
                    Note(0.000, 0.28, 2637.02, 2637.02, 0.9, 13.0, 0.18)
                )
            )
            SoundPreset.SOFT_BEEP -> renderNotes(
                totalSec = 0.15, gain = gain,
                notes = listOf(
                    Note(0.000, 0.13, 987.77, 987.77, 0.9, 20.0, 0.05)
                )
            )
            SoundPreset.TECH_BLIP -> renderNotes(
                totalSec = 0.19, gain = gain,
                notes = listOf(
                    Note(0.000, 0.07, 880.0, 1320.0, 0.85, 26.0, 0.15),
                    Note(0.075, 0.10, 1320.0, 1760.0, 0.95, 22.0, 0.15)
                )
            )
            SoundPreset.COIN_GET -> renderNotes(
                totalSec = 0.30, gain = gain,
                notes = listOf(
                    Note(0.000, 0.085, 987.77, 987.77, 0.9, 16.0, 0.35),
                    Note(0.080, 0.220, 1318.51, 1318.51, 1.0, 11.0, 0.30)
                )
            )
            SoundPreset.SUCCESS_CHIME -> renderNotes(
                totalSec = 0.34, gain = gain,
                notes = listOf(
                    Note(0.000, 0.10, 880.00, 880.00, 0.85, 18.0, 0.20),
                    Note(0.080, 0.10, 1108.73, 1108.73, 0.90, 18.0, 0.20),
                    Note(0.160, 0.18, 1318.51, 1318.51, 1.0, 12.0, 0.22)
                )
            )
            SoundPreset.ZEN_BOWL -> renderNotes(
                totalSec = 0.48, gain = gain,
                notes = listOf(
                    Note(0.000, 0.47, 740.0, 740.0, 0.85, 6.5, 0.16),
                    Note(0.000, 0.40, 1484.0, 1484.0, 0.32, 9.5, 0.0)
                )
            )
            SoundPreset.KALIMBA -> renderNotes(
                totalSec = 0.28, gain = gain,
                notes = listOf(
                    Note(0.000, 0.16, 1046.50, 1046.50, 0.95, 14.0, 0.38),
                    Note(0.085, 0.19, 1567.98, 1567.98, 0.90, 13.0, 0.35)
                )
            )
            SoundPreset.SNAP_CLICK -> renderNotes(
                totalSec = 0.08, gain = gain,
                notes = listOf(
                    Note(0.000, 0.07, 1900.0, 680.0, 1.0, 58.0, 0.30)
                )
            )
            SoundPreset.WHISTLE_UP -> renderNotes(
                totalSec = 0.20, gain = gain,
                notes = listOf(
                    Note(0.000, 0.19, 1100.0, 2100.0, 0.9, 15.0, 0.05)
                )
            )
            SoundPreset.TINY_TICK -> renderNotes(
                totalSec = 0.07, gain = gain,
                notes = listOf(
                    Note(0.000, 0.06, 1480.0, 1480.0, 0.95, 55.0, 0.12)
                )
            )
        }
    }

    private data class Note(
        val startSec: Double,
        val durSec: Double,
        val freqStart: Double,
        val freqEnd: Double,
        val amp: Double,
        val decayRate: Double,
        val harmonic2: Double
    )

    private fun renderNotes(totalSec: Double, gain: Double, notes: List<Note>): ShortArray {
        val totalSamples = (totalSec * SAMPLE_RATE).toInt().coerceAtLeast(1)
        val mix = DoubleArray(totalSamples)

        for (n in notes) {
            val startIdx = (n.startSec * SAMPLE_RATE).toInt().coerceIn(0, totalSamples - 1)
            val lenSamples = (n.durSec * SAMPLE_RATE).toInt().coerceAtLeast(1)
            val endIdx = (startIdx + lenSamples).coerceAtMost(totalSamples)
            val attackSec = 0.004
            var phase = 0.0

            for (i in startIdx until endIdx) {
                val t = (i - startIdx).toDouble() / SAMPLE_RATE
                val frac = (t / n.durSec).coerceIn(0.0, 1.0)
                val freq = n.freqStart + (n.freqEnd - n.freqStart) * frac
                phase += 2.0 * PI * freq / SAMPLE_RATE

                val attackEnv = if (t < attackSec) (t / attackSec) else 1.0
                val releaseEnv = if (frac > 0.85) ((1.0 - frac) / 0.15) else 1.0
                val env = attackEnv * releaseEnv * exp(-n.decayRate * t)

                val wave = sin(phase) + n.harmonic2 * sin(phase * 2.0)
                mix[i] += wave * n.amp * env
            }
        }

        // 防削波归一化
        var peak = 1.0
        for (v in mix) {
            val av = kotlin.math.abs(v)
            if (av > peak) peak = av
        }
        val scale = (32767.0 * gain) / peak
        return ShortArray(totalSamples) { idx ->
            (mix[idx] * scale).toInt().coerceIn(-32767, 32767).toShort()
        }
    }
}
