package com.tvhelper.color

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

enum class MarkColor(val label: String) {
    RED("红"),
    BLUE("蓝")
}

object AppStore {
    private const val PREFS_NAME = "tv_color_helper_prefs"

    // 红蓝圆球设置
    private const val KEY_POS_X = "overlay_pos_x"
    private const val KEY_POS_Y = "overlay_pos_y"
    private const val KEY_BTN_DP = "overlay_btn_dp"
    private const val KEY_BTN_GAP_DP = "overlay_btn_gap_dp"
    private const val KEY_UNSELECTED_BRIGHTNESS = "overlay_unselected_brightness"
    private const val KEY_SELECTED_BRIGHTNESS = "overlay_selected_brightness"

    // 完活弹窗设置
    private const val KEY_DONE_TEXT = "done_text"
    private const val KEY_DONE_SIZE_SP = "done_size_sp"
    private const val KEY_DONE_GRAY_PCT = "done_gray_pct"
    private const val KEY_DONE_POS_X = "done_pos_x"
    private const val KEY_DONE_POS_Y = "done_pos_y"

    // 右侧信息提示设置
    private const val KEY_INFO_SIZE_SP = "info_size_sp"
    private const val KEY_INFO_GRAY_PCT = "info_gray_pct"
    private const val KEY_INFO_GAP_DP = "info_gap_dp"
    private const val KEY_INFO_POS_X = "info_pos_x"
    private const val KEY_INFO_POS_Y = "info_pos_y"

    // 记录
    private const val KEY_MISSED_RECORDS = "missed_records"

    private var prefs: SharedPreferences? = null
    private val queue = LinkedHashMap<String, MarkColor>()
    private val logs = ArrayList<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val dateTimeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (_: Exception) {
            }
        }
    }

    // ---------- 队列管理 ----------

    @Synchronized
    fun putSymbol(symbol: String, color: MarkColor) {
        val key = symbol.trim().uppercase(Locale.US)
        if (key.isEmpty()) return
        queue[key] = color
        log("队列记录：$key -> ${color.label}色（当前待办 ${queue.size} 个）")
        notifyListeners()
    }

    @Synchronized
    fun getSymbolColor(symbol: String?): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        return queue[symbol.trim().uppercase(Locale.US)]
    }

    @Synchronized
    fun hasPendingItems(): Boolean = queue.isNotEmpty()

    @Synchronized
    fun snapshotQueue(): LinkedHashMap<String, MarkColor> = LinkedHashMap(queue)

    @Synchronized
    fun removeSymbol(symbol: String) {
        queue.remove(symbol.trim().uppercase(Locale.US))
        notifyListeners()
    }

    @Synchronized
    fun clearQueue() {
        queue.clear()
        notifyListeners()
    }

    // ---------- 日志与漏项记录 ----------

    @Synchronized
    fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        logs.add(line)
        if (logs.size > 300) {
            logs.removeAt(0)
        }
        notifyListeners()
    }

    @Synchronized
    fun getLogsText(): String = logs.joinToString("\n")

    @Synchronized
    fun clearLogs() {
        logs.clear()
        notifyListeners()
    }

    fun addMissedRecord(message: String) {
        val p = prefs ?: return
        val timestamped = "[${dateTimeFmt.format(Date())}] $message"
        val existing = p.getString(KEY_MISSED_RECORDS, "") ?: ""
        val list = existing.split("\n").filter { it.isNotBlank() }.toMutableList()
        list.add(0, timestamped)
        while (list.size > 100) {
            list.removeAt(list.lastIndex)
        }
        p.edit().putString(KEY_MISSED_RECORDS, list.joinToString("\n")).apply()
        notifyListeners()
    }

    fun getMissedRecords(): String = prefs?.getString(KEY_MISSED_RECORDS, "") ?: ""

    fun clearMissedRecords() {
        prefs?.edit()?.remove(KEY_MISSED_RECORDS)?.apply()
        notifyListeners()
    }

    // ---------- 红蓝圆球设置 ----------

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_POS_X, x)?.putInt(KEY_POS_Y, y)?.apply()
    }

    fun getOverlayX(): Int = prefs?.getInt(KEY_POS_X, -1) ?: -1

    fun getOverlayY(): Int = prefs?.getInt(KEY_POS_Y, -1) ?: -1

    fun resetOverlayPosition() {
        prefs?.edit()?.remove(KEY_POS_X)?.remove(KEY_POS_Y)?.apply()
    }

    // 直径范围：30dp ~ 60dp
    fun getButtonDiameterDp(): Int = (prefs?.getInt(KEY_BTN_DP, 34) ?: 34).coerceIn(30, 60)

    fun setButtonDiameterDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_DP, dp.coerceIn(30, 60))?.apply()
    }

    // 两圆点间距：最小 5dp（即原版间距），最大 60dp
    fun getButtonGapDp(): Int = (prefs?.getInt(KEY_BTN_GAP_DP, 5) ?: 5).coerceIn(5, 60)

    fun setButtonGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_GAP_DP, dp.coerceIn(5, 60))?.apply()
    }

    // 选中前明暗度：10% ~ 100%
    fun getUnselectedBrightness(): Int = (prefs?.getInt(KEY_UNSELECTED_BRIGHTNESS, 45) ?: 45).coerceIn(10, 100)

    fun setUnselectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_UNSELECTED_BRIGHTNESS, pct.coerceIn(10, 100))?.apply()
    }

    // 选中后明暗度：20% ~ 100%
    fun getSelectedBrightness(): Int = (prefs?.getInt(KEY_SELECTED_BRIGHTNESS, 100) ?: 100).coerceIn(20, 100)

    fun setSelectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_SELECTED_BRIGHTNESS, pct.coerceIn(20, 100))?.apply()
    }

    // ---------- 完活弹窗设置 ----------

    fun getDoneText(): String {
        val raw = prefs?.getString(KEY_DONE_TEXT, "完活")?.trim()
        return if (raw.isNullOrEmpty()) "完活" else raw
    }

    fun setDoneText(text: String) {
        val v = text.trim().ifEmpty { "完活" }
        prefs?.edit()?.putString(KEY_DONE_TEXT, v)?.apply()
    }

    // 字体大小：20sp ~ 100sp
    fun getDoneSizeSp(): Int = (prefs?.getInt(KEY_DONE_SIZE_SP, 56) ?: 56).coerceIn(20, 100)

    fun setDoneSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SIZE_SP, sp.coerceIn(20, 100))?.apply()
    }

    // 灰度：15% ~ 100%（纯黑白灰度）
    fun getDoneGrayPct(): Int = (prefs?.getInt(KEY_DONE_GRAY_PCT, 90) ?: 90).coerceIn(15, 100)

    fun setDoneGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_DONE_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    fun saveDonePosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_DONE_POS_X, x)?.putInt(KEY_DONE_POS_Y, y)?.apply()
    }

    fun getDoneX(): Int = prefs?.getInt(KEY_DONE_POS_X, -1) ?: -1

    fun getDoneY(): Int = prefs?.getInt(KEY_DONE_POS_Y, -1) ?: -1

    fun resetDonePosition() {
        prefs?.edit()?.remove(KEY_DONE_POS_X)?.remove(KEY_DONE_POS_Y)?.apply()
    }

    // ---------- 右侧竖排信息提示设置 ----------

    // 字体大小：10sp ~ 40sp
    fun getInfoSizeSp(): Int = (prefs?.getInt(KEY_INFO_SIZE_SP, 16) ?: 16).coerceIn(10, 40)

    fun setInfoSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_INFO_SIZE_SP, sp.coerceIn(10, 40))?.apply()
    }

    // 灰度：15% ~ 100%（纯黑白灰度）
    fun getInfoGrayPct(): Int = (prefs?.getInt(KEY_INFO_GRAY_PCT, 85) ?: 85).coerceIn(15, 100)

    fun setInfoGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_INFO_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    // 品种名与红/蓝额外间距：0dp ~ 180dp（0dp 时默认保留 1 个空格最小间距）
    fun getInfoGapDp(): Int = (prefs?.getInt(KEY_INFO_GAP_DP, 0) ?: 0).coerceIn(0, 180)

    fun setInfoGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_INFO_GAP_DP, dp.coerceIn(0, 180))?.apply()
    }

    fun saveInfoPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_INFO_POS_X, x)?.putInt(KEY_INFO_POS_Y, y)?.apply()
    }

    fun getInfoX(): Int = prefs?.getInt(KEY_INFO_POS_X, -1) ?: -1

    fun getInfoY(): Int = prefs?.getInt(KEY_INFO_POS_Y, -1) ?: -1

    fun resetInfoPosition() {
        prefs?.edit()?.remove(KEY_INFO_POS_X)?.remove(KEY_INFO_POS_Y)?.apply()
    }
}
