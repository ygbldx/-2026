package com.tvhelper.color

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

enum class QuickJumpTargetType {
    COLOR_SLOT,
    CATALOG_TARGET
}

data class QuickJumpEntry(
    val id: String = UUID.randomUUID().toString(),
    val displayName: String,
    val targetType: QuickJumpTargetType = QuickJumpTargetType.CATALOG_TARGET,
    val colorSlotIndex: Int = 1,
    val watchlistId: String = "",
    val watchlistName: String = "",
    val categoryName: String = "",
    val targetSymbol: String = "",
    val fallbackSymbol: String = ""
)

enum class WheelPadDisplayMode(val id: String, val label: String) {
    BOTH("BOTH", "同时显示 ▲ 和 ▼"),
    UP_ONLY("UP_ONLY", "仅显示上三角 ▲（切前一个）"),
    DOWN_ONLY("DOWN_ONLY", "仅显示下三角 ▼（切后一个）")
}

enum class JumpFontStyle(val id: String, val label: String) {
    NORMAL("NORMAL", "常规"),
    BOLD("BOLD", "粗体"),
    LIGHT("LIGHT", "细体"),
    ITALIC("ITALIC", "斜体"),
    BOLD_ITALIC("BOLD_ITALIC", "粗斜体"),
    MONOSPACE("MONOSPACE", "等宽"),
    SERIF("SERIF", "衬线")
}

enum class MarkColor(
    val menuIndex: Int,
    val label: String,
    val baseR: Int,
    val baseG: Int,
    val baseB: Int
) {
    RED(0, "红", 247, 66, 74),
    BLUE(1, "蓝", 38, 108, 255),
    GREEN(2, "绿", 104, 198, 114),
    YELLOW(3, "黄", 245, 190, 48),
    PURPLE(4, "紫", 184, 104, 198),
    CYAN(5, "青", 10, 218, 242),
    PINK(6, "粉", 238, 138, 174)
}

/**
 * 绑定列表上下文的待添加任务（彻底解决 ASX / SAF 等跨市场同名品种串号问题）
 */
data class PendingTask(
    val key: String,
    val symbol: String,
    val color: MarkColor,
    val preferredWatchlistId: String = ""
)

data class UnaddedItem(
    val symbol: String,
    val color: MarkColor?,
    val message: String,
    val timestamp: String,
    val preferredWatchlistId: String = ""
)

data class UnknownCatalogCandidate(
    val symbol: String,
    var watchlistId: String = "",
    var watchlistName: String = "",
    var prevSymbol: String = "",
    var nextSymbol: String = "",
    val timestamp: String = ""
)

data class CalibrationResult(
    val watchlistId: String,
    val watchlistName: String,
    val observedSymbols: List<String>,
    val timestamp: String
)

object AppStore {
    private const val PREFS_NAME = "tv_color_helper_prefs"

    // APP 层面总开关与持久化队列
    private const val KEY_WORK_ENABLED = "app_work_enabled"
    private const val KEY_PENDING_POOL_JSON = "pending_pool_v2_json"

    // 高级速度与策略设置
    private const val KEY_CUSTOM_LP_MS = "custom_long_press_ms"
    private const val KEY_POST_TAP_COOLDOWN_MS = "post_tap_cooldown_ms"
    private const val KEY_SCROLL_DURATION_MS = "scroll_duration_ms"
    private const val KEY_DRAWER_SWITCH_PREFERRED = "drawer_switch_preferred"
    private const val KEY_OVERWRITE_DIFF_FLAG = "overwrite_diff_color_flag"
    private const val KEY_SKIP_FLAG_CHECK_TURBO = "skip_flag_check_turbo"

    // 颜色圆球设置
    private const val KEY_POS_X = "overlay_pos_x"
    private const val KEY_POS_Y = "overlay_pos_y"
    private const val KEY_BTN_DP = "overlay_btn_dp"
    private const val KEY_BTN_GAP_DP = "overlay_btn_gap_dp"
    private const val KEY_UNSELECTED_BRIGHTNESS = "overlay_unselected_brightness"
    private const val KEY_SELECTED_BRIGHTNESS = "overlay_selected_brightness"
    private const val KEY_SELECTED_WHITE_RING = "overlay_selected_white_ring"
    private const val KEY_BALL_BADGE_ENABLED = "overlay_ball_badge_enabled"
    private const val KEY_ENABLED_COLORS = "overlay_enabled_colors"

    // 图表页圆球关闭服务方式（可多选）
    private const val KEY_BALL_EXIT_DOUBLE_TAP = "ball_exit_double_tap"
    private const val KEY_BALL_EXIT_SWIPE_RIGHT = "ball_exit_swipe_right"
    private const val KEY_BALL_EXIT_SWIPE_ANY = "ball_exit_swipe_any"

    // 完活弹窗与提示音设置
    private const val KEY_DONE_TEXT = "done_text"
    private const val KEY_DONE_SIZE_SP = "done_size_sp"
    private const val KEY_DONE_GRAY_PCT = "done_gray_pct"
    private const val KEY_DONE_POS_X = "done_pos_x"
    private const val KEY_DONE_POS_Y = "done_pos_y"
    private const val KEY_DONE_SOUND_ENABLED = "done_sound_enabled"
    private const val KEY_DONE_SOUND_ID = "done_sound_id"
    private const val KEY_DONE_SOUND_VOLUME = "done_sound_volume"

    // 独立新功能：点探索栏快捷列表直达（与原标色开关完全隔离）
    private const val KEY_EXPLORE_JUMP_ENABLED = "explore_jump_enabled"
    private const val KEY_JUMP_FONT_SIZE_SP = "jump_font_size_sp"
    private const val KEY_JUMP_FONT_STYLE = "jump_font_style"
    private const val KEY_JUMP_FONT_GRAY_PCT = "jump_font_gray_pct"
    private const val KEY_JUMP_FONT_OPACITY_PCT = "jump_font_opacity_pct"
    private const val KEY_JUMP_BG_OPACITY_PCT = "jump_bg_opacity_pct"
    private const val KEY_QUICK_JUMP_ENTRIES_JSON = "quick_jump_entries_v2_json"

    // 独立第三功能：图表滚轮上下切图按钮（▲/▼，与前两个功能完全隔离）
    private const val KEY_WHEEL_PAD_ENABLED = "wheel_pad_enabled"
    private const val KEY_WHEEL_PAD_MODE = "wheel_pad_mode"
    private const val KEY_WHEEL_PAD_SIZE_DP = "wheel_pad_size_dp"
    private const val KEY_WHEEL_PAD_BRIGHTNESS_PCT = "wheel_pad_brightness_pct"
    private const val KEY_WHEEL_PAD_OPACITY_PCT = "wheel_pad_opacity_pct"
    private const val KEY_WHEEL_PAD_GAP_DP = "wheel_pad_gap_dp"
    private const val KEY_WHEEL_PAD_CENTER_X_FRAC = "wheel_pad_center_x_frac"
    private const val KEY_WHEEL_PAD_CENTER_Y_FRAC = "wheel_pad_center_y_frac"
    private const val KEY_WHEEL_PAD_STEP_PERMILLE = "wheel_pad_step_permille"
    private const val KEY_WHEEL_PAD_DRAG_MS = "wheel_pad_drag_ms"
    private const val KEY_WHEEL_PAD_TOPLEFT_TRIGGER = "wheel_pad_topleft_trigger"
    private const val KEY_MIGRATED_V730 = "migrated_v730_defaults_v1" 

    // 记录
    private const val KEY_MISSED_RECORDS = "missed_records"
    private const val KEY_UNADDED_ITEMS_JSON = "unadded_items_json"
    private const val KEY_UNKNOWN_CANDIDATES_JSON = "unknown_candidates_json"

    private var appContext: Context? = null
    private var prefs: SharedPreferences? = null
    private val tasks = LinkedHashMap<String, PendingTask>()
    private val unaddedItems = ArrayList<UnaddedItem>()
    private val unknownCandidates = ArrayList<UnknownCatalogCandidate>()
    private val quickJumpEntries = ArrayList<QuickJumpEntry>()
    private val sessionMarked = LinkedHashMap<String, MarkColor>()
    @Volatile
    private var calibrationArmed = false
    @Volatile
    private var pendingCalibrationResult: CalibrationResult? = null
    private val logs = ArrayList<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val queueCountListeners = CopyOnWriteArrayList<(Int) -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val dateTimeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    @Synchronized
    fun init(context: Context) {
        val ctx = context.applicationContext
        if (appContext == null) {
            appContext = ctx
        }
        if (prefs == null) {
            prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            CatalogRepository.init(ctx)
            loadTasksLocked()
            loadUnaddedLocked()
            loadUnknownCandidatesLocked()
            loadQuickJumpEntriesLocked()
            applyOneTimeV730MigrationLocked()
        } else {
            CatalogRepository.init(ctx)
        }
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun addQueueCountListener(listener: (Int) -> Unit) {
        queueCountListeners.add(listener)
    }

    fun removeQueueCountListener(listener: (Int) -> Unit) {
        queueCountListeners.remove(listener)
    }

    private fun notifyQueueCountChanged() {
        val count = tasks.size
        for (l in queueCountListeners) {
            try {
                l(count)
            } catch (_: Exception) {
            }
        }
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (_: Exception) {
            }
        }
    }

    // ---------- APP 层面总开关 ----------

    fun isWorkEnabled(): Boolean = prefs?.getBoolean(KEY_WORK_ENABLED, true) ?: true

    fun setWorkEnabled(context: Context?, enabled: Boolean, source: String = "开关") {
        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) init(ctx)
        val prev = isWorkEnabled()
        prefs?.edit()?.putBoolean(KEY_WORK_ENABLED, enabled)?.apply()

        if (!enabled) {
            clearQueueInternal(silent = true)
            sessionMarked.clear()
            calibrationArmed = false
            if (prev) {
                log("服务开关(${source})：已关闭，待添加品种池已清空（系统无障碍保持常驻）")
            }
        } else if (!prev) {
            log("服务开关(${source})：已开启")
        }

        if (ctx != null) {
            WorkTileService.requestTileSync(ctx)
        }
        TvAccessibilityService.instance?.onWorkEnabledChanged(enabled)
        notifyListeners()
    }

    // ---------- 高级速度与策略参数 ----------

    fun getCustomLongPressMs(): Long = (prefs?.getLong(KEY_CUSTOM_LP_MS, 730L) ?: 730L).coerceIn(550L, 950L)

    fun setCustomLongPressMs(ms: Long) {
        prefs?.edit()?.putLong(KEY_CUSTOM_LP_MS, ms.coerceIn(550L, 950L))?.apply()
    }

    fun getPostTapCooldownMs(): Long = (prefs?.getLong(KEY_POST_TAP_COOLDOWN_MS, 300L) ?: 300L).coerceIn(200L, 650L)

    fun setPostTapCooldownMs(ms: Long) {
        prefs?.edit()?.putLong(KEY_POST_TAP_COOLDOWN_MS, ms.coerceIn(200L, 650L))?.apply()
    }

    fun getScrollDurationMs(): Long = (prefs?.getLong(KEY_SCROLL_DURATION_MS, 125L) ?: 125L).coerceIn(80L, 240L)

    fun setScrollDurationMs(ms: Long) {
        prefs?.edit()?.putLong(KEY_SCROLL_DURATION_MS, ms.coerceIn(80L, 240L))?.apply()
    }

    fun isDrawerSwitchPreferred(): Boolean = prefs?.getBoolean(KEY_DRAWER_SWITCH_PREFERRED, true) ?: true

    fun setDrawerSwitchPreferred(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_DRAWER_SWITCH_PREFERRED, enabled)?.apply()
    }

    fun isOverwriteDifferentColorFlag(): Boolean = prefs?.getBoolean(KEY_OVERWRITE_DIFF_FLAG, false) ?: false

    fun setOverwriteDifferentColorFlag(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_OVERWRITE_DIFF_FLAG, enabled)?.apply()
    }

    fun isSkipFlagCheckTurbo(): Boolean = prefs?.getBoolean(KEY_SKIP_FLAG_CHECK_TURBO, false) ?: false

    fun setSkipFlagCheckTurbo(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_SKIP_FLAG_CHECK_TURBO, enabled)?.apply()
    }

    fun resetSpeedDefaults() {
        prefs?.edit()
            ?.putLong(KEY_CUSTOM_LP_MS, 730L)
            ?.putLong(KEY_POST_TAP_COOLDOWN_MS, 300L)
            ?.putLong(KEY_SCROLL_DURATION_MS, 125L)
            ?.putBoolean(KEY_DRAWER_SWITCH_PREFERRED, true)
            ?.putBoolean(KEY_OVERWRITE_DIFF_FLAG, false)
            ?.putBoolean(KEY_SKIP_FLAG_CHECK_TURBO, false)
            ?.apply()
        notifyListeners()
    }

    // ---------- 上下文绑定的待添加品种池（防 ASX / SAF 跨市场同名串号） ----------

    private fun resolveLockedWatchlistId(symbol: String, contextWatchlistId: String?): String {
        val locs = CatalogRepository.findLocations(symbol)
        if (locs.isEmpty()) return ""
        val uniqueWlIds = locs.map { it.watchlistId }.distinct()
        if (uniqueWlIds.size == 1) return uniqueWlIds[0]
        if (!contextWatchlistId.isNullOrBlank() && contextWatchlistId in uniqueWlIds) {
            return contextWatchlistId
        }
        return ""
    }

    fun makeTaskKey(symbol: String, preferredWatchlistId: String): String {
        val sym = symbol.trim().uppercase(Locale.US)
        return if (preferredWatchlistId.isNotBlank()) "$preferredWatchlistId::$sym" else "ANY::$sym"
    }

    @Synchronized
    fun putTask(symbol: String, color: MarkColor, contextWatchlistId: String? = null): PendingTask? {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        if (cleanSym.isEmpty()) return null
        val lockedWlId = resolveLockedWatchlistId(cleanSym, contextWatchlistId)
        val key = makeTaskKey(cleanSym, lockedWlId)
        val task = PendingTask(key = key, symbol = cleanSym, color = color, preferredWatchlistId = lockedWlId)
        tasks[key] = task
        persistTasksLocked()
        val wlLabel = if (lockedWlId.isNotEmpty()) {
            CatalogRepository.getWatchlistById(lockedWlId)?.name?.let { "[$it]" }.orEmpty()
        } else ""
        log("待添加池记录：$cleanSym$wlLabel -> ${color.label}色（池内 ${tasks.size} 个）")
        notifyListeners()
        return task
    }

    @Synchronized
    fun getTaskColorForChart(symbol: String?, contextWatchlistId: String? = null): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        val cleanSym = symbol.trim().uppercase(Locale.US)
        val lockedWlId = resolveLockedWatchlistId(cleanSym, contextWatchlistId)
        val exactKey = makeTaskKey(cleanSym, lockedWlId)
        tasks[exactKey]?.let { return it.color }
        if (lockedWlId.isNotEmpty()) {
            tasks[makeTaskKey(cleanSym, "")]?.let { return it.color }
        }
        return tasks.values.firstOrNull { it.symbol == cleanSym }?.color
    }

    @Synchronized
    fun removeTaskForChart(symbol: String, contextWatchlistId: String? = null): Boolean {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        val lockedWlId = resolveLockedWatchlistId(cleanSym, contextWatchlistId)
        val exactKey = makeTaskKey(cleanSym, lockedWlId)
        var removed = tasks.remove(exactKey) != null
        if (!removed) {
            val fallbackKey = tasks.values.firstOrNull { it.symbol == cleanSym }?.key
            if (fallbackKey != null) {
                removed = tasks.remove(fallbackKey) != null
            }
        }
        if (removed) {
            persistTasksLocked()
            notifyListeners()
        }
        return removed
    }

    @Synchronized
    fun removeTaskByKey(key: String): Boolean {
        val removed = tasks.remove(key) != null
        if (removed) {
            persistTasksLocked()
            notifyListeners()
        }
        return removed
    }

    @Synchronized
    fun getTaskByKey(key: String): PendingTask? = tasks[key]

    @Synchronized
    fun hasPendingItems(): Boolean = tasks.isNotEmpty()

    @Synchronized
    fun pendingCount(): Int = tasks.size

    @Synchronized
    fun snapshotTasks(): List<PendingTask> = tasks.values.toList()

    @Synchronized
    fun clearQueue() {
        clearQueueInternal(silent = false)
    }

    @Synchronized
    private fun clearQueueInternal(silent: Boolean) {
        tasks.clear()
        persistTasksLocked()
        if (!silent) {
            notifyListeners()
        }
    }

    private fun persistTasksLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (t in tasks.values) {
            val obj = JSONObject()
            obj.put("k", t.key)
            obj.put("s", t.symbol)
            obj.put("c", t.color.name)
            obj.put("w", t.preferredWatchlistId)
            arr.put(obj)
        }
        p.edit().putString(KEY_PENDING_POOL_JSON, arr.toString()).apply()
        notifyQueueCountChanged()
    }

    private fun loadTasksLocked() {
        tasks.clear()
        if (!isWorkEnabled()) {
            persistTasksLocked()
            return
        }
        val raw = prefs?.getString(KEY_PENDING_POOL_JSON, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val sym = obj.optString("s", "").trim().uppercase(Locale.US)
                val col = MarkColor.values().firstOrNull { it.name == obj.optString("c", "") } ?: continue
                val wid = obj.optString("w", "")
                val key = obj.optString("k", "").ifBlank { makeTaskKey(sym, wid) }
                if (sym.isNotEmpty()) {
                    tasks[key] = PendingTask(key, sym, col, wid)
                }
            }
        } catch (_: Exception) {
        }
    }


    // ---------- 单条任务编辑（支持在 APP 首页直接改色/改目标列表） ----------

    @Synchronized
    fun updateTaskColor(key: String, newColor: MarkColor) {
        val old = tasks[key] ?: return
        tasks[key] = old.copy(color = newColor)
        persistTasksLocked()
        log("修改待办颜色：${old.symbol} -> ${newColor.label}色")
        notifyListeners()
    }

    @Synchronized
    fun updateTaskWatchlist(key: String, newWatchlistId: String) {
        val old = tasks.remove(key) ?: return
        val newKey = makeTaskKey(old.symbol, newWatchlistId)
        tasks[newKey] = old.copy(key = newKey, preferredWatchlistId = newWatchlistId)
        persistTasksLocked()
        val wlName = if (newWatchlistId.isNotEmpty()) CatalogRepository.getWatchlistById(newWatchlistId)?.name ?: "未知" else "自动匹配"
        log("修改目标列表：${old.symbol} -> $wlName")
        notifyListeners()
    }

    // ---------- 单条未找到提醒操作 ----------

    @Synchronized
    fun getUnaddedItems(): List<UnaddedItem> = unaddedItems.toList()

    @Synchronized
    fun requeueSingleUnadded(index: Int): Boolean {
        if (index !in unaddedItems.indices) return false
        val item = unaddedItems[index]
        if (item.symbol.isEmpty() || item.color == null) return false
        val resolved = CatalogRepository.resolveChartSymbolInCatalog(item.symbol, item.preferredWatchlistId.ifBlank { null }) ?: item.symbol
        val lockedWlId = resolveLockedWatchlistId(resolved, item.preferredWatchlistId.ifBlank { null })
        val key = makeTaskKey(resolved, lockedWlId)
        tasks[key] = PendingTask(key, resolved, item.color, lockedWlId)
        unaddedItems.removeAt(index)
        persistTasksLocked()
        persistUnaddedLocked()
        log("单条重试加入待添加池：$resolved -> ${item.color.label}色")
        notifyListeners()
        return true
    }

    @Synchronized
    fun removeSingleUnadded(index: Int) {
        if (index !in unaddedItems.indices) return
        unaddedItems.removeAt(index)
        persistUnaddedLocked()
        notifyListeners()
    }

    // ---------- 本轮已标色记忆（防止长复盘重复标色） ----------

    @Synchronized
    fun recordSessionMarked(symbol: String, color: MarkColor, watchlistId: String = "") {
        val clean = symbol.trim().uppercase(Locale.US)
        if (clean.isEmpty()) return
        val key = makeTaskKey(clean, resolveLockedWatchlistId(clean, watchlistId.ifBlank { null }))
        sessionMarked[key] = color
        if (sessionMarked.size > 300) {
            val firstKey = sessionMarked.keys.firstOrNull()
            if (firstKey != null) sessionMarked.remove(firstKey)
        }
        notifyListeners()
    }

    @Synchronized
    fun getSessionMarkedColor(symbol: String?, contextWatchlistId: String? = null): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        val clean = symbol.trim().uppercase(Locale.US)
        val locked = resolveLockedWatchlistId(clean, contextWatchlistId)
        sessionMarked[makeTaskKey(clean, locked)]?.let { return it }
        if (locked.isNotEmpty()) {
            sessionMarked[makeTaskKey(clean, "")]?.let { return it }
        }
        return null
    }

    @Synchronized
    fun sessionMarkedCount(): Int = sessionMarked.size

    @Synchronized
    fun clearSessionMarked() {
        sessionMarked.clear()
        notifyListeners()
    }

    // ---------- TV 自动采集/校准列表模式 ----------

    fun isCalibrationArmed(): Boolean = calibrationArmed

    fun armCalibrationMode() {
        calibrationArmed = true
        pendingCalibrationResult = null
        log("已启动 TV 列表自动采集模式：请切回 TradingView 目标自选表")
        notifyListeners()
    }

    fun cancelCalibrationMode() {
        calibrationArmed = false
        notifyListeners()
    }

    fun submitCalibrationResult(watchlistId: String, watchlistName: String, symbols: List<String>) {
        calibrationArmed = false
        pendingCalibrationResult = CalibrationResult(
            watchlistId = watchlistId,
            watchlistName = watchlistName,
            observedSymbols = symbols,
            timestamp = dateTimeFmt.format(Date())
        )
        log("TV列表采集完成：[$watchlistName] 共捕获 ${symbols.size} 个品种，回《品种大全》确认合并")
        notifyListeners()
    }

    fun peekCalibrationResult(): CalibrationResult? = pendingCalibrationResult

    fun consumeCalibrationResult(): CalibrationResult? {
        val r = pendingCalibrationResult
        pendingCalibrationResult = null
        notifyListeners()
        return r
    }

    // ---------- 日志与APP消息记录 ----------

    @Synchronized
    fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        logs.add(line)
        if (logs.size > 300) {
            logs.removeAt(0)
        }
        notifyListeners()
    }

    @Synchronized
    fun getLogsText(): String = logs.joinToString("\n")

    @Synchronized
    fun clearLogs() {
        logs.clear()
        notifyListeners()
    }

    @Synchronized
    fun addUnaddedItem(
        symbol: String,
        color: MarkColor?,
        message: String,
        preferredWatchlistId: String = ""
    ) {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        val ts = dateTimeFmt.format(Date())
        if (cleanSym.isNotEmpty()) {
            unaddedItems.removeAll { it.symbol == cleanSym && it.preferredWatchlistId == preferredWatchlistId }
        }
        unaddedItems.add(0, UnaddedItem(cleanSym, color, message, ts, preferredWatchlistId))
        while (unaddedItems.size > 100) {
            unaddedItems.removeAt(unaddedItems.lastIndex)
        }
        persistUnaddedLocked()
        notifyListeners()
    }

    @Synchronized
    fun countRetryableUnadded(): Int = unaddedItems.count { it.symbol.isNotEmpty() && it.color != null }

    @Synchronized
    fun requeueAllUnadded(): Int {
        var addedCount = 0
        val remaining = ArrayList<UnaddedItem>()
        for (item in unaddedItems) {
            if (item.symbol.isNotEmpty() && item.color != null) {
                val resolved = CatalogRepository.resolveChartSymbolInCatalog(item.symbol, item.preferredWatchlistId.ifBlank { null }) ?: item.symbol
                val lockedWlId = resolveLockedWatchlistId(resolved, item.preferredWatchlistId.ifBlank { null })
                val key = makeTaskKey(resolved, lockedWlId)
                tasks[key] = PendingTask(key, resolved, item.color, lockedWlId)
                addedCount++
            } else {
                remaining.add(item)
            }
        }
        if (addedCount > 0) {
            unaddedItems.clear()
            unaddedItems.addAll(remaining)
            persistTasksLocked()
            persistUnaddedLocked()
            log("一键重新加入待添加池：$addedCount 个品种（当前待办池共 ${tasks.size} 个）")
            notifyListeners()
        }
        return addedCount
    }

    @Synchronized
    fun getMissedRecords(): String {
        if (unaddedItems.isEmpty()) return ""
        return unaddedItems.joinToString("\n") { "[${it.timestamp}] ${it.message}" }
    }

    @Synchronized
    fun clearMissedRecords() {
        unaddedItems.clear()
        prefs?.edit()?.remove(KEY_MISSED_RECORDS)?.remove(KEY_UNADDED_ITEMS_JSON)?.apply()
        notifyListeners()
    }

    private fun persistUnaddedLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (it in unaddedItems) {
            val obj = JSONObject()
            obj.put("s", it.symbol)
            obj.put("c", it.color?.name ?: "")
            obj.put("m", it.message)
            obj.put("t", it.timestamp)
            obj.put("w", it.preferredWatchlistId)
            arr.put(obj)
        }
        p.edit().putString(KEY_UNADDED_ITEMS_JSON, arr.toString()).apply()
    }

    private fun loadUnaddedLocked() {
        unaddedItems.clear()
        val raw = prefs?.getString(KEY_UNADDED_ITEMS_JSON, null)
        if (!raw.isNullOrBlank()) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val sym = obj.optString("s", "").trim().uppercase(Locale.US)
                    val col = MarkColor.values().firstOrNull { it.name == obj.optString("c", "") }
                    val msg = obj.optString("m", "")
                    val ts = obj.optString("t", "")
                    val wid = obj.optString("w", "")
                    if (msg.isNotBlank()) {
                        unaddedItems.add(UnaddedItem(sym, col, msg, ts, wid))
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    // ---------- 不在《品种大全》的品种观察与一键写入 ----------

    @Synchronized
    fun recordUnknownSymbol(
        symbol: String,
        watchlistId: String = "",
        watchlistName: String = "",
        prevSymbol: String = "",
        nextSymbol: String = ""
    ) {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        if (cleanSym.isEmpty()) return
        if (CatalogRepository.resolveChartSymbolInCatalog(cleanSym) != null) return

        val existing = unknownCandidates.firstOrNull { it.symbol == cleanSym }
        val ts = dateTimeFmt.format(Date())
        if (existing != null) {
            if (watchlistId.isNotEmpty()) {
                existing.watchlistId = watchlistId
                existing.watchlistName = watchlistName
            }
            if (prevSymbol.isNotEmpty() || nextSymbol.isNotEmpty()) {
                existing.prevSymbol = prevSymbol.trim().uppercase(Locale.US)
                existing.nextSymbol = nextSymbol.trim().uppercase(Locale.US)
            }
        } else {
            unknownCandidates.add(
                0,
                UnknownCatalogCandidate(
                    symbol = cleanSym,
                    watchlistId = watchlistId,
                    watchlistName = watchlistName,
                    prevSymbol = prevSymbol.trim().uppercase(Locale.US),
                    nextSymbol = nextSymbol.trim().uppercase(Locale.US),
                    timestamp = ts
                )
            )
            while (unknownCandidates.size > 80) {
                unknownCandidates.removeAt(unknownCandidates.lastIndex)
            }
        }
        persistUnknownCandidatesLocked()
        notifyListeners()
    }

    @Synchronized
    fun getUnknownCandidates(): List<UnknownCatalogCandidate> {
        val removed = unknownCandidates.removeAll { CatalogRepository.findLocations(it.symbol).isNotEmpty() }
        if (removed) persistUnknownCandidatesLocked()
        return unknownCandidates.map { it.copy() }
    }

    @Synchronized
    fun removeUnknownCandidate(symbol: String) {
        val clean = symbol.trim().uppercase(Locale.US)
        if (unknownCandidates.removeAll { it.symbol == clean }) {
            persistUnknownCandidatesLocked()
            notifyListeners()
        }
    }

    @Synchronized
    fun clearUnknownCandidates() {
        unknownCandidates.clear()
        persistUnknownCandidatesLocked()
        notifyListeners()
    }

    private fun persistUnknownCandidatesLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (c in unknownCandidates) {
            val obj = JSONObject()
            obj.put("s", c.symbol)
            obj.put("wid", c.watchlistId)
            obj.put("wn", c.watchlistName)
            obj.put("prev", c.prevSymbol)
            obj.put("next", c.nextSymbol)
            obj.put("t", c.timestamp)
            arr.put(obj)
        }
        p.edit().putString(KEY_UNKNOWN_CANDIDATES_JSON, arr.toString()).apply()
    }

    private fun loadUnknownCandidatesLocked() {
        unknownCandidates.clear()
        val raw = prefs?.getString(KEY_UNKNOWN_CANDIDATES_JSON, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val sym = obj.optString("s", "").trim().uppercase(Locale.US)
                if (sym.isNotEmpty()) {
                    unknownCandidates.add(
                        UnknownCatalogCandidate(
                            symbol = sym,
                            watchlistId = obj.optString("wid", ""),
                            watchlistName = obj.optString("wn", ""),
                            prevSymbol = obj.optString("prev", ""),
                            nextSymbol = obj.optString("next", ""),
                            timestamp = obj.optString("t", "")
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
    }

    // ---------- 颜色圆球设置 ----------

    fun getEnabledColors(): List<MarkColor> {
        val raw = prefs?.getString(KEY_ENABLED_COLORS, null)
        if (raw.isNullOrBlank()) {
            return listOf(MarkColor.RED, MarkColor.BLUE)
        }
        val names = raw.split(",").toSet()
        val list = MarkColor.values().filter { it.name in names }
        return if (list.isEmpty()) listOf(MarkColor.RED) else list
    }

    fun setColorEnabled(color: MarkColor, enabled: Boolean): Boolean {
        val current = getEnabledColors().toMutableSet()
        if (enabled) {
            current.add(color)
        } else {
            if (current.size <= 1 && color in current) return false
            current.remove(color)
        }
        val ordered = MarkColor.values().filter { it in current }.joinToString(",") { it.name }
        prefs?.edit()?.putString(KEY_ENABLED_COLORS, ordered)?.apply()
        return true
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_POS_X, x)?.putInt(KEY_POS_Y, y)?.apply()
    }

    fun getOverlayX(): Int = prefs?.getInt(KEY_POS_X, -1) ?: -1

    fun getOverlayY(): Int = prefs?.getInt(KEY_POS_Y, -1) ?: -1

    fun resetOverlayPosition() {
        prefs?.edit()?.remove(KEY_POS_X)?.remove(KEY_POS_Y)?.apply()
    }

    fun getButtonDiameterDp(): Int = (prefs?.getInt(KEY_BTN_DP, 60) ?: 60).coerceIn(30, 80)

    fun setButtonDiameterDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_DP, dp.coerceIn(30, 80))?.apply()
    }

    fun getButtonGapDp(): Int = (prefs?.getInt(KEY_BTN_GAP_DP, 12) ?: 12).coerceIn(5, 60)

    fun setButtonGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_GAP_DP, dp.coerceIn(5, 60))?.apply()
    }

    fun getUnselectedBrightness(): Int = (prefs?.getInt(KEY_UNSELECTED_BRIGHTNESS, 60) ?: 60).coerceIn(10, 100)

    fun setUnselectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_UNSELECTED_BRIGHTNESS, pct.coerceIn(10, 100))?.apply()
    }

    fun getSelectedBrightness(): Int = (prefs?.getInt(KEY_SELECTED_BRIGHTNESS, 100) ?: 100).coerceIn(20, 100)

    fun setSelectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_SELECTED_BRIGHTNESS, pct.coerceIn(20, 100))?.apply()
    }

    fun resetBallAppearanceDefaults() {
        prefs?.edit()
            ?.putInt(KEY_BTN_DP, 60)
            ?.putInt(KEY_BTN_GAP_DP, 12)
            ?.putInt(KEY_UNSELECTED_BRIGHTNESS, 60)
            ?.putInt(KEY_SELECTED_BRIGHTNESS, 100)
            ?.putBoolean(KEY_SELECTED_WHITE_RING, true)
            ?.putBoolean(KEY_BALL_BADGE_ENABLED, true)
            ?.apply()
        notifyListeners()
    }

    fun isSelectedWhiteRingEnabled(): Boolean = prefs?.getBoolean(KEY_SELECTED_WHITE_RING, true) ?: true

    fun setSelectedWhiteRingEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_SELECTED_WHITE_RING, enabled)?.apply()
    }

    fun isBallBadgeEnabled(): Boolean = prefs?.getBoolean(KEY_BALL_BADGE_ENABLED, true) ?: true

    fun setBallBadgeEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_BADGE_ENABLED, enabled)?.apply()
    }

    fun isBallExitDoubleTap(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_DOUBLE_TAP, false) ?: false

    fun setBallExitDoubleTap(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_DOUBLE_TAP, enabled)?.apply()
    }

    fun isBallExitSwipeRight(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_SWIPE_RIGHT, false) ?: false

    fun setBallExitSwipeRight(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_SWIPE_RIGHT, enabled)?.apply()
    }

    fun isBallExitSwipeAny(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_SWIPE_ANY, true) ?: true

    fun setBallExitSwipeAny(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_SWIPE_ANY, enabled)?.apply()
    }

    // ---------- 完活弹窗与提示音设置 ----------

    fun getDoneText(): String {
        val raw = prefs?.getString(KEY_DONE_TEXT, "完活")?.trim()
        return if (raw.isNullOrEmpty()) "完活" else raw
    }

    fun setDoneText(text: String) {
        val v = text.trim().ifEmpty { "完活" }
        prefs?.edit()?.putString(KEY_DONE_TEXT, v)?.apply()
    }

    fun getDoneSizeSp(): Int = (prefs?.getInt(KEY_DONE_SIZE_SP, 56) ?: 56).coerceIn(20, 100)

    fun setDoneSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SIZE_SP, sp.coerceIn(20, 100))?.apply()
    }

    fun getDoneGrayPct(): Int = (prefs?.getInt(KEY_DONE_GRAY_PCT, 90) ?: 90).coerceIn(15, 100)

    fun setDoneGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_DONE_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    fun saveDonePosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_DONE_POS_X, x)?.putInt(KEY_DONE_POS_Y, y)?.apply()
    }

    fun getDoneX(): Int = prefs?.getInt(KEY_DONE_POS_X, -1) ?: -1

    fun getDoneY(): Int = prefs?.getInt(KEY_DONE_POS_Y, -1) ?: -1

    fun resetDonePosition() {
        prefs?.edit()?.remove(KEY_DONE_POS_X)?.remove(KEY_DONE_POS_Y)?.apply()
    }

    fun isDoneSoundEnabled(): Boolean = prefs?.getBoolean(KEY_DONE_SOUND_ENABLED, true) ?: true

    fun setDoneSoundEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_DONE_SOUND_ENABLED, enabled)?.apply()
    }

    fun getDoneSoundId(): String = prefs?.getString(KEY_DONE_SOUND_ID, SoundPreset.WECHAT.id) ?: SoundPreset.WECHAT.id

    fun setDoneSoundId(id: String) {
        prefs?.edit()?.putString(KEY_DONE_SOUND_ID, id)?.apply()
    }

    fun getDoneSoundVolume(): Int = (prefs?.getInt(KEY_DONE_SOUND_VOLUME, 75) ?: 75).coerceIn(0, 100)

    fun setDoneSoundVolume(vol: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SOUND_VOLUME, vol.coerceIn(0, 100))?.apply()
    }

    // ---------- 独立新功能：点探索栏快捷列表直达开关与黑白外观设置 ----------

    fun isExploreJumpEnabled(): Boolean = prefs?.getBoolean(KEY_EXPLORE_JUMP_ENABLED, true) ?: true

    fun setExploreJumpEnabled(context: Context?, enabled: Boolean, source: String = "列表快切开关") {
        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) init(ctx)
        val prev = isExploreJumpEnabled()
        prefs?.edit()?.putBoolean(KEY_EXPLORE_JUMP_ENABLED, enabled)?.apply()
        if (prev != enabled) {
            log("列表快切开关($source)：${if (enabled) "已开启" else "已关闭"}")
        }
        if (ctx != null) {
            ExploreJumpTileService.requestTileSync(ctx)
        }
        TvAccessibilityService.instance?.onExploreJumpEnabledChanged(enabled)
        notifyListeners()
    }

    fun getJumpFontSizeSp(): Int = (prefs?.getInt(KEY_JUMP_FONT_SIZE_SP, 17) ?: 17).coerceIn(12, 32)

    fun setJumpFontSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_JUMP_FONT_SIZE_SP, sp.coerceIn(12, 32))?.apply()
    }

    fun getJumpFontStyle(): JumpFontStyle {
        val id = prefs?.getString(KEY_JUMP_FONT_STYLE, JumpFontStyle.BOLD.id) ?: JumpFontStyle.BOLD.id
        return JumpFontStyle.values().firstOrNull { it.id == id } ?: JumpFontStyle.BOLD
    }

    fun setJumpFontStyle(style: JumpFontStyle) {
        prefs?.edit()?.putString(KEY_JUMP_FONT_STYLE, style.id)?.apply()
    }

    fun getJumpFontGrayPct(): Int = (prefs?.getInt(KEY_JUMP_FONT_GRAY_PCT, 92) ?: 92).coerceIn(0, 100)

    fun setJumpFontGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_JUMP_FONT_GRAY_PCT, pct.coerceIn(0, 100))?.apply()
    }

    fun getJumpFontOpacityPct(): Int = (prefs?.getInt(KEY_JUMP_FONT_OPACITY_PCT, 100) ?: 100).coerceIn(10, 100)

    fun setJumpFontOpacityPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_JUMP_FONT_OPACITY_PCT, pct.coerceIn(10, 100))?.apply()
    }

    fun getJumpBgOpacityPct(): Int = (prefs?.getInt(KEY_JUMP_BG_OPACITY_PCT, 88) ?: 88).coerceIn(0, 100)

    fun setJumpBgOpacityPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_JUMP_BG_OPACITY_PCT, pct.coerceIn(0, 100))?.apply()
    }

    fun resetJumpStyleDefaults() {
        prefs?.edit()
            ?.putInt(KEY_JUMP_FONT_SIZE_SP, 17)
            ?.putString(KEY_JUMP_FONT_STYLE, JumpFontStyle.BOLD.id)
            ?.putInt(KEY_JUMP_FONT_GRAY_PCT, 92)
            ?.putInt(KEY_JUMP_FONT_OPACITY_PCT, 100)
            ?.putInt(KEY_JUMP_BG_OPACITY_PCT, 88)
            ?.apply()
        notifyListeners()
    }

    // ---------- 快切列表项自定义管理（排序 / 新增 / 删除 / 改名 / 目标列表·细类别·品种定位） ----------

    fun defaultQuickJumpEntries(): List<QuickJumpEntry> = listOf(
        QuickJumpEntry(displayName = "第一颜色", targetType = QuickJumpTargetType.COLOR_SLOT, colorSlotIndex = 1),
        QuickJumpEntry(displayName = "第二颜色", targetType = QuickJumpTargetType.COLOR_SLOT, colorSlotIndex = 2),
        QuickJumpEntry(displayName = "第三颜色", targetType = QuickJumpTargetType.COLOR_SLOT, colorSlotIndex = 3),
        QuickJumpEntry(displayName = "外商", watchlistName = "-1商", fallbackSymbol = "GOLD"),
        QuickJumpEntry(displayName = "外指", watchlistName = "-2指", fallbackSymbol = "IH1!"),
        QuickJumpEntry(displayName = "基金", watchlistName = "-3基", fallbackSymbol = "U.UN"),
        QuickJumpEntry(displayName = "美中概", watchlistName = "-4❶中一", categoryName = "美中概", fallbackSymbol = "BABA"),
        QuickJumpEntry(displayName = "中一", watchlistName = "-4❶中一", categoryName = "中一", fallbackSymbol = "700"),
        QuickJumpEntry(displayName = "中二", watchlistName = "-4❶中二", fallbackSymbol = "857"),
        QuickJumpEntry(displayName = "美一", watchlistName = "-4❷美一", fallbackSymbol = "AAPL"),
        QuickJumpEntry(displayName = "美二", watchlistName = "-4❷美二", fallbackSymbol = "LLY"),
        QuickJumpEntry(displayName = "欧概", watchlistName = "-4❸欧概", fallbackSymbol = "SAP"),
        QuickJumpEntry(displayName = "欧股-德英", watchlistName = "-4❸欧股", categoryName = "德股", fallbackSymbol = "SAP"),
        QuickJumpEntry(displayName = "欧股-法它", watchlistName = "-4❸欧股", categoryName = "法股", fallbackSymbol = "MC"),
        QuickJumpEntry(displayName = "亚概", watchlistName = "-4❹亚", categoryName = "美日概", fallbackSymbol = "MUFG"),
        QuickJumpEntry(displayName = "亚股", watchlistName = "-4❹亚", categoryName = "日股", fallbackSymbol = "8035"),
        QuickJumpEntry(displayName = "汇债", watchlistName = "-5汇债", fallbackSymbol = "DXY"),
        QuickJumpEntry(displayName = "加密", watchlistName = "-6加密", fallbackSymbol = "CRYPTOB10")
    )

    @Synchronized
    fun getQuickJumpEntries(): List<QuickJumpEntry> {
        if (quickJumpEntries.isEmpty()) {
            quickJumpEntries.addAll(defaultQuickJumpEntries())
            persistQuickJumpEntriesLocked()
        }
        return quickJumpEntries.map { it.copy() }
    }

    @Synchronized
    fun addQuickJumpEntry(entry: QuickJumpEntry) {
        quickJumpEntries.add(entry)
        persistQuickJumpEntriesLocked()
        notifyListeners()
    }

    @Synchronized
    fun updateQuickJumpEntry(entry: QuickJumpEntry) {
        val idx = quickJumpEntries.indexOfFirst { it.id == entry.id }
        if (idx >= 0) {
            quickJumpEntries[idx] = entry
            persistQuickJumpEntriesLocked()
            notifyListeners()
        }
    }

    @Synchronized
    fun deleteQuickJumpEntry(id: String) {
        if (quickJumpEntries.removeAll { it.id == id }) {
            persistQuickJumpEntriesLocked()
            notifyListeners()
        }
    }

    @Synchronized
    fun moveQuickJumpEntry(fromIdx: Int, toIdx: Int) {
        if (fromIdx !in quickJumpEntries.indices || toIdx !in quickJumpEntries.indices || fromIdx == toIdx) return
        val item = quickJumpEntries.removeAt(fromIdx)
        quickJumpEntries.add(toIdx, item)
        persistQuickJumpEntriesLocked()
        notifyListeners()
    }

    @Synchronized
    fun saveQuickJumpEntriesOrderQuiet(newOrder: List<QuickJumpEntry>) {
        quickJumpEntries.clear()
        quickJumpEntries.addAll(newOrder)
        persistQuickJumpEntriesLocked()
        notifyListeners()
    }

    @Synchronized
    fun resetQuickJumpEntriesToDefault() {
        quickJumpEntries.clear()
        quickJumpEntries.addAll(defaultQuickJumpEntries())
        persistQuickJumpEntriesLocked()
        notifyListeners()
    }

    private fun persistQuickJumpEntriesLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (e in quickJumpEntries) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("dn", e.displayName)
            o.put("tt", e.targetType.name)
            o.put("cs", e.colorSlotIndex)
            o.put("wid", e.watchlistId)
            o.put("wn", e.watchlistName)
            o.put("cn", e.categoryName)
            o.put("ts", e.targetSymbol)
            o.put("fs", e.fallbackSymbol)
            arr.put(o)
        }
        p.edit().putString(KEY_QUICK_JUMP_ENTRIES_JSON, arr.toString()).apply()
    }

    private fun loadQuickJumpEntriesLocked() {
        quickJumpEntries.clear()
        val raw = prefs?.getString(KEY_QUICK_JUMP_ENTRIES_JSON, null)
        if (!raw.isNullOrBlank()) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val dn = o.optString("dn", "").trim()
                    if (dn.isEmpty()) continue
                    val tt = QuickJumpTargetType.values().firstOrNull { it.name == o.optString("tt", "") }
                        ?: QuickJumpTargetType.CATALOG_TARGET
                    quickJumpEntries.add(
                        QuickJumpEntry(
                            id = o.optString("id", "").ifBlank { UUID.randomUUID().toString() },
                            displayName = dn,
                            targetType = tt,
                            colorSlotIndex = o.optInt("cs", 1).coerceIn(1, 7),
                            watchlistId = o.optString("wid", ""),
                            watchlistName = o.optString("wn", ""),
                            categoryName = o.optString("cn", ""),
                            targetSymbol = o.optString("ts", ""),
                            fallbackSymbol = o.optString("fs", "")
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
        if (quickJumpEntries.isEmpty()) {
            quickJumpEntries.addAll(defaultQuickJumpEntries())
            persistQuickJumpEntriesLocked()
        }
    }

    // ---------- 独立第三功能：图表滚轮上下切图按钮（▲/▼）开关与外观/位置设置 ----------

    fun isWheelPadEnabled(): Boolean = prefs?.getBoolean(KEY_WHEEL_PAD_ENABLED, true) ?: true

    fun setWheelPadEnabled(context: Context?, enabled: Boolean, source: String = "滚轮切图开关") {
        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) init(ctx)
        val prev = isWheelPadEnabled()
        prefs?.edit()?.putBoolean(KEY_WHEEL_PAD_ENABLED, enabled)?.apply()
        if (prev != enabled) {
            log("滚轮切图开关($source)：${if (enabled) "已开启" else "已关闭"}")
        }
        if (ctx != null) {
            WheelPadTileService.requestTileSync(ctx)
        }
        TvAccessibilityService.instance?.onWheelPadEnabledChanged(enabled)
        notifyListeners()
    }

    fun getWheelPadDisplayMode(): WheelPadDisplayMode {
        val id = prefs?.getString(KEY_WHEEL_PAD_MODE, WheelPadDisplayMode.BOTH.id) ?: WheelPadDisplayMode.BOTH.id
        return WheelPadDisplayMode.values().firstOrNull { it.id == id } ?: WheelPadDisplayMode.BOTH
    }

    fun setWheelPadDisplayMode(mode: WheelPadDisplayMode) {
        prefs?.edit()?.putString(KEY_WHEEL_PAD_MODE, mode.id)?.apply()
        TvAccessibilityService.instance?.refreshWheelPadSettings()
    }

    fun isWheelTopLeftTriggerEnabled(): Boolean = prefs?.getBoolean(KEY_WHEEL_PAD_TOPLEFT_TRIGGER, true) ?: true

    fun setWheelTopLeftTriggerEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_WHEEL_PAD_TOPLEFT_TRIGGER, enabled)?.apply()
        TvAccessibilityService.instance?.onWheelPadEnabledChanged(isWheelPadEnabled())
    }

    // 大小设置幅度 20..100dp，默认 60dp
    fun getWheelPadSizeDp(): Int = (prefs?.getInt(KEY_WHEEL_PAD_SIZE_DP, 60) ?: 60).coerceIn(20, 100)

    fun setWheelPadSizeDp(dpVal: Int) {
        prefs?.edit()?.putInt(KEY_WHEEL_PAD_SIZE_DP, dpVal.coerceIn(20, 100))?.apply()
        TvAccessibilityService.instance?.refreshWheelPadSettings()
    }

    fun getWheelPadBrightnessPct(): Int = (prefs?.getInt(KEY_WHEEL_PAD_BRIGHTNESS_PCT, 50) ?: 50).coerceIn(0, 100)

    fun setWheelPadBrightnessPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_WHEEL_PAD_BRIGHTNESS_PCT, pct.coerceIn(0, 100))?.apply()
        TvAccessibilityService.instance?.refreshWheelPadSettings()
    }

    fun getWheelPadOpacityPct(): Int = (prefs?.getInt(KEY_WHEEL_PAD_OPACITY_PCT, 40) ?: 40).coerceIn(10, 100)

    fun setWheelPadOpacityPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_WHEEL_PAD_OPACITY_PCT, pct.coerceIn(10, 100))?.apply()
        TvAccessibilityService.instance?.refreshWheelPadSettings()
    }

    fun getWheelPadGapDp(): Int = (prefs?.getInt(KEY_WHEEL_PAD_GAP_DP, 20) ?: 20).coerceIn(4, 140)

    fun setWheelPadGapDp(dpVal: Int) {
        prefs?.edit()?.putInt(KEY_WHEEL_PAD_GAP_DP, dpVal.coerceIn(4, 140))?.apply()
        TvAccessibilityService.instance?.refreshWheelPadSettings()
    }

    // 默认中心坐标：X = 5.6% W（图二中部绿三角原位），Y = 62.7% H（第二幅图与第三幅图的交界水平中线）
    fun getWheelPadCenterXFrac(): Float = (prefs?.getFloat(KEY_WHEEL_PAD_CENTER_X_FRAC, 0.056f) ?: 0.056f).coerceIn(0.02f, 0.98f)

    fun getWheelPadCenterYFrac(): Float = (prefs?.getFloat(KEY_WHEEL_PAD_CENTER_Y_FRAC, 0.627f) ?: 0.627f).coerceIn(0.10f, 0.90f)

    fun saveWheelPadCenterFrac(xFrac: Float, yFrac: Float) {
        prefs?.edit()
            ?.putFloat(KEY_WHEEL_PAD_CENTER_X_FRAC, xFrac.coerceIn(0.02f, 0.98f))
            ?.putFloat(KEY_WHEEL_PAD_CENTER_Y_FRAC, yFrac.coerceIn(0.10f, 0.90f))
            ?.apply()
    }

    fun getWheelPadStepPermille(): Int = (prefs?.getInt(KEY_WHEEL_PAD_STEP_PERMILLE, 28) ?: 28).coerceIn(15, 52)

    fun setWheelPadStepPermille(permille: Int) {
        prefs?.edit()?.putInt(KEY_WHEEL_PAD_STEP_PERMILLE, permille.coerceIn(15, 52))?.apply()
    }

    fun getWheelPadDragMs(): Long = (prefs?.getLong(KEY_WHEEL_PAD_DRAG_MS, 240L) ?: 240L).coerceIn(140L, 480L)

    fun setWheelPadDragMs(ms: Long) {
        prefs?.edit()?.putLong(KEY_WHEEL_PAD_DRAG_MS, ms.coerceIn(140L, 480L))?.apply()
    }

    fun resetWheelPadDefaults(placeRightSide: Boolean = false) {
        val xFrac = if (placeRightSide) 0.92f else 0.08f
        prefs?.edit()
            ?.putBoolean(KEY_WHEEL_PAD_ENABLED, true)
            ?.putBoolean(KEY_WHEEL_PAD_TOPLEFT_TRIGGER, true)
            ?.putString(KEY_WHEEL_PAD_MODE, WheelPadDisplayMode.BOTH.id)
            ?.putInt(KEY_WHEEL_PAD_SIZE_DP, 60)
            ?.putInt(KEY_WHEEL_PAD_BRIGHTNESS_PCT, 50)
            ?.putInt(KEY_WHEEL_PAD_OPACITY_PCT, 40)
            ?.putInt(KEY_WHEEL_PAD_GAP_DP, 20)
            ?.putFloat(KEY_WHEEL_PAD_CENTER_X_FRAC, xFrac)
            ?.putFloat(KEY_WHEEL_PAD_CENTER_Y_FRAC, 0.627f)
            ?.putInt(KEY_WHEEL_PAD_STEP_PERMILLE, 28)
            ?.putLong(KEY_WHEEL_PAD_DRAG_MS, 240L)
            ?.apply()
        appContext?.let { WheelPadTileService.requestTileSync(it) }
        TvAccessibilityService.instance?.onWheelPadEnabledChanged(true)
        TvAccessibilityService.instance?.refreshWheelPadSettings()
        notifyListeners()
    }

    /**
     * v7.3.0 一次性升级迁移（仅执行一次，后续手动调整永久保留）：
     * 1) 应用新版圆球与三角形默认值
     * 2) 在现有快切列表中于“第二颜色”后自动插入“第三颜色”
     */
    private fun applyOneTimeV730MigrationLocked() {
        val p = prefs ?: return
        if (p.getBoolean(KEY_MIGRATED_V730, false)) return

        p.edit()
            .putInt(KEY_BTN_DP, 60)
            .putInt(KEY_BTN_GAP_DP, 12)
            .putInt(KEY_UNSELECTED_BRIGHTNESS, 60)
            .putInt(KEY_SELECTED_BRIGHTNESS, 100)
            .putBoolean(KEY_WHEEL_PAD_ENABLED, true)
            .putBoolean(KEY_WHEEL_PAD_TOPLEFT_TRIGGER, true)
            .putInt(KEY_WHEEL_PAD_SIZE_DP, 60)
            .putInt(KEY_WHEEL_PAD_BRIGHTNESS_PCT, 50)
            .putInt(KEY_WHEEL_PAD_OPACITY_PCT, 40)
            .putInt(KEY_WHEEL_PAD_GAP_DP, 20)
            .putBoolean(KEY_MIGRATED_V730, true)
            .apply()

        val hasColor3 = quickJumpEntries.any {
            it.targetType == QuickJumpTargetType.COLOR_SLOT && it.colorSlotIndex == 3
        }
        if (!hasColor3) {
            val c2Idx = quickJumpEntries.indexOfFirst {
                it.targetType == QuickJumpTargetType.COLOR_SLOT && it.colorSlotIndex == 2
            }
            val insertAt = if (c2Idx >= 0) c2Idx + 1 else minOf(2, quickJumpEntries.size)
            quickJumpEntries.add(
                insertAt,
                QuickJumpEntry(
                    displayName = "第三颜色",
                    targetType = QuickJumpTargetType.COLOR_SLOT,
                    colorSlotIndex = 3
                )
            )
            persistQuickJumpEntriesLocked()
        }
    }
}
