package com.tvhelper.color

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

enum class MarkColor(val label: String) {
    RED("红"),
    BLUE("蓝")
}

object AppStore {
    private const val PREFS_NAME = "tv_color_helper_prefs"
    private const val KEY_POS_X = "overlay_pos_x"
    private const val KEY_POS_Y = "overlay_pos_y"
    private const val KEY_BTN_DP = "overlay_btn_dp"
    private const val KEY_MARK_ALL_DUPLICATES = "mark_all_duplicates"
    private const val KEY_MISSED_RECORDS = "missed_records"

    private var prefs: SharedPreferences? = null
    private val queue = LinkedHashMap<String, MarkColor>()
    private val logs = ArrayList<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val dateTimeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (_: Exception) {
            }
        }
    }

    @Synchronized
    fun putSymbol(symbol: String, color: MarkColor) {
        val key = symbol.trim().uppercase(Locale.US)
        if (key.isEmpty()) return
        queue[key] = color
        log("队列记录：$key -> ${color.label}色（当前待办 ${queue.size} 个）")
        notifyListeners()
    }

    @Synchronized
    fun getSymbolColor(symbol: String?): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        return queue[symbol.trim().uppercase(Locale.US)]
    }

    @Synchronized
    fun hasPendingItems(): Boolean = queue.isNotEmpty()

    @Synchronized
    fun snapshotQueue(): LinkedHashMap<String, MarkColor> = LinkedHashMap(queue)

    @Synchronized
    fun removeSymbol(symbol: String) {
        queue.remove(symbol.trim().uppercase(Locale.US))
        notifyListeners()
    }

    @Synchronized
    fun clearQueue() {
        queue.clear()
        notifyListeners()
    }

    @Synchronized
    fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        logs.add(line)
        if (logs.size > 300) {
            logs.removeAt(0)
        }
        notifyListeners()
    }

    @Synchronized
    fun getLogsText(): String = logs.joinToString("\n")

    @Synchronized
    fun clearLogs() {
        logs.clear()
        notifyListeners()
    }

    fun addMissedRecord(message: String) {
        val p = prefs ?: return
        val timestamped = "[${dateTimeFmt.format(Date())}] $message"
        val existing = p.getString(KEY_MISSED_RECORDS, "") ?: ""
        val list = existing.split("\n").filter { it.isNotBlank() }.toMutableList()
        list.add(0, timestamped)
        while (list.size > 100) {
            list.removeAt(list.lastIndex)
        }
        p.edit().putString(KEY_MISSED_RECORDS, list.joinToString("\n")).apply()
        notifyListeners()
    }

    fun getMissedRecords(): String {
        return prefs?.getString(KEY_MISSED_RECORDS, "") ?: ""
    }

    fun clearMissedRecords() {
        prefs?.edit()?.remove(KEY_MISSED_RECORDS)?.apply()
        notifyListeners()
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_POS_X, x)?.putInt(KEY_POS_Y, y)?.apply()
    }

    fun getOverlayX(): Int = prefs?.getInt(KEY_POS_X, -1) ?: -1

    fun getOverlayY(): Int = prefs?.getInt(KEY_POS_Y, -1) ?: -1

    fun resetOverlayPosition() {
        prefs?.edit()?.remove(KEY_POS_X)?.remove(KEY_POS_Y)?.apply()
    }

    fun getButtonDiameterDp(): Int = prefs?.getInt(KEY_BTN_DP, 26) ?: 26

    fun setButtonDiameterDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_DP, dp.coerceIn(22, 42))?.apply()
        notifyListeners()
    }

    fun isMarkAllDuplicates(): Boolean = prefs?.getBoolean(KEY_MARK_ALL_DUPLICATES, true) ?: true

    fun setMarkAllDuplicates(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_MARK_ALL_DUPLICATES, enabled)?.apply()
        notifyListeners()
    }
}
