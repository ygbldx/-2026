package com.tvhelper.color

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

enum class MarkColor(
    val menuIndex: Int,
    val label: String,
    val baseR: Int,
    val baseG: Int,
    val baseB: Int
) {
    RED(0, "红", 247, 66, 74),
    BLUE(1, "蓝", 38, 108, 255),
    GREEN(2, "绿", 104, 198, 114),
    YELLOW(3, "黄", 245, 190, 48),
    PURPLE(4, "紫", 184, 104, 198),
    CYAN(5, "青", 10, 218, 242),
    PINK(6, "粉", 238, 138, 174)
}

/**
 * 绑定列表上下文的待添加任务（彻底解决 ASX / SAF 等跨市场同名品种串号问题）
 */
data class PendingTask(
    val key: String,
    val symbol: String,
    val color: MarkColor,
    val preferredWatchlistId: String = ""
)

data class UnaddedItem(
    val symbol: String,
    val color: MarkColor?,
    val message: String,
    val timestamp: String,
    val preferredWatchlistId: String = ""
)

data class UnknownCatalogCandidate(
    val symbol: String,
    var watchlistId: String = "",
    var watchlistName: String = "",
    var prevSymbol: String = "",
    var nextSymbol: String = "",
    val timestamp: String = ""
)

data class CalibrationResult(
    val watchlistId: String,
    val watchlistName: String,
    val observedSymbols: List<String>,
    val timestamp: String
)

object AppStore {
    private const val PREFS_NAME = "tv_color_helper_prefs"

    // APP 层面总开关与持久化队列
    private const val KEY_WORK_ENABLED = "app_work_enabled"
    private const val KEY_PENDING_POOL_JSON = "pending_pool_v2_json"

    // 高级速度与策略设置
    private const val KEY_CUSTOM_LP_MS = "custom_long_press_ms"
    private const val KEY_POST_TAP_COOLDOWN_MS = "post_tap_cooldown_ms"
    private const val KEY_SCROLL_DURATION_MS = "scroll_duration_ms"
    private const val KEY_DRAWER_SWITCH_PREFERRED = "drawer_switch_preferred"
    private const val KEY_OVERWRITE_DIFF_FLAG = "overwrite_diff_color_flag"
    private const val KEY_SKIP_FLAG_CHECK_TURBO = "skip_flag_check_turbo"

    // 颜色圆球设置
    private const val KEY_POS_X = "overlay_pos_x"
    private const val KEY_POS_Y = "overlay_pos_y"
    private const val KEY_BTN_DP = "overlay_btn_dp"
    private const val KEY_BTN_GAP_DP = "overlay_btn_gap_dp"
    private const val KEY_UNSELECTED_BRIGHTNESS = "overlay_unselected_brightness"
    private const val KEY_SELECTED_BRIGHTNESS = "overlay_selected_brightness"
    private const val KEY_SELECTED_WHITE_RING = "overlay_selected_white_ring"
    private const val KEY_BALL_BADGE_ENABLED = "overlay_ball_badge_enabled"
    private const val KEY_ENABLED_COLORS = "overlay_enabled_colors"

    // 图表页圆球关闭服务方式（可多选）
    private const val KEY_BALL_EXIT_DOUBLE_TAP = "ball_exit_double_tap"
    private const val KEY_BALL_EXIT_SWIPE_RIGHT = "ball_exit_swipe_right"
    private const val KEY_BALL_EXIT_SWIPE_ANY = "ball_exit_swipe_any"

    // 完活弹窗与提示音设置
    private const val KEY_DONE_TEXT = "done_text"
    private const val KEY_DONE_SIZE_SP = "done_size_sp"
    private const val KEY_DONE_GRAY_PCT = "done_gray_pct"
    private const val KEY_DONE_POS_X = "done_pos_x"
    private const val KEY_DONE_POS_Y = "done_pos_y"
    private const val KEY_DONE_SOUND_ENABLED = "done_sound_enabled"
    private const val KEY_DONE_SOUND_ID = "done_sound_id"
    private const val KEY_DONE_SOUND_VOLUME = "done_sound_volume"

    // 记录
    private const val KEY_MISSED_RECORDS = "missed_records"
    private const val KEY_UNADDED_ITEMS_JSON = "unadded_items_json"
    private const val KEY_UNKNOWN_CANDIDATES_JSON = "unknown_candidates_json"

    private var appContext: Context? = null
    private var prefs: SharedPreferences? = null
    private val tasks = LinkedHashMap<String, PendingTask>()
    private val unaddedItems = ArrayList<UnaddedItem>()
    private val unknownCandidates = ArrayList<UnknownCatalogCandidate>()
    private val sessionMarked = LinkedHashMap<String, MarkColor>()
    @Volatile
    private var calibrationArmed = false
    @Volatile
    private var pendingCalibrationResult: CalibrationResult? = null
    private val logs = ArrayList<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val dateTimeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    @Synchronized
    fun init(context: Context) {
        val ctx = context.applicationContext
        if (appContext == null) {
            appContext = ctx
        }
        if (prefs == null) {
            prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            CatalogRepository.init(ctx)
            loadTasksLocked()
            loadUnaddedLocked()
            loadUnknownCandidatesLocked()
        } else {
            CatalogRepository.init(ctx)
        }
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (_: Exception) {
            }
        }
    }

    // ---------- APP 层面总开关 ----------

    fun isWorkEnabled(): Boolean = prefs?.getBoolean(KEY_WORK_ENABLED, true) ?: true

    fun setWorkEnabled(context: Context?, enabled: Boolean, source: String = "开关") {
        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) init(ctx)
        val prev = isWorkEnabled()
        prefs?.edit()?.putBoolean(KEY_WORK_ENABLED, enabled)?.apply()

        if (!enabled) {
            clearQueueInternal(silent = true)
            sessionMarked.clear()
            calibrationArmed = false
            if (prev) {
                log("服务开关(${source})：已关闭，待添加品种池已清空（系统无障碍保持常驻）")
            }
        } else if (!prev) {
            log("服务开关(${source})：已开启")
        }

        if (ctx != null) {
            WorkTileService.requestTileSync(ctx)
        }
        TvAccessibilityService.instance?.onWorkEnabledChanged(enabled)
        notifyListeners()
    }

    // ---------- 高级速度与策略参数 ----------

    fun getCustomLongPressMs(): Long = (prefs?.getLong(KEY_CUSTOM_LP_MS, 740L) ?: 740L).coerceIn(550L, 950L)

    fun setCustomLongPressMs(ms: Long) {
        prefs?.edit()?.putLong(KEY_CUSTOM_LP_MS, ms.coerceIn(550L, 950L))?.apply()
    }

    fun getPostTapCooldownMs(): Long = (prefs?.getLong(KEY_POST_TAP_COOLDOWN_MS, 340L) ?: 340L).coerceIn(200L, 650L)

    fun setPostTapCooldownMs(ms: Long) {
        prefs?.edit()?.putLong(KEY_POST_TAP_COOLDOWN_MS, ms.coerceIn(200L, 650L))?.apply()
    }

    fun getScrollDurationMs(): Long = (prefs?.getLong(KEY_SCROLL_DURATION_MS, 125L) ?: 125L).coerceIn(80L, 240L)

    fun setScrollDurationMs(ms: Long) {
        prefs?.edit()?.putLong(KEY_SCROLL_DURATION_MS, ms.coerceIn(80L, 240L))?.apply()
    }

    fun isDrawerSwitchPreferred(): Boolean = prefs?.getBoolean(KEY_DRAWER_SWITCH_PREFERRED, true) ?: true

    fun setDrawerSwitchPreferred(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_DRAWER_SWITCH_PREFERRED, enabled)?.apply()
    }

    fun isOverwriteDifferentColorFlag(): Boolean = prefs?.getBoolean(KEY_OVERWRITE_DIFF_FLAG, false) ?: false

    fun setOverwriteDifferentColorFlag(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_OVERWRITE_DIFF_FLAG, enabled)?.apply()
    }

    fun isSkipFlagCheckTurbo(): Boolean = prefs?.getBoolean(KEY_SKIP_FLAG_CHECK_TURBO, false) ?: false

    fun setSkipFlagCheckTurbo(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_SKIP_FLAG_CHECK_TURBO, enabled)?.apply()
    }

    fun resetSpeedDefaults() {
        prefs?.edit()
            ?.putLong(KEY_CUSTOM_LP_MS, 740L)
            ?.putLong(KEY_POST_TAP_COOLDOWN_MS, 340L)
            ?.putLong(KEY_SCROLL_DURATION_MS, 125L)
            ?.putBoolean(KEY_DRAWER_SWITCH_PREFERRED, true)
            ?.putBoolean(KEY_OVERWRITE_DIFF_FLAG, false)
            ?.putBoolean(KEY_SKIP_FLAG_CHECK_TURBO, false)
            ?.apply()
        notifyListeners()
    }

    // ---------- 上下文绑定的待添加品种池（防 ASX / SAF 跨市场同名串号） ----------

    private fun resolveLockedWatchlistId(symbol: String, contextWatchlistId: String?): String {
        val locs = CatalogRepository.findLocations(symbol)
        if (locs.isEmpty()) return ""
        val uniqueWlIds = locs.map { it.watchlistId }.distinct()
        if (uniqueWlIds.size == 1) return uniqueWlIds[0]
        if (!contextWatchlistId.isNullOrBlank() && contextWatchlistId in uniqueWlIds) {
            return contextWatchlistId
        }
        return ""
    }

    fun makeTaskKey(symbol: String, preferredWatchlistId: String): String {
        val sym = symbol.trim().uppercase(Locale.US)
        return if (preferredWatchlistId.isNotBlank()) "$preferredWatchlistId::$sym" else "ANY::$sym"
    }

    @Synchronized
    fun putTask(symbol: String, color: MarkColor, contextWatchlistId: String? = null): PendingTask? {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        if (cleanSym.isEmpty()) return null
        val lockedWlId = resolveLockedWatchlistId(cleanSym, contextWatchlistId)
        val key = makeTaskKey(cleanSym, lockedWlId)
        val task = PendingTask(key = key, symbol = cleanSym, color = color, preferredWatchlistId = lockedWlId)
        tasks[key] = task
        persistTasksLocked()
        val wlLabel = if (lockedWlId.isNotEmpty()) {
            CatalogRepository.getWatchlistById(lockedWlId)?.name?.let { "[$it]" }.orEmpty()
        } else ""
        log("待添加池记录：$cleanSym$wlLabel -> ${color.label}色（池内 ${tasks.size} 个）")
        notifyListeners()
        return task
    }

    @Synchronized
    fun getTaskColorForChart(symbol: String?, contextWatchlistId: String? = null): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        val cleanSym = symbol.trim().uppercase(Locale.US)
        val lockedWlId = resolveLockedWatchlistId(cleanSym, contextWatchlistId)
        val exactKey = makeTaskKey(cleanSym, lockedWlId)
        tasks[exactKey]?.let { return it.color }
        if (lockedWlId.isNotEmpty()) {
            tasks[makeTaskKey(cleanSym, "")]?.let { return it.color }
        }
        return tasks.values.firstOrNull { it.symbol == cleanSym }?.color
    }

    @Synchronized
    fun removeTaskForChart(symbol: String, contextWatchlistId: String? = null): Boolean {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        val lockedWlId = resolveLockedWatchlistId(cleanSym, contextWatchlistId)
        val exactKey = makeTaskKey(cleanSym, lockedWlId)
        var removed = tasks.remove(exactKey) != null
        if (!removed) {
            val fallbackKey = tasks.values.firstOrNull { it.symbol == cleanSym }?.key
            if (fallbackKey != null) {
                removed = tasks.remove(fallbackKey) != null
            }
        }
        if (removed) {
            persistTasksLocked()
            notifyListeners()
        }
        return removed
    }

    @Synchronized
    fun removeTaskByKey(key: String): Boolean {
        val removed = tasks.remove(key) != null
        if (removed) {
            persistTasksLocked()
            notifyListeners()
        }
        return removed
    }

    @Synchronized
    fun getTaskByKey(key: String): PendingTask? = tasks[key]

    @Synchronized
    fun hasPendingItems(): Boolean = tasks.isNotEmpty()

    @Synchronized
    fun pendingCount(): Int = tasks.size

    @Synchronized
    fun snapshotTasks(): List<PendingTask> = tasks.values.toList()

    @Synchronized
    fun clearQueue() {
        clearQueueInternal(silent = false)
    }

    @Synchronized
    private fun clearQueueInternal(silent: Boolean) {
        tasks.clear()
        persistTasksLocked()
        if (!silent) {
            notifyListeners()
        }
    }

    private fun persistTasksLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (t in tasks.values) {
            val obj = JSONObject()
            obj.put("k", t.key)
            obj.put("s", t.symbol)
            obj.put("c", t.color.name)
            obj.put("w", t.preferredWatchlistId)
            arr.put(obj)
        }
        p.edit().putString(KEY_PENDING_POOL_JSON, arr.toString()).apply()
    }

    private fun loadTasksLocked() {
        tasks.clear()
        if (!isWorkEnabled()) {
            persistTasksLocked()
            return
        }
        val raw = prefs?.getString(KEY_PENDING_POOL_JSON, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val sym = obj.optString("s", "").trim().uppercase(Locale.US)
                val col = MarkColor.values().firstOrNull { it.name == obj.optString("c", "") } ?: continue
                val wid = obj.optString("w", "")
                val key = obj.optString("k", "").ifBlank { makeTaskKey(sym, wid) }
                if (sym.isNotEmpty()) {
                    tasks[key] = PendingTask(key, sym, col, wid)
                }
            }
        } catch (_: Exception) {
        }
    }


    // ---------- 单条任务编辑（支持在 APP 首页直接改色/改目标列表） ----------

    @Synchronized
    fun updateTaskColor(key: String, newColor: MarkColor) {
        val old = tasks[key] ?: return
        tasks[key] = old.copy(color = newColor)
        persistTasksLocked()
        log("修改待办颜色：${old.symbol} -> ${newColor.label}色")
        notifyListeners()
    }

    @Synchronized
    fun updateTaskWatchlist(key: String, newWatchlistId: String) {
        val old = tasks.remove(key) ?: return
        val newKey = makeTaskKey(old.symbol, newWatchlistId)
        tasks[newKey] = old.copy(key = newKey, preferredWatchlistId = newWatchlistId)
        persistTasksLocked()
        val wlName = if (newWatchlistId.isNotEmpty()) CatalogRepository.getWatchlistById(newWatchlistId)?.name ?: "未知" else "自动匹配"
        log("修改目标列表：${old.symbol} -> $wlName")
        notifyListeners()
    }

    // ---------- 单条未找到提醒操作 ----------

    @Synchronized
    fun getUnaddedItems(): List<UnaddedItem> = unaddedItems.toList()

    @Synchronized
    fun requeueSingleUnadded(index: Int): Boolean {
        if (index !in unaddedItems.indices) return false
        val item = unaddedItems[index]
        if (item.symbol.isEmpty() || item.color == null) return false
        val resolved = CatalogRepository.resolveChartSymbolInCatalog(item.symbol, item.preferredWatchlistId.ifBlank { null }) ?: item.symbol
        val lockedWlId = resolveLockedWatchlistId(resolved, item.preferredWatchlistId.ifBlank { null })
        val key = makeTaskKey(resolved, lockedWlId)
        tasks[key] = PendingTask(key, resolved, item.color, lockedWlId)
        unaddedItems.removeAt(index)
        persistTasksLocked()
        persistUnaddedLocked()
        log("单条重试加入待添加池：$resolved -> ${item.color.label}色")
        notifyListeners()
        return true
    }

    @Synchronized
    fun removeSingleUnadded(index: Int) {
        if (index !in unaddedItems.indices) return
        unaddedItems.removeAt(index)
        persistUnaddedLocked()
        notifyListeners()
    }

    // ---------- 本轮已标色记忆（防止长复盘重复标色） ----------

    @Synchronized
    fun recordSessionMarked(symbol: String, color: MarkColor, watchlistId: String = "") {
        val clean = symbol.trim().uppercase(Locale.US)
        if (clean.isEmpty()) return
        val key = makeTaskKey(clean, resolveLockedWatchlistId(clean, watchlistId.ifBlank { null }))
        sessionMarked[key] = color
        if (sessionMarked.size > 300) {
            val firstKey = sessionMarked.keys.firstOrNull()
            if (firstKey != null) sessionMarked.remove(firstKey)
        }
        notifyListeners()
    }

    @Synchronized
    fun getSessionMarkedColor(symbol: String?, contextWatchlistId: String? = null): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        val clean = symbol.trim().uppercase(Locale.US)
        val locked = resolveLockedWatchlistId(clean, contextWatchlistId)
        sessionMarked[makeTaskKey(clean, locked)]?.let { return it }
        if (locked.isNotEmpty()) {
            sessionMarked[makeTaskKey(clean, "")]?.let { return it }
        }
        return null
    }

    @Synchronized
    fun sessionMarkedCount(): Int = sessionMarked.size

    @Synchronized
    fun clearSessionMarked() {
        sessionMarked.clear()
        notifyListeners()
    }

    // ---------- TV 自动采集/校准列表模式 ----------

    fun isCalibrationArmed(): Boolean = calibrationArmed

    fun armCalibrationMode() {
        calibrationArmed = true
        pendingCalibrationResult = null
        log("已启动 TV 列表自动采集模式：请切回 TradingView 目标自选表")
        notifyListeners()
    }

    fun cancelCalibrationMode() {
        calibrationArmed = false
        notifyListeners()
    }

    fun submitCalibrationResult(watchlistId: String, watchlistName: String, symbols: List<String>) {
        calibrationArmed = false
        pendingCalibrationResult = CalibrationResult(
            watchlistId = watchlistId,
            watchlistName = watchlistName,
            observedSymbols = symbols,
            timestamp = dateTimeFmt.format(Date())
        )
        log("TV列表采集完成：[$watchlistName] 共捕获 ${symbols.size} 个品种，回《品种大全》确认合并")
        notifyListeners()
    }

    fun peekCalibrationResult(): CalibrationResult? = pendingCalibrationResult

    fun consumeCalibrationResult(): CalibrationResult? {
        val r = pendingCalibrationResult
        pendingCalibrationResult = null
        notifyListeners()
        return r
    }

    // ---------- 日志与APP消息记录 ----------

    @Synchronized
    fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        logs.add(line)
        if (logs.size > 300) {
            logs.removeAt(0)
        }
        notifyListeners()
    }

    @Synchronized
    fun getLogsText(): String = logs.joinToString("\n")

    @Synchronized
    fun clearLogs() {
        logs.clear()
        notifyListeners()
    }

    @Synchronized
    fun addUnaddedItem(
        symbol: String,
        color: MarkColor?,
        message: String,
        preferredWatchlistId: String = ""
    ) {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        val ts = dateTimeFmt.format(Date())
        if (cleanSym.isNotEmpty()) {
            unaddedItems.removeAll { it.symbol == cleanSym && it.preferredWatchlistId == preferredWatchlistId }
        }
        unaddedItems.add(0, UnaddedItem(cleanSym, color, message, ts, preferredWatchlistId))
        while (unaddedItems.size > 100) {
            unaddedItems.removeAt(unaddedItems.lastIndex)
        }
        persistUnaddedLocked()
        notifyListeners()
    }

    @Synchronized
    fun countRetryableUnadded(): Int = unaddedItems.count { it.symbol.isNotEmpty() && it.color != null }

    @Synchronized
    fun requeueAllUnadded(): Int {
        var addedCount = 0
        val remaining = ArrayList<UnaddedItem>()
        for (item in unaddedItems) {
            if (item.symbol.isNotEmpty() && item.color != null) {
                val resolved = CatalogRepository.resolveChartSymbolInCatalog(item.symbol, item.preferredWatchlistId.ifBlank { null }) ?: item.symbol
                val lockedWlId = resolveLockedWatchlistId(resolved, item.preferredWatchlistId.ifBlank { null })
                val key = makeTaskKey(resolved, lockedWlId)
                tasks[key] = PendingTask(key, resolved, item.color, lockedWlId)
                addedCount++
            } else {
                remaining.add(item)
            }
        }
        if (addedCount > 0) {
            unaddedItems.clear()
            unaddedItems.addAll(remaining)
            persistTasksLocked()
            persistUnaddedLocked()
            log("一键重新加入待添加池：$addedCount 个品种（当前待办池共 ${tasks.size} 个）")
            notifyListeners()
        }
        return addedCount
    }

    @Synchronized
    fun getMissedRecords(): String {
        if (unaddedItems.isEmpty()) return ""
        return unaddedItems.joinToString("\n") { "[${it.timestamp}] ${it.message}" }
    }

    @Synchronized
    fun clearMissedRecords() {
        unaddedItems.clear()
        prefs?.edit()?.remove(KEY_MISSED_RECORDS)?.remove(KEY_UNADDED_ITEMS_JSON)?.apply()
        notifyListeners()
    }

    private fun persistUnaddedLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (it in unaddedItems) {
            val obj = JSONObject()
            obj.put("s", it.symbol)
            obj.put("c", it.color?.name ?: "")
            obj.put("m", it.message)
            obj.put("t", it.timestamp)
            obj.put("w", it.preferredWatchlistId)
            arr.put(obj)
        }
        p.edit().putString(KEY_UNADDED_ITEMS_JSON, arr.toString()).apply()
    }

    private fun loadUnaddedLocked() {
        unaddedItems.clear()
        val raw = prefs?.getString(KEY_UNADDED_ITEMS_JSON, null)
        if (!raw.isNullOrBlank()) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val sym = obj.optString("s", "").trim().uppercase(Locale.US)
                    val col = MarkColor.values().firstOrNull { it.name == obj.optString("c", "") }
                    val msg = obj.optString("m", "")
                    val ts = obj.optString("t", "")
                    val wid = obj.optString("w", "")
                    if (msg.isNotBlank()) {
                        unaddedItems.add(UnaddedItem(sym, col, msg, ts, wid))
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    // ---------- 不在《品种大全》的品种观察与一键写入 ----------

    @Synchronized
    fun recordUnknownSymbol(
        symbol: String,
        watchlistId: String = "",
        watchlistName: String = "",
        prevSymbol: String = "",
        nextSymbol: String = ""
    ) {
        val cleanSym = symbol.trim().uppercase(Locale.US)
        if (cleanSym.isEmpty()) return
        if (CatalogRepository.resolveChartSymbolInCatalog(cleanSym) != null) return

        val existing = unknownCandidates.firstOrNull { it.symbol == cleanSym }
        val ts = dateTimeFmt.format(Date())
        if (existing != null) {
            if (watchlistId.isNotEmpty()) {
                existing.watchlistId = watchlistId
                existing.watchlistName = watchlistName
            }
            if (prevSymbol.isNotEmpty() || nextSymbol.isNotEmpty()) {
                existing.prevSymbol = prevSymbol.trim().uppercase(Locale.US)
                existing.nextSymbol = nextSymbol.trim().uppercase(Locale.US)
            }
        } else {
            unknownCandidates.add(
                0,
                UnknownCatalogCandidate(
                    symbol = cleanSym,
                    watchlistId = watchlistId,
                    watchlistName = watchlistName,
                    prevSymbol = prevSymbol.trim().uppercase(Locale.US),
                    nextSymbol = nextSymbol.trim().uppercase(Locale.US),
                    timestamp = ts
                )
            )
            while (unknownCandidates.size > 80) {
                unknownCandidates.removeAt(unknownCandidates.lastIndex)
            }
        }
        persistUnknownCandidatesLocked()
        notifyListeners()
    }

    @Synchronized
    fun getUnknownCandidates(): List<UnknownCatalogCandidate> {
        val removed = unknownCandidates.removeAll { CatalogRepository.findLocations(it.symbol).isNotEmpty() }
        if (removed) persistUnknownCandidatesLocked()
        return unknownCandidates.map { it.copy() }
    }

    @Synchronized
    fun removeUnknownCandidate(symbol: String) {
        val clean = symbol.trim().uppercase(Locale.US)
        if (unknownCandidates.removeAll { it.symbol == clean }) {
            persistUnknownCandidatesLocked()
            notifyListeners()
        }
    }

    @Synchronized
    fun clearUnknownCandidates() {
        unknownCandidates.clear()
        persistUnknownCandidatesLocked()
        notifyListeners()
    }

    private fun persistUnknownCandidatesLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (c in unknownCandidates) {
            val obj = JSONObject()
            obj.put("s", c.symbol)
            obj.put("wid", c.watchlistId)
            obj.put("wn", c.watchlistName)
            obj.put("prev", c.prevSymbol)
            obj.put("next", c.nextSymbol)
            obj.put("t", c.timestamp)
            arr.put(obj)
        }
        p.edit().putString(KEY_UNKNOWN_CANDIDATES_JSON, arr.toString()).apply()
    }

    private fun loadUnknownCandidatesLocked() {
        unknownCandidates.clear()
        val raw = prefs?.getString(KEY_UNKNOWN_CANDIDATES_JSON, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val sym = obj.optString("s", "").trim().uppercase(Locale.US)
                if (sym.isNotEmpty()) {
                    unknownCandidates.add(
                        UnknownCatalogCandidate(
                            symbol = sym,
                            watchlistId = obj.optString("wid", ""),
                            watchlistName = obj.optString("wn", ""),
                            prevSymbol = obj.optString("prev", ""),
                            nextSymbol = obj.optString("next", ""),
                            timestamp = obj.optString("t", "")
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
    }

    // ---------- 颜色圆球设置 ----------

    fun getEnabledColors(): List<MarkColor> {
        val raw = prefs?.getString(KEY_ENABLED_COLORS, null)
        if (raw.isNullOrBlank()) {
            return listOf(MarkColor.RED, MarkColor.BLUE)
        }
        val names = raw.split(",").toSet()
        val list = MarkColor.values().filter { it.name in names }
        return if (list.isEmpty()) listOf(MarkColor.RED) else list
    }

    fun setColorEnabled(color: MarkColor, enabled: Boolean): Boolean {
        val current = getEnabledColors().toMutableSet()
        if (enabled) {
            current.add(color)
        } else {
            if (current.size <= 1 && color in current) return false
            current.remove(color)
        }
        val ordered = MarkColor.values().filter { it in current }.joinToString(",") { it.name }
        prefs?.edit()?.putString(KEY_ENABLED_COLORS, ordered)?.apply()
        return true
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_POS_X, x)?.putInt(KEY_POS_Y, y)?.apply()
    }

    fun getOverlayX(): Int = prefs?.getInt(KEY_POS_X, -1) ?: -1

    fun getOverlayY(): Int = prefs?.getInt(KEY_POS_Y, -1) ?: -1

    fun resetOverlayPosition() {
        prefs?.edit()?.remove(KEY_POS_X)?.remove(KEY_POS_Y)?.apply()
    }

    fun getButtonDiameterDp(): Int = (prefs?.getInt(KEY_BTN_DP, 36) ?: 36).coerceIn(30, 80)

    fun setButtonDiameterDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_DP, dp.coerceIn(30, 80))?.apply()
    }

    fun getButtonGapDp(): Int = (prefs?.getInt(KEY_BTN_GAP_DP, 5) ?: 5).coerceIn(5, 60)

    fun setButtonGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_GAP_DP, dp.coerceIn(5, 60))?.apply()
    }

    fun getUnselectedBrightness(): Int = (prefs?.getInt(KEY_UNSELECTED_BRIGHTNESS, 45) ?: 45).coerceIn(10, 100)

    fun setUnselectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_UNSELECTED_BRIGHTNESS, pct.coerceIn(10, 100))?.apply()
    }

    fun getSelectedBrightness(): Int = (prefs?.getInt(KEY_SELECTED_BRIGHTNESS, 100) ?: 100).coerceIn(20, 100)

    fun setSelectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_SELECTED_BRIGHTNESS, pct.coerceIn(20, 100))?.apply()
    }

    fun isSelectedWhiteRingEnabled(): Boolean = prefs?.getBoolean(KEY_SELECTED_WHITE_RING, true) ?: true

    fun setSelectedWhiteRingEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_SELECTED_WHITE_RING, enabled)?.apply()
    }

    fun isBallBadgeEnabled(): Boolean = prefs?.getBoolean(KEY_BALL_BADGE_ENABLED, true) ?: true

    fun setBallBadgeEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_BADGE_ENABLED, enabled)?.apply()
    }

    fun isBallExitDoubleTap(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_DOUBLE_TAP, false) ?: false

    fun setBallExitDoubleTap(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_DOUBLE_TAP, enabled)?.apply()
    }

    fun isBallExitSwipeRight(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_SWIPE_RIGHT, false) ?: false

    fun setBallExitSwipeRight(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_SWIPE_RIGHT, enabled)?.apply()
    }

    fun isBallExitSwipeAny(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_SWIPE_ANY, true) ?: true

    fun setBallExitSwipeAny(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_SWIPE_ANY, enabled)?.apply()
    }

    // ---------- 完活弹窗与提示音设置 ----------

    fun getDoneText(): String {
        val raw = prefs?.getString(KEY_DONE_TEXT, "完活")?.trim()
        return if (raw.isNullOrEmpty()) "完活" else raw
    }

    fun setDoneText(text: String) {
        val v = text.trim().ifEmpty { "完活" }
        prefs?.edit()?.putString(KEY_DONE_TEXT, v)?.apply()
    }

    fun getDoneSizeSp(): Int = (prefs?.getInt(KEY_DONE_SIZE_SP, 56) ?: 56).coerceIn(20, 100)

    fun setDoneSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SIZE_SP, sp.coerceIn(20, 100))?.apply()
    }

    fun getDoneGrayPct(): Int = (prefs?.getInt(KEY_DONE_GRAY_PCT, 90) ?: 90).coerceIn(15, 100)

    fun setDoneGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_DONE_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    fun saveDonePosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_DONE_POS_X, x)?.putInt(KEY_DONE_POS_Y, y)?.apply()
    }

    fun getDoneX(): Int = prefs?.getInt(KEY_DONE_POS_X, -1) ?: -1

    fun getDoneY(): Int = prefs?.getInt(KEY_DONE_POS_Y, -1) ?: -1

    fun resetDonePosition() {
        prefs?.edit()?.remove(KEY_DONE_POS_X)?.remove(KEY_DONE_POS_Y)?.apply()
    }

    fun isDoneSoundEnabled(): Boolean = prefs?.getBoolean(KEY_DONE_SOUND_ENABLED, true) ?: true

    fun setDoneSoundEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_DONE_SOUND_ENABLED, enabled)?.apply()
    }

    fun getDoneSoundId(): String = prefs?.getString(KEY_DONE_SOUND_ID, SoundPreset.WECHAT.id) ?: SoundPreset.WECHAT.id

    fun setDoneSoundId(id: String) {
        prefs?.edit()?.putString(KEY_DONE_SOUND_ID, id)?.apply()
    }

    fun getDoneSoundVolume(): Int = (prefs?.getInt(KEY_DONE_SOUND_VOLUME, 75) ?: 75).coerceIn(0, 100)

    fun setDoneSoundVolume(vol: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SOUND_VOLUME, vol.coerceIn(0, 100))?.apply()
    }
}
