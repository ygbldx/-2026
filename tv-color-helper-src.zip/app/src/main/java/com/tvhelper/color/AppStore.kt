package com.tvhelper.color

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

enum class MarkColor(
    val menuIndex: Int,
    val label: String,
    val baseR: Int,
    val baseG: Int,
    val baseB: Int
) {
    RED(0, "红", 247, 66, 74),
    BLUE(1, "蓝", 38, 108, 255),
    GREEN(2, "绿", 104, 198, 114),
    YELLOW(3, "黄", 245, 190, 48),
    PURPLE(4, "紫", 184, 104, 198),
    CYAN(5, "青", 10, 218, 242),
    PINK(6, "粉", 238, 138, 174)
}

object AppStore {
    private const val PREFS_NAME = "tv_color_helper_prefs"

    // APP 层面总开关（与控制中心快捷开关、图表页手势退出严格同步，绝不关闭系统无障碍服务）
    private const val KEY_WORK_ENABLED = "app_work_enabled"
    // 持久化待添加品种池（只要服务不关闭就一直记住，关闭开关立刻清空）
    private const val KEY_PENDING_POOL_JSON = "pending_pool_json"

    // 颜色圆球设置
    private const val KEY_POS_X = "overlay_pos_x"
    private const val KEY_POS_Y = "overlay_pos_y"
    private const val KEY_BTN_DP = "overlay_btn_dp"
    private const val KEY_BTN_GAP_DP = "overlay_btn_gap_dp"
    private const val KEY_UNSELECTED_BRIGHTNESS = "overlay_unselected_brightness"
    private const val KEY_SELECTED_BRIGHTNESS = "overlay_selected_brightness"
    private const val KEY_SELECTED_WHITE_RING = "overlay_selected_white_ring"
    private const val KEY_ENABLED_COLORS = "overlay_enabled_colors"

    // 图表页圆球关闭服务方式（可多选）
    private const val KEY_BALL_EXIT_DOUBLE_TAP = "ball_exit_double_tap"
    private const val KEY_BALL_EXIT_SWIPE_RIGHT = "ball_exit_swipe_right"
    private const val KEY_BALL_EXIT_SWIPE_ANY = "ball_exit_swipe_any"

    // 完活弹窗与提示音设置
    private const val KEY_DONE_TEXT = "done_text"
    private const val KEY_DONE_SIZE_SP = "done_size_sp"
    private const val KEY_DONE_GRAY_PCT = "done_gray_pct"
    private const val KEY_DONE_POS_X = "done_pos_x"
    private const val KEY_DONE_POS_Y = "done_pos_y"
    private const val KEY_DONE_SOUND_ENABLED = "done_sound_enabled"
    private const val KEY_DONE_SOUND_ID = "done_sound_id"
    private const val KEY_DONE_SOUND_VOLUME = "done_sound_volume"

    // 右侧信息提示设置
    private const val KEY_INFO_ENABLED = "info_enabled"
    private const val KEY_INFO_SHOW_CN_NAME = "info_show_cn_name"
    private const val KEY_INFO_SHOW_SOURCE = "info_show_source"
    private const val KEY_INFO_CLOSE_DOUBLE_TAP = "info_close_double_tap"
    private const val KEY_INFO_CLOSE_SWIPE_RIGHT = "info_close_swipe_right"
    private const val KEY_INFO_CLOSE_SWIPE_ANY = "info_close_swipe_any"
    private const val KEY_INFO_SIZE_SP = "info_size_sp"
    private const val KEY_INFO_GRAY_PCT = "info_gray_pct"
    private const val KEY_INFO_GAP_DP = "info_gap_dp"
    private const val KEY_INFO_POS_X = "info_pos_x"
    private const val KEY_INFO_POS_Y = "info_pos_y"

    // 消息与提醒记录
    private const val KEY_MISSED_RECORDS = "missed_records"

    private var appContext: Context? = null
    private var prefs: SharedPreferences? = null
    private val queue = LinkedHashMap<String, MarkColor>()
    private val logs = ArrayList<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val dateTimeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    @Synchronized
    fun init(context: Context) {
        val ctx = context.applicationContext
        if (appContext == null) {
            appContext = ctx
        }
        if (prefs == null) {
            prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            loadQueueLocked()
        }
        CatalogRepository.init(ctx)
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (_: Exception) {
            }
        }
    }

    // ---------- APP 层面总开关（同步：APP大开关 + 状态栏快捷开关 + 图表手势） ----------

    fun isWorkEnabled(): Boolean = prefs?.getBoolean(KEY_WORK_ENABLED, true) ?: true

    fun setWorkEnabled(context: Context?, enabled: Boolean, source: String = "开关") {
        val ctx = context?.applicationContext ?: appContext
        if (ctx != null) init(ctx)
        val prev = isWorkEnabled()
        prefs?.edit()?.putBoolean(KEY_WORK_ENABLED, enabled)?.apply()

        if (!enabled) {
            // 关闭开关时立即清空待添加品种池，不再管
            clearQueueInternal(silent = true)
            if (prev) {
                log("服务开关(${source})：已关闭，待添加品种池已清空（系统无障碍保持常驻）")
            }
        } else if (!prev) {
            log("服务开关(${source})：已开启")
        }

        if (ctx != null) {
            WorkTileService.requestTileSync(ctx)
        }
        TvAccessibilityService.instance?.onWorkEnabledChanged(enabled)
        notifyListeners()
    }

    // ---------- 待添加品种池（持久化，关闭开关立即清空） ----------

    @Synchronized
    fun putSymbol(symbol: String, color: MarkColor) {
        val key = symbol.trim().uppercase(Locale.US)
        if (key.isEmpty()) return
        queue[key] = color
        persistQueueLocked()
        log("待添加池记录：$key -> ${color.label}色（当前池内 ${queue.size} 个）")
        notifyListeners()
    }

    @Synchronized
    fun getSymbolColor(symbol: String?): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        return queue[symbol.trim().uppercase(Locale.US)]
    }

    @Synchronized
    fun hasPendingItems(): Boolean = queue.isNotEmpty()

    @Synchronized
    fun snapshotQueue(): LinkedHashMap<String, MarkColor> = LinkedHashMap(queue)

    @Synchronized
    fun removeSymbol(symbol: String): Boolean {
        val removed = queue.remove(symbol.trim().uppercase(Locale.US)) != null
        if (removed) {
            persistQueueLocked()
            notifyListeners()
        }
        return removed
    }

    @Synchronized
    fun clearQueue() {
        clearQueueInternal(silent = false)
    }

    @Synchronized
    private fun clearQueueInternal(silent: Boolean) {
        queue.clear()
        persistQueueLocked()
        if (!silent) {
            notifyListeners()
        }
    }

    private fun persistQueueLocked() {
        val p = prefs ?: return
        val arr = JSONArray()
        for ((sym, col) in queue) {
            val obj = JSONObject()
            obj.put("s", sym)
            obj.put("c", col.name)
            arr.put(obj)
        }
        p.edit().putString(KEY_PENDING_POOL_JSON, arr.toString()).apply()
    }

    private fun loadQueueLocked() {
        queue.clear()
        if (!isWorkEnabled()) {
            persistQueueLocked()
            return
        }
        val raw = prefs?.getString(KEY_PENDING_POOL_JSON, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val sym = obj.optString("s", "").trim().uppercase(Locale.US)
                val colName = obj.optString("c", "")
                val col = MarkColor.values().firstOrNull { it.name == colName } ?: continue
                if (sym.isNotEmpty()) {
                    queue[sym] = col
                }
            }
        } catch (_: Exception) {
        }
    }

    // ---------- 日志与APP消息记录 ----------

    @Synchronized
    fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        logs.add(line)
        if (logs.size > 300) {
            logs.removeAt(0)
        }
        notifyListeners()
    }

    @Synchronized
    fun getLogsText(): String = logs.joinToString("\n")

    @Synchronized
    fun clearLogs() {
        logs.clear()
        notifyListeners()
    }

    fun addMissedRecord(message: String) {
        val p = prefs ?: return
        val timestamped = "[${dateTimeFmt.format(Date())}] $message"
        val existing = p.getString(KEY_MISSED_RECORDS, "") ?: ""
        val list = existing.split("\n").filter { it.isNotBlank() }.toMutableList()
        list.add(0, timestamped)
        while (list.size > 100) {
            list.removeAt(list.lastIndex)
        }
        p.edit().putString(KEY_MISSED_RECORDS, list.joinToString("\n")).apply()
        notifyListeners()
    }

    fun getMissedRecords(): String = prefs?.getString(KEY_MISSED_RECORDS, "") ?: ""

    fun clearMissedRecords() {
        prefs?.edit()?.remove(KEY_MISSED_RECORDS)?.apply()
        notifyListeners()
    }

    // ---------- 颜色圆球设置 ----------

    fun getEnabledColors(): List<MarkColor> {
        val raw = prefs?.getString(KEY_ENABLED_COLORS, null)
        if (raw.isNullOrBlank()) {
            return listOf(MarkColor.RED, MarkColor.BLUE)
        }
        val names = raw.split(",").toSet()
        val list = MarkColor.values().filter { it.name in names }
        return if (list.isEmpty()) listOf(MarkColor.RED) else list
    }

    fun setColorEnabled(color: MarkColor, enabled: Boolean): Boolean {
        val current = getEnabledColors().toMutableSet()
        if (enabled) {
            current.add(color)
        } else {
            if (current.size <= 1 && color in current) {
                return false
            }
            current.remove(color)
        }
        val ordered = MarkColor.values().filter { it in current }.joinToString(",") { it.name }
        prefs?.edit()?.putString(KEY_ENABLED_COLORS, ordered)?.apply()
        return true
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_POS_X, x)?.putInt(KEY_POS_Y, y)?.apply()
    }

    fun getOverlayX(): Int = prefs?.getInt(KEY_POS_X, -1) ?: -1

    fun getOverlayY(): Int = prefs?.getInt(KEY_POS_Y, -1) ?: -1

    fun resetOverlayPosition() {
        prefs?.edit()?.remove(KEY_POS_X)?.remove(KEY_POS_Y)?.apply()
    }

    fun getButtonDiameterDp(): Int = (prefs?.getInt(KEY_BTN_DP, 36) ?: 36).coerceIn(30, 80)

    fun setButtonDiameterDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_DP, dp.coerceIn(30, 80))?.apply()
    }

    fun getButtonGapDp(): Int = (prefs?.getInt(KEY_BTN_GAP_DP, 5) ?: 5).coerceIn(5, 60)

    fun setButtonGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_GAP_DP, dp.coerceIn(5, 60))?.apply()
    }

    fun getUnselectedBrightness(): Int = (prefs?.getInt(KEY_UNSELECTED_BRIGHTNESS, 45) ?: 45).coerceIn(10, 100)

    fun setUnselectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_UNSELECTED_BRIGHTNESS, pct.coerceIn(10, 100))?.apply()
    }

    fun getSelectedBrightness(): Int = (prefs?.getInt(KEY_SELECTED_BRIGHTNESS, 100) ?: 100).coerceIn(20, 100)

    fun setSelectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_SELECTED_BRIGHTNESS, pct.coerceIn(20, 100))?.apply()
    }

    fun isSelectedWhiteRingEnabled(): Boolean = prefs?.getBoolean(KEY_SELECTED_WHITE_RING, true) ?: true

    fun setSelectedWhiteRingEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_SELECTED_WHITE_RING, enabled)?.apply()
    }

    fun isBallExitDoubleTap(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_DOUBLE_TAP, false) ?: false

    fun setBallExitDoubleTap(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_DOUBLE_TAP, enabled)?.apply()
    }

    fun isBallExitSwipeRight(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_SWIPE_RIGHT, false) ?: false

    fun setBallExitSwipeRight(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_SWIPE_RIGHT, enabled)?.apply()
    }

    fun isBallExitSwipeAny(): Boolean = prefs?.getBoolean(KEY_BALL_EXIT_SWIPE_ANY, true) ?: true

    fun setBallExitSwipeAny(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_BALL_EXIT_SWIPE_ANY, enabled)?.apply()
    }

    // ---------- 完活弹窗与提示音设置 ----------

    fun getDoneText(): String {
        val raw = prefs?.getString(KEY_DONE_TEXT, "完活")?.trim()
        return if (raw.isNullOrEmpty()) "完活" else raw
    }

    fun setDoneText(text: String) {
        val v = text.trim().ifEmpty { "完活" }
        prefs?.edit()?.putString(KEY_DONE_TEXT, v)?.apply()
    }

    fun getDoneSizeSp(): Int = (prefs?.getInt(KEY_DONE_SIZE_SP, 56) ?: 56).coerceIn(20, 100)

    fun setDoneSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SIZE_SP, sp.coerceIn(20, 100))?.apply()
    }

    fun getDoneGrayPct(): Int = (prefs?.getInt(KEY_DONE_GRAY_PCT, 90) ?: 90).coerceIn(15, 100)

    fun setDoneGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_DONE_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    fun saveDonePosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_DONE_POS_X, x)?.putInt(KEY_DONE_POS_Y, y)?.apply()
    }

    fun getDoneX(): Int = prefs?.getInt(KEY_DONE_POS_X, -1) ?: -1

    fun getDoneY(): Int = prefs?.getInt(KEY_DONE_POS_Y, -1) ?: -1

    fun resetDonePosition() {
        prefs?.edit()?.remove(KEY_DONE_POS_X)?.remove(KEY_DONE_POS_Y)?.apply()
    }

    fun isDoneSoundEnabled(): Boolean = prefs?.getBoolean(KEY_DONE_SOUND_ENABLED, true) ?: true

    fun setDoneSoundEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_DONE_SOUND_ENABLED, enabled)?.apply()
    }

    fun getDoneSoundId(): String = prefs?.getString(KEY_DONE_SOUND_ID, SoundPreset.WECHAT.id) ?: SoundPreset.WECHAT.id

    fun setDoneSoundId(id: String) {
        prefs?.edit()?.putString(KEY_DONE_SOUND_ID, id)?.apply()
    }

    fun getDoneSoundVolume(): Int = (prefs?.getInt(KEY_DONE_SOUND_VOLUME, 75) ?: 75).coerceIn(0, 100)

    fun setDoneSoundVolume(vol: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SOUND_VOLUME, vol.coerceIn(0, 100))?.apply()
    }

    // ---------- 右侧竖排信息提示设置 ----------

    fun isInfoPanelEnabled(): Boolean = prefs?.getBoolean(KEY_INFO_ENABLED, true) ?: true

    fun setInfoPanelEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_INFO_ENABLED, enabled)?.apply()
    }

    fun isInfoShowCnName(): Boolean = prefs?.getBoolean(KEY_INFO_SHOW_CN_NAME, false) ?: false

    fun setInfoShowCnName(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_INFO_SHOW_CN_NAME, enabled)?.apply()
    }

    fun isInfoShowSource(): Boolean = prefs?.getBoolean(KEY_INFO_SHOW_SOURCE, false) ?: false

    fun setInfoShowSource(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_INFO_SHOW_SOURCE, enabled)?.apply()
    }

    fun isInfoCloseDoubleTap(): Boolean = prefs?.getBoolean(KEY_INFO_CLOSE_DOUBLE_TAP, true) ?: true

    fun setInfoCloseDoubleTap(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_INFO_CLOSE_DOUBLE_TAP, enabled)?.apply()
    }

    fun isInfoCloseSwipeRight(): Boolean = prefs?.getBoolean(KEY_INFO_CLOSE_SWIPE_RIGHT, false) ?: false

    fun setInfoCloseSwipeRight(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_INFO_CLOSE_SWIPE_RIGHT, enabled)?.apply()
    }

    fun isInfoCloseSwipeAny(): Boolean = prefs?.getBoolean(KEY_INFO_CLOSE_SWIPE_ANY, false) ?: false

    fun setInfoCloseSwipeAny(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_INFO_CLOSE_SWIPE_ANY, enabled)?.apply()
    }

    fun getInfoSizeSp(): Int = (prefs?.getInt(KEY_INFO_SIZE_SP, 26) ?: 26).coerceIn(20, 80)

    fun setInfoSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_INFO_SIZE_SP, sp.coerceIn(20, 80))?.apply()
    }

    fun getInfoGrayPct(): Int = (prefs?.getInt(KEY_INFO_GRAY_PCT, 85) ?: 85).coerceIn(15, 100)

    fun setInfoGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_INFO_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    fun getInfoGapDp(): Int = (prefs?.getInt(KEY_INFO_GAP_DP, 0) ?: 0).coerceIn(0, 180)

    fun setInfoGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_INFO_GAP_DP, dp.coerceIn(0, 180))?.apply()
    }

    fun saveInfoPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_INFO_POS_X, x)?.putInt(KEY_INFO_POS_Y, y)?.apply()
    }

    fun getInfoX(): Int = prefs?.getInt(KEY_INFO_POS_X, -1) ?: -1

    fun getInfoY(): Int = prefs?.getInt(KEY_INFO_POS_Y, -1) ?: -1

    fun resetInfoPosition() {
        prefs?.edit()?.remove(KEY_INFO_POS_X)?.remove(KEY_INFO_POS_Y)?.apply()
    }
}
