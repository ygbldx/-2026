package com.tvhelper.color

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

enum class MarkColor(
    val menuIndex: Int,
    val label: String,
    val baseR: Int,
    val baseG: Int,
    val baseB: Int
) {
    RED(0, "红", 247, 66, 74),
    BLUE(1, "蓝", 38, 108, 255),
    GREEN(2, "绿", 104, 198, 114),
    YELLOW(3, "黄", 245, 190, 48),
    PURPLE(4, "紫", 184, 104, 198),
    CYAN(5, "青", 10, 218, 242),
    PINK(6, "粉", 238, 138, 174)
}

enum class InfoCloseMode(val code: Int, val label: String) {
    DOUBLE_TAP(0, "双击清单关闭"),
    SWIPE_RIGHT(1, "右滑清单关闭"),
    SWIPE_RUDL(2, "右滑+上滑+下滑+左滑关闭");

    companion object {
        fun fromCode(code: Int): InfoCloseMode = values().firstOrNull { it.code == code } ?: DOUBLE_TAP
    }
}

enum class BallExitMode(val code: Int, val label: String) {
    DOUBLE_TAP(0, "双击圆球区域退出服务"),
    SWIPE_RIGHT(1, "从圆球区域右滑退出服务"),
    SWIPE_UDLR(2, "从圆球区域上滑+下滑+左滑+右滑退出服务");

    companion object {
        fun fromCode(code: Int): BallExitMode = values().firstOrNull { it.code == code } ?: SWIPE_UDLR
    }
}

object AppStore {
    private const val PREFS_NAME = "tv_color_helper_prefs"

    // 颜色圆球设置
    private const val KEY_POS_X = "overlay_pos_x"
    private const val KEY_POS_Y = "overlay_pos_y"
    private const val KEY_BTN_DP = "overlay_btn_dp"
    private const val KEY_BTN_GAP_DP = "overlay_btn_gap_dp"
    private const val KEY_UNSELECTED_BRIGHTNESS = "overlay_unselected_brightness"
    private const val KEY_SELECTED_BRIGHTNESS = "overlay_selected_brightness"
    private const val KEY_SELECTED_WHITE_RING = "overlay_selected_white_ring"
    private const val KEY_ENABLED_COLORS = "overlay_enabled_colors"
    private const val KEY_BALL_EXIT_MODE = "overlay_ball_exit_mode"

    // 完活弹窗与提示音设置
    private const val KEY_DONE_TEXT = "done_text"
    private const val KEY_DONE_SIZE_SP = "done_size_sp"
    private const val KEY_DONE_GRAY_PCT = "done_gray_pct"
    private const val KEY_DONE_POS_X = "done_pos_x"
    private const val KEY_DONE_POS_Y = "done_pos_y"
    private const val KEY_DONE_SOUND_ENABLED = "done_sound_enabled"
    private const val KEY_DONE_SOUND_ID = "done_sound_id"
    private const val KEY_DONE_SOUND_VOLUME = "done_sound_volume"

    // 右侧信息提示设置
    private const val KEY_INFO_ENABLED = "info_enabled"
    private const val KEY_INFO_CLOSE_MODE = "info_close_mode"
    private const val KEY_INFO_SIZE_SP = "info_size_sp"
    private const val KEY_INFO_GRAY_PCT = "info_gray_pct"
    private const val KEY_INFO_GAP_DP = "info_gap_dp"
    private const val KEY_INFO_POS_X = "info_pos_x"
    private const val KEY_INFO_POS_Y = "info_pos_y"

    // 记录
    private const val KEY_MISSED_RECORDS = "missed_records"

    private var prefs: SharedPreferences? = null
    private val queue = LinkedHashMap<String, MarkColor>()
    private val logs = ArrayList<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val dateTimeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (_: Exception) {
            }
        }
    }

    // ---------- 队列管理 ----------

    @Synchronized
    fun putSymbol(symbol: String, color: MarkColor) {
        val key = symbol.trim().uppercase(Locale.US)
        if (key.isEmpty()) return
        queue[key] = color
        log("队列记录：$key -> ${color.label}色（待办 ${queue.size} 个）")
        notifyListeners()
    }

    @Synchronized
    fun getSymbolColor(symbol: String?): MarkColor? {
        if (symbol.isNullOrBlank()) return null
        return queue[symbol.trim().uppercase(Locale.US)]
    }

    @Synchronized
    fun hasPendingItems(): Boolean = queue.isNotEmpty()

    @Synchronized
    fun snapshotQueue(): LinkedHashMap<String, MarkColor> = LinkedHashMap(queue)

    @Synchronized
    fun removeSymbol(symbol: String): Boolean {
        val removed = queue.remove(symbol.trim().uppercase(Locale.US)) != null
        if (removed) {
            notifyListeners()
        }
        return removed
    }

    @Synchronized
    fun clearQueue() {
        queue.clear()
        notifyListeners()
    }

    // ---------- 日志与漏项记录 ----------

    @Synchronized
    fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        logs.add(line)
        if (logs.size > 300) {
            logs.removeAt(0)
        }
        notifyListeners()
    }

    @Synchronized
    fun getLogsText(): String = logs.joinToString("\n")

    @Synchronized
    fun clearLogs() {
        logs.clear()
        notifyListeners()
    }

    fun addMissedRecord(message: String) {
        val p = prefs ?: return
        val timestamped = "[${dateTimeFmt.format(Date())}] $message"
        val existing = p.getString(KEY_MISSED_RECORDS, "") ?: ""
        val list = existing.split("\n").filter { it.isNotBlank() }.toMutableList()
        list.add(0, timestamped)
        while (list.size > 100) {
            list.removeAt(list.lastIndex)
        }
        p.edit().putString(KEY_MISSED_RECORDS, list.joinToString("\n")).apply()
        notifyListeners()
    }

    fun getMissedRecords(): String = prefs?.getString(KEY_MISSED_RECORDS, "") ?: ""

    fun clearMissedRecords() {
        prefs?.edit()?.remove(KEY_MISSED_RECORDS)?.apply()
        notifyListeners()
    }

    // ---------- 颜色圆球设置 ----------

    fun getEnabledColors(): List<MarkColor> {
        val raw = prefs?.getString(KEY_ENABLED_COLORS, null)
        if (raw.isNullOrBlank()) {
            return listOf(MarkColor.RED, MarkColor.BLUE)
        }
        val names = raw.split(",").toSet()
        val list = MarkColor.values().filter { it.name in names }
        return if (list.isEmpty()) listOf(MarkColor.RED) else list
    }

    fun setColorEnabled(color: MarkColor, enabled: Boolean): Boolean {
        val current = getEnabledColors().toMutableSet()
        if (enabled) {
            current.add(color)
        } else {
            if (current.size <= 1 && color in current) {
                return false
            }
            current.remove(color)
        }
        val ordered = MarkColor.values().filter { it in current }.joinToString(",") { it.name }
        prefs?.edit()?.putString(KEY_ENABLED_COLORS, ordered)?.apply()
        return true
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_POS_X, x)?.putInt(KEY_POS_Y, y)?.apply()
    }

    fun getOverlayX(): Int = prefs?.getInt(KEY_POS_X, -1) ?: -1

    fun getOverlayY(): Int = prefs?.getInt(KEY_POS_Y, -1) ?: -1

    fun resetOverlayPosition() {
        prefs?.edit()?.remove(KEY_POS_X)?.remove(KEY_POS_Y)?.apply()
    }

    // 直径范围：30dp ~ 80dp
    fun getButtonDiameterDp(): Int = (prefs?.getInt(KEY_BTN_DP, 36) ?: 36).coerceIn(30, 80)

    fun setButtonDiameterDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_DP, dp.coerceIn(30, 80))?.apply()
    }

    // 两圆点间距：最小 5dp，最大 60dp
    fun getButtonGapDp(): Int = (prefs?.getInt(KEY_BTN_GAP_DP, 5) ?: 5).coerceIn(5, 60)

    fun setButtonGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_BTN_GAP_DP, dp.coerceIn(5, 60))?.apply()
    }

    // 选中前明暗度：10% ~ 100%
    fun getUnselectedBrightness(): Int = (prefs?.getInt(KEY_UNSELECTED_BRIGHTNESS, 45) ?: 45).coerceIn(10, 100)

    fun setUnselectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_UNSELECTED_BRIGHTNESS, pct.coerceIn(10, 100))?.apply()
    }

    // 选中后明暗度：20% ~ 100%
    fun getSelectedBrightness(): Int = (prefs?.getInt(KEY_SELECTED_BRIGHTNESS, 100) ?: 100).coerceIn(20, 100)

    fun setSelectedBrightness(pct: Int) {
        prefs?.edit()?.putInt(KEY_SELECTED_BRIGHTNESS, pct.coerceIn(20, 100))?.apply()
    }

    // 选中后是否显示白色外圈
    fun isSelectedWhiteRingEnabled(): Boolean = prefs?.getBoolean(KEY_SELECTED_WHITE_RING, true) ?: true

    fun setSelectedWhiteRingEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_SELECTED_WHITE_RING, enabled)?.apply()
    }

    // 图表页圆球退出服务方式
    fun getBallExitMode(): BallExitMode {
        val code = prefs?.getInt(KEY_BALL_EXIT_MODE, BallExitMode.SWIPE_UDLR.code) ?: BallExitMode.SWIPE_UDLR.code
        return BallExitMode.fromCode(code)
    }

    fun setBallExitMode(mode: BallExitMode) {
        prefs?.edit()?.putInt(KEY_BALL_EXIT_MODE, mode.code)?.apply()
    }

    // ---------- 完活弹窗与提示音设置 ----------

    fun getDoneText(): String {
        val raw = prefs?.getString(KEY_DONE_TEXT, "完活")?.trim()
        return if (raw.isNullOrEmpty()) "完活" else raw
    }

    fun setDoneText(text: String) {
        val v = text.trim().ifEmpty { "完活" }
        prefs?.edit()?.putString(KEY_DONE_TEXT, v)?.apply()
    }

    fun getDoneSizeSp(): Int = (prefs?.getInt(KEY_DONE_SIZE_SP, 56) ?: 56).coerceIn(20, 100)

    fun setDoneSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SIZE_SP, sp.coerceIn(20, 100))?.apply()
    }

    fun getDoneGrayPct(): Int = (prefs?.getInt(KEY_DONE_GRAY_PCT, 90) ?: 90).coerceIn(15, 100)

    fun setDoneGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_DONE_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    fun saveDonePosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_DONE_POS_X, x)?.putInt(KEY_DONE_POS_Y, y)?.apply()
    }

    fun getDoneX(): Int = prefs?.getInt(KEY_DONE_POS_X, -1) ?: -1

    fun getDoneY(): Int = prefs?.getInt(KEY_DONE_POS_Y, -1) ?: -1

    fun resetDonePosition() {
        prefs?.edit()?.remove(KEY_DONE_POS_X)?.remove(KEY_DONE_POS_Y)?.apply()
    }

    fun isDoneSoundEnabled(): Boolean = prefs?.getBoolean(KEY_DONE_SOUND_ENABLED, true) ?: true

    fun setDoneSoundEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_DONE_SOUND_ENABLED, enabled)?.apply()
    }

    fun getDoneSoundId(): String = prefs?.getString(KEY_DONE_SOUND_ID, SoundPreset.WECHAT.id) ?: SoundPreset.WECHAT.id

    fun setDoneSoundId(id: String) {
        prefs?.edit()?.putString(KEY_DONE_SOUND_ID, id)?.apply()
    }

    fun getDoneSoundVolume(): Int = (prefs?.getInt(KEY_DONE_SOUND_VOLUME, 75) ?: 75).coerceIn(0, 100)

    fun setDoneSoundVolume(vol: Int) {
        prefs?.edit()?.putInt(KEY_DONE_SOUND_VOLUME, vol.coerceIn(0, 100))?.apply()
    }

    // ---------- 右侧竖排信息提示设置 ----------

    fun isInfoPanelEnabled(): Boolean = prefs?.getBoolean(KEY_INFO_ENABLED, true) ?: true

    fun setInfoPanelEnabled(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_INFO_ENABLED, enabled)?.apply()
    }

    fun getInfoCloseMode(): InfoCloseMode {
        val code = prefs?.getInt(KEY_INFO_CLOSE_MODE, InfoCloseMode.DOUBLE_TAP.code) ?: InfoCloseMode.DOUBLE_TAP.code
        return InfoCloseMode.fromCode(code)
    }

    fun setInfoCloseMode(mode: InfoCloseMode) {
        prefs?.edit()?.putInt(KEY_INFO_CLOSE_MODE, mode.code)?.apply()
    }

    // 字体大小：20sp ~ 80sp
    fun getInfoSizeSp(): Int = (prefs?.getInt(KEY_INFO_SIZE_SP, 26) ?: 26).coerceIn(20, 80)

    fun setInfoSizeSp(sp: Int) {
        prefs?.edit()?.putInt(KEY_INFO_SIZE_SP, sp.coerceIn(20, 80))?.apply()
    }

    fun getInfoGrayPct(): Int = (prefs?.getInt(KEY_INFO_GRAY_PCT, 85) ?: 85).coerceIn(15, 100)

    fun setInfoGrayPct(pct: Int) {
        prefs?.edit()?.putInt(KEY_INFO_GRAY_PCT, pct.coerceIn(15, 100))?.apply()
    }

    fun getInfoGapDp(): Int = (prefs?.getInt(KEY_INFO_GAP_DP, 0) ?: 0).coerceIn(0, 180)

    fun setInfoGapDp(dp: Int) {
        prefs?.edit()?.putInt(KEY_INFO_GAP_DP, dp.coerceIn(0, 180))?.apply()
    }

    fun saveInfoPosition(x: Int, y: Int) {
        prefs?.edit()?.putInt(KEY_INFO_POS_X, x)?.putInt(KEY_INFO_POS_Y, y)?.apply()
    }

    fun getInfoX(): Int = prefs?.getInt(KEY_INFO_POS_X, -1) ?: -1

    fun getInfoY(): Int = prefs?.getInt(KEY_INFO_POS_Y, -1) ?: -1

    fun resetInfoPosition() {
        prefs?.edit()?.remove(KEY_INFO_POS_X)?.remove(KEY_INFO_POS_Y)?.apply()
    }
}
