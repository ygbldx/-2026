package com.tvhelper.color

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * 自定义正方形可点区域的三角形按钮 View：
 * - 整个 sizePx × sizePx 正方形区域均可点动（绝不仅限三角形内部）
 * - 默认显示 ▲ 或 ▼，点击后瞬间变为正方形 ■ 持续 160ms 作为触控反馈，再变回三角形
 */
class WheelTriangleView(
    context: Context,
    val isUp: Boolean
) : View(context) {

    private var brightnessPct: Int = 82
    private var opacityPct: Int = 72
    private var showSquareFeedback: Boolean = false
    private val triPath = Path()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val mainHandler = Handler(Looper.getMainLooper())
    private val resetShapeRunnable = Runnable {
        showSquareFeedback = false
        invalidate()
    }

    init {
        // 1/255 透明底色确保整个正方形边界 100% 命中触摸，不漏点
        setBackgroundColor(Color.argb(1, 0, 0, 0))
        isClickable = true
    }

    fun applyAppearance(brightness: Int, opacity: Int) {
        brightnessPct = brightness.coerceIn(0, 100)
        opacityPct = opacity.coerceIn(15, 100)
        val gray = (brightnessPct * 255 / 100).coerceIn(0, 255)
        val alpha = (opacityPct * 255 / 100).coerceIn(38, 255)
        fillPaint.color = Color.argb(alpha, gray, gray, gray)
        invalidate()
    }

    fun triggerSquareFeedback() {
        mainHandler.removeCallbacks(resetShapeRunnable)
        showSquareFeedback = true
        invalidate()
        mainHandler.postDelayed(resetShapeRunnable, 160L)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        mainHandler.removeCallbacks(resetShapeRunnable)
        showSquareFeedback = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 4f || h <= 4f) return

        val pad = (w * 0.09f).coerceAtLeast(2f)
        if (showSquareFeedback) {
            fillPaint.pathEffect = null
            val r = (w * 0.08f).coerceAtLeast(2f)
            canvas.drawRoundRect(pad, pad, w - pad, h - pad, r, r, fillPaint)
        } else {
            fillPaint.pathEffect = CornerPathEffect((w * 0.07f).coerceAtLeast(2f))
            triPath.reset()
            if (isUp) {
                triPath.moveTo(w * 0.5f, pad)
                triPath.lineTo(pad, h - pad)
                triPath.lineTo(w - pad, h - pad)
            } else {
                triPath.moveTo(pad, pad)
                triPath.lineTo(w - pad, pad)
                triPath.lineTo(w * 0.5f, h - pad)
            }
            triPath.close()
            canvas.drawPath(triPath, fillPaint)
        }
    }
}

/**
 * 独立的第三功能悬浮层控制器（与标色悬浮球、探索快切完全隔离）：
 * 1) 左上角白框区域隐形触发热区（x: 0..24.5% W, y: 1.6%..8.2% H）：仅在图表页挂载，轻点显隐 ▲/▼，长按透传进原搜索
 * 2) 仅出现 ▲ / ▼ 按钮本体（零多余底框），以第二/三幅图交界线(62.7% H)为默认中线，支持长按自由拖拽位置
 */
class WheelSwitchOverlay(
    private val context: Context,
    private val onStepRequested: (goPrev: Boolean) -> Unit,
    private val onPassThroughTopLeftTap: (Float, Float) -> Unit
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    // 1. 左上角白框隐形触发热区
    private var triggerView: View? = null
    private var triggerParams: WindowManager.LayoutParams? = null
    @Volatile
    private var isTriggerAttached = false
    @Volatile
    private var passThroughUntilMs = 0L

    // 2. ▲ / ▼ 悬浮按钮组（仅按钮本身，透明容器无多余遮挡）
    private var padRoot: LinearLayout? = null
    private var padParams: WindowManager.LayoutParams? = null
    private var upBtn: WheelTriangleView? = null
    private var downBtn: WheelTriangleView? = null
    @Volatile
    private var isPadAttached = false
    @Volatile
    private var padToggledOn = false

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun screenSize(): Pair<Int, Int> {
        val b = wm.maximumWindowMetrics.bounds
        return b.width() to b.height()
    }

    fun isAnyVisible(): Boolean = isTriggerAttached || isPadAttached

    fun showTopLeftTrigger() {
        if (System.currentTimeMillis() < passThroughUntilMs) {
            hideTopLeftTrigger()
            return
        }
        mainHandler.post {
            if (System.currentTimeMillis() < passThroughUntilMs) return@post
            ensureTriggerCreated()
            val v = triggerView ?: return@post
            val p = triggerParams ?: return@post
            if (!isTriggerAttached && !v.isAttachedToWindow) {
                try {
                    wm.addView(v, p)
                    isTriggerAttached = true
                } catch (_: Exception) {
                }
            }
            // 若当前已处于展开态，同步确保 ▲/▼ 可见
            if (padToggledOn) {
                showPadInternal()
            }
        }
    }

    fun hideTopLeftTrigger() {
        mainHandler.post {
            val v = triggerView ?: return@post
            if (isTriggerAttached || v.isAttachedToWindow) {
                try {
                    wm.removeViewImmediate(v)
                } catch (_: Exception) {
                    try { wm.removeView(v) } catch (_: Exception) {}
                }
            }
            isTriggerAttached = false
        }
    }

    fun hideAll(resetToggle: Boolean = true) {
        if (resetToggle) padToggledOn = false
        mainHandler.post {
            val tv = triggerView
            if (tv != null && (isTriggerAttached || tv.isAttachedToWindow)) {
                try {
                    wm.removeViewImmediate(tv)
                } catch (_: Exception) {
                    try { wm.removeView(tv) } catch (_: Exception) {}
                }
            }
            isTriggerAttached = false
            hidePadInternal()
        }
    }

    fun refreshPadSettingsInPlace() {
        mainHandler.post {
            if (padRoot == null) return@post
            rebuildPadContents()
            if (isPadAttached && padRoot?.isAttachedToWindow == true) {
                updatePadLayoutFromSavedCenter()
            }
        }
    }

    private fun ensureTriggerCreated() {
        if (triggerView != null) return
        val (sw, sh) = screenSize()
        // 精准覆盖图二左上角手绘白框区域（x: 0..24.5% W, y: 1.6%..8.2% H），同时保留顶部 1.6% 边缘以便顺畅下拉状态栏
        val boxW = (sw * 0.245f).toInt().coerceAtLeast(dp(84))
        val boxTop = (sh * 0.016f).toInt()
        val boxH = ((sh * 0.082f).toInt() - boxTop).coerceAtLeast(dp(44))

        val v = View(context).apply {
            setBackgroundColor(Color.argb(1, 0, 0, 0))
            isClickable = true
        }

        var downX = 0f
        var downY = 0f
        var moved = false
        var longPressed = false
        val longPressRunnable = Runnable {
            longPressed = true
            // 长按左上角区域 520ms -> 放行 2.5 秒并透传点击（方便偶尔需要进原生商品搜索）
            passThroughUntilMs = System.currentTimeMillis() + 2500L
            hideTopLeftTrigger()
            val tx = (boxW * 0.50f)
            val ty = (sh * 0.054f)
            mainHandler.postDelayed({ onPassThroughTopLeftTap(tx, ty) }, 35L)
        }

        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    moved = false
                    longPressed = false
                    mainHandler.removeCallbacks(longPressRunnable)
                    mainHandler.postDelayed(longPressRunnable, 520L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(ev.rawX - downX) > touchSlop || abs(ev.rawY - downY) > touchSlop) {
                        moved = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (!moved && !longPressed && AppStore.isWheelPadEnabled()) {
                        togglePad()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    true
                }
                else -> false
            }
        }

        val params = WindowManager.LayoutParams(
            boxW,
            boxH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            fitInsetsTypes = 0
            x = 0
            y = boxTop
        }

        triggerView = v
        triggerParams = params
    }

    private fun togglePad() {
        padToggledOn = !padToggledOn
        if (padToggledOn) {
            showPadInternal()
        } else {
            hidePadInternal()
        }
    }

    private fun showPadInternal() {
        ensurePadCreated()
        rebuildPadContents()
        val root = padRoot ?: return
        val params = padParams ?: return
        computeParamsPosition(params)
        if (!isPadAttached && !root.isAttachedToWindow) {
            try {
                wm.addView(root, params)
                isPadAttached = true
            } catch (_: Exception) {
            }
        } else {
            try {
                wm.updateViewLayout(root, params)
                isPadAttached = true
            } catch (_: Exception) {
            }
        }
    }

    private fun hidePadInternal() {
        val root = padRoot ?: return
        if (isPadAttached || root.isAttachedToWindow) {
            try {
                wm.removeViewImmediate(root)
            } catch (_: Exception) {
                try { wm.removeView(root) } catch (_: Exception) {}
            }
        }
        isPadAttached = false
    }

    private fun ensurePadCreated() {
        if (padRoot != null) return
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.TRANSPARENT)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            fitInsetsTypes = 0
        }
        padRoot = root
        padParams = params
    }

    private fun measurePadSizePx(): Pair<Int, Int> {
        val mode = AppStore.getWheelPadDisplayMode()
        val sz = dp(AppStore.getWheelPadSizeDp())
        val gap = dp(AppStore.getWheelPadGapDp())
        val h = if (mode == WheelPadDisplayMode.BOTH) (sz * 2 + gap) else sz
        return sz to h
    }

    private fun computeParamsPosition(params: WindowManager.LayoutParams) {
        val (sw, sh) = screenSize()
        val (pw, ph) = measurePadSizePx()
        val cx = (sw * AppStore.getWheelPadCenterXFrac()).toInt()
        val cy = (sh * AppStore.getWheelPadCenterYFrac()).toInt()
        params.width = pw
        params.height = ph
        params.x = (cx - pw / 2).coerceIn(0, (sw - pw).coerceAtLeast(0))
        params.y = (cy - ph / 2).coerceIn(dp(24), (sh - ph - dp(24)).coerceAtLeast(dp(24)))
    }

    private fun updatePadLayoutFromSavedCenter() {
        val root = padRoot ?: return
        val params = padParams ?: return
        computeParamsPosition(params)
        try {
            wm.updateViewLayout(root, params)
        } catch (_: Exception) {
        }
    }

    private fun rebuildPadContents() {
        val root = padRoot ?: return
        root.removeAllViews()
        upBtn = null
        downBtn = null

        val mode = AppStore.getWheelPadDisplayMode()
        val sizePx = dp(AppStore.getWheelPadSizeDp())
        val gapPx = dp(AppStore.getWheelPadGapDp())
        val bright = AppStore.getWheelPadBrightnessPct()
        val opacity = AppStore.getWheelPadOpacityPct()

        if (mode == WheelPadDisplayMode.BOTH || mode == WheelPadDisplayMode.UP_ONLY) {
            val u = WheelTriangleView(context, isUp = true).apply {
                applyAppearance(bright, opacity)
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
            }
            attachTriangleTouch(u, goPrev = true)
            upBtn = u
            root.addView(u)
        }

        if (mode == WheelPadDisplayMode.BOTH || mode == WheelPadDisplayMode.DOWN_ONLY) {
            val d = WheelTriangleView(context, isUp = false).apply {
                applyAppearance(bright, opacity)
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                    if (mode == WheelPadDisplayMode.BOTH) topMargin = gapPx
                }
            }
            attachTriangleTouch(d, goPrev = false)
            downBtn = d
            root.addView(d)
        }
    }

    /**
     * 完整正方形热区点击 + 长按自由移动位置（松手记忆中心坐标）
     */
    private fun attachTriangleTouch(btn: WheelTriangleView, goPrev: Boolean) {
        var downRawX = 0f
        var downRawY = 0f
        var startWinX = 0
        var startWinY = 0
        var isDragging = false
        var movedTooFar = false

        val dragUnlockRunnable = Runnable {
            isDragging = true
            padRoot?.animate()?.scaleX(1.12f)?.scaleY(1.12f)?.setDuration(80L)?.start()
        }

        btn.setOnTouchListener { _, ev ->
            val root = padRoot ?: return@setOnTouchListener false
            val params = padParams ?: return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX
                    downRawY = ev.rawY
                    startWinX = params.x
                    startWinY = params.y
                    isDragging = false
                    movedTooFar = false
                    mainHandler.removeCallbacks(dragUnlockRunnable)
                    mainHandler.postDelayed(dragUnlockRunnable, 340L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (!isDragging) {
                        if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                            movedTooFar = true
                            mainHandler.removeCallbacks(dragUnlockRunnable)
                        }
                    } else {
                        val (sw, sh) = screenSize()
                        val (pw, ph) = measurePadSizePx()
                        params.x = (startWinX + dx.toInt()).coerceIn(0, (sw - pw).coerceAtLeast(0))
                        params.y = (startWinY + dy.toInt()).coerceIn(dp(18), (sh - ph - dp(18)).coerceAtLeast(dp(18)))
                        try {
                            wm.updateViewLayout(root, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    mainHandler.removeCallbacks(dragUnlockRunnable)
                    if (isDragging) {
                        isDragging = false
                        root.animate().scaleX(1.0f).scaleY(1.0f).setDuration(80L).start()
                        val (sw, sh) = screenSize()
                        val (pw, ph) = measurePadSizePx()
                        val cxFrac = (params.x + pw / 2f) / sw.toFloat()
                        val cyFrac = (params.y + ph / 2f) / sh.toFloat()
                        AppStore.saveWheelPadCenterFrac(cxFrac, cyFrac)
                    } else if (!movedTooFar) {
                        // 点击反馈：瞬间变为正方形 ■ 保持 160ms 再变回三角形
                        btn.triggerSquareFeedback()
                        onStepRequested(goPrev)
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(dragUnlockRunnable)
                    if (isDragging) {
                        isDragging = false
                        root.animate().scaleX(1.0f).scaleY(1.0f).setDuration(80L).start()
                    }
                    true
                }
                else -> false
            }
        }
    }

    fun destroy() {
        mainHandler.removeCallbacksAndMessages(null)
        hideAll(resetToggle = true)
    }
}

/**
 * 第三功能专用零惯性慢速滚轮划动执行器（完全独立于原 GestureDriver）：
 * 三段式手势：按住品种名称 35ms -> 慢速平滑拖动(默认 240ms) -> 末端刹停 120ms 再松手，
 * 确保松手速度严格为 0 px/s，单次精准切 1 个品种，绝不连划多个！
 */
class WheelSwipeController(
    private val service: AccessibilityService,
    private val inspector: NodeInspector,
    private val screenSizeProvider: () -> Pair<Int, Int>
) {
    fun performSingleStep(goPrev: Boolean): Boolean {
        val (sw, sh) = screenSizeProvider()
        val liveCenter = inspector.findTradingViewRoot()?.let { inspector.findChartWheelCenterPoint(it) }
        val startX = liveCenter?.first ?: (sw * 0.075f)
        val rawCenterY = liveCenter?.second ?: (sh * 0.940f)

        val distPx = sh * (AppStore.getWheelPadStepPermille() / 1000f)
        val dragMs = AppStore.getWheelPadDragMs()

        // ▲（前一个品种）：按住品种名往下慢慢划一下
        // ▼（后一个品种）：按住品种名往上慢慢划一下（对应图二左下角划动轨迹）
        val startY: Float
        val endY: Float
        if (goPrev) {
            startY = rawCenterY.coerceIn(sh * 0.928f, sh * 0.944f)
            endY = (startY + distPx).coerceAtMost(sh * 0.985f)
        } else {
            startY = rawCenterY.coerceIn(sh * 0.935f, sh * 0.948f)
            endY = (startY - distPx).coerceAtLeast(sh * 0.875f)
        }

        // 第 1 段：按住品种名称 35ms
        val holdStartPath = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, startY)
        }
        val s1 = GestureDescription.StrokeDescription(holdStartPath, 0L, 35L, true)
        if (!dispatchSync(GestureDescription.Builder().addStroke(s1).build())) return false

        // 第 2 段：慢速平滑划动（避免过快触发连划）
        val dragPath = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, endY)
        }
        val s2 = s1.continueStroke(dragPath, 0L, dragMs, true)
        if (!dispatchSync(GestureDescription.Builder().addStroke(s2).build())) return false

        // 第 3 段：末端静置刹停 120ms（大于 Android VelocityTracker 100ms 窗口，彻底清零惯性）
        val brakePath = Path().apply {
            moveTo(startX, endY)
            lineTo(startX, endY)
        }
        val s3 = s2.continueStroke(brakePath, 0L, 120L, false)
        return dispatchSync(GestureDescription.Builder().addStroke(s3).build())
    }

    private fun dispatchSync(gesture: GestureDescription): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val dispatched = service.dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    ok = false
                    latch.countDown()
                }
            },
            null
        )
        if (!dispatched) return false
        latch.await(1500, TimeUnit.MILLISECONDS)
        return ok
    }
}
